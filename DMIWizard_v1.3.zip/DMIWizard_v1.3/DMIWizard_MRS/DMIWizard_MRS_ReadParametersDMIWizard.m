function [sw, carfreq] = DMIWizard_MRS_ReadParametersDMIWizard(MRSParameterFileDMIWizard)

% Read parameters from DMIWizard parameter file
fileID = fopen(MRSParameterFileDMIWizard,'r+');
if (fileID > 0)
    Data = textscan(fileID, '%s', 'delimiter', '\n', 'whitespace', '');
    CStr = Data{1};
    
    % Scanning for particular parameters
    % Spectral width
    IndexParameter = strfind(CStr, 'sw');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    sw = str2num(LineParameter(11:end));   
      
    % Carrier frequency
    IndexParameter = strfind(CStr, 'carfreq ');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    carfreq = str2num(LineParameter(11:end));      
    
    fclose(fileID);
    
    % Display parameters
    disp(' ');
    disp('Reading DMIWizard MRS parameters ...');
    dd1 = ['Spectral width = ' num2str(sw,3) ' kHz'];
    dd2 = ['Carrier frequency = ' num2str(carfreq,5) ' MHz'];
    disp(dd1); disp(dd2);
    disp(' ');
end;