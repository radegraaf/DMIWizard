function DMIWizard_MRSI_WriteMetabolicMapScaled(MetabolicMap,handles)

fileID = fopen(handles.OutputFileName,'w+');
fprintf(fileID,'%20.7f\n',reshape(MetabolicMap,1,[]));
fclose(fileID);

% Save map in DICOM format
% A scaled metabolic map is likely in the 0 - 20 mM or 0 - 1 ratio range.
% All metabolic DICOM maps are multiplied by 1000 and saved as uint16 data
% (0 .. 65535 value range).
handles.OutputFileName2 = [handles.OutputFileName 'x1000.dcm'];
dicomwrite(uint16(1000*MetabolicMap),handles.OutputFileName2);

[OperationTime,~] = DMIWizard_MRSI_CalculateTime;
TextOutput1 = [OperationTime ' - Metabolic ' num2str(handles.MMStyle) ' map written to disk in:'];
TextOutput2 = [OperationTime ' - ' handles.OutputFileName];
disp(TextOutput1); disp(TextOutput2);
DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+',TextOutput2);