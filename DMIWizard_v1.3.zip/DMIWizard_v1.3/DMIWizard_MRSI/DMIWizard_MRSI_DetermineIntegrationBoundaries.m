function [Freq1,Freq2] = DMIWizard_MRSI_DetermineIntegrationBoundaries(FID3Dnrec,handles)

% Generate a global spectrum

% 1. Phase correction
for c1 = 1:handles.np1;
    for c2 = 1:handles.np2;
        for c3 = 1:handles.np3;

            % Phase correct receivers based on first FID point
            for c4 = 1:handles.nrec;
                PhaseFactor = abs(FID3Dnrec(1,c4,c1,c2,c3))./FID3Dnrec(1,c4,c1,c2,c3);
                FID3Dnrec(:,c4,c1,c2,c3) = FID3Dnrec(:,c4,c1,c2,c3).*PhaseFactor;
            end;
        end;
    end;
end;

% 2. Add most intense FID signals - base operations on second point
% as the first point is sometimes corrupted.
maxFID = max(max(max(max(max(real(FID3Dnrec(2:end,:,:,:,:)))))));
FIDglobal = 0;
for c1 = 1:handles.np1;
    for c2 = 1:handles.np2;
        for c3 = 1:handles.np3;
            for c4 = 1:handles.nrec;
                if (max(real(FID3Dnrec(2:end,c4,c1,c2,c3))) > 0.35*maxFID)
                    FIDglobal = FIDglobal + abs(FID3Dnrec(2,c4,c1,c2,c3))*FID3Dnrec(:,c4,c1,c2,c3);
                end;
            end;
        end;
    end;
end;

FIDglobal = FIDglobal*(abs(FIDglobal(1))/FIDglobal(1));
FIDglobal = DMIWizard_MRSI_Apodization(FIDglobal,handles);
specglobal = fftshift(fft(FIDglobal));

[PeakHeight,PeakIndex] = max(real(specglobal));

FreqCount1 = PeakIndex;
while ((real(specglobal(FreqCount1)) > 0.25*PeakHeight) && (FreqCount1 > 1))
    FreqCount1 = FreqCount1 - 1;
end;

FreqCount2 = PeakIndex;
while ((real(specglobal(FreqCount2)) > 0.25*PeakHeight) && (FreqCount2 < length(specglobal)))
    FreqCount2 = FreqCount2 + 1;
end;

PeakWidth = FreqCount2 - FreqCount1;

Freq1 = PeakIndex - PeakWidth;
Freq2 = PeakIndex + PeakWidth;