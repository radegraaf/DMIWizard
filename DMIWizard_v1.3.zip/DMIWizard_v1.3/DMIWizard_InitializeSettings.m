function DMIWizard_InitializeSettings(handles)

DMIWizard_Main_Text0_Object = findall(0,'Tag','DMIWizard_Main_Text0');
set(DMIWizard_Main_Text0_Object,'BackgroundColor',handles.GUIBackgroundColor1);
set(DMIWizard_Main_Text0_Object,'ForegroundColor',handles.GUIForegroundColor1);
set(DMIWizard_Main_Text0_Object,'FontName',handles.GUIFontName);
set(DMIWizard_Main_Text0_Object,'FontSize',(0.65/0.56)*handles.GUIFontSize);

DMIWizard_Main_Text1_Object = findall(0,'Tag','DMIWizard_Main_Text1');
set(DMIWizard_Main_Text1_Object,'BackgroundColor',handles.GUIBackgroundColor1);
set(DMIWizard_Main_Text1_Object,'ForegroundColor',handles.GUIForegroundColor1);
set(DMIWizard_Main_Text1_Object,'FontName',handles.GUIFontName);
set(DMIWizard_Main_Text1_Object,'FontSize',(0.35/0.56)*handles.GUIFontSize);

DMIWizard_Main_Text2_Object = findall(0,'Tag','DMIWizard_Main_Text2');
set(DMIWizard_Main_Text2_Object,'BackgroundColor',handles.GUIBackgroundColor1);
set(DMIWizard_Main_Text2_Object,'ForegroundColor',handles.GUIForegroundColor1);
set(DMIWizard_Main_Text2_Object,'FontName',handles.GUIFontName);
set(DMIWizard_Main_Text2_Object,'FontSize',(0.35/0.56)*handles.GUIFontSize);

DMIWizard_Main_Text3_Object = findall(0,'Tag','DMIWizard_Main_Text3');
set(DMIWizard_Main_Text3_Object,'BackgroundColor',handles.GUIBackgroundColor1);
set(DMIWizard_Main_Text3_Object,'ForegroundColor',handles.GUIForegroundColor1);
set(DMIWizard_Main_Text3_Object,'FontName',handles.GUIFontName);
set(DMIWizard_Main_Text3_Object,'FontSize',(0.35/0.56)*handles.GUIFontSize);

DMIWizard_Main_Text4_Object = findall(0,'Tag','DMIWizard_Main_Text4');
set(DMIWizard_Main_Text4_Object,'BackgroundColor',handles.GUIBackgroundColor1);
set(DMIWizard_Main_Text4_Object,'ForegroundColor',handles.GUIForegroundColor1);
set(DMIWizard_Main_Text4_Object,'FontName',handles.GUIFontName);
set(DMIWizard_Main_Text4_Object,'FontSize',(0.35/0.56)*handles.GUIFontSize);

MRS_pushbutton_Object = findall(0,'Tag','MRS_pushbutton');
set(MRS_pushbutton_Object,'BackgroundColor',handles.GUIBackgroundColor1);
set(MRS_pushbutton_Object,'ForegroundColor',handles.GUIForegroundColor1);
set(MRS_pushbutton_Object,'FontName',handles.GUIFontName);
set(MRS_pushbutton_Object,'FontSize',(0.30/0.56)*handles.GUIFontSize);

MRSI_pushbutton_Object = findall(0,'Tag','MRSI_Main_pushbutton');
set(MRSI_pushbutton_Object,'BackgroundColor',handles.GUIBackgroundColor1);
set(MRSI_pushbutton_Object,'ForegroundColor',handles.GUIForegroundColor1);
set(MRSI_pushbutton_Object,'FontName',handles.GUIFontName);
set(MRSI_pushbutton_Object,'FontSize',(0.30/0.56)*handles.GUIFontSize);

Exit_pushbutton_Object = findall(0,'Tag','Exit_pushbutton');
set(Exit_pushbutton_Object,'BackgroundColor',handles.GUIBackgroundColor1);
set(Exit_pushbutton_Object,'ForegroundColor',handles.GUIForegroundColor1);
set(Exit_pushbutton_Object,'FontName',handles.GUIFontName);
set(Exit_pushbutton_Object,'FontSize',(0.30/0.56)*handles.GUIFontSize);

CloseWindows_pushbutton_Object = findall(0,'Tag','CloseWindows_pushbutton');
set(CloseWindows_pushbutton_Object,'BackgroundColor',handles.GUIBackgroundColor1);
set(CloseWindows_pushbutton_Object,'ForegroundColor',handles.GUIForegroundColor1);
set(CloseWindows_pushbutton_Object,'FontName',handles.GUIFontName);
set(CloseWindows_pushbutton_Object,'FontSize',(0.30/0.56)*handles.GUIFontSize);
