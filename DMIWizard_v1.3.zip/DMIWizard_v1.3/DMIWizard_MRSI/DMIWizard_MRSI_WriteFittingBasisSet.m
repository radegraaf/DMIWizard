function DMIWizard_MRSI_WriteFittingBasisSet(handles)

%**************************************************************************
% DMIWizard_MRSI_WriteFittingResults.m
%
% Write spectral fitting results to disk (fitting parameters are saved
% in a separate file).
%**************************************************************************

% Extract directory for saving purposes
if ismac
    % Mac plaform
    coor = find(handles.MRSIPath == '/');
elseif isunix
    % Linux plaform
    coor = find(handles.MRSIPath == '/');
elseif ispc
    % Windows platform
    coor = find(handles.MRSIPath == '\');
end               
MRSIPathDir = handles.MRSIPath(1:max(coor));

file = [MRSIPathDir '\FittingResultsBasisSet.txt'];
fileID = fopen(file,'w+');
fprintf(fileID,'%9.5f   %9.5f\n',[reshape(real(handles.BasisFID),1,[]); reshape(imag(handles.BasisFID),1,[])]);
fclose(fileID);

[OperationTime,~] = DMIWizard_MRSI_CalculateTime;
TextOutput1 = [OperationTime ' - Spectral fitting basisset written to: ' file];
disp(TextOutput1); disp(' '); 