function [Baseline, ErrorFlag] = DMIWizard_MRSI_ReadFittingBaseline(handles)

%**************************************************************************
% DMIWizard_MRSI_ReadFittingBaseline.m
%
% Read baseline-related results from disk.
%**************************************************************************

if ismac
    % Mac plaform
    coor = find(handles.MRSIPath == '/');
elseif isunix
    % Linux plaform
    coor = find(handles.MRSIPath == '/');
elseif ispc
    % Windows platform
    coor = find(handles.MRSIPath == '\');
end               
MRSIPathDir = handles.MRSIPath(1:max(coor));
    
file = [MRSIPathDir 'FittingResultsBaseline.txt'];
fileID = fopen(file,'r+');
ErrorFlag = 0;
if (fileID > 0)
    datain = fscanf(fileID,'%g %g %g %g %g %g',[6 Inf]);
    fclose(fileID);
    
    BL0 = datain(4,:);
    BL0 = reshape(BL0,handles.np1,handles.np2,handles.np3);
    BL1 = datain(5,:);
    BL1 = reshape(BL1,handles.np1,handles.np2,handles.np3);
    BL2 = datain(6,:);
    BL2 = reshape(BL2,handles.np1,handles.np2,handles.np3);
    
    Baseline(1,:,:,:) = BL0;
    Baseline(2,:,:,:) = BL1;
    Baseline(3,:,:,:) = BL2;
    
    [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
    TextOutput0 = [OperationTime ' - Reading baseline-related spectral fitting results from ' file];
    disp(TextOutput0);
else
    ErrorFlag = 1;
    Baseline = [];
end;