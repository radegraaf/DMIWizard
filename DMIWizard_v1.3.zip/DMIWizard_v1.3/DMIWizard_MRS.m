function varargout = DMIWizard_MRS(varargin)
% DMIWIZARD_MRS MATLAB code for DMIWizard_MRS.fig
%      DMIWizard_MRS, by itself, creates a new DMIWizard_MRS or raises the existing
%      singleton*.
%
%      H = DMIWizard_MRS returns the handle to a new DMIWizard_MRS or the handle to
%      the existing singleton*.
%
%      DMIWizard_MRS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DMIWizard_MRS.M with the given input arguments.
%
%      DMIWizard_MRS('Property','Value',...) creates a new DMIWizard_MRS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before DMIWizard_MRS_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to DMIWizard_MRS_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help DMIWizard_MRS

% Last Modified by GUIDE v2.5 25-Sep-2019 16:15:40

addpath(genpath(pwd));

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @DMIWizard_MRS_OpeningFcn, ...
                   'gui_OutputFcn',  @DMIWizard_MRS_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before DMIWizard_MRS is made visible.
function DMIWizard_MRS_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to DMIWizard_MRS (see VARARGIN)

% Choose default command line output for DMIWizard_MRS
handles.output = hObject;

% Set Position/Size of Figure Based on Screen Size
set(groot,'Units','points');
ScreenSize = get(groot,'ScreenSize');
ScreenWidth = ScreenSize(3);
ScreenHeight = ScreenSize(4);

FigXPos = .2275*ScreenWidth; % .02
FigYPos = .15*ScreenHeight; % .2275
FigWidth = .37*ScreenWidth; % .18
FigHeight = .75*ScreenHeight; %.6725

% Read DMIWizard settings
handles = DMIWizard_MRS_ReadSettings(handles);

set(handles.figure1,'Units','points','Position',[FigXPos FigYPos FigWidth FigHeight],...
    'Color',handles.GUIBackgroundColor1)

% Initialize DMIWizard settings
DMIWizard_MRS_InitializeSettings(handles);

% Update handles structure
guidata(hObject, handles);

Initialize_GUI(hObject, eventdata, handles);

% --- Outputs from this function are returned to the command line.
function varargout = DMIWizard_MRS_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% Code related to GUI/handles parameter initialization
function Initialize_GUI(hObject, eventdata, handles)
handles.MetaboliteFile = handles.GUIDefaultPath;
handles.WaterFile = handles.GUIDefaultPath;
handles.FIDSaveFilePath = handles.GUIDefaultPath;
handles.ConsoleType = 'Bruker';
handles.ExtendedFFTOutput = 1;

% Set position and size for two supporting figures
set(groot,'Units','points');
ScreenSize = get(groot,'ScreenSize');
ScreenWidth = ScreenSize(3);
ScreenHeight = ScreenSize(4);

handles.Fig1XPos = .605*ScreenWidth;
handles.Fig1YPos = .545*ScreenHeight;
handles.Fig1Width = .3*ScreenWidth;
handles.Fig1Height = .2945*ScreenHeight;

handles.Fig2XPos = 0.605*ScreenWidth;
handles.Fig2YPos = 0.15*ScreenHeight;
handles.Fig2Width = 0.3*ScreenWidth;
handles.Fig2Height = 0.298*ScreenHeight;

handles.SaveInLoadDirectory = 0;

% Parameters related to data format
handles.nfidi = 1;
InitialNumOfFIDs_Object = findall(0,'Tag','InitialNumOfFIDs_edit');
set(InitialNumOfFIDs_Object,'TooltipString','Total number of FIDs in data file.');

handles.nexp = 1;
NumOfExperiments_Object = findall(0,'Tag','NumOfExperiments_edit');
set(NumOfExperiments_Object,'TooltipString','Number of unique experiments (e.g. different b-values).');

handles.nrec = 1;
NumberOfReceivers_Object = findall(0,'Tag','NumberOfReceivers_edit');
set(NumberOfReceivers_Object,'TooltipString','Number of receivers.');

handles.nrep = 1;
NumberOfRepititions_Object = findall(0,'Tag','NumberOfRepititions_edit');
set(NumberOfRepititions_Object,'TooltipString','Number of repetitions.');

handles.nfidf = 1;
FinalNumOfFIDs_Object = findall(0,'Tag','FinalNumOfFIDs_edit');
set(FinalNumOfFIDs_Object,'TooltipString','Number of FIDs following receiver and repetition combination.');

handles.FIDtrunc = 0;
FIDtrunction_Object = findall(0,'Tag','FIDtrunction_edit');
set(FIDtrunction_Object,'TooltipString','Maximum number of FID points (0 = no limit).');

handles.be = 0;
BigEndian_Object = findall(0,'Tag','BigEndian_checkbox');
set(BigEndian_Object,'TooltipString','Big-endian (Bruker) or long (Varian) data format.');

% Spectral parameters
handles.sw = 5;
SpectralBandwidth_Object = findall(0,'Tag','SpectralBandwidth_edit');
set(SpectralBandwidth_Object,'TooltipString','Spectral width (kHz)');

handles.ph0 = 0;
ZeroOrderPhase_Object = findall(0,'Tag','ZeroOrderPhase_edit');
set(ZeroOrderPhase_Object,'TooltipString','Zero order phase correction (deg)');

handles.ph1 = 0;
FirstOrderPhase_Object = findall(0,'Tag','FirstOrderPhase_edit');
set(FirstOrderPhase_Object,'TooltipString','First order phase correction (deg/kHz)');

handles.npzf = 16384;
SpectralPoints_Object = findall(0,'Tag','SpectralPoints_edit');
set(SpectralPoints_Object,'TooltipString','Spectral points following FFT');

FourierTransform_Object = findall(0,'Tag','FourierTransform_pushbutton');
set(FourierTransform_Object,'TooltipString','Perform 1D Fourier transformation.');

% Apodization-related parameters
handles.emf = 0;
ExponentialMultiply_Object = findall(0,'Tag','ExponentialMultiply_edit');
set(ExponentialMultiply_Object,'TooltipString','Exponential line broadening (Hz)');

handles.gmf = 0;
GaussianMultiply_Object = findall(0,'Tag','GaussianMultiply_edit');
set(GaussianMultiply_Object,'TooltipString','Gaussian line broadening (Hz)');

handles.gmfs = 0;
GaussianShift_Object = findall(0,'Tag','GaussianShift_edit');
set(GaussianShift_Object,'TooltipString','Gaussian time domain shift (ms)');

% Display parameters
handles.nspec = 1;
SpectrumNumber_Object = findall(0,'Tag','SpectrumNumber_edit');
set(SpectrumNumber_Object,'TooltipString','Spectrum/FID number selected from a multi-FID data.');

handles.ZxLow = -2;
handles.ZxLowPreviousValue = -2;
LowFrequencyBoundary_Object = findall(0,'Tag','LowFrequencyBoundary_edit');
set(LowFrequencyBoundary_Object,'TooltipString','Lower spectral zoom frequency (kHz or ppm).');

handles.ZxHigh = 0.5;
handles.ZxHighPreviousValue = 0.5;
HighFrequencyBoundary_Object = findall(0,'Tag','HighFrequencyBoundary_edit');
set(HighFrequencyBoundary_Object,'TooltipString','Higher spectral zoom frequency (kHz or ppm).');

handles.ZyLow = -200;
handles.ZyLowPreviousValue = -200;
LowIntensityBoundary_Object = findall(0,'Tag','LowIntensityBoundary_edit');
set(LowIntensityBoundary_Object,'TooltipString','Lower spectral zoom intensity.');

handles.ZyHigh = 2000;
handles.ZyHighPreviousValue = 2000;
HighIntensityBoundary_Object = findall(0,'Tag','HighIntensityBoundary_edit');
set(HighIntensityBoundary_Object,'TooltipString','Higher spectral zoom intensity.');

handles.ZyScale = 4;
handles.ZyScalePreviousValue = 4;
IntensityScalingFactor_Object = findall(0,'Tag','IntensityScalingFactor_edit');
set(IntensityScalingFactor_Object,'TooltipString','Ten-fold intensity scaling.');

ZoomIn_Object = findall(0,'Tag','ZoomIn_pushbutton');
set(ZoomIn_Object,'TooltipString','Zoom in frequeny axis with two clicks.');

ZoomOut_Object = findall(0,'Tag','ZoomOut_pushbutton');
set(ZoomOut_Object,'TooltipString','Maximum zoom out of frequeny axis.');

% Frequency-alignment-related parameters
FrequencyAlignment_Object2 = findall(0,'Tag','FrequencyAlignment_pushbutton');
set(FrequencyAlignment_Object2,'TooltipString','Indicate frequency alignment spectral region with two clicks.');

handles.FrequencyAlignmentFit = 0;
FrequencyAlignmentFit_Object = findall(0,'Tag','FrequencyAlignmentFit_checkbox');
set(FrequencyAlignmentFit_Object,'TooltipString','Polynomial fitting option for frequency alignment.');

handles.FrequencyAlignmentOrder = 3;
FrequencyAlignmentOrder_Object = findall(0,'Tag','FrequencyAlignmentOrder');
set(FrequencyAlignmentOrder_Object,'TooltipString','Polynomial fitting order for frequency alignment.');

handles.APinclude = 0;
IncludeApodization_Object = findall(0,'Tag','IncludeApodization_checkbox');
set(IncludeApodization_Object,'TooltipString','Include apodization when writing FIDs to file.');

handles.dgd = 71.75;
GroupDelay_Object = findall(0,'Tag','GroupDelay_edit');
set(GroupDelay_Object,'TooltipString','Digital group delay (Bruker only).');

handles.refppm = 0;
ReferencePPM_Object = findall(0,'Tag','ReferencePPM_edit');
set(ReferencePPM_Object,'TooltipString','Reference chemical shift (ppm).');

handles.reffreq = 0;
ReferenceFrequency_Object = findall(0,'Tag','ReferenceFrequency_edit');
set(ReferenceFrequency_Object,'TooltipString','Reference frequency (kHz).');

handles.carfreq = 400.5;
CarrierFrequency_Object = findall(0,'Tag','CarrierFrequency_edit');
set(CarrierFrequency_Object,'TooltipString','Larmor frequency (MHz).');

handles.fcal = 0;
Calibrate_Object = findall(0,'Tag','Calibrate_checkbox');
set(Calibrate_Object,'TooltipString','Switch between kHz and ppm axes.');

RefFreqpushbutton_Object = findall(0,'Tag','RefFreqpushbutton');
set(RefFreqpushbutton_Object,'TooltipString','Indicate reference signal with one click.');

handles.av = 0;
AbsoluteValue_Object = findall(0,'Tag','AbsoluteValue_checkbox');
set(AbsoluteValue_Object,'TooltipString','Display spectrum in absolute value.');

% Parameters related to baseline correction
handles.bcorder = 2;
BaselineCorrectionOrder_Object = findall(0,'Tag','BaselineCorrectionOrder');
set(BaselineCorrectionOrder_Object,'TooltipString','Polynomial fitting order used for baseline correction.');

BaselineCorrectionDefine_Object = findall(0,'Tag','BaselineCorrectionDefine_pushbutton');
set(BaselineCorrectionDefine_Object,'TooltipString',sprintf('Baseline definition.\nExit by pressing Enter.'));

BaselineCorrectionCalculate_Object = findall(0,'Tag','BaselineCorrectionCalculate_pushbutton');
set(BaselineCorrectionCalculate_Object,'TooltipString','Baseline calculation.');

BaselineCorrectionCorrect_Object = findall(0,'Tag','BaselineCorrectionCorrect_pushbutton');
set(BaselineCorrectionCorrect_Object,'TooltipString','Baseline correction.');

handles.fileBCsave = 0;
BaselineCorrectionWriteToBCBoundaries_Object = findall(0,'Tag','BaselineCorrectionWriteToBCBoundaries_checkbox');
set(BaselineCorrectionWriteToBCBoundaries_Object,'TooltipString','Write baseline definition to file (BCboundaries.txt).');

handles.fileBC = 0;
BCuseSpecfiedBoundaries_Object = findall(0,'Tag','BCuseSpecfiedBoundaries_checkbox');
set(BCuseSpecfiedBoundaries_Object,'TooltipString','Read baseline definition from file (BCboundaries.txt).');

% Parameters related to numerical integration
IntegrationDefine_Object = findall(0,'Tag','IntegrationDefine_pushbutton');
set(IntegrationDefine_Object,'TooltipString',sprintf('Integration boundary definition.\nExit by pressing Enter.'));

IntegrationIntegrate_Object = findall(0,'Tag','IntegrationIntegrate_pushbutton');
set(IntegrationIntegrate_Object,'TooltipString','Numerical integration.');

handles.fileINTsave = 0;
IntegrationWriteToINTBoundaries_Object = findall(0,'Tag','IntegrationWriteToINTBoundaries_checkbox');
set(IntegrationWriteToINTBoundaries_Object,'TooltipString','Write integration boundary definition to file (INTboundaries.txt).');

handles.fileINT = 0;
INTuseSpecfiedBoundaries_Object = findall(0,'Tag','INTuseSpecfiedBoundaries_checkbox');
set(INTuseSpecfiedBoundaries_Object,'TooltipString','Read integration boundary definition from file (INTboundaries.txt).');

% Parameters related to peak and noise estimation
ShiftPickPeak_Object = findall(0,'Tag','ShiftPickPeak_pushbutton');
set(ShiftPickPeak_Object,'TooltipString','Set intensity threshold for peak picking with one click.');

PickNoise_Object = findall(0,'Tag','PickNoise_pushbutton');
set(PickNoise_Object,'TooltipString','Indicate spectral noise region with with two clicks.');

% Batch processing will be implemented in DMIWizard v2.0
% Make checkbox invisible for DMIWizard v1.0
handles.BatchProcessing = 0;
set(findall(0,'Tag','BatchProcessing_checkbox'),'Visible','Off');
        
handles.ParUpdate = 1;
handles.MRSSaveFilePath = 'C:\';

% Update GUI data structure
guidata(hObject, handles);

%------------------------------------------------------------
% Functions related to data input/output
%------------------------------------------------------------
function MetaboliteFile_edit_Callback(hObject, eventdata, handles)
handles.MetaboliteFile = get(hObject,'String');

% Update GUI data structure
guidata(hObject,handles)

function MetaboliteFile_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function SelectMetaboliteFile_pushbutton_Callback(hObject, eventdata, handles)
% Prepare for when Cancel button is pressed
MetaboliteFileCancel = handles.MetaboliteFile;

% Get new file and path names
[filename, pathname] = uigetfile('*.*','Select FID file',handles.MetaboliteFile);

% Action performed when Cancel button is pressed
if isequal(filename,0) || isequal(pathname,0)
    handles.MetaboliteFile = MetaboliteFileCancel;
else
    handles.MetaboliteFile = [pathname filename];
end;

% Updata GUI data structure
guidata(hObject,handles)

% Set the edit box string to the new input filename
set(handles.MetaboliteFile_edit,'String',handles.MetaboliteFile);

function LoadMetaboliteFile_pushbutton_Callback(hObject, eventdata, handles)
% Clear Matlab command window
clc;

handles.ExtendedFFTOutput = 1;
handles = DMIWizard_MRS_LoadMetaboliteFile(handles);

% Update GUI - carrier frequency
CarFreq_Object = findall(0,'Tag','CarrierFrequency_edit');
set(CarFreq_Object,'String',handles.carfreq);

% Update GUI - digital group delay
GroupDelay_Object = findall(0,'Tag','GroupDelay_edit');
set(GroupDelay_Object,'String',handles.dgd);

% Update GUI - spectral bandwidth
SpectralBandwidth_Object = findall(0,'Tag','SpectralBandwidth_edit');
set(SpectralBandwidth_Object,'String',handles.sw);

% Update GUI - initial number of FIDs
InitialNumOfFIDs_Object = findall(0,'Tag','InitialNumOfFIDs_edit');
set(InitialNumOfFIDs_Object,'String',handles.nfidi);

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function ConvSelectConsoleType_popupmenu_Callback(hObject, eventdata, handles)
% Function executes when selecting a new excitation pulse 1
ConsoleTypes = cellstr(get(hObject,'String'));
handles.ConsoleType = ConsoleTypes{get(hObject,'Value')};

switch handles.ConsoleType
    case 'Bruker'
        set(findall(0,'Tag','GroupDelay_edit'),'Visible','On');
        set(findall(0,'Tag','GroupDelayName'),'Visible','On');
    otherwise
        set(findall(0,'Tag','GroupDelay_edit'),'Visible','Off');
        set(findall(0,'Tag','GroupDelayName'),'Visible','Off');
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Updata GUI data structure
guidata(hObject,handles)

function ConvSelectConsoleType_popupmenu_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function WaterFile_edit_Callback(hObject, eventdata, handles)
handles.WaterFile = get(hObject,'String');

% Update GUI data structure
guidata(hObject,handles)

function WaterFile_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function SelectWaterFile_pushbutton_Callback(hObject, eventdata, handles)
% Prepare for when Cancel button is pressed
WaterFileCancel = handles.WaterFile;

% Get new file and path names
[filename, pathname] = uigetfile('*.*','Select FID file',handles.WaterFile);

% Action performed when Cancel button is pressed
if isequal(filename,0) || isequal(pathname,0)
    handles.WaterFile = WaterFileCancel;
else
    handles.WaterFile = [pathname filename];
end;

% Update GUI data structure
guidata(hObject,handles)

% Set the edit box string to the new input filename
set(handles.WaterFile_edit,'String',handles.WaterFile);

function LoadWaterFile_pushbutton_Callback(hObject, eventdata, handles)
handles.FIDw = DMIWizard_MRS_LoadWaterFile(handles);

% Update GUI data structure
guidata(hObject,handles)

function FIDSaveFilePath_edit_Callback(hObject, eventdata, handles)
handles.FIDSaveFilePath = get(hObject,'String');

% Update GUI data structure
guidata(hObject,handles)

function FIDSaveFilePath_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function FIDSelectSaveFilePath_pushbutton_Callback(hObject, eventdata, handles)
% Prepare for when Cancel button is pressed
SaveFilePathCancel = handles.FIDSaveFilePath;

% Get new file and path names
[filename, pathname] = uiputfile('*.*','Select output file',handles.FIDSaveFilePath);

% Action performed when Cancel button is pressed
if isequal(filename,0) || isequal(pathname,0)
    handles.FIDSaveFilePath = SaveFilePathCancel;
else
    handles.FIDSaveFilePath = [pathname filename];
end;

% Updata GUI data structure
guidata(hObject,handles)

% Set the edit box string to the new input filename
set(handles.FIDSaveFilePath_edit,'String',handles.FIDSaveFilePath);

function FIDSaveToFilePath_pushbutton_Callback(hObject, eventdata, handles)
% When 'Save in Load Directory' is indicated
if (handles.SaveInLoadDirectory > 0)
    handles.FIDSaveFilePath = handles.MetaboliteFile;
end;

disp(' ');
if isfield(handles,'FIDsum') > 0
    [SavePathDir,~,~] = fileparts(handles.FIDSaveFilePath);
    if isdir(SavePathDir) > 0 && strcmp(handles.FIDSaveFilePath,'C:\') < 1
        for c1 = 1:1:(handles.nfidf/handles.nexp)
            for c2 = 1:1:handles.nexp

                if (c1 < 10)
                   filename = [handles.FIDSaveFilePath '0' num2str(c1) '.sum' num2str(c2)];
                   filenamepar = [handles.FIDSaveFilePath '0' num2str(c1) '.par'];
                else
                   filename = [handles.FIDSaveFilePath num2str(c1) '.sum' num2str(c2)];
                   filenamepar = [handles.FIDSaveFilePath num2str(c1) '.par'];
                end

                % Calculate FID signal from phased NMR spectrum
                if (handles.APinclude > 0)
                    if (handles.nexp == 1)
                        FIDsave = DMIWizard_MRSApodization(handles.FIDsum(:,c1), handles);
                    else
                        FIDsave = DMIWizard_MRSApodization(handles.FIDsum(:,c2,c1), handles);
                    end;
                else
                    if (handles.nexp == 1)
                        FIDsave = handles.FIDsum(:,c1);
                    else
                        FIDsave = handles.FIDsum(:,c2,c1);
                    end;
                end;

                specsave = fftshift(fft(FIDsave));
                specsave = DMIWizard_MRS_PhaseCorrection(specsave, handles);

                % Inverse Fourier transformation
                FIDsave = ifft(fftshift(specsave));
                FIDsave = FIDsave(1:handles.np);

                switch handles.ConsoleType
                    case 'Bruker'
                        % Remove digital group delay at end of FID
                        FIDsave(handles.np-round(handles.dgd):handles.np) = 0.0;
                end;

                fileID = fopen(filename,'w+');
                fprintf(fileID,'%9.5f		%9.5f\n',[reshape(real(FIDsave),1,[]); reshape(imag(FIDsave),1,[])]);
                fclose(fileID);

                [OperationTime,~] = DMIWizard_MRS_CalculateTime;
                TextOutput1 = [OperationTime ' - Saving of FID ' filename ' completed.'];
                disp(TextOutput1);
                DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
                if (handles.APinclude > 0)
                    TextOutput1 = [OperationTime ' - FID saved with time-domain apodization included.'];
                    disp(TextOutput1);
                    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
                end;

                % Save parameter file
                output1A = ['sw      = ' num2str(handles.sw) '\n'];
                output1B = ['carfreq = ' num2str(handles.carfreq) '\n']; 

                fileID2 = fopen(filenamepar,'w');
                fprintf(fileID2,output1A); fprintf(fileID2,output1B); 
                fclose(fileID2);
            end;
        end;
        DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+','');
    else
        [OperationTime,~] = DMIWizard_MRS_CalculateTime;
        ErrorOutput1 = [OperationTime ' - Error   : Invalid FID save path.'];
        ErrorOutput2 = [OperationTime ' - Error   : FID file not saved.'];
        ErrorOutput3 = [OperationTime ' - Solution: Select valid FID save path.'];
        disp(' '); disp(ErrorOutput1); disp(ErrorOutput2); disp(ErrorOutput3);
    end
else   
    [OperationTime,~] = DMIWizard_MRS_CalculateTime;
    ErrorOutput1 = [OperationTime ' - Error    : Summed FID does not exist and cannot be saved to file.'];
    ErrorOutput2 = [OperationTime ' - Solution : Perform separation and summation prior to saving.'];
    disp(ErrorOutput1); disp(ErrorOutput2); beep;
end

% Update GUI data structure
guidata(hObject,handles)

function SameDirectorySave_checkbox_Callback(hObject, eventdata, handles)
handles.SaveInLoadDirectory = get(hObject,'Value');

if handles.SaveInLoadDirectory == 1
    handles.FIDSaveFilePath = handles.MetaboliteFile;
    SaveFile_Object = findall(0,'Tag','FIDSaveFilePath_edit');
    set(SaveFile_Object,'String',handles.FIDSaveFilePath);
end

% Update GUI data structure
guidata(hObject,handles)

function InitialNumOfFIDs_edit_Callback(hObject, eventdata, handles)
handles.nfidi = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.nfidi) > 0) || (isinf(handles.nfidi) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for initial number of FIDs.'];
    ErrorMessage2 = ['Error: Initial number of FIDs set to valid default value (1).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.nfidi = 1;
    set(hObject,'String',handles.nfidi);
end;

% Force initial number of FIDs as an integer
handles.nfidi = round(handles.nfidi);

% Only allow positive initial number of FIDs
if (handles.nfidi < 0)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for initial number of FIDs.'];
    ErrorMessage2 = ['Error: Initial number of FIDs set to valid default value (1).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.nfidi = 1;
    set(hObject,'String',handles.nfidi);
else
    set(hObject,'String',handles.nfidi);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function InitialNumOfFIDs_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function NumOfExperiments_edit_Callback(hObject, eventdata, handles)
handles.nexp = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.nexp) > 0) || (isinf(handles.nexp) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for number of experiments.'];
    ErrorMessage2 = ['Error: Number of experiments set to valid default value (1).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.nexp = 1;
    set(hObject,'String',handles.nexp);
end;

% Force number of experiments as an integer
handles.nexp = round(handles.nexp);

% Only allow positive number of experiments
if (handles.nexp < 0)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for number of experiments.'];
    ErrorMessage2 = ['Error: Number of experiments set to valid default value (1).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.nexp = 1;
    set(hObject,'String',handles.nexp);
else
    set(hObject,'String',handles.nexp);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function NumOfExperiments_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function NumberOfReceivers_edit_Callback(hObject, eventdata, handles)
handles.nrec = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.nrec) > 0) || (isinf(handles.nrec) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for number of receivers.'];
    ErrorMessage2 = ['Error: Number of receivers set to valid default value (1).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.nrec = 1;
    set(hObject,'String',handles.nrec);
end;

% Force number of receivers as an integer
handles.nrec = round(handles.nrec);

% Only allow positive number of receivers
if (handles.nrec < 0)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for number of receivers.'];
    ErrorMessage2 = ['Error: Number of receivers set to valid default value (1).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.nrec = 1;
    set(hObject,'String',handles.nrec);
else
    set(hObject,'String',handles.nrec);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function NumberOfReceivers_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function NumberOfRepititions_edit_Callback(hObject, eventdata, handles)
handles.nrep = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.nrep) > 0) || (isinf(handles.nrep) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for number of repetitions.'];
    ErrorMessage2 = ['Error: Number of repetitions set to valid default value (1).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.nrep = 1;
    set(hObject,'String',handles.nrep);
end;

% Force number of repetitions as an integer
handles.nrep = round(handles.nrep);

% Only allow positive number of repetitions
if (handles.nrep < 0)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for number of repetitions.'];
    ErrorMessage2 = ['Error: Number of repetitions set to valid default value (1).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.nrep = 1;
    set(hObject,'String',handles.nrep);
else
    set(hObject,'String',handles.nrep);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function NumberOfRepititions_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function FinalNumOfFIDs_edit_Callback(hObject, eventdata, handles)
handles.nfidf = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.nfidf) > 0) || (isinf(handles.nfidf) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for final number of FIDs.'];
    ErrorMessage2 = ['Error: Final number of FIDs set to valid default value (1).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.nfidf = 1;
    set(hObject,'String',handles.nexp);
end;

% Force final number of FIDs as an integer
handles.nfidf = round(handles.nfidf);

% Only allow positive final number of FIDs
if (handles.nfidf < 0)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for final number of FIDs.'];
    ErrorMessage2 = ['Error: Final number of FIDs set to valid default value (1).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.nfidf = 1;
    set(hObject,'String',handles.nfidf);
else
    set(hObject,'String',handles.nfidf);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function FinalNumOfFIDs_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function PhaseCorrectReceivers_pushbutton_Callback(hObject, eventdata, handles)
if (isfield(handles,'FIDw') > 0)
    % Water reference signal is available
    
    if (isfield(handles,'FID') > 0)
        signal = reshape(handles.FID,handles.np,handles.nrec,handles.nexp,handles.nrep);
        signalw = reshape(handles.FIDw,handles.np,handles.nrec);
    
        % Determine maximum position of FID
        switch handles.ConsoleType
            case 'Bruker'
                FIDmaxpos = round(handles.dgd)+2;
            otherwise
                FIDmaxpos = 1;
        end;
    
        handles.ReceiverPhase = zeros(1,handles.nrec);
        for c1 = 1:handles.nrec;
            phfactor = abs(signalw(FIDmaxpos,c1))/signalw(FIDmaxpos,c1);
            signal(:,c1,:,:) = signal(:,c1,:,:).*phfactor;
            handles.ReceiverPhase(c1) = (180/pi)*atan2(imag(phfactor),real(phfactor));
        end;
    
        handles.FID = reshape(signal,handles.np,handles.nrec*handles.nexp*handles.nrep);
        handles.FIDw = reshape(signalw,handles.np,handles.nrec);

        handles.ph0 = 0;
        ph0_Object = findall(0,'Tag','ZeroOrderPhase_edit');
        set(ph0_Object,'String',handles.ph0);

        handles.ExtendedFFTOutput = 0;
        handles = DMIWizard_MRS_FFT(handles);
        
        [OperationTime,~] = DMIWizard_MRS_CalculateTime;         
        TextOutput1 = [OperationTime ' - Reference-based receiver phase correction completed with:'];
        disp(' '); disp(TextOutput1);
        DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
        for c1 = 1:handles.nrec;
            TextOutput1 = [OperationTime ' - Receiver ' num2str(c1) ' phase = ' num2str(handles.ReceiverPhase(c1),4) ' deg.'];
            disp(TextOutput1);
            DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
        end;
        DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',' ');
            
    else
        disp('Error   : No metabolite FID signal available.'); 
        disp('Solution: Load metabolite FID signal before attempting receiver phase correction.');
    end;
else
    % Water reference signal is not available
    
    if ((isfield(handles,'FID') > 0) && (handles.nrec > 1))
        % For low SNR data, phase correction based on the first FID
        % point does not work reliably. As an alternative, phasing will be 
        % based on maximizing the spectral integral over a selected region.
        
        figure(2);
        freq = ginput(2);
        freq1 = min([freq(1,1) freq(2,1)]);     % Lower frequency in kHz or ppm
        freq2 = max([freq(1,1) freq(2,1)]);     % Upper frequency in kHz or ppm
        
        freq = -0.5*handles.sw:handles.sw/(handles.npzf-1):0.5*handles.sw;
        
        % Convert frequencies to pixel coordinates
        if (handles.fcal > 0)
            % Axis in ppm
            ppm = (1000*(freq-handles.reffreq)/handles.carfreq) + handles.refppm;
            coor = find((ppm > freq1) & (ppm < freq2));
        else
            % Axis in kHz
            coor = find((freq > freq1) & (freq < freq2));
        end;
        
        % Temporarily sum signals over repetitions and experiments loops to increase SNR
        signal = reshape(handles.FID,handles.np,handles.nrec,handles.nexp,handles.nrep);
        signal2 = squeeze(sum(sum(signal,4),3));
        
        ph0 = handles.ph0;
        handles.ph0 = 0.0;
        handles.ReceiverPhase = zeros(1,handles.nrec);
        for c1 = 1:handles.nrec;
            maxint = -Inf;
            for phs = 0:5:355;
                FIDphs = signal2(:,c1).*exp(1i*(pi/180)*phs);
                FIDapodized = DMIWizard_MRS_Apodization(FIDphs, handles);
                spec = fftshift(fft(FIDapodized,handles.npzf));
                % Phase correction (primarily necessary for Bruker digital
                % group delay)
                
                spec = DMIWizard_MRS_PhaseCorrection(spec, handles);
                if (sum(real(spec(coor))) > maxint)
                    maxint = sum(real(spec(coor)));
                    handles.ReceiverPhase(c1) = phs;
                end;
            end;
        end;
        handles.ph0 = ph0;
        
        % Apply optimial phase
        for c1 = 1:handles.nrec;
            for c2 = 1:handles.nexp;
                for c3 = 1:handles.nrep;
                    signal(:,c1,c2,c3) = signal(:,c1,c2,c3)*exp(1i*(pi/180)*handles.ReceiverPhase(c1));
                end;
            end;
        end;

        handles.FID = reshape(signal,handles.np,handles.nrec*handles.nexp*handles.nrep);
        
        handles.ph0 = 0;
        ph0_Object = findall(0,'Tag','ZeroOrderPhase_edit');
        set(ph0_Object,'String',handles.ph0);

        handles.ExtendedFFTOutput = 0;
        handles = DMIWizard_MRS_FFT(handles);
        
        [OperationTime,~] = DMIWizard_MRS_CalculateTime;         
        TextOutput1 = [OperationTime ' - Iterative receiver phase correction completed with:'];
        disp(' '); disp(TextOutput1);
        DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
        for c1 = 1:handles.nrec;
            TextOutput1 = [OperationTime ' - Receiver ' num2str(c1) ' phase = ' num2str(handles.ReceiverPhase(c1),4) ' deg.'];
            disp(TextOutput1);
            DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
        end;
        DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',' ');
    else
        [OperationTime,~] = DMIWizard_MRS_CalculateTime;
        ErrorOutput1 = [OperationTime ' - Error   : No multi-receiver FID signal available.'];
        ErrorOutput2 = [OperationTime ' - Solution: Load multi-receiver FID signal before attempting receiver phase correction.'];
        disp(' '); disp(ErrorOutput1); disp(ErrorOutput2);
    end;
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function AddReceivers_pushbutton_Callback(hObject, eventdata, handles)
% Adds multiple receivers (after phase correction)
% with (linear) amplitude weighting.

if (isfield(handles,'FIDw') > 0)
    % Water reference signal is available
    
    if (isfield(handles,'FID') > 0)
        
        signal = reshape(handles.FID,handles.np,handles.nrec,handles.nexp,handles.nrep);
        signalw = reshape(handles.FIDw,handles.np,handles.nrec);
    
        % Determine maximum position of FID
        switch handles.ConsoleType
            case 'Bruker'
                FIDmaxpos = round(handles.dgd) + 2;
            otherwise
                FIDmaxpos = 1;
        end;
    
        % Signal weights for summation
        handles.ReceiverWeight(1:handles.nrec) = abs(signalw(FIDmaxpos,1:handles.nrec));
        handles.ReceiverWeight = handles.ReceiverWeight./sqrt(sum(handles.ReceiverWeight.*handles.ReceiverWeight));
    
        signalsum = 0;   
        for c1 = 1:handles.nrec;
            signalsum = signalsum + handles.ReceiverWeight(c1)*signal(:,c1,:,:);
        end;
        
        [OperationTime,~] = DMIWizard_MRS_CalculateTime;         
        TextOutput1 = [OperationTime ' - Reference-based, amplitude-weighted receiver summation completed with:'];
        disp(' '); disp(TextOutput1);
        DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
        for c1 = 1:handles.nrec;
            TextOutput1 = [OperationTime ' - Receiver ' num2str(c1) ' amplitude weight = ' num2str(handles.ReceiverWeight(c1),4)];
            disp(TextOutput1);
            DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
        end;
        DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',' ');
    
        handles.nrec = 1;
        nrec_Object = findall(0,'Tag','NumberOfReceivers_edit');
        set(nrec_Object,'String',handles.nrec);

        handles.nspec = 1;
        nspec_Object = findall(0,'Tag','SpectrumNumber_edit');
        set(nspec_Object,'String',handles.nspec);

        handles.nfidi = handles.nexp*handles.nrep;
        nfidi_Object = findall(0,'Tag','InitialNumOfFIDs_edit');
        set(nfidi_Object,'String',handles.nfidi);

        handles.FID = reshape(signalsum,handles.np,handles.nexp*handles.nrep);
                
        handles.ExtendedFFTOutput = 1;
        handles = DMIWizard_MRS_FFT(handles);
    else
        disp('Error   : No metabolite or water FID signal available.'); 
        disp('Solution: Load metabolite FID signal before attempting receiver summation.');
    end;
else
    % Water reference signal is not available
    
    if ((isfield(handles,'FID') > 0) && (handles.nrec > 1))
        % For low SNR data, phase correction based on the first FID
        % point does not work reliably. As an alternative, phasing will be 
        % based on maximizing the spectral integral over a selected region.
        
        figure(2);
        freq = ginput(2);
        freq1 = min([freq(1,1) freq(2,1)]);     % Lower frequency in kHz or ppm
        freq2 = max([freq(1,1) freq(2,1)]);     % Upper frequency in kHz or ppm
        
        freq = -0.5*handles.sw:handles.sw/(handles.npzf-1):0.5*handles.sw;
        
        % Convert frequencies to pixel coordinates
        if (handles.fcal > 0)
            % Axis in ppm
            ppm = (1000*(freq-handles.reffreq)/handles.carfreq) + handles.refppm;
            coor = find((ppm > freq1) & (ppm < freq2));
        else
            % Axis in kHz
            coor = find((freq > freq1) & (freq < freq2));
        end;
        
        % Temporarily sum signals over repetitions and experiments loops to increase SNR
        signal = reshape(handles.FID,handles.np,handles.nrec,handles.nexp,handles.nrep);
        signal2 = squeeze(sum(sum(signal,4),3));
        
        handles.ReceiverWeight = zeros(1,handles.nrec);
        for c1 = 1:handles.nrec;
            FID = signal2(:,c1);
            FIDapodized = DMIWizard_MRS_Apodization(FID, handles);
            spec = fftshift(fft(FIDapodized,handles.npzf));    
            % Signal weights for summation
            handles.ReceiverWeight(c1) = sum(abs(spec(coor)));
        end;
        handles.ReceiverWeight = handles.ReceiverWeight./sqrt(sum(handles.ReceiverWeight.*handles.ReceiverWeight));
    
        signalsum = 0;
        for c1 = 1:handles.nrec;
            signalsum = signalsum + handles.ReceiverWeight(c1)*signal(:,c1,:,:);
        end;
        
        [OperationTime,~] = DMIWizard_MRS_CalculateTime;         
        TextOutput1 = [OperationTime ' - Iterative, amplitude-weighted receiver summation completed with:'];
        disp(' '); disp(TextOutput1);
        DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
        for c1 = 1:handles.nrec;
            TextOutput1 = [OperationTime ' - Receiver ' num2str(c1) ' amplitude weight = ' num2str(handles.ReceiverWeight(c1),4)];
            disp(TextOutput1);
            DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
        end;
        DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',' ');
        
        handles.nrec = 1;
        nrec_Object = findall(0,'Tag','NumberOfReceivers_edit');
        set(nrec_Object,'String',handles.nrec);

        handles.nspec = 1;
        nspec_Object = findall(0,'Tag','SpectrumNumber_edit');
        set(nspec_Object,'String',handles.nspec);

        handles.nfidi = handles.nexp*handles.nrep;
        nfidi_Object = findall(0,'Tag','InitialNumOfFIDs_edit');
        set(nfidi_Object,'String',handles.nfidi);

        handles.FID = reshape(signalsum,handles.np,handles.nexp*handles.nrep);
               
        handles.ExtendedFFTOutput = 1;
        handles = DMIWizard_MRS_FFT(handles);
    else
        [OperationTime,~] = DMIWizard_MRS_CalculateTime;
        ErrorOutput1 = [OperationTime ' - Error   : No multi-receiver FID signal available.'];
        ErrorOutput2 = [OperationTime ' - Solution: Load multi-receiver FID signal before attempting receiver phase correction.'];
        disp(' '); disp(ErrorOutput1); disp(ErrorOutput2);
    end;
end

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function SeparateAndSummate_pushbutton_Callback(hObject, eventdata, handles)
%******************************************
% Performs a separation and summation of
% the initial FIDs to produce the final 
% FIDs.
%******************************************
if isfield(handles,'FID') == 1
    handles.np = size(handles.FID,1);
    if (handles.nexp*handles.nrep ~= handles.nfidi)
        OperationTime = DMIWizard_MRS_CalculateTime;   
        ErrorMessage1 = [OperationTime ' - Error   : Number of initial FIDs does not equal the product of experiments x receivers x repetitions.'];
        ErrorMessage2 = [OperationTime ' - Solution: Adjust number of experiments and/or receivers and/or repetitions.'];
        disp(' '); disp(ErrorMessage1); disp(ErrorMessage2);
    else
        handles.FID = reshape(handles.FID,handles.np,handles.nexp,handles.nrep);

        if (mod(handles.nfidf,handles.nexp) > 0)
            OperationTime = DMIWizard_MRS_CalculateTime;   
            ErrorMessage1 = [OperationTime ' - Error   : Number of final FIDs is not an multiple of number of experiments.'];
            ErrorMessage2 = [OperationTime ' - Solution: Adjust number of final FIDs.'];
            disp(' '); disp(ErrorMessage1); disp(ErrorMessage2);
        else
            if (handles.nfidf > handles.nrep*handles.nexp)
                OperationTime = DMIWizard_MRS_CalculateTime;   
                ErrorMessage1 = [OperationTime ' - Error   : Number of final FIDs is larger than the available number of FIDs.'];
                ErrorMessage2 = [OperationTime ' - Solution: Adjust number of final FIDs.'];
                disp(' '); disp(ErrorMessage1); disp(ErrorMessage2);
            else
                handles.FIDseparated = reshape(handles.FID,handles.np,handles.nexp,round(handles.nrep*handles.nexp/handles.nfidf),(handles.nfidf/handles.nexp));
                handles.FIDsum = squeeze(sum(handles.FIDseparated,3));
                handles.FID = handles.FIDsum;

                [OperationTime,~] = DMIWizard_MRS_CalculateTime;         
                TextOutput1 = [OperationTime ' - Separation and summation completed.'];
                TextOutput2 = [OperationTime ' - Orginal ' num2str(handles.nfidi) ' FIDs separated into ' ...
                    num2str(handles.nfidf) ' FIDs (summed over ' num2str(handles.nrep) ' repetitions each).'];
                disp(' '); disp(TextOutput1); disp(TextOutput2);
                DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
                DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+',TextOutput2);

                handles.nspec = 1;
                nspec_Object = findall(0,'Tag','SpectrumNumber_edit');
                set(nspec_Object,'String',handles.nspec);

                handles.nfidi = handles.nexp;
                nfidi_Object = findall(0,'Tag','InitialNumOfFIDs_edit');
                set(nfidi_Object,'String',handles.nfidi);

                handles.nrep = 1;
                nrep_Object = findall(0,'Tag','NumberOfRepititions_edit');
                set(nrep_Object,'String',handles.nrep);

                % Generate spec and specA
                handles.ExtendedFFTOutput = 0;
                handles = DMIWizard_MRS_FFT(handles);
            end;
        end;
    end;
else
    [OperationTime,~] = DMIWizard_MRS_CalculateTime;
    ErrorOutput1 = [OperationTime ' - Error   : No FID signal available.'];
    ErrorOutput2 = [OperationTime ' - Solution: Load FID signal before attempting separation and summation.'];
    disp(' '); disp(ErrorOutput1); disp(ErrorOutput2);
end

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function SpectralBandwidth_edit_Callback(hObject, eventdata, handles)
handles.sw = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.sw) > 0) || (isinf(handles.sw) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for spectral bandwidth.'];
    ErrorMessage2 = ['Error: Spectral bandwidth set to valid default value (5.0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.sw = 5.0;
    set(hObject,'String',handles.sw);
end;

% Only allow positive spectral bandwidths
if (handles.sw < 0)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for spectral bandwidth.'];
    ErrorMessage2 = ['Error: Spectral bandwidth set to valid default value (5.0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.sw = 5.0;
    set(hObject,'String',handles.sw);
else
    set(hObject,'String',handles.sw);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function SpectralBandwidth_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function SpectralPoints_edit_Callback(hObject, eventdata, handles)
handles.npzf = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.npzf) > 0) || (isinf(handles.npzf) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for spectral points.'];
    ErrorMessage2 = ['Error: Spectral points set to valid default value (8192).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.npzf = 8192;
    set(hObject,'String',handles.npzf);
end;

% Force spectral points as an integer
handles.npzf = round(handles.npzf);

% Only allow positive spectral points
if (handles.npzf < 0)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for spectral points.'];
    ErrorMessage2 = ['Error: Spectral points set to valid default value (8192).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.npzf = 8192;
    set(hObject,'String',handles.npzf);
else
    set(hObject,'String',handles.npzf);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function SpectralPoints_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% Functions related to zero and first-order phase correction
function ZeroOrderPhase_edit_Callback(hObject, eventdata, handles)
handles.ph0 = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.ph0) > 0) || (isinf(handles.ph0) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for zero-order phase.'];
    ErrorMessage2 = ['Error: Zero-order phase set to valid default value (0.0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.ph0 = 0.0;
    set(hObject,'String',handles.ph0);
end;

if isfield(handles,'spec') == 1
    % Phase correction
    handles.specPhased = DMIWizard_MRS_PhaseCorrection(handles.spec, handles);
    
    % Display spectrum
    DMIWizard_MRS_DisplaySpectrum(handles.specPhased(:,handles.nspec), handles);
end

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function ZeroOrderPhase_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% Zero-order phase correction increase pushbutton
function IncreaseZeroOrderPhase_pushbutton_Callback(hObject, eventdata, handles)
handles.ph0 = handles.ph0 + 5;
if (handles.ph0 > 180)
    handles.ph0 = handles.ph0-360;
end

ph0_Object = findall(0,'Tag','ZeroOrderPhase_edit');
set(ph0_Object,'String',handles.ph0);

if isfield(handles,'spec') == 1
    % Phase correction
    handles.specPhased = DMIWizard_MRS_PhaseCorrection(handles.spec, handles);
    
    % Display spectrum
    DMIWizard_MRS_DisplaySpectrum(handles.specPhased(:,handles.nspec), handles);
end

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

% First-order phase correction increase pushbutton
function IncreaseFirstOrderPhase_pushbutton_Callback(hObject, eventdata, handles)
handles.ph1 = handles.ph1 + 5;

ph1_Object = findall(0,'Tag','FirstOrderPhase_edit');
set(ph1_Object,'String',handles.ph1);

if isfield(handles,'spec') == 1
    % Phase correction
    handles.specPhased = DMIWizard_MRS_PhaseCorrection(handles.spec, handles);
    
    % Display spectrum
    DMIWizard_MRS_DisplaySpectrum(handles.specPhased(:,handles.nspec), handles);
end

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

% Zero-order phase correction decrease pushbutton
function DecreaseZeroOrderPhase_pushbutton_Callback(hObject, eventdata, handles)
handles.ph0 = handles.ph0 - 5;
if (handles.ph0 < -180)
    handles.ph0 = handles.ph0 + 360;
end

ph0_Object = findall(0,'Tag','ZeroOrderPhase_edit');
set(ph0_Object,'String',handles.ph0);

if isfield(handles,'spec') == 1
    % Phase correction
    handles.specPhased = DMIWizard_MRS_PhaseCorrection(handles.spec, handles);
    
    % Display spectrum
    DMIWizard_MRS_DisplaySpectrum(handles.specPhased(:,handles.nspec), handles);
end

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function FirstOrderPhase_edit_Callback(hObject, eventdata, handles)
handles.ph1 = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.ph1) > 0) || (isinf(handles.ph1) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for first-order phase.'];
    ErrorMessage2 = ['Error: First-order phase set to valid default value (0.0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.ph1 = 0.0;
    set(hObject,'String',handles.ph1);
end;

if isfield(handles,'spec') == 1
    % Phase correction
    handles.specPhased = DMIWizard_MRS_PhaseCorrection(handles.spec, handles);
    
    % Display spectrum
    DMIWizard_MRS_DisplaySpectrum(handles.specPhased(:,handles.nspec), handles);
end

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function FirstOrderPhase_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% First-order phase correction decrease pushbutton
function DecreaseFirstOrderPhase_pushbutton_Callback(hObject, eventdata, handles)
handles.ph1 = handles.ph1 - 5;

ph1_Object = findall(0,'Tag','FirstOrderPhase_edit');
set(ph1_Object,'String',handles.ph1);

if isfield(handles,'spec') == 1
    % Phase correction
    handles.specPhased = DMIWizard_MRS_PhaseCorrection(handles.spec, handles);
    
    % Display spectrum
    DMIWizard_MRS_DisplaySpectrum(handles.specPhased(:,handles.nspec), handles);
end

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function SpectrumNumber_edit_Callback(hObject, eventdata, handles)
handles.nspec = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.nspec) > 0) || (isinf(handles.nspec) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for spectrum number.'];
    ErrorMessage2 = ['Error: Spectrum number set to valid default value (1).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.nspec = 1;
    set(hObject,'String',handles.nspec);
end;

% Force spectrum number as an integer
handles.nspec = round(handles.nspec);

% Only allow positive spectrum number
if (handles.nspec < 0)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for spectrum number.'];
    ErrorMessage2 = ['Error: Spectrum number set to valid default value (1).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.nspec = 1;
    set(hObject,'String',handles.nspec);
else
    set(hObject,'String',handles.nspec);
end;

if isfield(handles,'specPhased') == 1
    % Display spectrum
    DMIWizard_MRS_DisplaySpectrum(handles.specPhased(:,handles.nspec), handles);
end

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function SpectrumNumber_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function IncreaseSpectrumNumber_pushbutton_Callback(hObject, eventdata, handles)
handles.nspec = handles.nspec + 1;
if (handles.nspec > handles.nfidi)
    handles.nspec = handles.nspec-1;
end

nspec_Object = findall(0,'Tag','SpectrumNumber_edit');
set(nspec_Object,'String',handles.nspec);

if isfield(handles,'specPhased') == 1
    % Display spectrum
    DMIWizard_MRS_DisplaySpectrum(handles.specPhased(:,handles.nspec), handles);
end

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function DecreaseSpectrumNumber_pushbutton_Callback(hObject, eventdata, handles)
handles.nspec = handles.nspec - 1;
if (handles.nspec < 1)
    handles.nspec = handles.nspec+1;
end;

nspec_Object = findall(0,'Tag','SpectrumNumber_edit');
set(nspec_Object,'String',handles.nspec);

if isfield(handles,'specPhased') == 1
    % Display spectrum
    DMIWizard_MRS_DisplaySpectrum(handles.specPhased(:,handles.nspec), handles);
end

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function LowFrequencyBoundary_edit_Callback(hObject, eventdata, handles)
handles.ZxLow = str2double(get(hObject,'String'));

if (handles.fcal > 0)
    LowFreq = (1000*(-0.5*handles.sw-handles.reffreq)/handles.carfreq) + handles.refppm;
else
    LowFreq = -0.5*handles.sw;
end;

% Check for invalid entry
if ((isnan(handles.ZxLow) > 0) || (isinf(handles.ZxLow) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for lower frequency boundary.'];
    ErrorMessage2 = ['Error: Lower frequency boundary set to previous value (' num2str(handles.ZxLowPreviousValue) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.ZxLow = handles.ZxLowPreviousValue;
    set(hObject,'String',handles.ZxLow);
end;

% Force lower boundary below higher boundary
if (handles.ZxLow >= handles.ZxHigh)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for lower frequency boundary.'];
    ErrorMessage2 = ['Error: Lower frequency boundary set to previous value (' num2str(handles.ZxLowPreviousValue) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.ZxLow = handles.ZxLowPreviousValue;
    set(hObject,'String',handles.ZxLow);
else
    set(hObject,'String',handles.ZxLow);
end;

if isfield(handles,'specPhased') == 1
    % Display spectrum
    DMIWizard_MRS_DisplaySpectrum(handles.specPhased(:,handles.nspec), handles);
end

% Update previous value
handles.ZxLowPreviousValue = handles.ZxLow;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function LowFrequencyBoundary_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function HighFrequencyBoundary_edit_Callback(hObject, eventdata, handles)
handles.ZxHigh = str2double(get(hObject,'String'));

if (handles.fcal > 0)
    HighFreq = (1000*(0.5*handles.sw-handles.reffreq)/handles.carfreq) + handles.refppm;
else
    HighFreq = 0.5*handles.sw;
end;

% Check for invalid entry
if ((isnan(handles.ZxHigh) > 0) || (isinf(handles.ZxHigh) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for higher frequency boundary.'];
    ErrorMessage2 = ['Error: Higher frequency boundary set to previous value (' num2str(handles.ZxHighPreviousValue) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.ZxHigh = handles.ZxHighPreviousValue;
    set(hObject,'String',handles.ZxHigh);
end;

% Force higher boundary above lower boundary
if (handles.ZxHigh <= handles.ZxLow)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for higher frequency boundary.'];
    ErrorMessage2 = ['Error: Higher frequency boundary set to previous value (' num2str(handles.ZxHighPreviousValue) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.ZxHigh = handles.ZxHighPreviousValue;
    set(hObject,'String',handles.ZxHigh);
else
    set(hObject,'String',handles.ZxHigh);
end;

if isfield(handles,'specPhased') == 1
    % Display spectrum
    DMIWizard_MRS_DisplaySpectrum(handles.specPhased(:,handles.nspec), handles);
end

% Update previous value
handles.ZxHighPreviousValue = handles.ZxHigh;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function HighFrequencyBoundary_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function LowIntensityBoundary_edit_Callback(hObject, eventdata, handles)
handles.ZyLow = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.ZyLow) > 0) || (isinf(handles.ZyLow) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for lower intensity boundary.'];
    ErrorMessage2 = ['Error: Lower intensity boundary set to previous value (' num2str(handles.ZyLowPreviousValue) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.ZyLow = handles.ZyLowPreviousValue;
    set(hObject,'String',handles.ZyLow);
end;

% Force lower intensity boundary below higher intensity boundary
if (handles.ZyLow >= handles.ZyHigh)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for lower intensity boundary.'];
    ErrorMessage2 = ['Error: Lower intensity boundary set to previous value (' num2str(handles.ZyLowPreviousValue) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.ZyLow = handles.ZyLowPreviousValue;
    set(hObject,'String',handles.ZyLow);
else
    set(hObject,'String',handles.ZyLow);
end;

if isfield(handles,'specPhased') == 1
    % Display spectrum
    DMIWizard_MRS_DisplaySpectrum(handles.specPhased(:,handles.nspec), handles);
end

% Update previous value
handles.ZyLowPreviousValue = handles.ZyLow;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function LowIntensityBoundary_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function HighIntensityBoundary_edit_Callback(hObject, eventdata, handles)
handles.ZyHigh = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.ZyHigh) > 0) || (isinf(handles.ZyHigh) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for higher intensity boundary.'];
    ErrorMessage2 = ['Error: Higher intensity boundary set to previous value (' num2str(handles.ZyHighPreviousValue) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.ZyHigh = handles.ZyHighPreviousValue;
    set(hObject,'String',handles.ZyHigh);
end;

% Force higher intensity boundary above lower intensity boundary
if (handles.ZyHigh <= handles.ZyLow)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for higher intensity boundary.'];
    ErrorMessage2 = ['Error: Higher intensity boundary set to previous value (' num2str(handles.ZyHighPreviousValue) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.ZyHigh = handles.ZyHighPreviousValue;
    set(hObject,'String',handles.ZyHigh);
else
    set(hObject,'String',handles.ZyHigh);
end;

if isfield(handles,'specPhased') == 1
    % Display spectrum
    DMIWizard_MRS_DisplaySpectrum(handles.specPhased(:,handles.nspec), handles);
end

% Update previous value
handles.ZyHighPreviousValue = handles.ZyHigh;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function HighIntensityBoundary_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function IncreaseFrequencyLowBoundary_pushbutton_Callback(hObject, eventdata, handles)
handles.ZxLow = handles.ZxLow + 0.05;
if (handles.ZxLow >= handles.ZxHigh)
    handles.ZxLow = handles.ZxLow - 0.05;
end

ZxLow_Object = findall(0,'Tag','LowFrequencyBoundary_edit');
set(ZxLow_Object,'String',handles.ZxLow);

if isfield(handles,'specPhased') == 1
    % Display spectrum
    DMIWizard_MRS_DisplaySpectrum(handles.specPhased(:,handles.nspec), handles);
end

% Update previous values
handles.ZxLowPreviousValue = handles.ZxLow;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function IncreaseFrequencyHighBoundary_pushbutton_Callback(hObject, eventdata, handles)
handles.ZxHigh = handles.ZxHigh + 0.05;
if (handles.ZxHigh > 0.5*handles.sw)
    handles.ZxHigh = 0.5*handles.sw;
end;

ZxHigh_Object = findall(0,'Tag','HighFrequencyBoundary_edit');
set(ZxHigh_Object,'String',handles.ZxHigh);

if isfield(handles,'specPhased') == 1
    % Display spectrum
    DMIWizard_MRS_DisplaySpectrum(handles.specPhased(:,handles.nspec), handles);
end

% Update previous values
handles.ZxHighPreviousValue = handles.ZxHigh;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function DecreaseFrequencyLowBoundary_pushbutton_Callback(hObject, eventdata, handles)
handles.ZxLow = handles.ZxLow - 0.05;
if (handles.ZxLow < -0.5*handles.sw)
    handles.ZxLow = -0.5*handles.sw;
end;

ZxLow_Object = findall(0,'Tag','LowFrequencyBoundary_edit');
set(ZxLow_Object,'String',handles.ZxLow);

if isfield(handles,'specPhased') == 1
    % Display spectrum
    DMIWizard_MRS_DisplaySpectrum(handles.specPhased(:,handles.nspec), handles);
end

% Update previous values
handles.ZxLowPreviousValue = handles.ZxLow;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function DecreaseFrequencyHighBoundary_pushbutton_Callback(hObject, eventdata, handles)
handles.ZxHigh = handles.ZxHigh - 0.05;
if (handles.ZxHigh <= handles.ZxLow)
    handles.ZxHigh = handles.ZxHigh + 0.05;
end

ZxHigh_Object = findall(0,'Tag','HighFrequencyBoundary_edit');
set(ZxHigh_Object,'String',handles.ZxHigh);

if isfield(handles,'specPhased') == 1
    % Display spectrum
    DMIWizard_MRS_DisplaySpectrum(handles.specPhased(:,handles.nspec), handles);
end

% Update previous values
handles.ZxHighPreviousValue = handles.ZxHigh;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function IncreaseLowIntensityBoundary_pushbutton_Callback(hObject, eventdata, handles)
ZyLowOrig = handles.ZyLow;
handles.ZyLow = round(handles.ZyLow+0.1*abs(handles.ZyLow));
if (handles.ZyLow >= handles.ZyHigh)
    handles.ZyLow = ZyLowOrig;
end

ZyLow_Object = findall(0,'Tag','LowIntensityBoundary_edit');
set(ZyLow_Object,'String',handles.ZyLow);

if isfield(handles,'specPhased') == 1
    % Display spectrum
    DMIWizard_MRS_DisplaySpectrum(handles.specPhased(:,handles.nspec), handles);
end

% Update previous values
handles.ZyLowPreviousValue = handles.ZyLow;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function DecreaseLowIntensityBoundary_pushbutton_Callback(hObject, eventdata, handles)
handles.ZyLow = round(handles.ZyLow-0.1*abs(handles.ZyLow));

ZyLow_Object = findall(0,'Tag','LowIntensityBoundary_edit');
set(ZyLow_Object,'String',handles.ZyLow);

if isfield(handles,'specPhased') == 1
    % Display spectrum
    DMIWizard_MRS_DisplaySpectrum(handles.specPhased(:,handles.nspec), handles);
end

% Update previous values
handles.ZyLowPreviousValue = handles.ZyLow;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function IntensityScalingFactor_edit_Callback(hObject, eventdata, handles)
handles.ZyScale = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.ZyScale) > 0) || (isinf(handles.ZyScale) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for signal scaling factor.'];
    ErrorMessage2 = ['Error: Signal scaling factor set to previous value (' num2str(handles.ZyScalePreviousValue) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.ZyScale = handles.ZyScalePreviousValue;
    set(hObject,'String',handles.ZyScale);
end;

if isfield(handles,'specPhased') == 1
    % Display spectrum
    DMIWizard_MRS_DisplaySpectrum(handles.specPhased(:,handles.nspec), handles);
end

% Update previous value
handles.ZyScalePreviousValue = handles.ZyScale;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)


% --- Executes during object creation, after setting all properties.
function IntensityScalingFactor_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function IncreaseHighIntensityBoundary_pushbutton_Callback(hObject, eventdata, handles)
handles.ZyHigh = round(handles.ZyHigh+0.1*abs(handles.ZyHigh));

ZyHigh_Object = findall(0,'Tag','HighIntensityBoundary_edit');
set(ZyHigh_Object,'String',handles.ZyHigh);

if isfield(handles,'specPhased') == 1
    % Display spectrum
    DMIWizard_MRS_DisplaySpectrum(handles.specPhased(:,handles.nspec), handles);
end

% Update previous values
handles.ZyHighPreviousValue = handles.ZyHigh;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function DecreaseHighIntensityBoundary_pushbutton_Callback(hObject, eventdata, handles)
ZyHighOrig = handles.ZyHigh;
handles.ZyHigh = round(handles.ZyHigh-0.1*abs(handles.ZyHigh));
if (handles.ZyHigh <= handles.ZyLow)
    handles.ZyHigh = ZyHighOrig;
end

ZyHigh_Object = findall(0,'Tag','HighIntensityBoundary_edit');
set(ZyHigh_Object,'String',handles.ZyHigh);

if isfield(handles,'specPhased') == 1
    % Display spectrum
    DMIWizard_MRS_DisplaySpectrum(handles.specPhased(:,handles.nspec), handles);
end

% Update previous values
handles.ZyHighPreviousValue = handles.ZyHigh;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function IncreaseSignalScalingFactor_pushbutton_Callback(hObject, eventdata, handles)
handles.ZyScale = handles.ZyScale + 1;

ZyScale_Object = findall(0,'Tag','IntensityScalingFactor_edit');
set(ZyScale_Object,'String',handles.ZyScale);

if isfield(handles,'specPhased') == 1
    % Display spectrum
    DMIWizard_MRS_DisplaySpectrum(handles.specPhased(:,handles.nspec), handles);
end

% Update previous values
handles.ZyScalePreviousValue = handles.ZyScale;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function DecreaseSignalScalingFactor_pushbutton_Callback(hObject, eventdata, handles)
handles.ZyScale = handles.ZyScale - 1;

ZyScale_Object = findall(0,'Tag','IntensityScalingFactor_edit');
set(ZyScale_Object,'String',handles.ZyScale);

if isfield(handles,'specPhased') == 1
    % Display spectrum
    DMIWizard_MRS_DisplaySpectrum(handles.specPhased(:,handles.nspec), handles);
end

% Update previous values
handles.ZyScalePreviousValue = handles.ZyScale;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

% --- Executes on button press in FourierTransform_pushbutton.
function FourierTransform_pushbutton_Callback(hObject, eventdata, handles)

if isfield(handles,'FID') == 1
    handles = DMIWizard_MRS_FFT(handles);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function ReferenceFrequency_edit_Callback(hObject, eventdata, handles)
handles.reffreq = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.reffreq) > 0) || (isinf(handles.reffreq) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for reference frequency.'];
    ErrorMessage2 = ['Error: Reference frequency set to valid default value (0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.reffreq = 0;
    set(hObject,'String',handles.reffreq);
end;

if isfield(handles,'specPhased') == 1
    % Display spectrum
    DMIWizard_MRS_DisplaySpectrum(handles.specPhased(:,handles.nspec), handles);
end

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function ReferenceFrequency_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function FrequencyAlignment_pushbutton_Callback(hObject, eventdata, handles)

handles = DMIWizard_MRS_FrequencyAlignment(handles);

if isfield(handles,'specPhased') == 1
    % Display spectrum
    DMIWizard_MRS_DisplaySpectrum(handles.specPhased(:,handles.nspec), handles);
end

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function FrequencyAlignmentFit_checkbox_Callback(hObject, eventdata, handles)

handles.FrequencyAlignmentFit = get(hObject,'Value');

if isfield(handles,'specPhased') == 1
    % Display spectrum
    DMIWizard_MRS_DisplaySpectrum(handles.specPhased(:,handles.nspec), handles);
end

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function FrequencyAlignmentOrder_Callback(hObject, eventdata, handles)
handles.FrequencyAlignmentOrder = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.FrequencyAlignmentOrder) > 0) || (isinf(handles.FrequencyAlignmentOrder) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for frequency alignment order.'];
    ErrorMessage2 = ['Error: Frequency alignment order set to valid default value (3).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.FrequencyAlignmentOrder = 3;
    set(hObject,'String',handles.FrequencyAlignmentOrder);
end;

% Force alignment order as an integer
handles.FrequencyAlignmentOrder = round(handles.FrequencyAlignmentOrder);

% Only allow positive, non-zero alignment orders
if (handles.FrequencyAlignmentOrder < 1)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for frequency alignment order.'];
    ErrorMessage2 = ['Error: Frequency alignment order set to valid default value (3).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.FrequencyAlignmentOrder = 3;
    set(hObject,'String',handles.FrequencyAlignmentOrder);
else
    set(hObject,'String',handles.FrequencyAlignmentOrder);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function FrequencyAlignmentOrder_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function BatchProcessing_checkbox_Callback(hObject, eventdata, handles)
handles.BatchProcessing = get(hObject,'Value');

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function ParameterUpdate_checkbox_Callback(hObject, eventdata, handles)
handles.ParUpdate = get(hObject,'Value');

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function MRSSaveFilePath_edit_Callback(hObject, eventdata, handles)
handles.MRSSaveFilePath = get(hObject,'String');

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function MRSSaveFilePath_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function MRSSelectSaveFilePath_pushbutton_Callback(hObject, eventdata, handles)
% Prepare for when Cancel button is pressed
SaveFilePathCancel = handles.MRSSaveFilePath;

% Get new file and path names
[filename, pathname] = uigetfile('*.*','Select MRS file',handles.MRSSaveFilePath);

% Action performed when Cancel button is pressed
if isequal(filename,0) || isequal(pathname,0)
    handles.MRSSaveFilePath = SaveFilePathCancel;
else
    handles.MRSSaveFilePath = [pathname filename];
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

% Set the edit box string to the new input filename
set(handles.MRSSaveFilePath_edit,'String',handles.MRSSaveFilePath);

function MRSSaveToFilePath_pushbutton_Callback(hObject, eventdata, handles)
% Function to save frequency domain spectra to file
[SavePathDir,~,~] = fileparts(handles.MRSSaveFilePath);
if isdir(SavePathDir) > 0 && strcmp(handles.MRSSaveFilePath,'C:\') < 1
    freq = -0.5*handles.sw:handles.sw/(handles.npzf-1):0.5*handles.sw;

    if (handles.fcal > 0)
        ppm = (1000*(freq-handles.reffreq)/handles.carfreq) + handles.refppm;

        coor = find((ppm > handles.ZxLow) & (ppm < handles.ZxHigh));

        if (isempty(coor) > 0)
            disp('Error   : Invalid frequency boundaries.');
            disp('Error   : Frequency domain spectrum not saved.');
            MRSmatrix = [];
        else
            MRSmatrix = [reshape(ppm(coor),1,[]); reshape(real(handles.specPhased(coor,handles.nspec)),1,[]); ...
                reshape(imag(handles.specPhased(coor,handles.nspec)),1,[])];
        end;

    else    
        coor = find((freq > handles.ZxLow) & (freq < handles.ZxHigh));

        if (isempty(coor) > 0)
            disp('Error   : Invalid frequency boundaries.');
            disp('Error   : Frequency domain spectrum not saved.');
            MRSmatrix = [];
        else
            MRSmatrix = [reshape(freq(coor),1,[]); reshape(real(handles.specPhased(coor,handles.nspec)),1,[]); ...
                reshape(imag(handles.specPhased(coor,handles.nspec)),1,[])];
        end;
    end;

    fileID = fopen(handles.MRSSaveFilePath,'w');
    fprintf(fileID,'%9.5f		%9.5f		%9.5f\n',MRSmatrix);
    fclose(fileID);

    [OperationTime,~] = DMIWizard_MRS_CalculateTime;
    TextOutput1 = [OperationTime ' - Saving of spectrum ' handles.MRSSaveFilePath ' completed.'];
    disp(' '); disp(TextOutput1);
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
else    
    [OperationTime,~] = DMIWizard_MRS_CalculateTime;
    ErrorOutput1 = [OperationTime ' - Error   : Invalid MRS save path.'];
    ErrorOutput2 = [OperationTime ' - Error   : MRS file not saved.'];
    ErrorOutput3 = [OperationTime ' - Solution: Select valid MRS save path.'];
    disp(' '); disp(ErrorOutput1); disp(ErrorOutput2); disp(ErrorOutput3);
end
    
% Updata GUI data structure
guidata(hObject,handles)

function IncludeApodization_checkbox_Callback(hObject, eventdata, handles)
handles.APinclude = get(hObject,'Value');

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function ExponentialMultiply_edit_Callback(hObject, eventdata, handles)
handles.emf = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.emf) > 0) || (isinf(handles.emf) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for exponential multiply.'];
    ErrorMessage2 = ['Error: Exponential multiply set to valid default value (0.0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.emf = 0.0;
    set(hObject,'String',handles.emf);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function ExponentialMultiply_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function GaussianMultiply_edit_Callback(hObject, eventdata, handles)
handles.gmf = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.gmf) > 0) || (isinf(handles.gmf) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for Gaussian multiply.'];
    ErrorMessage2 = ['Error: Gaussian multiply set to valid default value (0.0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.gmf = 0.0;
    set(hObject,'String',handles.gmf);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function GaussianMultiply_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function GaussianShift_edit_Callback(hObject, eventdata, handles)
handles.gmfs = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.gmfs) > 0) || (isinf(handles.gmfs) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for Gaussian shift.'];
    ErrorMessage2 = ['Error: Gaussian shift set to valid default value (0.0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.gmfs = 0.0;
    set(hObject,'String',handles.gmfs);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function GaussianShift_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function GroupDelay_edit_Callback(hObject, eventdata, handles)
handles.dgd = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.dgd) > 0) || (isinf(handles.dgd) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for digital group delay.'];
    ErrorMessage2 = ['Error: Digital group delay set to valid default value (0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.dgd = 0;
    set(hObject,'String',handles.dgd);
end;

% Only allow positive digital group delay
if (handles.dgd < 0)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for digital group delay.'];
    ErrorMessage2 = ['Error: Digital group delay set to valid default value (0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.dgd = 0;
    set(hObject,'String',handles.dgd);
else
    set(hObject,'String',handles.dgd);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function GroupDelay_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function B0Correct_pushbutton_Callback(hObject, eventdata, handles)
if isfield(handles,'FIDw') > 0
    
    if (size(handles.FID,1) == size(handles.FIDw,1))
        
        phw = atan2(imag(handles.FIDw),real(handles.FIDw));
        %phw = unwrap(phw);
        %phw = phw/4;
        
        handles.FID = handles.FID.*exp(-1i*phw);
        
        clear phw;
        
        OperationTime = DMIWizard_MRS_CalculateTime;
        dd = [OperationTime ' - B0 correction of current handles.FID ... done.'];
        disp(dd);
        
    else
        disp('Error: Number of points in water and metabolite handles.FIDs are not equal.');
        disp('Solution: Use another water handles.FID or re-acquire water handles.FID.');
        beep;
    end;
else
    disp('Error: Water handles.FID does not exist.');
    disp('Solution: Load water handles.FID file.');
    beep;
end;

% Time domain multiplication
handles.FIDap = DMIWizard_MRSApodization(handles.FID, handles);

% Fourier transformation (with zerofilling)
spec = fftshift(fft(handles.FIDap,handles.npzf));

clear handles.FIDap;

% Phase correction
specA = DMIWizard_MRS_PhaseCorrection(spec, handles);

% Display spectrum
DMIWizard_MRSDisplaySpectrum(specA, handles);

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function ReferencePPM_edit_Callback(hObject, eventdata, handles)
handles.refppm = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.refppm) > 0) || (isinf(handles.refppm) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for reference ppm.'];
    ErrorMessage2 = ['Error: Reference ppm set to valid default value (0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.refppm = 0;
    set(hObject,'String',handles.refppm);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function ReferencePPM_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function CarrierFrequency_edit_Callback(hObject, eventdata, handles)
handles.carfreq = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.carfreq) > 0) || (isinf(handles.carfreq) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for carrier frequency.'];
    ErrorMessage2 = ['Error: Carrier frequency set to valid default value (0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.carfreq = 0;
    set(hObject,'String',handles.carfreq);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function CarrierFrequency_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function AbsoluteValue_checkbox_Callback(hObject, eventdata, handles)
handles.av = get(hObject,'Value');

if isfield(handles,'specPhased') == 1
    % Display spectrum
    DMIWizard_MRS_DisplaySpectrum(handles.specPhased(:,handles.nspec), handles);
end

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function Calibrate_checkbox_Callback(hObject, eventdata, handles)
handles.fcal = get(hObject,'Value');

if isfield(handles,'specPhased') == 1
    % Display spectrum
    handles = DMIWizard_MRS_DisplaySpectrum(handles.specPhased(:,handles.nspec), handles);
end

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function AutoPhase_pushbutton_Callback(hObject, eventdata, handles)
handles = DMIWizard_MRSAutoPhase(handles);

if isfield(handles,'specPhased') == 1
    % Display spectrum
    DMIWizard_MRS_DisplaySpectrum(handles.specPhased(:,handles.nspec), handles);
end

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function BaselineCorrectionWriteToBCBoundaries_checkbox_Callback(hObject, eventdata, handles)
handles.fileBCsave = get(hObject,'Value');

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function BCuseSpecfiedBoundaries_checkbox_Callback(hObject, eventdata, handles)
handles.fileBC = get(hObject,'Value');

if handles.fileBC == 1 
   dd = ['Baseline correction boundaries read from BCboundaries.txt'];
   disp(dd);
end

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function IntegrationWriteToINTBoundaries_checkbox_Callback(hObject, eventdata, handles)
handles.fileINTsave = get(hObject,'Value');

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function INTuseSpecfiedBoundaries_checkbox_Callback(hObject, eventdata, handles)
handles.fileINT = get(hObject,'Value');

if handles.fileINT == 1 
   dd = ['Integration boundaries read from INTboundaries.txt'];
   disp(dd);
end

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function BaselineCorrectionDefine_pushbutton_Callback(hObject, eventdata, handles)
%*************************************************
% Defines the baseline of a spectrum.
% Procedure : baseline-resonance-baseline
% Number of boundaries : even numbered
% End baseline definition with "Enter"
%
% Output data:
% handles.BCx = x-axis in integer coordinates
% handles.BCy = y-axis (real data)
%*************************************************
handles.freq = -0.5*handles.sw:(handles.sw/(handles.npzf-1)):0.5*handles.sw;
handles.freq = reshape(handles.freq,handles.npzf,1);

if (handles.fileBC > 0)
    %****************************% 
    % Predefined boundaries      %
    %****************************%
    fileID = fopen('BCboundaries.txt','r');

    if (fileID < 0)
        disp(' ');
        disp('Error: BCboundaries file does not exist or can not be opened.');
        disp('Solution: Check file location and/or permissions.');
        disp(' '); beep;
    else      
        BCBoundaries = fscanf(fileID,'%g',[1 inf]);
        fclose(fileID);
        
        BCAxisFormat = BCBoundaries(1);
        BCBoundaries = BCBoundaries(2:end);
        nBCBoundaries = numel(BCBoundaries);
        
        if (BCAxisFormat > 0)
            % Stored baseline boundaries in ppm
            
            [OperationTime,~] = DMIWizard_MRS_CalculateTime;
            TextOutput1 = [OperationTime ' - BC boundaries in ppm from left (positive) to right (negative) read from file:'];
            disp(' '); disp(TextOutput1);
            DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
    
            for c1 = 1:1:nBCBoundaries;
               TextOutput1 = [OperationTime ' - Baseline correction boundary ' num2str(c1) ' = ' num2str(BCBoundaries(c1),4) ' ppm.'];
               disp(TextOutput1);
               DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
            end;           
        else
            % Stored baseline boundaries in kHz
            
            [OperationTime,~] = DMIWizard_MRS_CalculateTime;
            TextOutput1 = [OperationTime ' - BC boundaries in kHz from left (positive) to right (negative) read from file:'];
            disp(' '); disp(TextOutput1);
            DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
            
            for c1 = 1:1:nBCBoundaries;
               TextOutput1 = [OperationTime ' - Baseline correction boundary ' num2str(c1) ' = ' num2str(BCBoundaries(c1),4) ' kHz.'];
               disp(TextOutput1);
               DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
            end; 
        end;
        BCBoundaries = reshape(BCBoundaries,[],1);
    end;
    
    if (handles.fcal ~= BCAxisFormat)
        disp(' ');
        if (handles.fcal > 0)
            disp('Error   : Current axis format (ppm) does not equal the stored baseline boundaries format (kHz).');
        else
            disp('Error   : Current axis format (kHz) does not equal the stored baseline boundaries format (ppm).');
        end;
        disp('Error   : Retrieved baseline boundaries are not appropriate for current data.');
        disp('Solution: Perform manual baseline boundary selection.');
        beep;
        BCBoundaries = [];
        nBCBoundaries = 0;
    end;
else
    %****************************% 
    % Manual input of boundaries %
    %****************************%
    figure(2);
 
    MousePosition = ginput;
    BCBoundaries = MousePosition(:,1);    % Boundaries (in kHz)
    nBCBoundaries = numel(BCBoundaries);  % Number of boundaries
    
    clear MousePosition;
               
    [OperationTime,~] = DMIWizard_MRS_CalculateTime;
    TextOutput1 = [OperationTime ' - Manually selected BC boundaries in kHz from left (positive) to right (negative):'];
    disp(' '); disp(TextOutput1);
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
        
    if (handles.fcal > 0)
        % Horizontal axis in ppm
        for c1 = 1:1:nBCBoundaries
            TextOutput1 = [OperationTime ' - Baseline correction boundary ' num2str(c1) ' = ' num2str(BCBoundaries(c1),4) ' ppm.'];
            disp(TextOutput1);
            DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
        end;        
    else
        % Horizontal axis in kHz
        for c1 = 1:1:nBCBoundaries
            TextOutput1 = [OperationTime ' - Baseline correction boundary ' num2str(c1) ' = ' num2str(BCBoundaries(c1),4) ' kHz.'];
            disp(TextOutput1);
            DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
        end;
    end;
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',' ');
end

% Check for odd number of boundaries
if (mod(nBCBoundaries,2) > 0)
    BCBoundaries = BCBoundaries(1:end-1);
    nBCBoundaries = nBCBoundaries - 1;
    
    disp(' ');
    disp('Warning: Odd number of baseline correction boundaries detected.');
    disp('Warning: Last boundary has been removed.');
    disp(' ');
    beep;
end;

%***************************************************
% Convert indicated frequencies to integer points
% BCBoundaries > BCBoundariesPixels
%***************************************************
if (nBCBoundaries > 0)
    if (handles.fcal > 0)
        % Indicated boundaries in ppm
        ppm1 = (1000*(-0.5*handles.sw-handles.reffreq)/handles.carfreq) + handles.refppm;
        ppm2 = (1000*(0.5*handles.sw-handles.reffreq)/handles.carfreq) + handles.refppm;

        slope = (handles.npzf - 1)/(ppm2 - ppm1);
        intercept = 1 - ppm1*slope;

        BCBoundariesPixels = round(BCBoundaries*slope + intercept);
    else
        % Indicated boundaries in kHz
        BCBoundariesPixels = round(0.5*handles.npzf + BCBoundaries*(handles.npzf/handles.sw));
    end;

    %***************************************************
    % Sort out baseline from signal based on their
    % alteration: baseline - signal - baseline ...
    %***************************************************
    handles.BCx = [];
    handles.BCy = [];
    if (BCBoundariesPixels(1) > BCBoundariesPixels(end))
       count = 0;
       for c1 = 1:2:nBCBoundaries-1
          for c2 = 1:(BCBoundariesPixels(c1)-BCBoundariesPixels(c1+1))
             handles.BCx(count+c2) = BCBoundariesPixels(c1+1)+c2;
             if (handles.av > 0)
                 % Absolute value baseline correction
                 handles.BCy(count+c2) = abs(handles.specPhased(handles.BCx(count+c2),handles.nspec));
             else
                 % Phase-sensitive baseline correction
                 handles.BCy(count+c2) = real(handles.specPhased(handles.BCx(count+c2),handles.nspec));
             end;
          end;
          count = count + BCBoundariesPixels(c1)-BCBoundariesPixels(c1+1);
       end;
    else
       count = 0;
       for c1 = 1:2:nBCBoundaries-1;
          for c2 = 1:(BCBoundariesPixels(c1+1)-BCBoundariesPixels(c1));
             handles.BCx(count+c2) = BCBoundariesPixels(c1)+c2;
             if (handles.av > 0)
                 % Absolute value baseline correction
                 handles.BCy(count+c2) = abs(handles.specPhased(handles.BCx(count+c2),handles.nspec));
             else
                 % Phase-sensitive baseline correction
                 handles.BCy(count+c2) = real(handles.specPhased(handles.BCx(count+c2),handles.nspec));
             end;
          end;
          count = count + BCBoundariesPixels(c1+1)-BCBoundariesPixels(c1);
       end;
    end;

    if (handles.fileBCsave > 0)
        fileID = fopen('BCboundaries.txt','w');
        if (handles.fcal > 0)
            fprintf(fileID,'%1.0f\n',1);
        else
            fprintf(fileID,'%1.0f\n',0);
        end;
        fprintf(fileID,'%9.5f\n',BCBoundaries);
        fclose(fileID);

        [OperationTime,~] = DMIWizard_MRS_CalculateTime;
        TextOutput1 = [OperationTime ' - Indicated baseline boundaries written to file .../BCboundaries.txt.'];
        disp(TextOutput1);
        DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
    end;
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function BaselineCorrectionCalculate_pushbutton_Callback(hObject, eventdata, handles)
%*******************************************************
% Calculates baseline using a polynomial approximation.
%
% BCx = x-axis in integer coordinates
% BCy = y-axis (real data)
%*******************************************************

if isfield(handles,'BCx') > 0 && isfield(handles,'BCy') > 0
    
    %***************************************************
    % Calculate baseline segments from spline function
    %***************************************************
    [pc1,pc2,pc3] = polyfit(handles.BCx,handles.BCy,handles.bcorder);
    BCx2 = min(handles.BCx):1:max(handles.BCx);
    handles.BCfit = polyval(pc1,BCx2,[],pc3);

    c1 = min(handles.BCx):1:max(handles.BCx);

    figure(2);
    clf;
    axes('XDir','reverse','XLim',[handles.ZxLow handles.ZxHigh],'YLim',[handles.ZyLow handles.ZyHigh]);
    hold on;

    if (handles.fcal > 0)
        % Axis in ppm
        ppm = (1000*(handles.freq-handles.reffreq)/handles.carfreq) + handles.refppm;
        if (handles.av > 0)
            plot(ppm,(abs(handles.spec(:,handles.nspec))/(10^handles.ZyScale)))
        else
            plot(ppm,(real(handles.specPhased(:,handles.nspec))/(10^handles.ZyScale)))
        end;
        plot(ppm(c1),(real(handles.BCfit)/(10^handles.ZyScale)),'r');
        xlabel('Chemical shift (ppm)')
        
    else
        % Axis in kHz
        if (handles.av > 0)
            plot(handles.freq,(abs(handles.spec(:,handles.nspec))/(10^handles.ZyScale)),'b');
        else
            plot(handles.freq,(real(handles.specPhased(:,handles.nspec))/(10^handles.ZyScale)),'b');
        end;
        plot(handles.freq(c1),(real(handles.BCfit)/(10^handles.ZyScale)),'r');
        xlabel('Frequency (kHz)');
    end;

    [OperationTime,~] = DMIWizard_MRS_CalculateTime;
    TextOutput1 = [OperationTime ' - Baseline calculation using ' num2str(handles.bcorder) '-order polynomial fitting completed.'];
    disp(' '); disp(TextOutput1);
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+',TextOutput1);
else
    disp('Error: Baseline boundaries do not exist.');
    disp('Solution: Use <Define> to indicate boundaries.');
    beep;
end

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function BaselineCorrectionCorrect_pushbutton_Callback(hObject, eventdata, handles)
%*************************************************
% Perform baseline correction.
%
% BCx = x-axis in integer coordinates
% BCy = y-axis (real data)
%*************************************************

pexist(1) = isfield(handles,'specPhased');
pexist(2) = isfield(handles,'BCx');
pexist(3) = isfield(handles,'BCfit');

if (sum(pexist) < 3)
    disp('Error: Not all parameters required for baseline correction exist.');
    disp('Solution: First perform baseline definition and calculation.');
else

    handles.np = size(handles.specPhased,1);
    BCsub = zeros(1,handles.np);

    for c1 = min(handles.BCx):max(handles.BCx)
       BCsub(c1) = handles.BCfit(c1 - min(handles.BCx) + 1);
    end

    BCsub = reshape(BCsub,handles.np,1);

    figure(2);
    clf;
    axes('XDir','reverse','XLim',[handles.ZxLow handles.ZxHigh],'YLim',[handles.ZyLow handles.ZyHigh]);
    hold on;
    
    if (handles.fcal > 0)
        % Axis in ppm
        ppm = (1000*(handles.freq-handles.reffreq)/handles.carfreq) + handles.refppm;
        if (handles.av > 0)
            handles.specBC = abs(handles.specPhased(:,handles.nspec)) - BCsub;
            plot(ppm,(abs(handles.specBC)/(10^handles.ZyScale)))
        else
            handles.specBC = handles.specPhased(:,handles.nspec) - BCsub;
            plot(ppm,(real(handles.specBC)/(10^handles.ZyScale)))
        end;
        xlabel('Chemical shift (ppm)')
    else
        % Axis in kHz
        if (handles.av > 0)
            handles.specBC = abs(handles.specPhased(:,handles.nspec)) - BCsub;
            plot(handles.freq,(abs(handles.specBC)/(10^handles.ZyScale)),'b');
        else
            handles.specBC = handles.specPhased(:,handles.nspec) - BCsub;
            plot(handles.freq,(real(handles.specBC)/(10^handles.ZyScale)),'b');
        end;
        xlabel('Frequency (kHz)')
    end;

    [OperationTime,~] = DMIWizard_MRS_CalculateTime;
    TextOutput1 = [OperationTime ' - Baseline correction completed.'];
    disp(' '); disp(TextOutput1);
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+',TextOutput1);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function IntegrationDefine_pushbutton_Callback(hObject, eventdata, handles)
%*************************************************
% Defines the integration regions of a spectrum.
% Procedure : baseline-resonance-baseline
% Number of boundaries : even numbered
% End baseline definition with "Enter"
%*************************************************

if (handles.fileINT > 0)
    %****************************% 
    % Predefined boundaries      %
    %****************************%
    fileID = fopen('INTboundaries.txt','r');

    if (fileID < 0)
        disp(' ');
        disp('Error: File does not exist or can not be opened.');
        disp('Solution: Check file location and/or permissions.');
        disp(' '); beep;
    else
        
       IntBoundaries = fscanf(fileID,'%g',[1 inf]);
       fclose(fileID);
       
       IntAxisFormat = IntBoundaries(1);
       handles.IntBoundaries = IntBoundaries(2:end);
       nIntBoundaries = numel(handles.IntBoundaries);
       
       if (IntAxisFormat > 0)
            % Stored integration boundaries in ppm
            disp(' ');
            disp('Integration boundaries in ppm from left (positive) to right (negative) read from file:');
            for c1 = 1:1:nIntBoundaries;
               dd1 = ['Integration boundary ' num2str(c1) ' = ' num2str(handles.IntBoundaries(c1),4) ' ppm.'];
               disp(dd1);
            end;
       else
            % Stored integration boundaries in kHz
            disp(' ');
            disp('Integration boundaries in kHz from left (positive) to right (negative) read from file:');
            for c1 = 1:1:nIntBoundaries;
               dd1 = ['Integration boundary ' num2str(c1) ' = ' num2str(handles.IntBoundaries(c1),4) ' kHz.'];
               disp(dd1);
            end;          
       end;
       handles.IntBoundaries = reshape(handles.IntBoundaries,[],1);
    end;
    
    if (handles.fcal ~= IntAxisFormat)
        disp(' ');
        if (handles.fcal > 0)
            disp('Error   : Current axis format (ppm) does not equal the stored integration boundaries format (kHz).');
        else
            disp('Error   : Current axis format (kHz) does not equal the stored integration boundaries format (ppm).');
        end;
        disp('Error   : Retrieved integration boundaries are not appropriate for current data.');
        disp('Solution: Perform manual integration boundary selection.');
        beep;
        handles.IntBoundaries = [];
        nIntBoundaries = numel(handles.IntBoundaries);
    end;
else
    %****************************% 
    % Manual input of boundaries %
    %****************************%
    figure(2);
    MousePosition = ginput;
    handles.IntBoundaries = MousePosition(:,1);     % Boundaries
    nIntBoundaries = numel(handles.IntBoundaries);  % Number of boundaries
        
    [OperationTime,~] = DMIWizard_MRS_CalculateTime;
    if (handles.fcal > 0)
        % Axis in ppm
        TextOutput1 = [OperationTime ' - Manually selected integration boundaries in ppm from left (positive) to right (negative):'];
        disp(' '); disp(TextOutput1);
        DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
    
        for c1 = 1:1:nIntBoundaries;
            TextOutput1 = [OperationTime ' - Integration boundary ' num2str(c1) ' = ' num2str(handles.IntBoundaries(c1),4) ' ppm.'];
            disp(TextOutput1);
            DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
        end;        
    else
        % Axis in kHz
        TextOutput1 = [OperationTime ' - Manually selected integration boundaries in kHz from left (positive) to right (negative):'];
        disp(' '); disp(TextOutput1);
        DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
        
        for c1 = 1:1:nIntBoundaries;
            TextOutput1 = [OperationTime ' - Integration boundary ' num2str(c1) ' = ' num2str(handles.IntBoundaries(c1),4) ' kHz.'];
            disp(TextOutput1);
            DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
        end;
    end;
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+',TextOutput1);
end;

%***************************************************
% Convert indicated frequencies to integer points
% handles.IntBoundaries > handles.IntBoundariesPixels
%***************************************************

if isfield(handles,'BCx') < 1
    disp(' ');
    disp('Warning: A baseline correction is required prior to integration.');
    disp('Warning: Integratal definition has been terminated.');
    beep;
else
    if (nIntBoundaries > 0)
        if (handles.fcal > 0)
            % Axis in ppm
            ppm1 = (1000*(-0.5*handles.sw-handles.reffreq)/handles.carfreq) + handles.refppm;
            ppm2 = (1000*(0.5*handles.sw-handles.reffreq)/handles.carfreq) + handles.refppm;

            slope = (handles.npzf - 1)/(ppm2 - ppm1);
            intercept = 1 - ppm1*slope;

            handles.IntBoundariesPixels = round(handles.IntBoundaries*slope + intercept);
        else
            % Axis in kHz
            handles.IntBoundariesPixels = round(0.5*handles.npzf + handles.IntBoundaries*(handles.npzf/handles.sw));
        end;

        if (handles.av > 0)
            % Absolute value integration
            handles.IntData = abs(handles.specBC(min(handles.IntBoundariesPixels):max(handles.IntBoundariesPixels)));
        else
            % Phase-sensitive integration
            handles.IntData = real(handles.specBC(min(handles.IntBoundariesPixels):max(handles.IntBoundariesPixels)));
        end;
    end;
end;

if (nIntBoundaries > 0)
    if (handles.fileINTsave > 0)
        fileID = fopen('INTboundaries.txt','w');
        if (handles.fcal > 0)
            fprintf(fileID,'%1.0f\n',1);
        else
            fprintf(fileID,'%1.0f\n',0);
        end;
        fprintf(fileID,'%9.5f\n',handles.IntBoundaries);
        fclose(fileID);

        [OperationTime,~] = DMIWizard_MRS_CalculateTime;
        TextOutput1 = [OperationTime ' - Indicated integration boundaries written to file .../INTboundaries.txt.'];
        disp(TextOutput1);
        DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+',TextOutput1);
    end;
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function IntegrationIntegrate_pushbutton_Callback(hObject, eventdata, handles)
%*************************************************
% Performs spectral integration between 
% pre-defined boundaries.
%*************************************************

pexist(1) = isfield(handles,'IntBoundariesPixels');
pexist(2) = isfield(handles,'IntData');

if (sum(pexist) < 2)
    disp('Error: Not all parameters required for integration exist.');
    disp('Solution: First perform integral boundary definition.');
else
    nIntBoundaries = numel(handles.IntBoundariesPixels);
    
    if (nIntBoundaries > 0)
        MinIntBoundaryPixels = min(handles.IntBoundariesPixels);
        MaxIntBoundaryPixels = max(handles.IntBoundariesPixels);

        MinIntBoundarykHz = min(handles.IntBoundaries);
        MaxIntBoundarykHz = max(handles.IntBoundaries);

        % Calculate total integral
        Integral = zeros(1,MaxIntBoundaryPixels-MinIntBoundaryPixels+1);
        Integral(1) = 0.0;
        for c1 = MinIntBoundaryPixels+1:MaxIntBoundaryPixels;
           Integral(c1+1-MinIntBoundaryPixels) = Integral(c1-MinIntBoundaryPixels) + handles.IntData(c1-MinIntBoundaryPixels);
        end;

        % Calculate integrals for individual resonances
        IntegralSegments = zeros(1,nIntBoundaries-1);
        for c1 = 1:1:(nIntBoundaries-1)
           IntegralSegments(c1) = Integral(handles.IntBoundariesPixels(nIntBoundaries-c1)-MinIntBoundaryPixels+1) - ...
               Integral(handles.IntBoundariesPixels(nIntBoundaries-c1+1)-MinIntBoundaryPixels+1);
        end;

        % Integration from right to left
        if (handles.IntBoundariesPixels(1) < handles.IntBoundariesPixels(end))
            IntegralSegments = -1.0*IntegralSegments(end:-1:1);
        end;

        % Display integrals in Matlab command window
        [OperationTime,~] = DMIWizard_MRS_CalculateTime;
        TextOutput1 = [OperationTime ' - Integrals (from right to left).'];
        disp(' '); disp(TextOutput1);
        DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);

        for c1 = (nIntBoundaries-1):-1:1
           TextOutput1 = [OperationTime ' - Integral ' num2str(nIntBoundaries-c1) ' = ' num2str(IntegralSegments(nIntBoundaries-c1),5)];
           disp(TextOutput1);
           DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
        end;
        DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',' ');

        % Draw spectrum and integral
        if isfield(handles,'fh5') > 0 && (handles.fh5 == 5)
            % Use existing integral figure
            figure(handles.fh5);
            clf(handles.fh5);
            axes('XDir','reverse','XLim',[MinIntBoundarykHz MaxIntBoundarykHz],'YLim',[handles.ZyLow handles.ZyHigh],'NextPlot','add');
            hold on;
        else
            % Start new integral window
            handles.fh5 = figure(5);
            axes('XDir','reverse','XLim',[MinIntBoundarykHz MaxIntBoundarykHz],'YLim',[handles.ZyLow handles.ZyHigh],'NextPlot','add');
            hold on;
        end;

        k = MinIntBoundarykHz:(MaxIntBoundarykHz-MinIntBoundarykHz)/(length(handles.IntData)-1):MaxIntBoundarykHz;
        freq2 = MinIntBoundarykHz + (MaxIntBoundarykHz-MinIntBoundarykHz)*((k-MinIntBoundarykHz)/(MaxIntBoundarykHz-MinIntBoundarykHz));

        plot(freq2,handles.IntData/(10^handles.ZyScale),'b',freq2,(0.5*handles.ZyHigh*Integral/max(Integral)),'r')
        if (handles.fcal > 0)
            % Axis in ppm
            xlabel('Chemical shift (ppm)')
            hold on;
        else
            % Axis in kHz
            xlabel('Frequency (kHz)')
            hold on;
        end;

        % Draw integration boundaries
        for c1 = 1:1:nIntBoundaries
           nintemp = MinIntBoundarykHz + ...
               (MaxIntBoundarykHz-MinIntBoundarykHz)*((handles.IntBoundaries(c1)-MinIntBoundarykHz)/(MaxIntBoundarykHz-MinIntBoundarykHz));
           xx = [nintemp nintemp];
           yy = [handles.ZyLow handles.ZyHigh];
           figure(handles.fh5);
           gg = line(xx,yy);
           set(gg,'Color','g');
        end;

        clear handles.intdata;
    end;

    if (nIntBoundaries > 0)
        % Write integration results to file
        % 1. Integration figure
        [SavePathDir,~,~] = fileparts(handles.MetaboliteFile);
        if isdir(SavePathDir) > 0 && strcmp(handles.MetaboliteFile,'C:\') < 1
            if (handles.BatchProcessing > 0)
                PathSave1 = [handles.MetaboliteFile handles.BatchOutputExt '_int.fig'];
            else
                PathSave1 = [handles.MetaboliteFile '_int.fig'];
            end;
        else
            if (handles.BatchProcessing > 0)
                PathSave1 = [handles.ProcessingHistoryFile handles.BatchOutputExt '_int.fig'];
            else
                PathSave1 = [handles.ProcessingHistoryFile '_int.fig'];
            end;
        end
        saveas(handles.fh5,PathSave1,'fig');

        % 2. Integration boundaries and values
        
        [SavePathDir,~,~] = fileparts(handles.MetaboliteFile);
        if isdir(SavePathDir) > 0 && strcmp(handles.MetaboliteFile,'C:\') < 1
            if (handles.BatchProcessing > 0)
                PathSave2 = [handles.MetaboliteFile handles.BatchOutputExt '_int'];
            else
                PathSave2 = [handles.MetaboliteFile '_int'];
            end;
        else
            if (handles.BatchProcessing > 0)
                PathSave2 = [handles.ProcessingHistoryFile handles.BatchOutputExt '_int'];
            else
                PathSave2 = [handles.ProcessingHistoryFile '_int'];
            end;
        end

        % Determine approximate power for proper scaling
        PowerInt = round(log10(max(IntegralSegments)))-1;

        fileID = fopen(PathSave2,'w');
        output1 = ['Boundary 1 (kHz) - Boundary 2 (kHz) - Integral (x10^' num2str(PowerInt) ') \r\r'];
        fprintf(fileID,output1,' ');
        fclose(fileID);

        if (handles.BatchProcessing > 0)
            % Add results to integration overview file
            output1 = {MRSpathLoad};
            CellCounter = ['A' num2str(handles.OverViewFileCounter)];
            [status,message] = xlswrite(OverViewFile,output1,1,CellCounter);
            handles.OverViewFileCounter = handles.OverViewFileCounter + 1;

            output0 = ['Integral (x10^' num2str(PowerInt) ')'];
            output1 = {'Boundary 1 (kHz)','Boundary 2 (kHz)',output0};
            CellCounter = ['A' num2str(handles.OverViewFileCounter)];
            [status,message] = xlswrite(OverViewFile,output1,1,CellCounter);
            handles.OverViewFileCounter = handles.OverViewFileCounter + 1;
        end;

        for c1 = 1:nIntBoundaries-1;
            if (handles.IntBoundariesPixels(1) < handles.IntBoundariesPixels(end))
                % Integration from right to left
                DataOut = [handles.IntBoundaries(c1); handles.IntBoundaries(c1+1); IntegralSegments(c1)*10^(-1.0*PowerInt)];
            else
                DataOut = [handles.IntBoundaries(c1); handles.IntBoundaries(c1+1); IntegralSegments(end-c1+1)*10^(-1.0*PowerInt)];
            end;

            fileID = fopen(PathSave2,'a');
            fprintf(fileID,'%9.5f  %9.5f   %9.5f\r',DataOut);
            fclose(fileID);

            if (handles.BatchProcessing > 0)
                CellCounter = ['A' num2str(handles.OverViewFileCounter)];
                [status,message] = xlswrite(OverViewFile,DataOut',1,CellCounter);
                handles.OverViewFileCounter = handles.OverViewFileCounter + 1;       
            end;
        end;

        if (handles.BatchProcessing > 0)
            handles.OverViewFileCounter = handles.OverViewFileCounter + 1;       
        end;
        
        [OperationTime,~] = DMIWizard_MRS_CalculateTime;
        TextOutput1 = [OperationTime ' - Integration plot saved to: ' num2str(PathSave1)];
        TextOutput2 = [OperationTime ' - Integration data saved to: ' num2str(PathSave2)];
        disp(' '); disp(TextOutput1); disp(TextOutput2);
        DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
        DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+',TextOutput2);

        if (handles.BatchProcessing > 0)
            if (handles.status < 1)
                disp(' ');
                disp('********************************************************');
                disp('Error: Unable to write data to overview Excel file.');
                disp('Matlab error message:');
                dd1 = [message.message];
                disp(dd1);
                disp('********************************************************');
                disp(' ');
                beep;
            else
                dd1 = ['Integration data saved to overview Excel file : ' num2str(handles.OverViewFile)];
                disp(' '); disp(dd1); disp(' ');
            end;
        end;
    else
        disp(' ');
        disp('Error   : No valid integration boundaries selected.');
        disp('Solution: First perform integration boundary definition before attempting integration.');
        beep;
    end;
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function PickNoise_pushbutton_Callback(hObject, eventdata, handles)
%*************************************************
% MRSpicknoise.m
%*************************************************

figure(2);

% Extract noise region
fb = ginput(2);

if (handles.av > 0)
    % Absolute-valued noise
    specA = abs(handles.spec(:,handles.nspec));
else
    % Real-valued noise
    specA = real(DMIWizard_MRS_PhaseCorrection(handles.spec(:,handles.nspec),handles));
end;
handles.freq = -0.5*handles.sw:handles.sw/(length(handles.specPhased)-1):0.5*handles.sw;

if (handles.fcal > 0)
    ppm1 = (1000*(min(handles.freq)-handles.reffreq)/handles.carfreq) + handles.refppm;
    ppm2 = (1000*(max(handles.freq)-handles.reffreq)/handles.carfreq) + handles.refppm;
   
    npppm = size(specA,1);
   
    stepppm = (ppm2-ppm1)/npppm;
   
    handles.freq = (ppm1+stepppm):stepppm:ppm2;
    handles.freq = reshape(handles.freq,1,npppm);
end;

coor = find((handles.freq > fb(2,1)) & (handles.freq < fb(1,1)));

noisespecA = specA(coor);
freqspecA = handles.freq(coor)';

% Baseline correct noise
P = polyfit(freqspecA,noisespecA,1);
baselinenoise = polyval(P,freqspecA);

stdnoise = std(noisespecA);
stdnoisecorrected = std(noisespecA - baselinenoise);

figure;
plot(freqspecA,noisespecA,'b',freqspecA,baselinenoise,'r');
axis([min(freqspecA) max(freqspecA) min(noisespecA) max(noisespecA)]);
if (handles.fcal > 0)
    xlabel('Frequency (ppm)');
else
    xlabel('Frequency (kHz)');
end;
title('blue = noise, red = best linear fit');

[OperationTime,~] = DMIWizard_MRS_CalculateTime;
TextOutput1 = [OperationTime ' - SD noise = ' num2str(stdnoise)];
TextOutput2 = [OperationTime ' - SD noise (baseline corrected) = ' num2str(stdnoisecorrected)];
disp(' '); disp(TextOutput1); disp(TextOutput2);
DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+',TextOutput2);

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function ShiftPickPeak_pushbutton_Callback(hObject, eventdata, handles)
%*************************************************
% Indicate the level about which multiple peaks
% are 'picked'.
%*************************************************

figure(2);

[freq,level] = ginput(1);

if (handles.fcal < 1)
    % Obtain frequencies in Hertz or ppm
        np = length(handles.spec);
    freqHz = -0.5*handles.sw:handles.sw/(np-1):0.5*handles.sw;
    coorzoom = find((freqHz > handles.ZxLow) & (freqHz < handles.ZxHigh));
    freqzoom = freqHz(coorzoom);
    
    if (handles.av > 0)
        % Absolute valued peak picking
        speczoom = abs(handles.spec(:,handles.nspec));
        speczoom = speczoom(coorzoom);
    else        
        % Phase correction
        specA = DMIWizard_MRS_PhaseCorrection(handles.spec(:,handles.nspec), handles);
        speczoom = specA(coorzoom);
    end;

    [peaks,coor] = findpeaks(real(speczoom),'minpeakheight',level*10^handles.ZyScale);

    figure(4);
    axes('XDir','reverse','XLim',[handles.ZxLow handles.ZxHigh],'YLim',[handles.ZyLow handles.ZyHigh],'NextPlot','add')
    for c1 = 1:1:length(coor)
        plot(freqzoom,real(speczoom)/(10^handles.ZyScale),'b',freqzoom(coor(c1)),real(speczoom(coor(c1)))/(10^handles.ZyScale),'o')
        text(freqzoom(coor(c1)),(0.9+0.02*(-1)^c1)*handles.ZyHigh,num2str(c1),'HorizontalAlignment','center')
        xdata = [freqzoom(coor(c1)) freqzoom(coor(c1))];
        ydata = [real(speczoom(coor(c1)))/(10^handles.ZyScale)  (0.88+0.02*(-1)^c1)*handles.ZyHigh];
        line(xdata,ydata,'LineStyle','--','Color',[1 0 0]);
        xlabel('Frequency (kHz)')
    end;

    npeaks = length(peaks);

    % Display resonance positions
    [OperationTime,~] = DMIWizard_MRS_CalculateTime;
    disp(' ');
    if (npeaks > 1)
        for c1 = 1:1:npeaks-1;
            TextOutput1 = [OperationTime ' - Signal ' num2str(c1) ', frequency = ' ...
                num2str(freqzoom(coor(c1))) ' kHz, height = ' num2str(peaks(c1))];
            TextOutput2 = [OperationTime ' - Delta ' num2str(c1+1) ' - ' num2str(c1) ' = ' ...
                num2str(1000*(freqzoom(coor(c1+1))-freqzoom(coor(c1)))) ' Hz'];
            disp(TextOutput1); disp(TextOutput2);
            DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
        end;
        TextOutput2 = [OperationTime ' - Signal ' num2str(npeaks) ', frequency = ' ...
            num2str(freqzoom(coor(npeaks))) ' kHz, height = ' num2str(peaks(npeaks))];
        disp(TextOutput2);
        DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+',TextOutput2);
    else       
        TextOutput1 = [OperationTime ' - Signal ' num2str(npeaks) ', frequency = ' ...
            num2str(freqzoom(coor(npeaks))) ' kHz, height = ' num2str(peaks(npeaks))];
        disp(TextOutput1);
        DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+',TextOutput1);
    end;
    
    % Write peak frequencies to file
    if (ispc > 0)
       coorslash = find(handles.MetaboliteFile == '\');
    else
       coorslash = find(handles.MetaboliteFile == '/');
    end;
    handles.MetaboliteFileDir = handles.MetaboliteFile(1:max(coorslash));

    OperationTime2 = [OperationTime(1:2) OperationTime(4:5) OperationTime(7:8)];
    MRSpathPeakPick = [handles.MetaboliteFileDir 'PeakPick' OperationTime2 '.txt'];
    fileID = fopen(MRSpathPeakPick,'w+');
    fprintf(fileID,'%9.7f   %9.7f\n',[freqzoom(coor); peaks']);
    fclose(fileID);
    
    TextOutput1 = [OperationTime ' - Peak pick frequencies and intensities saved to file :'];
    TextOutput2 = [OperationTime ' - ' MRSpathPeakPick];
    disp(TextOutput1); disp(TextOutput2);
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+',TextOutput2);
else
    % Obtain frequencies in ppm
    np = length(handles.spec);
    freqHz = -0.5*handles.sw:handles.sw/(np-1):0.5*handles.sw;
    freqppm = handles.refppm + 1000*((freqHz-handles.reffreq)/handles.carfreq);

    % Phase correction
    specA = DMIWizard_MRS_PhaseCorrection(handles.spec(:,handles.nspec), handles);

    coorzoom = find((freqppm > handles.ZxLow) & (freqppm < handles.ZxHigh));
    freqzoom = freqppm(coorzoom);
    speczoom = specA(coorzoom);

    [peaks,coor] = findpeaks(real(speczoom),'minpeakheight',level*10^handles.ZyScale);

    figure(4)
    clf;
    axes('XDir','reverse','XLim',[handles.ZxLow handles.ZxHigh],'YLim',[handles.ZyLow handles.ZyHigh],'NextPlot','add')
    for c1 = 1:1:length(coor)
        plot(freqzoom,real(speczoom)/(10^handles.ZyScale),'b',freqzoom(coor(c1)),real(speczoom(coor(c1)))/(10^handles.ZyScale),'o')
        text(freqzoom(coor(c1)),(0.9+0.02*(-1)^c1)*handles.ZyHigh,num2str(c1),'HorizontalAlignment','center')
        xdata = [freqzoom(coor(c1)) freqzoom(coor(c1))];
        ydata = [real(speczoom(coor(c1)))/(10^handles.ZyScale)  (0.88+0.02*(-1)^c1)*handles.ZyHigh];
        line(xdata,ydata,'LineStyle','--','Color',[1 0 0]);
        xlabel('Chemical shift (ppm)')
    end;

    npeaks = length(peaks);

    % Display resonance positions
    [OperationTime,~] = DMIWizard_MRS_CalculateTime;
    if (npeaks > 1)
        disp(' ');
        for c1 = 1:1:npeaks-1;
            TextOutput1 = [OperationTime ' - Signal ' num2str(c1) ', chemical shift = ' ...
                num2str(freqzoom(coor(c1))) ' ppm, height = ' num2str(peaks(c1))];
            TextOutput2 = [OperationTime ' - Delta ' num2str(c1+1) ' - ' num2str(c1) ' = ' num2str(freqzoom(coor(c1+1))-freqzoom(coor(c1))) ' ppm = '...
                num2str(handles.carfreq*(freqzoom(coor(c1+1))-freqzoom(coor(c1)))) ' Hz'];
            disp(TextOutput1); disp(TextOutput2);
            DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
        end;
        TextOutput2 = [OperationTime ' - Signal ' num2str(npeaks) ', chemical shift = ' ...
            num2str(freqzoom(coor(npeaks))) ' ppm, height = ' num2str(peaks(npeaks))];
        disp(TextOutput2);
        DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+',TextOutput2);
    else
        TextOutput1 = [OperationTime ' - Signal ' num2str(npeaks) ', chemical shift = ' ...
            num2str(freqzoom(coor(npeaks))) ' ppm, height = ' num2str(peaks(npeaks))];
        disp(TextOutput1);
        DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+',TextOutput1);
    end;
    
    % Write peak frequencies to file
    if (ispc > 0)
       coorslash = find(handles.MetaboliteFile == '\');
    else
       coorslash = find(handles.MetaboliteFile == '/');
    end;
    handles.MetaboliteFileDir = handles.MetaboliteFile(1:max(coorslash));

    OperationTime2 = [OperationTime(1:2) OperationTime(4:5) OperationTime(7:8)];
    MRSpathPeakPick = [handles.MetaboliteFileDir 'PeakPick' OperationTime2 '.txt'];
    fileID = fopen(MRSpathPeakPick,'w+');
    fprintf(fileID,'%9.7f   %9.7f\n',[freqzoom(coor); peaks']);
    fclose(fileID);
    
    TextOutput1 = [OperationTime ' - Peak pick frequencies and intensities saved to file :'];
    TextOutput2 = [OperationTime ' - ' MRSpathPeakPick];
    disp(TextOutput1); disp(TextOutput2);
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+',TextOutput2);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)


function BaselineCorrectionOrder_Callback(hObject, eventdata, handles)
handles.bcorder = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.bcorder) > 0) || (isinf(handles.bcorder) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for baseline order.'];
    ErrorMessage2 = ['Error: Baseline order set to valid default value (1).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.bcorder = 1;
    set(hObject,'String',handles.bcorder);
end;

% Force baseline order as an integer
handles.bcorder = round(handles.bcorder);

% Only allow positive baseline orders
if (handles.nfidi < 0)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for baseline order.'];
    ErrorMessage2 = ['Error: Baseline order set to valid default value (1).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.bcorder = 1;
    set(hObject,'String',handles.bcorder);
else
    set(hObject,'String',handles.bcorder);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function BaselineCorrectionOrder_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function FIDtrunction_edit_Callback(hObject, eventdata, handles)
handles.FIDtrunc = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.FIDtrunc) > 0) || (isinf(handles.FIDtrunc) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for FID truncation.'];
    ErrorMessage2 = ['Error: FID truncation set to valid default value (0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.FIDtrunc = 0;
    set(hObject,'String',handles.FIDtrunc);
end;

% Force FID truncation as an integer
handles.FIDtrunc = round(handles.FIDtrunc);

% Only allow positive FID truncations
if (handles.FIDtrunc < 0)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for FID truncation.'];
    ErrorMessage2 = ['Error: FID truncation set to valid default value (0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.FIDtrunc = 0;
    set(hObject,'String',handles.FIDtrunc);
else
    set(hObject,'String',handles.FIDtrunc);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function FIDtrunction_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function RefFreqpushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to RefFreqpushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

figure(2);

r = ginput(1);
handles.reffreq = r(1,1);

% Update GUI - reference frequency
RefFreq_Object = findall(0,'Tag','ReferenceFrequency_edit');
set(RefFreq_Object,'String',handles.reffreq);

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function ZoomIn_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to ZoomIn_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

figure(2);

r = ginput(2);
handles.ZxLow = min([r(1,1) r(2,1)]);
handles.ZxHigh = max([r(1,1) r(2,1)]);

% Update GUI - lower frequency boundary
LowFreq_Object = findall(0,'Tag','LowFrequencyBoundary_edit');
set(LowFreq_Object,'String',handles.ZxLow);

% Update GUI - higher frequency boundary
HighFreq_Object = findall(0,'Tag','HighFrequencyBoundary_edit');
set(HighFreq_Object,'String',handles.ZxHigh);

if isfield(handles,'specPhased') == 1
    % Display spectrum
    DMIWizard_MRS_DisplaySpectrum(handles.specPhased(:,handles.nspec), handles);
end

% Update previous values
handles.ZxLowPreviousValue = handles.ZxLow;
handles.ZxHighPreviousValue = handles.ZxHigh;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function ZoomOut_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to ZoomOut_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if (handles.fcal > 0)
    ppm1 = (1000*(-0.5*handles.sw-handles.reffreq)/handles.carfreq) + handles.refppm;
    ppm2 = (1000*(0.5*handles.sw-handles.reffreq)/handles.carfreq) + handles.refppm;
    
    handles.ZxLow = min([ppm1 ppm2]);
    handles.ZxHigh = max([ppm1 ppm2]);
else    
    handles.ZxLow = -0.5*handles.sw;
    handles.ZxHigh = 0.5*handles.sw;
end;

LowFrequencyBoundary_Object = findall(0,'Tag','LowFrequencyBoundary_edit');
set(LowFrequencyBoundary_Object,'String',handles.ZxLow);

HighFrequencyBoundary_Object = findall(0,'Tag','HighFrequencyBoundary_edit');
set(HighFrequencyBoundary_Object,'String',handles.ZxHigh);

if isfield(handles,'specPhased') == 1
    % Display spectrum
    DMIWizard_MRS_DisplaySpectrum(handles.specPhased(:,handles.nspec), handles);
end

% Update previous values
handles.ZxLowPreviousValue = handles.ZxLow;
handles.ZxHighPreviousValue = handles.ZxHigh;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function BigEndian_checkbox_Callback(hObject, eventdata, handles)
% Select big-endian data format (primarily for reading older data)
handles.be = get(hObject,'Value');

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)
