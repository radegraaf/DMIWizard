function handles = DMIWizard_MRS_ReadSettings(handles)

fileID = fopen('DMIWizardSettings.txt','r');

if (fileID < 0)
    % DMIWizard settings file cannot be read, continue with default values
    handles.GUIBackgroundColor = [0.94 0.94 0.94];
    handles.GUIForegroundColor = [0.00 0.00 0.00];
    handles.GUIFont = 'MS Sans Serif';
    handles.GUIFontSize = 0.56;
    handles.GUIDefaultPath = 'C:\';

    [OperationTime,~] = DMIWizard_MRS_CalculateTime;
    WarningMessage1 = [OperationTime ' - Warning : DMIWizardSettings.txt could not be opened.'];
    WarningMessage2 = [OperationTime ' - Solution: Continuing with default settings.'];
    disp(WarningMessage1); disp(WarningMessage2);
else
    % Read DMIWizard settings file
    Data = textscan(fileID, '%s', 'delimiter', '\n', 'whitespace', '');
    CStr = Data{1};
    fclose(fileID);

    % Scanning for BackgroundColor1
    Index1 = strfind(CStr, 'DMIWizard_BackgroundColor1');
    Index2 = find(~cellfun('isempty', Index1), 1);
    Line1 = char(CStr(Index2));
    coor1 = find(Line1 == '['); coor2 = find(Line1 == ']');
    if (((isempty(coor1(1)) < 1) && (isempty(coor2(1)) < 1) && (coor2(1)-coor1(1)-2 > 0)))
        GUIBackgroundColor = str2num(Line1(coor1(1)+1:coor2(1)-1));
        if (isempty(GUIBackgroundColor) < 1)
            handles.GUIBackgroundColor1 = GUIBackgroundColor;
        else
            handles.GUIBackgroundColor1 = [0.94 0.94 0.94];
        end;
    else
        handles.GUIBackgroundColor1 = [0.94 0.94 0.94];
    end;
    
    % Scanning for BackgroundColor2
    Index1 = strfind(CStr, 'DMIWizard_BackgroundColor2');
    Index2 = find(~cellfun('isempty', Index1), 1);
    Line1 = char(CStr(Index2));
    coor1 = find(Line1 == '['); coor2 = find(Line1 == ']');
    if (((isempty(coor1(1)) < 1) && (isempty(coor2(1)) < 1) && (coor2(1)-coor1(1)-2 > 0)))
        GUIBackgroundColor = str2num(Line1(coor1(1)+1:coor2(1)-1));
        if (isempty(GUIBackgroundColor) < 1)
            handles.GUIBackgroundColor2 = GUIBackgroundColor;
        else
            handles.GUIBackgroundColor2 = [1.00 1.00 1.00];
        end;
    else
        handles.GUIBackgroundColor2 = [1.00 1.00 1.00];
    end;
    
    % Scanning for ForegroundColor1
    Index1 = strfind(CStr, 'DMIWizard_ForegroundColor1');
    Index2 = find(~cellfun('isempty', Index1), 1);
    Line1 = char(CStr(Index2));
    coor1 = find(Line1 == '['); coor2 = find(Line1 == ']');
    if (((isempty(coor1(1)) < 1) && (isempty(coor2(1)) < 1) && (coor2(1)-coor1(1)-2 > 0)))
        GUIForegroundColor = str2num(Line1(coor1(1)+1:coor2(1)-1));
        if (isempty(GUIForegroundColor) < 1)
            handles.GUIForegroundColor1 = GUIForegroundColor;
        else
            handles.GUIForegroundColor1 = [0.94 0.94 0.94];
        end;
    else
        handles.GUIForegroundColor1 = [0.94 0.94 0.94];
    end;
    
    % Scanning for ForegroundColor2
    Index1 = strfind(CStr, 'DMIWizard_ForegroundColor2');
    Index2 = find(~cellfun('isempty', Index1), 1);
    Line1 = char(CStr(Index2));
    coor1 = find(Line1 == '['); coor2 = find(Line1 == ']');
    if (((isempty(coor1(1)) < 1) && (isempty(coor2(1)) < 1) && (coor2(1)-coor1(1)-2 > 0)))
        GUIForegroundColor = str2num(Line1(coor1(1)+1:coor2(1)-1));
        if (isempty(GUIForegroundColor) < 1)
            handles.GUIForegroundColor2 = GUIForegroundColor;
        else
            handles.GUIForegroundColor2 = [0.94 0.94 0.94];
        end;
    else
        handles.GUIForegroundColor2 = [0.94 0.94 0.94];
    end;
    
    % Scanning for FontName
    Index1 = strfind(CStr, 'DMIWizard_FontName');
    Index2 = find(~cellfun('isempty', Index1), 1);
    Line1 = char(CStr(Index2));
    coor1 = find(Line1 == '=');
    if ((isempty(coor1(1)) < 1))
        GUIFontName = Line1(coor1(1)+1:end);
        if (isempty(GUIFontName) < 1)
            handles.GUIFontName = GUIFontName;
        else
            handles.GUIFontName = 'MS Sans Serif';
        end;
    else
        handles.GUIFontName = 'MS Sans Serif';
    end;
    
    % Scanning for FontSize
    Index1 = strfind(CStr, 'DMIWizard_FontSize');
    Index2 = find(~cellfun('isempty', Index1), 1);
    Line1 = char(CStr(Index2));
    coor1 = find(Line1 == '=');
    if ((isempty(coor1(1)) < 1))
        GUIFontSize = str2num(Line1(coor1(1)+1:end));
        if (isempty(GUIFontSize) < 1)
            handles.GUIFontSize = GUIFontSize;
        else
            handles.GUIFontSize = 0.56;
        end;
    else
        handles.GUIFontSize = 0.56;
    end;
    
    % Scanning for Default Path
    Index1 = strfind(CStr, 'DMIWizard_DefaultPath');
    Index2 = find(~cellfun('isempty', Index1), 1);
    Line1 = char(CStr(Index2));
    coor1 = find(Line1 == '=');
    if ((isempty(coor1(1)) < 1))
        GUIDefaultPath = Line1(coor1(1)+1:end);
        if (isempty(GUIDefaultPath) < 1)
            handles.GUIDefaultPath = GUIDefaultPath;
        else
            handles.GUIDefaultPath = 'C:\';
        end;
    else
        handles.GUIDefaultPath = 'C:\';
    end;
    
    % Scanning for MRS_Color1
    Index1 = strfind(CStr, 'DMIWizard_MRS_Color1');
    Index2 = find(~cellfun('isempty', Index1), 1);
    Line1 = char(CStr(Index2));
    coor1 = find(Line1 == '['); coor2 = find(Line1 == ']');
    if (((isempty(coor1(1)) < 1) && (isempty(coor2(1)) < 1) && (coor2(1)-coor1(1)-2 > 0)))
        GUIMRSColor = str2num(Line1(coor1(1)+1:coor2(1)-1));
        if (isempty(GUIMRSColor) < 1)
            handles.GUIMRSColor1 = GUIMRSColor;
        else
            handles.GUIMRSColor1 = [0.89 0.94 0.90];
        end;
    else
        handles.GUIMRSColor1 = [0.89 0.94 0.90];
    end;
    
    % Scanning for MRS_Color2
    Index1 = strfind(CStr, 'DMIWizard_MRS_Color2');
    Index2 = find(~cellfun('isempty', Index1), 1);
    Line1 = char(CStr(Index2));
    coor1 = find(Line1 == '['); coor2 = find(Line1 == ']');
    if (((isempty(coor1(1)) < 1) && (isempty(coor2(1)) < 1) && (coor2(1)-coor1(1)-2 > 0)))
        GUIMRSColor = str2num(Line1(coor1(1)+1:coor2(1)-1));
        if (isempty(GUIMRSColor) < 1)
            handles.GUIMRSColor2 = GUIMRSColor;
        else
            handles.GUIMRSColor2 = [0.87 0.92 0.98];
        end;
    else
        handles.GUIMRSColor2 = [0.87 0.92 0.98];
    end;
    
    % Scanning for MRS_Color3
    Index1 = strfind(CStr, 'DMIWizard_MRS_Color3');
    Index2 = find(~cellfun('isempty', Index1), 1);
    Line1 = char(CStr(Index2));
    coor1 = find(Line1 == '['); coor2 = find(Line1 == ']');
    if (((isempty(coor1(1)) < 1) && (isempty(coor2(1)) < 1) && (coor2(1)-coor1(1)-2 > 0)))
        GUIMRSColor = str2num(Line1(coor1(1)+1:coor2(1)-1));
        if (isempty(GUIMRSColor) < 1)
            handles.GUIMRSColor3 = GUIMRSColor;
        else
            handles.GUIMRSColor3 = [0.96 0.92 0.92];
        end;
    else
        handles.GUIMRSColor3 = [0.96 0.92 0.92];
    end;
    
    % Scanning for MRS_Color4
    Index1 = strfind(CStr, 'DMIWizard_MRS_Color4');
    Index2 = find(~cellfun('isempty', Index1), 1);
    Line1 = char(CStr(Index2));
    coor1 = find(Line1 == '['); coor2 = find(Line1 == ']');
    if (((isempty(coor1(1)) < 1) && (isempty(coor2(1)) < 1) && (coor2(1)-coor1(1)-2 > 0)))
        GUIMRSColor = str2num(Line1(coor1(1)+1:coor2(1)-1));
        if (isempty(GUIMRSColor) < 1)
            handles.GUIMRSColor4 = GUIMRSColor;
        else
            handles.GUIMRSColor4 = [1.00 0.97 0.92];
        end;
    else
        handles.GUIMRSColor4 = [1.00 0.97 0.92];
    end;
end;