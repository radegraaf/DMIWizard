function handles = DMIWizard_MRS_DisplaySpectrum(specPhased, handles)

np = length(specPhased);

freq = -0.5*handles.sw:handles.sw/(np-1):0.5*handles.sw;
freq = reshape(freq,np,1);

fh2 = figure(2);
set(fh2,'Units','points','Name','Frequency domain',...
    'Position',[handles.Fig2XPos handles.Fig2YPos handles.Fig2Width handles.Fig2Height])
clf;

if (handles.fcal > 0)
    %**********************************
    % Display spectrum with PPM scale
    %**********************************
    ppm1 = (1000*(min(freq)-handles.reffreq)/handles.carfreq) + handles.refppm;
    ppm2 = (1000*(max(freq)-handles.reffreq)/handles.carfreq) + handles.refppm;
   
    npppm = size(specPhased,1);
   
    stepppm = (ppm2-ppm1)/npppm;
   
    ppm = (ppm1+stepppm):stepppm:ppm2;
    
    if isnan(ppm) > 0
        disp('Error: Calibration not possible with given parameters')
        disp('Error: Calibration set to a valid default value (OFF).')
        disp(' ');
        handles.fcal = 0;
        fcal_Object = findall(0,'Tag','Calibrate_checkbox');
        set(fcal_Object,'Value',handles.fcal);
        
       %**********************************
       % Display spectrum with kHz scale
       %**********************************  
       axes('XDir','reverse','XLim',[handles.ZxLow handles.ZxHigh],'YLim',[handles.ZyLow handles.ZyHigh],'NextPlot','add');

       if (handles.av > 0)
           plot(freq,(abs(specPhased)/(10^handles.ZyScale)))
           xlabel('Frequency (kHz)')
       else
           plot(freq,(real(specPhased)/(10^handles.ZyScale)))
           xlabel('Frequency (kHz)')
       end
       return
    end
    
    ppm = reshape(ppm,npppm,1);
   
    axes('XDir','reverse','XLim',[handles.ZxLow handles.ZxHigh],'YLim',[handles.ZyLow handles.ZyHigh],'NextPlot','add')

    if (handles.av > 0)
        plot(ppm,(abs(specPhased)/(10^handles.ZyScale)))
        xlabel('Chemical shift (ppm)')
    else
        plot(ppm,(real(specPhased)/(10^handles.ZyScale)))
        xlabel('Chemical shift (ppm)')
    end;
else 
   %**********************************
   % Display spectrum with kHz scale
   %**********************************  
   axes('XDir','reverse','XLim',[handles.ZxLow handles.ZxHigh],'YLim',[handles.ZyLow handles.ZyHigh],'NextPlot','add');

   if (handles.av > 0)
       plot(freq,(abs(specPhased)/(10^handles.ZyScale)))
       xlabel('Frequency (kHz)')
   else
       plot(freq,(real(specPhased)/(10^handles.ZyScale)))
       xlabel('Frequency (kHz)')
   end;
end;