function [M0, LineShift, LineWidth, Phase, ErrorFlag] = DMIWizard_MRSI_ReadFittingResults(handles)

%**************************************************************************
% DMIWizard_MRSI_ReadFittingResults.m
%
% Read spectral fitting results from disk (fitting parameters are extracted
% from a separate file).
%**************************************************************************

if ismac
    % Mac plaform
    coor = find(handles.MRSIPath == '/');
elseif isunix
    % Linux plaform
    coor = find(handles.MRSIPath == '/');
elseif ispc
    % Windows platform
    coor = find(handles.MRSIPath == '\');
end               
MRSIPathDir = handles.MRSIPath(1:max(coor));
    
% 1. Main fitting result (amplitude, shift, width)
file = [MRSIPathDir 'FittingResultsMain.txt'];
fileID = fopen(file,'r+');
ErrorFlag = 0;
if (fileID > 0)
    datain = fscanf(fileID,'%g %g %g %g %g %g %g',[7 Inf]);
    fclose(fileID);
    
    M0 = datain(5,:);
    M0 = reshape(M0,handles.nresFit,handles.np1,handles.np2,handles.np3);
    LineShift = datain(6,:); 
    LineShift = reshape(LineShift,handles.nresFit,handles.np1,handles.np2,handles.np3);    
    LineWidth = datain(7,:); 
    LineWidth = reshape(LineWidth,handles.nresFit,handles.np1,handles.np2,handles.np3);
    
    [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
    TextOutput0 = [OperationTime ' - Reading main spectral fitting results from ' file];
    disp(TextOutput0);
else
    M0 = []; LineShift = []; LineWidth = [];
    ErrorFlag = 1;
end;

% 2. Phase-related fitting results
file = [MRSIPathDir 'FittingResultsPhase.txt'];
fileID = fopen(file,'r+');
if (fileID > 0)
    datain = fscanf(fileID,'%g %g %g %g %g',[5 Inf]);
    fclose(fileID);
    
    Phase0 = datain(4,:);
    Phase0 = reshape(Phase0,handles.np1,handles.np2,handles.np3);
    Phase1 = datain(5,:);
    Phase1 = reshape(Phase1,handles.np1,handles.np2,handles.np3);
    
    Phase(1,:,:,:) = Phase0;
    Phase(2,:,:,:) = Phase1;
    
    [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
    TextOutput0 = [OperationTime ' - Reading phase-related spectral fitting results from ' file];
    disp(TextOutput0);
else
    Phase = [];
    ErrorFlag = 1;
end;