function [FOV1mri,FOV2mri,FOV3mri,np1mri,np2mri,np3mri,...
    FOV1mriOffset,FOV2mriOffset,FOV3mriOffset]  = ReadParametersBrukerMSME(MRIParameterFileBruker)

% Reading entire method parameter file
fileID = fopen(MRIParameterFileBruker,'r');
Data = textscan(fileID, '%s', 'delimiter', '\n', 'whitespace', '');
CStr = Data{1};

% Scanning for particular parameters
% 1A. FOV (read, phase)
IndexFOV = strfind(CStr, '##$PVM_FovCm');
Index = find(~cellfun('isempty', IndexFOV), 1);
LineFOV = char(CStr(Index+1));

FOV = str2num(LineFOV);
FOV1mri = 10*FOV(1);        % cm -> mm
FOV2mri = 10*FOV(2);        % cm -> mm

% 1B. FOV (slice)
IndexSliceThk = strfind(CStr, '##$PVM_SliceThick=');
Index = find(~cellfun('isempty', IndexSliceThk), 1);
LineSliceThk = char(CStr(Index));

SliceThk = str2num(LineSliceThk(19:end));

IndexSliceGap = strfind(CStr, '##$PVM_SPackArrSliceGap=');
Index = find(~cellfun('isempty', IndexSliceGap), 1);
LineSliceGap = char(CStr(Index+1));

SliceGap = str2num(LineSliceGap);

% 2A. Matrix size
IndexMatrixSize = strfind(CStr, '##$PVM_Matrix');
% PVM_Matrix may occur twice in case of MSME to 3D MRI conversion
Index = find(~cellfun('isempty', IndexMatrixSize));
Index = Index(end);
LineMatrixSize = char(CStr(Index+1));

MatrixSize = str2num(LineMatrixSize);
np1mri = MatrixSize(1);
np2mri = MatrixSize(2);

% 2B. Number of slices
IndexNS = strfind(CStr, '##$PVM_SPackArrNSlices');
Index = find(~cellfun('isempty', IndexNS), 1);
LineNS= char(CStr(Index+1));
np3mri = str2num(LineNS);

FOV3mri = (np3mri-1)*(SliceThk + SliceGap);

% 3. FOV offset/shift
IndexFOV1S = strfind(CStr, '##$PVM_SPackArrReadOffset');
Index = find(~cellfun('isempty', IndexFOV1S), 1);
LineFOV1S= char(CStr(Index+1));
FOV1mriOffset = str2num(LineFOV1S);

FOV2mriOffset = 0.0;

IndexFOV3S = strfind(CStr, '##$PVM_SPackArrSliceOffset');
Index = find(~cellfun('isempty', IndexFOV3S), 1);
LineFOV3S= char(CStr(Index+1));
FOV3mriOffset = str2num(LineFOV3S);

% Display parameters
disp(' ');
disp('Reading Bruker MSME parameters ...');
dd1 = ['[FOV1, FOV2, FOV3] = [ ' num2str(round(FOV1mri)) ', ' num2str(round(FOV2mri)) ', ' num2str(round(FOV3mri)) '] mm'];
dd2 = ['[FOV1 offset, FOV2 offset, FOV3 offset] = [ ' num2str(round(FOV1mriOffset)) ', ' num2str(round(FOV2mriOffset)) ', ' num2str(round(FOV3mriOffset)) '] mm'];
dd3 = ['[np1, np2, np3] = [ ' num2str(round(np1mri)) ', ' num2str(round(np2mri)) ', ' num2str(round(np3mri)) ']'];
disp(dd1); disp(dd2); disp(dd3);
disp(' ');

fclose(fileID);