function handles = DMIWizard_MRS_PhaseAlignment(handles)
%******************************************
% Performs a phase alignment.
%******************************************

if (handles.nfidi > 1) && isfield(handles,'spec') == 1
    OperationTime = DMIWizard_MRS_CalculateTime;
    dd = [OperationTime ' - Phase alignment started ...'];
    disp(dd);

    RFinv = -1.0*handles.RF;   % To account for the recent axis inversion

    nps = size(handles.spec,1);

    %*****************************************************
    % Determine relationship between number
    % of points and absolute frequency
    %*****************************************************
    aa = -(1000*handles.sw/(nps-1)); bb = 1000*handles.sw*(0.5+(1/(nps-1)));

    %********************************************************
    % Calculate reference point from reference frequency
    %********************************************************
    RP = (RFinv-bb)/aa;
    RPtol = (handles.RFtol/(1000*handles.sw))*nps;
    bnd1 = round(RP-RPtol); bnd2 = round(RP+RPtol);

    level = 10;

    ph0water = zeros(1,handles.nfidi);
    ph0array = -180:10:170;
    coeff = [1 0]; lb = [0.9 -180]; ub = [1.1 180];
    opt = optimset('Display','off');

    for kk1 = 1:1:handles.nfidi;
        if (100*(kk1/handles.nfidi) > level)
            dd = [num2str(level) ' % of phase alignment done.'];
            disp(dd);
            level = level + 10;
        end;

        counter = 1;
        int = zeros(1,length(ph0array));

        % Remember original zero-order phase 
        ph0orig = handles.ph0;

        for kk2 = 1:length(ph0array);   
           handles.ph0 = ph0array(kk2);
           spectest = DMIWizard_MRS_PhaseCorrection(handles.spec(:,kk1), handles);
           int(counter) = sum(real(spectest(bnd1:1:bnd2)));
           counter = counter + 1;
        end;

        % Restore original zero-order phase 
        handles.ph0 = ph0orig;

        ph0fit = lsqcurvefit('DMIWizard_MRS_CosineFunction',coeff,ph0array,int/max(abs(int)),lb,ub,opt);
        ph0water(kk1) = ph0fit(2);

        clear int index;

        handles.FID(:,kk1) = handles.FID(:,kk1).*exp((pi/180)*1i*ph0water(kk1));
    end;

    xx = 1:1:handles.nfidi;

    figure(2);
    subplot(2,1,1), plot(xx,ph0water,'r');
    axis([1 handles.nfidi min(ph0water) max(ph0water)])
    xlabel('spectrum number'); ylabel('phase (deg)');
    title('Before phase alignment');

    subplot(2,1,2), plot(xx,0*ph0water,'g');
    axis([1 handles.nfidi -1 1])
    xlabel('spectrum number'); ylabel('phase (deg)');
    title('After phase alignment');

    OperationTime = DMIWizard_MRS_CalculateTime;
    dd = [OperationTime ' - Phase alignment completed.'];
    disp(dd);

    % Perform FFT to visualize the results
    handles = DMIWizard_MRS_FFT(handles);
elseif handles.nfidi <= 1
    disp(' ');
    disp('Note: Initial number of FIDs is equal to one.');
    disp('Note: Phase alignment is not performed.');
elseif isfield(handles,'spec') < 1
    disp(' ');
    disp('Note: Fourier Transformation not yet performed');
    disp('Note: Phase alignment is not performed');
end