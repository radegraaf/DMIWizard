function handles = DMIWizard_MRS_FFT(handles)

% Performs a fast Fourier transformation on the FID.
handles.np = size(handles.FID,1);

% Allocate memory
FIDap = zeros(handles.np,handles.nfidi);
handles.spec = zeros(handles.npzf,handles.nfidi);
handles.specPhased = zeros(handles.npzf,handles.nfidi);

for c1 = 1:1:handles.nfidi
    % Time domain apodization
    FID1 = DMIWizard_MRS_Apodization(handles.FID(:,c1), handles);

    % Fourier transformation (with zerofilling)
    handles.spec(:,c1) = fftshift(fft(FID1,handles.npzf));

    % Phase correction
    handles.specPhased(:,c1) = DMIWizard_MRS_PhaseCorrection(handles.spec(:,c1), handles);
end

% Display spectrum
if (handles.nspec > handles.nfidi)
    handles.nspec = 1;
    nspec_Object = findall(0,'Tag','SpectrumNumber_edit');
    set(nspec_Object,'String',handles.nspec);
end

DMIWizard_MRS_DisplaySpectrum(handles.specPhased(:,handles.nspec), handles);

if (handles.ExtendedFFTOutput > 0)
    [OperationTime,~] = DMIWizard_MRS_CalculateTime;
    TextOutput1 = [OperationTime ' - Spectral 1D FFT with:'];
    TextOutput2 = [OperationTime ' - Spectral width  = ' num2str(handles.sw) ' kHz'];
    TextOutput3 = [OperationTime ' - Line broadening = ' num2str(handles.emf) ' Hz'];
    TextOutput4 = [OperationTime ' - Spectral points = ' num2str(handles.npzf)];
    TextOutput5 = [OperationTime ' - FID truncation  = ' num2str(handles.FIDtrunc)];
    TextOutput6 = [OperationTime ' - Group delay     = ' num2str(handles.dgd)];
    TextOutput7 = [OperationTime ' - Initial number of FIDs    = ' num2str(handles.nfidi)];
    TextOutput8 = [OperationTime ' - Number of experiments     = ' num2str(handles.nexp)];
    TextOutput9 = [OperationTime ' - Number of receivers       = ' num2str(handles.nrec)];
    TextOutput10 = [OperationTime ' - Number of repetitions     = ' num2str(handles.nrep)];

    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput2);
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput3);
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput4);
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput5);
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput6);
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput7);
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput8);
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput9);
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+',TextOutput10);
    disp(TextOutput1); disp(TextOutput2); disp(TextOutput3); disp(TextOutput4);
    disp(TextOutput5); disp(TextOutput6); disp(TextOutput7); disp(TextOutput8);
    disp(TextOutput9); disp(TextOutput10);
end;