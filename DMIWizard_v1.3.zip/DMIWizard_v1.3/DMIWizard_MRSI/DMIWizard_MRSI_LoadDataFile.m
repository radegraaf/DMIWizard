function handles = DMIWizard_MRSI_LoadDataFile(handles);
%------------------------------------------------------
% Function for reading vendor-specific FID files
%
% Note - The direct reading of vendor-specific FID
% files has been discontinued (except Bruker), due to
% the unknown k-space sampling, averaging and looping.
% It is recommended to convert vendor-specific DMI data
% to DMIWizard compatible data with external scripts.
%------------------------------------------------------
handles.FID = 1;
handles.FileErrorFlag = 0;  % Error flag indicating correct/incorrect file loading

switch handles.ConsoleType
    case {'Bruker-PV6','Bruker-PV360','DMIWizard'}
        % Bruker or NMRWizard data
        fileID = fopen(handles.MRSIPath,'r+');
    case {'DICOM (2D)','DICOM (3D)','NifTI'}
        clc;
        disp('Error     : DMI data in DICOM or NifTI format is not yet supported.');
        disp('Solution  : Write an stand-alone script to convert DICOM/NifTI data to DMIWizard format.');
        fileID = -1;        
    otherwise
        clc;
        disp('Error     : Direct reading of DMI data for GE, Philips and Siemens is not supported.');
        disp('Solution  : Write an stand-alone script to convert the data to DMIWizard format.');
        fileID = -1;
end;

if fileID < 0
%     errordlg('Selected data file cannot be found or read.','File Error');
    
    % Assign default values to parameters
    handles.FID = zeros(1024,handles.np1,handles.np2,handles.np3);
    handles.nav = 1; handles.npb = 0; handles.nrec = 1; 
    handles.np = 1024; handles.KSpaceSamplingScheme = 1;
    
    [OperationTime,OperationDate] = DMIWizard_MRSI_CalculateTime;   
    ErrorMessage1 = [OperationTime ' - Error   : Selected data file cannot be found or read.'];
    ErrorMessage2 = [OperationTime ' - Solution: Continuing with an (1024x' num2str(handles.np1) 'x' ...
        num2str(handles.np2) 'x' num2str(handles.np3) ') zero-amplitude FID and default parameters.'];
    disp(' '); disp(ErrorMessage1); disp(ErrorMessage2);
    
    % Create processing history file name
    % Find the appropriate output directory
    dirs = regexp(path, pathsep,'split');
    if ismac
        % Mac plaform
        SearchTerm = '/DMIWizard_v1.3/Results';
    elseif isunix
        % Linux plaform
        SearchTerm = '/DMIWizard_v1.3/Results';
    elseif ispc
        % Windows platform
        SearchTerm = '\DMIWizard_v1.3\Results';
    end

    for c1 = 1:length(dirs);
       DirOne = char(dirs(c1));
       if (length(DirOne) > 22)
           DirMatch = strcmp(DirOne(end-22:end),SearchTerm);
           if (DirMatch > 0)
               OutputDirBase = DirOne;
           end;
       end;
    end;
    
    if ismac
        % Mac plaform
        handles.ProcessingHistoryFile = [OutputDirBase '/ProcessingHistory' OperationDate  '.txt'];
    elseif isunix
        % Linux plaform
       handles.ProcessingHistoryFile = [OutputDirBase '/ProcessingHistory' OperationDate  '.txt'];
    elseif ispc
        % Windows platform
        handles.ProcessingHistoryFile = [OutputDirBase '\ProcessingHistory' OperationDate  '.txt'];
    end
    
else
    
    switch handles.ConsoleType
        case {'Bruker-PV6','Bruker-PV360'}           
            [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
            TextOutput1 = [OperationTime ' - Reading Bruker MRSI data file:'];
            TextOutput2 = [OperationTime ' - ' handles.MRSIPath];
            disp(TextOutput1); disp(TextOutput2);
       
            switch handles.ConsoleType
                case 'Bruker-PV6'
                    indata1 = fread(fileID, inf, 'long');         % PV6
                case 'Bruker-PV360'
                    indata1 = fread(fileID, Inf, 'float64');      % PV360
            end;
            fclose(fileID);
            
            [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
            TextOutput3 = [OperationTime ' - Reading Bruker MRSI data file completed.'];
            disp(TextOutput3);
            
            % Read parameters from Bruker parameter file
            if ismac
                % Mac plaform
                coor = find(handles.MRSIPath == '/');
            elseif isunix
                % Linux plaform
                coor = find(handles.MRSIPath == '/');
            elseif ispc
                % Windows platform
                coor = find(handles.MRSIPath == '\');
            end               
            MRSIPathDir = handles.MRSIPath(1:max(coor));
            
            % Create new processing history file
            [~,OperationDate] = DMIWizard_MRSI_CalculateTime;
            handles.ProcessingHistoryFile = [MRSIPathDir 'ProcessingHistory' OperationDate  '.txt'];
            DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'w+',TextOutput1);
            DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput2);
            DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+',TextOutput3);

            MRSIParameterFileBruker = [MRSIPathDir 'method'];
            if (exist(MRSIParameterFileBruker,'file') > 0)
               [handles.FOV1, handles.FOV2, handles.FOV3, handles.sw, ...
                   handles.np1, handles.np2, handles.np3, handles.nav, ...
                   handles.np, handles.npb, handles.nrec, handles.KSpaceSamplingScheme,...
                   handles.nu0] = DMIWizard_MRSI_ReadParametersBruker(MRSIParameterFileBruker);
            else
                % Parameter file does not exist - continue with default values
                [OperationTime,~] = DMIWizard_MRSI_CalculateTime;   
                ErrorMessage1 = [OperationTime ' - Error   : Parameter file ' MRSIParameterFileBruker ' does not exist.'];
                ErrorMessage2 = [OperationTime ' - Solution: Continuing with an (1024x' num2str(handles.np1) 'x' ...
                    num2str(handles.np2) 'x' num2str(handles.np3) ') zero-amplitude FID and default parameters.'];
                disp(' '); disp(ErrorMessage1); disp(ErrorMessage2);

                handles.FID = zeros(1024,handles.np1,handles.np2,handles.np3);
                handles.nav = 1; handles.npb = 0; handles.nrec = 1; 
                handles.np = 1024; handles.KSpaceSamplingScheme = 1;
                handles.nu0 = 100; handles.FileErrorFlag = 1;
            end;
            
            if ((rem(length(indata1),2) > 0) || isempty(indata1) > 0)
                [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
                ErrorMessage1 = [OperationTime ' - Error   : Odd or zero number of FID data points.'];
                ErrorMessage2 = [OperationTime ' - Solution: Continuing with an (1024x' num2str(handles.np1) 'x' ...
                    num2str(handles.np2) 'x' num2str(handles.np3) ') zero-amplitude FID and default parameters.'];
                disp(' '); disp(ErrorMessage1); disp(ErrorMessage2);
                
                handles.FID = zeros(1024,handles.np1,handles.np2,handles.np3);
                handles.nav = 1; handles.npb = 0; handles.nrec = 1; 
                handles.np = 1024; handles.KSpaceSamplingScheme = 1;
                handles.nu0 = 100; handles.FileErrorFlag = 1;
            else
                if (max(abs(handles.FID(:))) > 0)
                    % Only read data when not initialized with an empty matrix
                    handles.FID = indata1(1:2:end) + 1i*indata1(2:2:end);
                end;
            end;
                                   
        case 'DMIWizard'
            [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
            TextOutput1 = [OperationTime ' - Reading DMIWizard MRSI data file:'];
            TextOutput2 = [OperationTime ' - ' handles.MRSIPath];
            disp(TextOutput1); disp(TextOutput2);
                                    
            indata1 = fread(fileID, inf, 'long');
            fclose(fileID);
            
            [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
            TextOutput3 = [OperationTime ' - Reading DMIWizard MRSI data file completed.'];
            disp(TextOutput3);
            
            % Create new processing history file
            if ismac
                % Mac plaform
                coor = find(handles.MRSIPath == '/');
            elseif isunix
                % Linux plaform
                coor = find(handles.MRSIPath == '/');
            elseif ispc
                % Windows platform
                coor = find(handles.MRSIPath == '\');
            end
            MRSIPathDir = handles.MRSIPath(1:max(coor));

            [~,OperationDate] = DMIWizard_MRSI_CalculateTime;
            handles.ProcessingHistoryFile = [MRSIPathDir 'ProcessingHistory' OperationDate  '.txt'];
            DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'w+',TextOutput1);
            DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput2);
            DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+',TextOutput3);
            
            % Read parameters from DMIWizard parameter file
            coor = find(handles.MRSIPath == '.');
            if (isempty(coor) > 0)
                % Basefile name does not have an extension
                MRSIPathDir = [handles.MRSIPath '.'];
            else
                % Basefile name has an extension
                MRSIPathDir = handles.MRSIPath(1:max(coor));
            end;
            
            MRSIParameterFileNMRWizard = [MRSIPathDir 'par'];
            if (exist(MRSIParameterFileNMRWizard,'file') > 0)
               [handles.FOV1, handles.FOV2, handles.FOV3, handles.np1, ...
                   handles.np2, handles.np3, handles.sw, handles.np, ...
                   handles.npb, handles.nav, handles.nrec, handles.nu0] = ...
                   DMIWizard_MRSI_ReadParametersNMRWizard(MRSIParameterFileNMRWizard);
            else                
                % Parameter file does not exist - continue with default values
                [OperationTime,~] = DMIWizard_MRSI_CalculateTime;   
                ErrorMessage1 = [OperationTime ' - Error   : Parameter file ' MRSIParameterFileNMRWizard ' does not exist.'];
                ErrorMessage2 = [OperationTime ' - Solution: Continuing with an (1024x' num2str(handles.np1) 'x' ...
                    num2str(handles.np2) 'x' num2str(handles.np3) ') zero-amplitude FID and default parameters.'];
                disp(' '); disp(ErrorMessage1); disp(ErrorMessage2);

                handles.FID = zeros(1024,handles.np1,handles.np2,handles.np3);
                handles.nav = 1; handles.npb = 0; handles.nrec = 1; 
                handles.np = 1024; handles.KSpaceSamplingScheme = 1;
                handles.nu0 = 100; handles.FileErrorFlag = 1;
            end;
            
            if ((rem(length(indata1),2) > 0) || isempty(indata1) > 0)
                [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
                ErrorMessage1 = [OperationTime ' - Error   : Odd or zero number of FID data points.'];
                ErrorMessage2 = [OperationTime ' - Solution: Continuing with an (1024x' num2str(handles.np1) 'x' ...
                    num2str(handles.np2) 'x' num2str(handles.np3) ') zero-amplitude FID and default parameters.'];
                disp(' '); disp(ErrorMessage1); disp(ErrorMessage2);
                
                handles.FID = zeros(1024,handles.np1,handles.np2,handles.np3);
                handles.nav = 1; handles.npb = 0; handles.nrec = 1; 
                handles.np = 1024; handles.KSpaceSamplingScheme = 1;
                handles.nu0 = 100; handles.FileErrorFlag = 1;
            else
                if (max(abs(handles.FID(:))) > 0)
                    % Only read data when not initialized with an empty matrix
                    handles.FID = indata1(1:2:end) + 1i*indata1(2:2:end);
                end;
            end;
            
            % DMIWizard data is always stored with full k-space coverage
            handles.KSpaceSamplingScheme = 1;
            [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
            TextOutput4 = [OperationTime ' - Force k-space sampling to Cubic-linear for DMIWizard data'];
            disp(TextOutput4);
            DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+',TextOutput4);
    end;
    
    switch handles.KSpaceSamplingScheme
        case 1
            % Cubic linear
            switch handles.naloop
                case 1
                    % New(er) data acquisition - NA is the slowest loop
                    handles.FID = reshape(handles.FID,handles.np,handles.nrec,...
                        handles.np1,handles.np2,handles.np3,handles.nav);
                    handles.FID = sum(handles.FID,6);   % Add averages
                case 2
                    % Old(er) data acquisition - NA is the fastest loop
                    handles.FID = reshape(handles.FID,handles.np,handles.nrec,...
                        handles.nav,handles.np1,handles.np2,handles.np3);
                    handles.FID = sum(handles.FID,3);   % Add averages
            end;
            handles.FID = reshape(handles.FID,handles.np,handles.nrec,...
                handles.np1,handles.np2,handles.np3);
                        
            % Following addition, set number of averages to 1
            handles.nav = 1;
            
        case 2
            % Spherical linear
            switch handles.naloop
                case 1     
                    % New(er) data acquisition - NA is the slowest loop
                    nexp = numel(handles.FID)/(handles.np*handles.nrec*handles.nav);
                    if (rem(nexp,1) > 0)
                        [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
                        ErrorMessage1 = [OperationTime ' - Error   : Indicated matrix sizes and number of points not compatible with FID data.'];
                        ErrorMessage2 = [OperationTime ' - Solution: Continuing with an (1024x' num2str(handles.np1) 'x' ...
                            num2str(handles.np2) 'x' num2str(handles.np3) ') zero-amplitude FID and default parameters.'];
                        disp(' '); disp(ErrorMessage1); disp(ErrorMessage2);

                        handles.FID = zeros(1024,handles.np1,handles.np2,handles.np3);
                        handles.nav = 1; handles.npb = 0; handles.nrec = 1; 
                        handles.np = 1024; handles.KSpaceSamplingScheme = 1;
                        handles.FileErrorFlag = 1;
                    else
                        handles.FID = reshape(handles.FID,handles.np,handles.nrec,[],handles.nav);
                        %handles.FID = handles.FID(:,:,:,1:4); % Use this line to process lower number of averages
                        handles.FID = sum(handles.FID,4);   % Add averages
                        nexp = numel(handles.FID)/(handles.np*handles.nrec);
                        handles.FID = reshape(handles.FID,handles.np,handles.nrec,1,nexp);
                    end;
                    
                case 2
                    % Old(er) data acquisition - NA is the fastest loop
                    nexp = numel(handles.FID)/(handles.np*handles.nrec*handles.nav);
                    if (rem(nexp,1) > 0)
                        [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
                        ErrorMessage1 = [OperationTime ' - Error   : Indicated matrix sizes and number of points not compatible with FID data.'];
                        ErrorMessage2 = [OperationTime ' - Solution: Continuing with an (1024x' num2str(handles.np1) 'x' ...
                            num2str(handles.np2) 'x' num2str(handles.np3) ') zero-amplitude FID and default parameters.'];
                        disp(ErrorMessage1); disp(ErrorMessage2);

                        handles.FID = zeros(1024,handles.np1,handles.np2,handles.np3);
                        handles.nav = 1; handles.npb = 0; handles.nrec = 1; 
                        handles.np = 1024; handles.KSpaceSamplingScheme = 1;
                        handles.FileErrorFlag = 1;
                    else
                        handles.FID = reshape(handles.FID,handles.np,handles.nrec,handles.nav,[]);
                        handles.FID = sum(handles.FID,3);   % Add averages
                        handles.nexp = numel(handles.FID)/(handles.np*handles.nrec);
                        handles.FID = reshape(handles.FID,handles.np,handles.nrec,1,handles.nexp);
                    end;
            end;

            if (nexp == handles.np1*handles.np2*handles.np3)
                disp('Error: k-space data size is not in agreement with spherical k-space encoding.');
                disp(' ');
                beep;
                
                [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
                ErrorMessage1 = [OperationTime ' - Error   : K-space data size is not compatible with spherical k-space encoding.'];
                ErrorMessage2 = [OperationTime ' - Solution: Continuing with an (1024x' num2str(handles.np1) 'x1x' ...
                    num2str(handles.np2) 'x' num2str(handles.np3) ') zero-amplitude FID and default parameters.'];
                disp(' '); disp(ErrorMessage1); disp(ErrorMessage2);

                handles.FID = zeros(1024,1,handles.np1,handles.np2,handles.np3);
                handles.nav = 1; handles.npb = 0; handles.nrec = 1; 
                handles.np = 1024; handles.KSpaceSamplingScheme = 1;
                handles.FileErrorFlag = 1;
            else
                % Check k-space sampling scheme as it may have changed due
                % to an earlier error condition.
                if (handles.KSpaceSamplingScheme == 2)
                    % Following addition, set number of averages to 1
                    handles.nav = 1;

                    [KSpaceCoor1, KSpaceCoor2, KSpaceCoor3] = ...
                        DMIWizard_MRSI_GenerateKSpaceEncoding(handles.np1, handles.np2, handles.np3, 'sphere');
                    [KSpaceCoor1c, KSpaceCoor2c, KSpaceCoor3c] = ...
                        DMIWizard_MRSI_GenerateKSpaceEncoding(handles.np1, handles.np2, handles.np3, 'cubic');

                    FID2 = zeros(handles.np,handles.nrec,handles.np1*handles.np2*handles.np3);
                    for c1 = 1:nexp;
                        coor = find((KSpaceCoor1(c1) == KSpaceCoor1c) & (KSpaceCoor2(c1) == KSpaceCoor2c) & (KSpaceCoor3(c1) == KSpaceCoor3c));
                        for c2 = 1:handles.nrec;
                            FID2(:,c2,coor(1)) = handles.FID(:,c2,1,c1);
                        end;
                    end;

                    handles.FID = FID2; clear FID2;
                    handles.FID = reshape(handles.FID,handles.np,handles.nrec,handles.np1,handles.np2,handles.np3);
                end;
            end;
    end;

    switch handles.ConsoleType
        case {'Bruker-PV6','Bruker-PV360'}
            % Remove points corresponding to the Bruker digital group delay
            handles.FID(1:handles.np-handles.npb,:,:,:,:) = handles.FID(handles.npb+1:end,:,:,:,:);
            handles.FID(handles.np-handles.npb+1:end,:,:,:,:) = 0.0;
            
            handles.npb = 0;
    end;
    
    % Apply k-space re-ordering to get the data in a [X Y Z] acquisition order
    handles.FID = permute(handles.FID,[1 2 handles.AcquisitionOrder(1)+2 handles.AcquisitionOrder(2)+2 handles.AcquisitionOrder(3)+2]);
    
    handles.np1 = size(handles.FID,3);
    handles.np2 = size(handles.FID,4);
    handles.np3 = size(handles.FID,5);
    
    % Apply k-space flip
    if (handles.KSpaceDataFlip(1) == 1)
        handles.FID = handles.FID(:,:,end:-1:1,:,:);
    end;
    
    if (handles.KSpaceDataFlip(2) == 1);
        handles.FID = handles.FID(:,:,:,end:-1:1,:);
    end;
    
    if (handles.KSpaceDataFlip(3) == 1)
        handles.FID = handles.FID(:,:,:,:,end:-1:1);
    end;    

    [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
    TextOutput1 = [OperationTime ' - Acquisition order [X, Y, Z] = [ ' ...
        num2str(handles.AcquisitionOrder(1)) ', ' num2str(handles.AcquisitionOrder(2)) ...
        ', ' num2str(handles.AcquisitionOrder(3)) ']'];
    TextOutput2 = [OperationTime ' - K-space flip [X, Y, Z] = [ ' ...
        num2str(handles.KSpaceDataFlip(1)) ', ' num2str(handles.KSpaceDataFlip(2)) ...
        ', ' num2str(handles.KSpaceDataFlip(3)) '] (0 = no, 1 = yes)'];   
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+',TextOutput2);
    
    % Read DMI pixel shift (if it exist)
    if ismac
        % Mac plaform
        coor = find(handles.MRSIPath == '/');
    elseif isunix
        % Linux plaform
        coor = find(handles.MRSIPath == '/');
    elseif ispc
        % Windows platform
        coor = find(handles.MRSIPath == '\');
    end
    MRSIPathDir = handles.MRSIPath(1:max(coor));
    DMIShiftFile = [MRSIPathDir 'DMIshift.txt'];
    if (exist(DMIShiftFile,'file') > 0)
        fileID = fopen(DMIShiftFile,'r');
        if (fileID > 0)
            datain = fscanf(fileID,'%g',[1 Inf]);
            fclose(fileID);

            handles.DMIshift1 = round(datain(1));
            handles.DMIshift2 = round(datain(2));
            handles.DMIshift3 = round(datain(3));

            OperationTime = DMIWizard_MRSI_CalculateTime;
            TextOutput1 = [OperationTime ' - DMI pixel shift file (' DMIShiftFile ') found and read.'];
            TextOutput2 = [OperationTime ' - DMI will be shifted by [' num2str(handles.DMIshift1) ', ' ...
                num2str(handles.DMIshift2) ', ' num2str(handles.DMIshift3) ' ] pixels during FFT.'];
            disp(TextOutput1); disp(TextOutput2);
        else
            handles.DMIshift1 = 0.0;
            handles.DMIshift2 = 0.0;
            handles.DMIshift3 = 0.0;
        end;
    else
        handles.DMIshift1 = 0.0;
        handles.DMIshift2 = 0.0;
        handles.DMIshift3 = 0.0;               
    end;
     
    fh1 = figure(1);
    set(fh1,'Units','points','Name','Time domain',...
        'Position',[handles.Fig1XPos handles.Fig1YPos handles.Fig1Width handles.Fig1Height])

    % Display FID
    time = 0:(1/handles.sw):(handles.np-1)*(1/handles.sw);
    FID1 = squeeze(handles.FID(:,1,round(0.5*handles.np1),round(0.5*handles.np2),round(0.5*handles.np3)));
    plot(time,imag(FID1),'r',time,real(FID1),'b');
    if (min(abs(FID1)) ~= max(abs(FID1)))
        axis ([0 max(time) -1*max(abs(FID1)) max(abs(FID1))]);
        xlabel('Time (ms)');
    else
        axis([0 max(time) -1*max(abs(FID1))-1 max(abs(FID1))+1]);
        xlabel('Time (ms)');
    end;    
    tt = ['K-space location = (' num2str(round(0.5*handles.np1)) ', ' ...
        num2str(round(0.5*handles.np2)) ', ' num2str(round(0.5*handles.np3)) ')'];
    title(tt);

    % Read fitting related files only when experimental DMI data is
    % succesfully loaded.
    if (handles.FileErrorFlag < 1)
        % Read existing files related to spectral fitting for combined display
        % with experimental data.
        handles.FittingErrorFlag = 0;

        % 1. Fitting parameters
        [handles.nresFit, handles.ZxLowFit, handles.ZxHighFit, handles.ZyScaleFit, handles.intthFit, handles.BasisSetDirFit, handles.PKFileFit, ...
            handles.ShiftReference, handles.ShiftReferencekHz, handles.MaximumGlobalOffsetFit, handles.RFCenterFrequency, ...
            handles.BLOFit, handles.NumberOfIterations, handles.LSDFit, handles.LineshapeFit, handles.PhaseFit, ...
            handles.FirstOrderPhaseEstimateFit, handles.FirstOrderFixFit, handles.FittingErrorFlag] = ...
            DMIWizard_MRSI_ReadFittingParameters(handles);
        
        if (handles.FittingErrorFlag < 1)
            % 2. Main fitting result (amplitude, shift, width)
            [handles.LCMFit.M0, handles.LCMFit.LineShift, handles.LCMFit.LineWidth, ...
                handles.LCMFit.Phase, handles.FittingErrorFlag2] = DMIWizard_MRSI_ReadFittingResults(handles);

            handles.FittingErrorFlag = handles.FittingErrorFlag + handles.FittingErrorFlag2;
        end;
    
        if (handles.FittingErrorFlag < 1)
            % 3. Basisset FIDs
            [handles.LCMFit.BasisFID, handles.FittingErrorFlag2] = DMIWizard_MRSI_ReadFittingBasisSet(handles);

            handles.FittingErrorFlag = handles.FittingErrorFlag + handles.FittingErrorFlag2;
        end;
    
        if (handles.FittingErrorFlag < 1)
            % 4. Baseline related parameters
            [handles.LCMFit.Baseline, handles.FittingErrorFlag2] = DMIWizard_MRSI_ReadFittingBaseline(handles);

            handles.FittingErrorFlag = handles.FittingErrorFlag + handles.FittingErrorFlag2;
        end;
    
        if (handles.FittingErrorFlag < 1)
            % 5. Distortion related parameters
            [handles.LCMFit.LSD, handles.FittingErrorFlag2] = DMIWizard_MRSI_ReadFittingLSD(handles);

            handles.FittingErrorFlag = handles.FittingErrorFlag + handles.FittingErrorFlag2;
        end;
    
        if (handles.FittingErrorFlag < 1)
            % 6. Metabolite-ID related parameters
            [handles.LCMFit.MetaboliteName, handles.LCMFit.MetaboliteCS, handles.LCMFit.MetaboliteFreq, ...
                handles.FittingErrorFlag2] = DMIWizard_MRSI_ReadFittingIDs(handles);

            handles.FittingErrorFlag = handles.FittingErrorFlag + handles.FittingErrorFlag2;
        end;
    
        % Remove spec3Dfit field from earlier data sets
        if (isfield(handles,'spec3Dfit') > 0)
            handles = rmfield(handles,'spec3Dfit');
        end;
        
        % Remove LCMFit field in case of a file reading error
        if (handles.FittingErrorFlag > 0)
            if (isfield(handles,'LCMFit') > 0)
                handles = rmfield(handles,'LCMFit');
            end;
        end;
    
        % Reconstruct fitted spectra
        if (handles.FittingErrorFlag < 1)
            for c1 = 1:handles.np1;
                for c2 = 1:handles.np2;
                    for c3 = 1:handles.np3;
                        spec1Dfit = DMIWizard_MRSI_FittingFunction02(handles,c1,c2,c3);
                        handles.spec3Dfit(:,c1,c2,c3) = spec1Dfit;
                    end;
                end;
            end;
        
            % Set spectral frequency boundaries to those used during spectral fitting
            LowFrequencyBoundary_Object = findall(0,'Tag','FrequencyLow_edit');
            set(LowFrequencyBoundary_Object,'String',handles.ZxLowFit);
            handles.ZxLow = handles.ZxLowFit;

            HighFrequencyBoundary_Object = findall(0,'Tag','FrequencyHigh_edit');
            set(HighFrequencyBoundary_Object,'String',handles.ZxHighFit);
            handles.ZxHigh = handles.ZxHighFit;
            
            ScaleFrequencyBoundary_Object = findall(0,'Tag','SignalScalingFactor_edit');
            set(ScaleFrequencyBoundary_Object,'String',handles.ZyScaleFit);
            handles.ZyScale = handles.ZyScaleFit;
            
            intth_Object = findall(0,'Tag','Threshold_edit');
            set(intth_Object,'String',handles.intthFit);
            handles.intth = handles.intthFit;
        
            % Update spectrum display
            if (isfield(handles,'spec3D') == 1)
                handles = DMIWizard_MRSI_DisplaySpectrum(handles);
            end;
        end;
    end;
end;