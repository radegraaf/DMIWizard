function [BasisFID, ErrorFlag] = DMIWizard_MRSI_ReadFittingBasisSet(handles)

%**************************************************************************
% DMIWizard_MRSI_ReadFittingBasisSet.m
%
% Read spectral fitting basis FIDs from disk.
%**************************************************************************

if ismac
    % Mac plaform
    coor = find(handles.MRSIPath == '/');
elseif isunix
    % Linux plaform
    coor = find(handles.MRSIPath == '/');
elseif ispc
    % Windows platform
    coor = find(handles.MRSIPath == '\');
end               
MRSIPathDir = handles.MRSIPath(1:max(coor));
    
% 1. Main fitting result (amplitude, shift, width)
file = [MRSIPathDir 'FittingResultsBasisSet.txt'];
fileID = fopen(file,'r+');
ErrorFlag = 0;
if (fileID > 0)
    datain = fscanf(fileID,'%g %g',[2 Inf]);
    fclose(fileID);
    
    BasisFID = datain(1,:) + 1i*datain(2,:);
    BasisFID = reshape(BasisFID,[],handles.nresFit);
    
    [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
    TextOutput0 = [OperationTime ' - Reading spectral fitting basisset from ' file];
    disp(TextOutput0);
else
    BasisFID = [];
    ErrorFlag = 1;
end;