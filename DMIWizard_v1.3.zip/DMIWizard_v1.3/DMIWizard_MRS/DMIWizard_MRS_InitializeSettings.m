function DMIWizard_MRS_InitializeSettings(handles)

% Object with general background/foreground colors
DMIWizard_MRS.Object1{1} = 'Text_InitialFIDs';
DMIWizard_MRS.Object1{2} = 'Text_NumberOfExperiments';
DMIWizard_MRS.Object1{3} = 'Text_NumberOfReceivers';
DMIWizard_MRS.Object1{4} = 'Text_NumberOfRepetitions';
DMIWizard_MRS.Object1{5} = 'Text_FinalFIDs';
DMIWizard_MRS.Object1{6} = 'Text_FIDTruncation';

DMIWizard_MRS.Object1{7} = 'Text_SpectrumNumber';
DMIWizard_MRS.Object1{8} = 'Text_ZeroOrderPhase';
DMIWizard_MRS.Object1{9} = 'Text_FirstOrderPhase';
DMIWizard_MRS.Object1{10} = 'Text_SpectralBandwidth';
DMIWizard_MRS.Object1{11} = 'Text_SpectralPoints';
DMIWizard_MRS.Object1{12} = 'Text_EM';
DMIWizard_MRS.Object1{13} = 'Text_GM';
DMIWizard_MRS.Object1{14} = 'Text_GS';

DMIWizard_MRS.Object1{15} = 'GroupDelayName';
DMIWizard_MRS.Object1{16} = 'Text_CarFreq';
DMIWizard_MRS.Object1{17} = 'Text_RefPPM';
DMIWizard_MRS.Object1{18} = 'Text_Calibrate';
DMIWizard_MRS.Object1{19} = 'Text_FreqLow';
DMIWizard_MRS.Object1{20} = 'Text_FreqHigh';
DMIWizard_MRS.Object1{21} = 'Text_SignalLow';
DMIWizard_MRS.Object1{22} = 'Text_SignalHigh';
DMIWizard_MRS.Object1{23} = 'Text_SignalScale';

DMIWizard_MRS.Object1{24} = 'Text_BC';
DMIWizard_MRS.Object1{25} = 'Text_BCorder';
DMIWizard_MRS.Object1{26} = 'Text_BCfile';
DMIWizard_MRS.Object1{27} = 'Text_INT';
DMIWizard_MRS.Object1{28} = 'Text_INTfile';

% Checkboxes
DMIWizard_MRS.Object1{29} = 'BigEndian_checkbox';
DMIWizard_MRS.Object1{30} = 'IncludeApodization_checkbox';
DMIWizard_MRS.Object1{31} = 'FrequencyAlignmentFit_checkbox';
DMIWizard_MRS.Object1{32} = 'AbsoluteValue_checkbox';
DMIWizard_MRS.Object1{33} = 'Calibrate_checkbox';

DMIWizard_MRS.Object1{34} = 'BaselineCorrectionWriteToBCBoundaries_checkbox';
DMIWizard_MRS.Object1{35} = 'BCuseSpecfiedBoundaries_checkbox';
DMIWizard_MRS.Object1{36} = 'IntegrationWriteToINTBoundaries_checkbox';
DMIWizard_MRS.Object1{37} = 'INTuseSpecfiedBoundaries_checkbox';
DMIWizard_MRS.Object1{38} = 'BatchProcessing_checkbox';

DMIWizard_MRS.Object1{39} = 'PhaseCorrectReceivers_pushbutton';
DMIWizard_MRS.Object1{40} = 'AddReceivers_pushbutton';
DMIWizard_MRS.Object1{41} = 'FrequencyAlignment_pushbutton';
DMIWizard_MRS.Object1{42} = 'SeparateAndSummate_pushbutton';
DMIWizard_MRS.Object1{43} = 'SelectWaterFile_pushbutton';
DMIWizard_MRS.Object1{44} = 'LoadWaterFile_pushbutton';

DMIWizard_MRS.Object1{45} = 'IncreaseSpectrumNumber_pushbutton';
DMIWizard_MRS.Object1{46} = 'IncreaseZeroOrderPhase_pushbutton';
DMIWizard_MRS.Object1{47} = 'IncreaseFirstOrderPhase_pushbutton';
DMIWizard_MRS.Object1{48} = 'IncreaseFrequencyLowBoundary_pushbutton';
DMIWizard_MRS.Object1{49} = 'IncreaseFrequencyHighBoundary_pushbutton';
DMIWizard_MRS.Object1{50} = 'IncreaseLowIntensityBoundary_pushbutton';
DMIWizard_MRS.Object1{51} = 'IncreaseHighIntensityBoundary_pushbutton';
DMIWizard_MRS.Object1{52} = 'IncreaseSignalScalingFactor_pushbutton';

DMIWizard_MRS.Object1{53} = 'DecreaseSpectrumNumber_pushbutton';
DMIWizard_MRS.Object1{54} = 'DecreaseZeroOrderPhase_pushbutton';
DMIWizard_MRS.Object1{55} = 'DecreaseFirstOrderPhase_pushbutton';
DMIWizard_MRS.Object1{56} = 'DecreaseFrequencyLowBoundary_pushbutton';
DMIWizard_MRS.Object1{57} = 'DecreaseFrequencyHighBoundary_pushbutton';
DMIWizard_MRS.Object1{58} = 'DecreaseLowIntensityBoundary_pushbutton';
DMIWizard_MRS.Object1{59} = 'DecreaseHighIntensityBoundary_pushbutton';
DMIWizard_MRS.Object1{60} = 'DecreaseSignalScalingFactor_pushbutton';

for c1 = 1:numel(DMIWizard_MRS.Object1);
    DMIWizard_MRS_Object = findall(0,'Tag',char(DMIWizard_MRS.Object1(c1)));
    set(DMIWizard_MRS_Object,'BackgroundColor',handles.GUIBackgroundColor1);
    set(DMIWizard_MRS_Object,'ForegroundColor',handles.GUIForegroundColor1);
    set(DMIWizard_MRS_Object,'FontName',handles.GUIFontName);
    set(DMIWizard_MRS_Object,'FontSize',handles.GUIFontSize);
end;

DMIWizard_MRS_Object = findall(0,'Tag','Text_FAorder');
set(DMIWizard_MRS_Object,'BackgroundColor',handles.GUIBackgroundColor1);
set(DMIWizard_MRS_Object,'ForegroundColor',handles.GUIForegroundColor1);
set(DMIWizard_MRS_Object,'FontName',handles.GUIFontName);
set(DMIWizard_MRS_Object,'FontSize',(0.83/0.56)*handles.GUIFontSize);

% Objects with time-domain-related colors
DMIWizard_MRS.Object2{1} = 'MetaboliteFile_edit';
DMIWizard_MRS.Object2{2} = 'SelectMetaboliteFile_pushbutton';
DMIWizard_MRS.Object2{3} = 'LoadMetaboliteFile_pushbutton';
DMIWizard_MRS.Object2{4} = 'FIDSaveFilePath_edit';
DMIWizard_MRS.Object2{5} = 'FIDSelectSaveFilePath_pushbutton';
DMIWizard_MRS.Object2{6} = 'FIDSaveToFilePath_pushbutton';

DMIWizard_MRS.Object2{7} = 'InitialNumOfFIDs_edit';
DMIWizard_MRS.Object2{8} = 'NumOfExperiments_edit';
DMIWizard_MRS.Object2{9} = 'NumberOfReceivers_edit';
DMIWizard_MRS.Object2{10} = 'NumberOfRepititions_edit';
DMIWizard_MRS.Object2{11} = 'FinalNumOfFIDs_edit';
DMIWizard_MRS.Object2{12} = 'FIDtrunction_edit';
DMIWizard_MRS.Object2{13} = 'GroupDelay_edit';

for c1 = 1:numel(DMIWizard_MRS.Object2);
    DMIWizard_MRS_Object = findall(0,'Tag',char(DMIWizard_MRS.Object2(c1)));
    set(DMIWizard_MRS_Object,'BackgroundColor',handles.GUIMRSColor1);
    set(DMIWizard_MRS_Object,'ForegroundColor',handles.GUIForegroundColor2);
    set(DMIWizard_MRS_Object,'FontName',handles.GUIFontName);
    set(DMIWizard_MRS_Object,'FontSize',handles.GUIFontSize);
end;

% Objects with frequency-domain-related colors
DMIWizard_MRS.Object3{1} = 'MRSSaveFilePath_edit';
DMIWizard_MRS.Object3{2} = 'MRSSelectSaveFilePath_pushbutton';
DMIWizard_MRS.Object3{3} = 'MRSSaveToFilePath_pushbutton';

DMIWizard_MRS.Object3{4} = 'SpectralBandwidth_edit';
DMIWizard_MRS.Object3{5} = 'ZeroOrderPhase_edit';
DMIWizard_MRS.Object3{6} = 'FirstOrderPhase_edit';
DMIWizard_MRS.Object3{7} = 'SpectrumNumber_edit';
DMIWizard_MRS.Object3{8} = 'SpectralPoints_edit';
DMIWizard_MRS.Object3{9} = 'ExponentialMultiply_edit';
DMIWizard_MRS.Object3{10} = 'GaussianMultiply_edit';
DMIWizard_MRS.Object3{11} = 'GaussianShift_edit';
DMIWizard_MRS.Object3{12} = 'FourierTransform_pushbutton';

DMIWizard_MRS.Object3{13} = 'LowFrequencyBoundary_edit';
DMIWizard_MRS.Object3{14} = 'HighFrequencyBoundary_edit';
DMIWizard_MRS.Object3{15} = 'LowIntensityBoundary_edit';
DMIWizard_MRS.Object3{16} = 'HighIntensityBoundary_edit';
DMIWizard_MRS.Object3{17} = 'IntensityScalingFactor_edit';
DMIWizard_MRS.Object3{18} = 'ZoomIn_pushbutton';
DMIWizard_MRS.Object3{19} = 'ZoomOut_pushbutton';

for c1 = 1:numel(DMIWizard_MRS.Object3);
    DMIWizard_MRS_Object = findall(0,'Tag',char(DMIWizard_MRS.Object3(c1)));
    set(DMIWizard_MRS_Object,'BackgroundColor',handles.GUIMRSColor2);
    set(DMIWizard_MRS_Object,'ForegroundColor',handles.GUIForegroundColor2);
    set(DMIWizard_MRS_Object,'FontName',handles.GUIFontName);
    set(DMIWizard_MRS_Object,'FontSize',handles.GUIFontSize);
end;

% Objects with calibration-related colors
DMIWizard_MRS.Object4{1} = 'RefFreqpushbutton';
DMIWizard_MRS.Object4{2} = 'ReferenceFrequency_edit';
DMIWizard_MRS.Object4{3} = 'CarrierFrequency_edit';
DMIWizard_MRS.Object4{4} = 'ReferencePPM_edit';

for c1 = 1:numel(DMIWizard_MRS.Object4);
    DMIWizard_MRS_Object = findall(0,'Tag',char(DMIWizard_MRS.Object4(c1)));
    set(DMIWizard_MRS_Object,'BackgroundColor',handles.GUIMRSColor3);
    set(DMIWizard_MRS_Object,'ForegroundColor',handles.GUIForegroundColor2);
    set(DMIWizard_MRS_Object,'FontName',handles.GUIFontName);
    set(DMIWizard_MRS_Object,'FontSize',handles.GUIFontSize);
end;

% Objects with baseline/integration-related colors
DMIWizard_MRS.Object5{1} = 'BaselineCorrectionDefine_pushbutton';
DMIWizard_MRS.Object5{2} = 'BaselineCorrectionCalculate_pushbutton';
DMIWizard_MRS.Object5{3} = 'BaselineCorrectionCorrect_pushbutton';
DMIWizard_MRS.Object5{4} = 'IntegrationDefine_pushbutton';
DMIWizard_MRS.Object5{5} = 'IntegrationIntegrate_pushbutton';
DMIWizard_MRS.Object5{6} = 'ShiftPickPeak_pushbutton';
DMIWizard_MRS.Object5{7} = 'PickNoise_pushbutton';

for c1 = 1:numel(DMIWizard_MRS.Object5);
    DMIWizard_MRS_Object = findall(0,'Tag',char(DMIWizard_MRS.Object5(c1)));
    set(DMIWizard_MRS_Object,'BackgroundColor',handles.GUIMRSColor4);
    set(DMIWizard_MRS_Object,'ForegroundColor',handles.GUIForegroundColor2);
    set(DMIWizard_MRS_Object,'FontName',handles.GUIFontName);
    set(DMIWizard_MRS_Object,'FontSize',handles.GUIFontSize);
end;

% Objects with generic color 2 (typically white entry boxes)
DMIWizard_MRS.Object6{1} = 'WaterFile_edit';
DMIWizard_MRS.Object6{2} = 'ConvSelectConsoleType_popupmenu';
DMIWizard_MRS.Object6{3} = 'FrequencyAlignmentOrder';
DMIWizard_MRS.Object6{4} = 'BaselineCorrectionOrder';

for c1 = 1:numel(DMIWizard_MRS.Object6);
    DMIWizard_MRS_Object = findall(0,'Tag',char(DMIWizard_MRS.Object6(c1)));
    set(DMIWizard_MRS_Object,'BackgroundColor',handles.GUIBackgroundColor2);
    set(DMIWizard_MRS_Object,'ForegroundColor',handles.GUIForegroundColor2);
    set(DMIWizard_MRS_Object,'FontName',handles.GUIFontName);
    set(DMIWizard_MRS_Object,'FontSize',handles.GUIFontSize);
end;

MetaboliteFile_edit_Object = findall(0,'Tag','MetaboliteFile_edit');
set(MetaboliteFile_edit_Object,'String',handles.GUIDefaultPath);

WaterFile_edit_Object = findall(0,'Tag','WaterFile_edit');
set(WaterFile_edit_Object,'String',handles.GUIDefaultPath);

MRSSaveFilePath_edit_Object = findall(0,'Tag','MRSSaveFilePath_edit');
set(MRSSaveFilePath_edit_Object,'String',handles.GUIDefaultPath);

FIDSaveFilePath_edit_Object = findall(0,'Tag','FIDSaveFilePath_edit');
set(FIDSaveFilePath_edit_Object,'String',handles.GUIDefaultPath);