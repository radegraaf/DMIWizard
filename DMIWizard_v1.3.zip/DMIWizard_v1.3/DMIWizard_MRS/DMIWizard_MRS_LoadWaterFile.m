function FIDw = DMIWizard_MRS_LoadWaterFile(handles)
%**************************************************************************
% Function for reading in water file
% NEEDS OFFICIAL SUPPORT FOR PHILIPS AND SIEMENS FILE TYPES
%**************************************************************************

switch handles.ConsoleType
    case 'Bruker'
        fileID = fopen(handles.WaterFile,'r+');
    case {'Varian','Bruker-SGI','Varian-SUN'}
        fileID = fopen(handles.WaterFile,'r+','b');
    case 'Philips'
        fileID = 1; % May not be correct
    case 'Siemens'
        fileID = fopen(handles.WaterFile,'r+'); % May not be correct
    case 'DMI-Wizard'
        fileID = -1;
end

if fileID < 0
    errordlg('File not found','File Error');
else
    disp(' ');
    
    switch handles.ConsoleType
        case 'Bruker'
            disp('Reading Bruker data ...');
            
            indata1 = fread(fileID, inf, 'long');
            fclose(fileID);

            % Note: Bruker data = (R, I)
            FIDw = indata1(1:2:length(indata1)) + 1i*indata1(2:2:length(indata1));
           
            disp('... done.');
        case 'Varian'
            disp('Reading Varian data ...');
            
            % Read file header
            FileHeader = fread(fileID,8,'long');
            %************************************
            % File header structure:
            % 1 = number of blocks
            % 2 = number of traces per block
            % 3 = number of elements per trace
            %************************************
            nbtemp = FileHeader(1);
            nttemp = FileHeader(2);
            nptemp = FileHeader(3);

            disp(' ');
            disp('File header information: ');
            dd1 = ['Number of blocks per file = ' num2str(nbtemp)];
            dd2 = ['Number of traces per block = ' num2str(nttemp)];
            dd3 = ['Number of points per trace = ' num2str(nptemp)];
            disp(dd1); disp(dd2); disp(dd3); disp(' ');
            
            indata1 = zeros(nbtemp*nttemp*nptemp,1);
            for kk1 = 1:1:nbtemp
                [fileID] = fread(fileID,7,'long');
                indata1((kk1-1)*nttemp*nptemp+1:1:kk1*nttemp*nptemp) = fread(fileID,nttemp*nptemp,'float');
            end
            fclose(fileID);

            indata1 = reshape(indata1,nptemp*nttemp*nbtemp,1);

            FIDw = zeros(round(0.5*nbtemp*nttemp*nptemp),1);
            
            % Note: Varian data = (I, R)
            for kk1 = 1:1:round(0.5*length(indata1))
                FIDw(kk1) = indata1(2*kk1) + 1i*indata1(2*kk1-1);
            end
            
            disp('... done');
        case 'Bruker-SGI'
            disp('Reading Bruker SGI data ...');
            
            indata1 = fread(fileID, inf, 'long');
            fclose(fileID);

            % Note: Bruker data = (R, I)
            FIDw = indata1(1:2:length(indata1)) + 1i*indata1(2:2:length(indata1));

        case 'Varian-SUN'
            disp('Reading Varian SUN data ...');
            
            % Read file header
            FileHeader = fread(fileID,8,'long');
            %************************************
            % File header structure:
            % 1 = number of blocks
            % 2 = number of traces per block
            % 3 = number of elements per trace
            %************************************
            nbtemp = FileHeader(1);
            nttemp = FileHeader(2);
            nptemp = FileHeader(3);

            disp(' ');
            disp('File header information: ');
            dd1 = ['Number of blocks per file = ' num2str(nbtemp)];
            dd2 = ['Number of traces per block = ' num2str(nttemp)];
            dd3 = ['Number of points per trace = ' num2str(nptemp)];
            disp(dd1); disp(dd2); disp(dd3); disp(' ');
            
            indata1 = zeros(nbtemp*nttemp*nptemp,1);
            for kk1 = 1:1:nbtemp;
                [fileID] = fread(fileID,7,'long');
                indata1((kk1-1)*nttemp*nptemp+1:1:kk1*nttemp*nptemp) = fread(fileID,nttemp*nptemp,'float');
            end;
            fclose(fileID);

            indata1 = reshape(indata1,nptemp*nttemp*nbtemp,1);

            FIDw = zeros(round(0.5*nbtemp*nttemp*nptemp),1);
            
            % Note: Varian data = (I, R)
            for kk1 = 1:1:round(0.5*length(indata1))
                FIDw(kk1) = indata1(2*kk1) + 1i*indata1(2*kk1-1);
            end
            
            disp('... done');
        case 'Philips' % May be wrong
            disp('Reading Philips raw data ...');
                        
            [FIDw,info] = DMIWizard_MRS_LoadPhilipsData(handles.MetaboliteFile);
            
            disp('... done.');

            FIDw = reshape(FIDw,numel(FIDw),1);
            
            dsf = 8;
                 
            dd = ['Downsampling Philips data by a factor of ' num2str(dsf) ' ...'];
            disp(dd);
            
            FIDw = reshape(FIDw,8,round(numel(FIDw)/8));
            
            FIDw = squeeze(sum(FIDw,1));  
            
            disp('... done.');
        case 'Siemens' % May be wrong
            FIDw = fopen(handles.WaterFile,'r','l','US-ASCII');
            fseek(FIDw,0,'eof');
            fileSize = ftell(FIDw);
            fseek(FIDw,0,'bof');
            firstInt  = fread(FIDw,1,'uint32');
            fclose(FIDw);
    end
    figure(1);
    plot(real(FIDw(:,1)));
    axis([1 length(FIDw) min(real(FIDw(:,1))) max(real(FIDw(:,1)))])
    
    disp(' ');
    dd1 = ['Loading ' handles.WaterFile ' ... done.'];
    disp(dd1);
end