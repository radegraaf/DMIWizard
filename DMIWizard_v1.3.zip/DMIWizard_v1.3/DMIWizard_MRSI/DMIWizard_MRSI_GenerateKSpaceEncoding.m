function [KSpaceCoor1, KSpaceCoor2, KSpaceCoor3] = DMIWizard_MRSI_GenerateKSpaceEncoding(np1, np2, np3, KSpacePattern)

% Generate a 'column-order array' = 0, -1, +1, -2, +2, -3, +3, ... */
ColumnOrder = zeros(1,128);
for c1 = 0:2:127;
    ColumnOrder(c1+1) = round(c1/2);
    ColumnOrder(c1+2) = -round((c1+1)/2);
end;

%**************************************************
%* Generate the various k-space sampling patterns 
%**************************************************
switch KSpacePattern
    case 'cubic'
        % Cubically sampled MRSI 
        count = 1;
        for c3 = 0:1:np3-1;
            for c2 = 0:1:np2-1;
                for c1 = 0:1:np1-1;
                    KSpaceCoor1(count) = -1.0 + 2.0*c1/np1;
                    KSpaceCoor2(count) = -1.0 + 2.0*c2/np2;
                    KSpaceCoor3(count) = -1.0 + 2.0*c3/np3;
                    count = count + 1;
                end;
            end;
        end;
        
        % Round values to prevent issues with variable machine 
        % precision on different platforms.
        KSpaceCoor1 = (10^-4)*round(KSpaceCoor1*10^4);
        KSpaceCoor2 = (10^-4)*round(KSpaceCoor2*10^4);
        KSpaceCoor3 = (10^-4)*round(KSpaceCoor3*10^4);
        
    case 'sphere'
        % Spherically sampled MRSI
                 
        KSpaceA = zeros(np1,np2,np3);
        KSpaceB = zeros(np1,np2,np3);
        KSpaceC = zeros(np1,np2,np3);
        % First define regular, rectangular grid
        for c3 = 0:1:np3-1;
            for c2 = 0:1:np2-1;
                for c1 = 0:1:np1-1;
                    KSpaceA(c1+1,c2+1,c3+1) = -1.0 + 2.0*c1/np1;
                    KSpaceB(c1+1,c2+1,c3+1) = -1.0 + 2.0*c2/np2;
                    KSpaceC(c1+1,c2+1,c3+1) = -1.0 + 2.0*c3/np3;
                end;
            end;
        end;
        
        % Round values to prevent issues with variable machine 
        % precision on different platforms.
        KSpaceA = (10^-4)*round(KSpaceA*10^4);
        KSpaceB = (10^-4)*round(KSpaceB*10^4);
        KSpaceC = (10^-4)*round(KSpaceC*10^4);
        
        % Second, put values in final arrays while checking if 
        % they fall within circular k-space area.               
        count = 1;
        for c3 = 0:1:np3-1;
            for c2 = 0:1:np2-1;
                for c1 = 0:1:np1-1;
                    if (KSpaceA(c1+1,c2+1,c3+1)*KSpaceA(c1+1,c2+1,c3+1) + ...
                            KSpaceB(c1+1,c2+1,c3+1)*KSpaceB(c1+1,c2+1,c3+1) + ...
                            KSpaceC(c1+1,c2+1,c3+1)*KSpaceC(c1+1,c2+1,c3+1) <= 1.0)
                            
                        KSpaceCoor1(count) = KSpaceA(c1+1,c2+1,c3+1);
                        KSpaceCoor2(count) = KSpaceB(c1+1,c2+1,c3+1);
                        KSpaceCoor3(count) = KSpaceC(c1+1,c2+1,c3+1);
                        count = count + 1;
                    end;
                end;
            end;
        end;
end;