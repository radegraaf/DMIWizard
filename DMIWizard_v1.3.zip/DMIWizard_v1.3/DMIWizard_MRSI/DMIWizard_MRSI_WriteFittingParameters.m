function DMIWizard_MRSI_WriteFittingParameters(handles)

%**************************************************************************
% DMIWizard_MRSI_WriteFittingParameters.m
%
% Write spectral fitting parameters to disk (fitting results are saved
% in a separate file).
%**************************************************************************

ppmlow = handles.RFCenterFrequency - 1000*handles.ZxHigh/handles.nu0;
ppmhigh = handles.RFCenterFrequency - 1000*handles.ZxLow/handles.nu0;

output1A = ['Number of resonances       = ' num2str(handles.nres) '\n'];
output1B = ['Frequency low (kHz)        = ' num2str(handles.ZxLow) '\n'];
output1C = ['Frequency low (ppm)        = ' num2str(ppmlow) '\n'];
output1D = ['Frequency high (kHz)       = ' num2str(handles.ZxHigh) '\n'];
output1E = ['Frequency high (ppm)       = ' num2str(ppmhigh) '\n'];
output1F1 = ['Intensity scaling factor   = ' num2str(handles.ZyScale) '\n'];
output1F2 = ['Threshold (percent)        = ' num2str(handles.intth) '\n'];

output1G = ['Basis set directory        = ' handles.BasisSetDir];
output1H = ['Prior knowledge file       = ' handles.PKFile];

output1I = ['Shift reference (ppm)      = ' num2str(handles.ShiftReference) '\n'];
output1J = ['Shift reference (kHz)      = ' num2str(handles.ShiftReferencekHz) '\n'];
output1K = ['RF center frequency (ppm)  = ' num2str(handles.RFCenterFrequency) '\n'];
output1L = ['Baseline order             = ' num2str(handles.BaselineOrder) '\n'];
output1M = ['Number of iterations       = ' num2str(handles.NumberOfIterations) '\n'];
output1N = ['Base line shape            = ' handles.LineShapeSelection '\n'];
output1O = ['Line shape distortion      = ' num2str(handles.LineShapeDistortion) '\n'];
output1P = ['Maximum global offset (Hz) = ' num2str(handles.MaximumGlobalOffset) '\n'];
output1Q = ['Phase correction           = ' handles.PhaseSelection '\n'];
output1R = ['First-order phase estimate = ' num2str(handles.FirstOrderPhaseEstimate) '\n'];
if (handles.FirstOrderFix > 0)
    output1S = ['Fixed first-order phase    = Y\n'];
else
    output1S = ['Fixed first-order phase    = N\n'];
end;

% Extract directory for saving purposes
if ismac
    % Mac plaform
    coor = find(handles.MRSIPath == '/');
elseif isunix
    % Linux plaform
    coor = find(handles.MRSIPath == '/');
elseif ispc
    % Windows platform
    coor = find(handles.MRSIPath == '\');
end               
MRSIPathDir = handles.MRSIPath(1:max(coor));
            
file = [MRSIPathDir '\FittingParameters.txt'];
fileID = fopen(file,'w');
fprintf(fileID,output1A); fprintf(fileID,output1B); fprintf(fileID,output1C); 
fprintf(fileID,output1D); fprintf(fileID,output1E);
fprintf(fileID,output1F1); fprintf(fileID,output1F2);
fprintf(fileID,'%s\n',output1G); fprintf(fileID,'%s\n',output1H);
fprintf(fileID,output1I); fprintf(fileID,output1J); fprintf(fileID,output1K); 
fprintf(fileID,output1L); fprintf(fileID,output1M); fprintf(fileID,output1N); 
fprintf(fileID,output1O); fprintf(fileID,output1P); fprintf(fileID,output1Q);
fprintf(fileID,output1R); fprintf(fileID,output1S);
fclose(fileID);

[OperationTime,~] = DMIWizard_MRSI_CalculateTime;
TextOutput1 = [OperationTime ' - Fitting parameters written to: ' file];
disp(' '); disp(TextOutput1);