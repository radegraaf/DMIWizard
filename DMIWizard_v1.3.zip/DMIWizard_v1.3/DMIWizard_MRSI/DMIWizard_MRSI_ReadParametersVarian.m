function [FOV1, FOV2, FOV3, sw, np1, np2, np3, np, npb, ...
    nav, nrec, nu0] = DMIWizard_MRSI_ReadParametersVarian(MRSParameterFileVarian)

npb = 0;        % Bruker specific number
nrec = 1;       % One receiver
nav = 1;        % Averages are assumed to be summed during acquisition
np1 = 11;       % For the current pulse sequence, number of encodes is fixed to 11
np2 = 11;       % For the current pulse sequence, number of encodes is fixed to 11
np3 = 11;       % For the current pulse sequence, number of encodes is fixed to 11
FOV1 = 33;
FOV2 = 33;
FOV3 = 33;
nu0 = 61.4122459;

% Reading entire procpar parameter file
fileID = fopen(MRSParameterFileVarian,'r');
Data = textscan(fileID, '%s', 'delimiter', '\n', 'whitespace', '');
CStr = Data{1};

% Scanning for particular parameters
% 1. Spectral width
IndexSWH = strfind(CStr, 'sw ');
Index = find(~cellfun('isempty', IndexSWH), 1);
LineSWH = char(CStr(Index+1));

sw = 0.001*str2num(LineSWH(3:end));

% 2. Number of acquisition points
IndexNP = strfind(CStr, 'np ');
Index = find(~cellfun('isempty', IndexNP), 1);
LineNP = char(CStr(Index+1));

np = round(0.5*str2num(LineNP(3:end)));

% KSpaceSamplingName = 'Spherical_linear';
% switch KSpaceSamplingName
%     case 'Cubic_linear'
%         KSpaceSamplingScheme = 1;
%     case 'Spherical_linear'
%         KSpaceSamplingScheme = 2;
% end;

% Display parameters
disp(' ');
disp('Reading Varian parameters ...');
dd1 = ['Spectral width = ' num2str(sw,6) ' kHz'];
dd2 = ['Number of acquisition points = ' num2str(np)];
disp(dd1); disp(dd2);
disp('... done.');

fclose(fileID);