function [sw, carfreq] = DMIWizard_MRS_ReadParametersVarian(MRSParameterFileVarian)

% Reading entire procpar parameter file
fileID = fopen(MRSParameterFileVarian,'r');
Data = textscan(fileID, '%s', 'delimiter', '\n', 'whitespace', '');
CStr = Data{1};

% Scanning for particular parameters
% 1. Spectral width
IndexSWH = strfind(CStr, 'sw ');
Index = find(~cellfun('isempty', IndexSWH), 1);
LineSWH = char(CStr(Index+1));

sw = 0.001*str2num(LineSWH(3:end));

% 2. Carrier frequency
IndexCF = strfind(CStr, 'sfrq ');
Index = find(~cellfun('isempty', IndexCF));
LineCF = char(CStr(Index+1));

% A typical procpar file has multiple 'sfrq ' entries.
% Select the correct one based on the value (> 10 MHz).
for c1 = 1:size(LineCF,1);
    CFvalue = str2num(LineCF(c1,3:end));
    if (CFvalue > 10)
        carfreq = CFvalue;
    end;
end;

% Display parameters
disp(' ');
disp('Reading Varian parameters ...');
dd1 = ['Spectral width = ' num2str(sw,6) ' kHz'];
dd2 = ['Carrier frequency = ' num2str(carfreq,6) ' MHz'];
disp(dd1); disp(dd2);
disp('... done.');

fclose(fileID);