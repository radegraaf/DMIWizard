function varargout = DMIWizard_Mapping(varargin)
% DMIWIZARD_MAPPING MATLAB code for DMIWizard_Mapping.fig
%      DMIWIZARD_MAPPING, by itself, creates a new DMIWIZARD_MAPPING or raises the existing
%      singleton*.
%
%      H = DMIWIZARD_MAPPING returns the handle to a new DMIWIZARD_MAPPING or the handle to
%      the existing singleton*.
%
%      DMIWIZARD_MAPPING('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DMIWIZARD_MAPPING.M with the given input arguments.
%
%      DMIWIZARD_MAPPING('Property','Value',...) creates a new DMIWIZARD_MAPPING or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before DMIWizard_Mapping_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to DMIWizard_Mapping_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help DMIWizard_Mapping

% Last Modified by GUIDE v2.5 07-Jan-2022 10:08:30

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @DMIWizard_Mapping_OpeningFcn, ...
                   'gui_OutputFcn',  @DMIWizard_Mapping_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before DMIWizard_Mapping is made visible.
function DMIWizard_Mapping_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to DMIWizard_Mapping (see VARARGIN)

% Choose default command line output for DMIWizard_Mapping
handles.output = hObject;

% Set Position/Size of Figure Based on Screen Size
set(groot,'Units','points');
ScreenSize = get(groot,'ScreenSize');
ScreenWidth = ScreenSize(3);
ScreenHeight = ScreenSize(4);

FigXPos = .605*ScreenWidth; % .02
FigYPos = .5425*ScreenHeight; % .2275
FigWidth = .30*ScreenWidth; % .18
FigHeight = .3575*ScreenHeight; %.6725

% Read DMIWizard settings
handles = DMIWizard_MRSI_ReadSettings(handles);

set(hObject,'Units','points','Position',[FigXPos FigYPos FigWidth FigHeight],...
    'Color',handles.GUIBackgroundColor1);

% Update handles structure
guidata(hObject, handles);

Initialize_GUI(hObject,eventdata,handles);


% --- Outputs from this function are returned to the command line.
function varargout = DMIWizard_Mapping_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

function Initialize_GUI(hObject,eventdata,handles)

% Extract parameters from main window
handles = ExtractParametersFromDMIWizardMainWindow(hObject, eventdata, handles);

handles.Map1Path = handles.GUIDefaultPath;
handles.Map2Path = handles.GUIDefaultPath;
handles.Map3Path = handles.GUIDefaultPath;

handles.MapOperation = 1;
MapOperation_Object = findall(0,'Tag','MapOperationPopupMenu');
set(MapOperation_Object,'TooltipString','Select mathematical operation (+, /, x, -)');

handles.Input1Type = 1;
Input1Type_Object = findall(0,'Tag','Input1PopupMenu');
set(Input1Type_Object,'TooltipString','Indicate a constant (double) or map ID (integer).');

handles.Input2Type = 1;
Input2Type_Object = findall(0,'Tag','Input2PopupMenu');
set(Input2Type_Object,'TooltipString','Indicate a constant (double) or map ID (integer).');

handles.Input1 = 1;
Input1_Object = findall(0,'Tag','Input1Edit');
set(Input1_Object,'TooltipString','Input 1 constant.');

handles.InputMap1 = 'metabolic map 1';
InputMap1_Object = findall(0,'Tag','InputMap1Edit');
set(InputMap1_Object,'TooltipString','Input 1 map filename and location.');

SelectMap1PushButton_Object = findall(0,'Tag','SelectMap1PushButton');
set(SelectMap1PushButton_Object,'TooltipString','Select metabolic map 1.');

% Default visibility setting
InputMap1_Object = findall(0,'Tag','InputMap1Edit');
set(InputMap1_Object,'Visible','Off');
set(InputMap1_Object,'Enable','Off');
SelectMap1PushButton_Object = findall(0,'Tag','SelectMap1PushButton');
set(SelectMap1PushButton_Object,'Visible','Off');

handles.Input2 = 2;
Input2_Object = findall(0,'Tag','Input2Edit');
set(Input2_Object,'TooltipString','Input 2 constant.');

handles.InputMap2 = 'metabolic map 2';
InputMap2_Object = findall(0,'Tag','InputMap2Edit');
set(InputMap2_Object,'TooltipString','Input 2 map filename and location.');

SelectMap2PushButton_Object = findall(0,'Tag','SelectMap2PushButton');
set(SelectMap2PushButton_Object,'TooltipString','Select metabolic map 2.');

% Default visibility setting
InputMap2_Object = findall(0,'Tag','InputMap2Edit');
set(InputMap2_Object,'Visible','Off');
set(InputMap2_Object,'Enable','Off');
SelectMap2PushButton_Object = findall(0,'Tag','SelectMap2PushButton');
set(SelectMap2PushButton_Object,'Visible','Off');

% Initialize metabolic maps in case 'Calculate' is pressed without 
% loading maps from file.
switch handles.Orientation
    case 1       
        % Axial plane 
        handles.MetabolicMapInput1 = handles.Input1*ones(handles.np1,handles.np2);
        handles.MetabolicMapInput2 = handles.Input2*ones(handles.np1,handles.np2);
        handles.ROI = ones(handles.np1,handles.np2);
    case 2       
        % Coronal plane 
        handles.MetabolicMapInput1 = handles.Input1*ones(handles.np1,handles.np3);
        handles.MetabolicMapInput2 = handles.Input2*ones(handles.np1,handles.np3);
        handles.ROI = ones(handles.np1,handles.np3);
    case 3       
        % Sagittal plane 
        handles.MetabolicMapInput1 = handles.Input1*ones(handles.np2,handles.np3);
        handles.MetabolicMapInput2 = handles.Input2*ones(handles.np2,handles.np3);
        handles.ROI = ones(handles.np2,handles.np3);
end;

handles.Map3Path = 'metabolic map output';
OutputID_Object = findall(0,'Tag','OutputIDEdit');
set(OutputID_Object,'TooltipString','Output map filename and location.');

SelectMap3PushButton_Object = findall(0,'Tag','SelectMap3PushButton');
set(SelectMap3PushButton_Object,'TooltipString','Select output metabolic map.');

handles.Map4Path = 'ROI map';
ROIMap_Object = findall(0,'Tag','ROIMapEdit');
set(ROIMap_Object,'TooltipString','ROI map filename and location.');

SelectMap4PushButton_Object = findall(0,'Tag','SelectMap4PushButton');
set(SelectMap4PushButton_Object,'TooltipString','Select ROI map.');

% Default visibility setting
ROIMap_Object = findall(0,'Tag','ROIMapEdit');
set(ROIMap_Object,'Enable','Off');

handles.MaximumMapIntensity = 10;
MaximumMapIntensity_Object = findall(0,'Tag','MaximumMapIntensityEdit');
set(MaximumMapIntensity_Object,'TooltipString','Maximum metabolic map intensity.');
handles.MaximumMapIntensityPreviousValue = 10;

handles.MaximumMRIIntensity = 200;
MaximumMRIIntensity_Object = findall(0,'Tag','MaximumMRIIntensityEdit');
set(MaximumMRIIntensity_Object,'TooltipString','Maximum MRI intensity.');
handles.MaximumMRIIntensityPreviousValue = 100;

handles.MapShift = 0;
MapShift_Object = findall(0,'Tag','MapShiftEdit');
set(MapShift_Object,'TooltipString','Map shift (in number of pixels).');
handles.MapShiftPreviousValue = 0;

CalculateMapPushButton_Object = findall(0,'Tag','CalculateMapPushButton');
set(CalculateMapPushButton_Object,'TooltipString','Calculate metabolic map based on inputs 1 and 2.');

DisplayMapPushButton_Object = findall(0,'Tag','DisplayMapPushButton');
set(DisplayMapPushButton_Object,'TooltipString','Display calculated metabolic map.');

handles = ExtractParametersFromDMIWizardMainWindow(hObject, eventdata, handles);

% Update current handles in workspace
assignin('base','currentHandles2',handles)

% Update handles structure
guidata(hObject, handles);

function handles = ExtractParametersFromDMIWizardMainWindow(hObject, eventdata, handles)

% Retrieve and update GUI data structure from DMIWizard MRSI window
DMIWizard_MRSI_Object = findall(0,'Name','DMIWizard_MRSI');
handlesMRSI = guidata(DMIWizard_MRSI_Object);

% Extract parameters from main DMIWizard window and add to handles
handles.Orientation = handlesMRSI.Orientation;
handles.sp1 = handlesMRSI.sp1;
handles.sp2 = handlesMRSI.sp2;
handles.sp3 = handlesMRSI.sp3;
handles.sp4 = handlesMRSI.sp4;

handles.np1 = handlesMRSI.np1;
handles.np2 = handlesMRSI.np2;
handles.np3 = handlesMRSI.np3;

handles.np1mri = handlesMRSI.np1mri;
handles.np2mri = handlesMRSI.np2mri;
handles.np3mri = handlesMRSI.np3mri;

handles.np1ext = handlesMRSI.np1ext;
handles.np2ext = handlesMRSI.np2ext;
handles.np3ext = handlesMRSI.np3ext;

if (isfield(handlesMRSI,'ProcessingHistoryFile') == 1)
    handles.ProcessingHistoryFile = handlesMRSI.ProcessingHistoryFile;
end;
handles.MRSIPath = handlesMRSI.MRSIPath;

if (isfield(handlesMRSI,'MRI') > 0)
    handles.MRI = handlesMRSI.MRI;
else
    [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
    WarningOutput1 = [OperationTime ' - Warning : MRI does not exist.'];
    WarningOutput2 = [OperationTime ' - Warning : Continuing with uniform MRI.'];
    disp(WarningOutput1); disp(WarningOutput2);
    
    handles.MRI = ones(handles.np1ext,handles.np2ext,handles.np3ext);
end;

handles.MRIScale = handlesMRSI.MRIScale;
if (isfield(handles,'ROI') > 0)
    % ROI is loaded and available from file
    handles.ROI = handles.ROI;
else
    if (isfield(handlesMRSI,'ROI') > 0)
        % ROI has been generated in the main DMIWizard window
        handles.ROI = handlesMRSI.ROI;
    else
        [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
        WarningOutput1 = [OperationTime ' - Warning : ROI does not exist.'];
        WarningOutput2 = [OperationTime ' - Warning : Continuing with uniform ROI.'];
        disp(WarningOutput1); disp(WarningOutput2);

        switch handles.Orientation
            case 1       
                % Axial plane 
                handles.ROI = ones(handles.np1ext,handles.np2ext);
            case 2       
                % Coronal plane 
                handles.ROI = ones(handles.np1ext,handles.np3ext);
            case 3       
                % Sagittal plane 
                handles.ROI = ones(handles.np2ext,handles.np3ext);
        end;
    end;
end;
handles.MRIBackground = handlesMRSI.MRIBackground;
handles.Interpolation = handlesMRSI.Interpolation;
handles.KernelWidth = handlesMRSI.KernelWidth;
handles.Transparency = handlesMRSI.Transparency;

% Update current handles in workspace
assignin('base','currentHandles2',handles)

% Update handles structure
guidata(hObject, handles);

% --- Executes on selection change in MapOperationPopupMenu.
function MapOperationPopupMenu_Callback(hObject, eventdata, handles)
contents = cellstr(get(hObject,'String'));
MapOperationSelection = contents{get(hObject,'Value')};

switch MapOperationSelection
    case 'Addition 1 + 2'
        handles.MapOperation = 1;
    case 'Division 1 / 2'
        handles.MapOperation = 2;
    case 'Multiplication 1 x 2'
        handles.MapOperation = 3;
    case 'Subtraction 1 - 2'
        handles.MapOperation = 4;
    case 'Shift 1 (dimension 1)'
        handles.MapOperation = 5;
    case 'Shift 1 (dimension 2)'
        handles.MapOperation = 6;
    case 'Shift 2 (dimension 1)'
        handles.MapOperation = 7;
    case 'Shift 2 (dimension 2)'
        handles.MapOperation = 8;
end

% Update current handles in workspace
assignin('base','currentHandles2',handles)

% Update handles structure
guidata(hObject,handles);


function MapOperationPopupMenu_CreateFcn(hObject, eventdata, ~)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function Input1PopupMenu_Callback(hObject, eventdata, handles)
% Extract parameters from main window
handles = ExtractParametersFromDMIWizardMainWindow(hObject, eventdata, handles);

contents = cellstr(get(hObject,'String'));
Input1Selection = contents{get(hObject,'Value')};

switch Input1Selection
    case 'Constant'
        handles.Input1Type = 1;
        
        % Make number entry visible
        Input1_Object = findall(0,'Tag','Input1Edit');
        set(Input1_Object,'Visible','On');
        
        % Make map name entry and selection invisible
        InputMap1_Object = findall(0,'Tag','InputMap1Edit');
        set(InputMap1_Object,'Visible','Off');
        set(InputMap1_Object,'Enable','Off');
        SelectMap1PushButton_Object = findall(0,'Tag','SelectMap1PushButton');
        set(SelectMap1PushButton_Object,'Visible','Off');
        
        % Generate constant-amplitude map
        switch handles.Orientation
            case 1       
                % Axial plane 
                handles.MetabolicMapInput1 = handles.Input1*ones(handles.np1,handles.np2);
            case 2       
                % Coronal plane 
                handles.MetabolicMapInput1 = handles.Input1*ones(handles.np1,handles.np3);
            case 3       
                % Sagittal plane 
                handles.MetabolicMapInput1 = handles.Input1*ones(handles.np2,handles.np3);
        end;
        
    case 'Map ID'
        handles.Input1Type = 2;
        
        % Make number entry invisible
        Input1_Object = findall(0,'Tag','Input1Edit');
        set(Input1_Object,'Visible','Off');
        
        % Make map name entry and selection visible
        InputMap1_Object = findall(0,'Tag','InputMap1Edit');
        set(InputMap1_Object,'Visible','On');
        set(InputMap1_Object,'Enable','Off');
        SelectMap1PushButton_Object = findall(0,'Tag','SelectMap1PushButton');
        set(SelectMap1PushButton_Object,'Visible','On');
end;

% Update current handles in workspace
assignin('base','currentHandles2',handles)

% Update handles structure
guidata(hObject,handles);

function Input1PopupMenu_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Input2PopupMenu_Callback(hObject, eventdata, handles)
% Extract parameters from main window
handles = ExtractParametersFromDMIWizardMainWindow(hObject, eventdata, handles);

contents = cellstr(get(hObject,'String'));
Input2Selection = contents{get(hObject,'Value')};

switch Input2Selection
    case 'Constant'
        handles.Input2Type = 1;
        
        % Make number entry invisible
        Input2_Object = findall(0,'Tag','Input2Edit');
        set(Input2_Object,'Visible','On');
        
        % Make map name entry and selection invisible
        InputMap2_Object = findall(0,'Tag','InputMap2Edit');
        set(InputMap2_Object,'Visible','Off');
        set(InputMap2_Object,'Enable','Off');
        SelectMap2PushButton_Object = findall(0,'Tag','SelectMap2PushButton');
        set(SelectMap2PushButton_Object,'Visible','Off');
        
        % Generate constant-amplitude map
        switch handles.Orientation
            case 1       
                % Axial plane 
                handles.MetabolicMapInput2 = handles.Input2*ones(handles.np1,handles.np2);
            case 2       
                % Coronal plane 
                handles.MetabolicMapInput2 = handles.Input2*ones(handles.np1,handles.np3);
            case 3       
                % Sagittal plane 
                handles.MetabolicMapInput2 = handles.Input2*ones(handles.np2,handles.np3);
        end;
        
    case 'Map ID'
        handles.Input2Type = 2;
        
        % Make number entry invisible
        Input2_Object = findall(0,'Tag','Input2Edit');
        set(Input2_Object,'Visible','Off');
        
        % Make map name entry and selection invisible
        InputMap2_Object = findall(0,'Tag','InputMap2Edit');
        set(InputMap2_Object,'Visible','On');
        set(InputMap2_Object,'Enable','Off');
        SelectMap2PushButton_Object = findall(0,'Tag','SelectMap2PushButton');
        set(SelectMap2PushButton_Object,'Visible','On');
end;

if (handles.Input2Type == 2)
    % Integer number for map ID
    handles.Input2 = round(handles.Input2);
    set(findall(0,'Tag','Input2Edit'),'String',handles.Input2);
end;

% Update current handles in workspace
assignin('base','currentHandles2',handles)

% Update handles structure
guidata(hObject,handles);

function Input2PopupMenu_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function OutputIDEdit_Callback(hObject, eventdata, handles)
handles.Map3Path = get(hObject,'String');

% Update current handles in workspace
assignin('base','currentHandles2',handles)

% Update handles structure
guidata(hObject,handles);

function OutputIDEdit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Input1Edit_Callback(hObject, eventdata, handles)
% Extract parameters from main window
handles = ExtractParametersFromDMIWizardMainWindow(hObject, eventdata, handles);

handles.Input1 = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.Input1) > 0) || (isinf(handles.Input1) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for input 1.'];
    ErrorMessage2 = ['Error: Input 1 set to a valid value (1).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.Input1 = 1;
    set(hObject,'String',handles.Input1);
end;

% Generate constant-amplitude map
switch handles.Orientation
    case 1       
        % Axial plane 
        handles.MetabolicMapInput1 = handles.Input1*ones(handles.np1,handles.np2);
    case 2       
        % Coronal plane 
        handles.MetabolicMapInput1 = handles.Input1*ones(handles.np1,handles.np3);
    case 3       
        % Sagittal plane 
        handles.MetabolicMapInput1 = handles.Input1*ones(handles.np2,handles.np3);
end;

% Update current handles in workspace
assignin('base','currentHandles2',handles)

% Update handles structure
guidata(hObject,handles);


function Input1Edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function Input2Edit_Callback(hObject, eventdata, handles)
% Extract parameters from main window
handles = ExtractParametersFromDMIWizardMainWindow(hObject, eventdata, handles);

handles.Input2 = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.Input2) > 0) || (isinf(handles.Input2) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for input 2.'];
    ErrorMessage2 = ['Error: Input 2 set to a valid value (1).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.Input2 = 1;
    set(hObject,'String',handles.Input2);
end;
% Generate constant-amplitude map
switch handles.Orientation
    case 1       
        % Axial plane 
        handles.MetabolicMapInput2 = handles.Input2*ones(handles.np1,handles.np2);
    case 2       
        % Coronal plane 
        handles.MetabolicMapInput2 = handles.Input2*ones(handles.np1,handles.np3);
    case 3       
        % Sagittal plane 
        handles.MetabolicMapInput2 = handles.Input2*ones(handles.np2,handles.np3);
end;

% Update current handles in workspace
assignin('base','currentHandles2',handles)

% Update handles structure
guidata(hObject,handles);

function Input2Edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function MaximumMapIntensityEdit_Callback(hObject, eventdata, handles)
handles.MaximumMapIntensity = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.MaximumMapIntensity) > 0) || (isinf(handles.MaximumMapIntensity) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for maximum map intensity.'];
    ErrorMessage2 = ['Error: Maximum map intensity set to valid default value (10).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.MaximumMapIntensity = 10.0;
    set(hObject,'String',handles.MaximumMapIntensity);
end;

% Force minimum map intensity above zero
if (handles.MaximumMapIntensity <= 0.0)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for maximum map intensity.'];
    ErrorMessage2 = ['Error: Maximum map intensity set to previous value (' num2str(handles.MaximumMapIntensityPreviousValue) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.MaximumMapIntensity = handles.MaximumMapIntensityPreviousValue;
    set(hObject,'String',handles.MaximumMapIntensity);
else
    set(hObject,'String',handles.MaximumMapIntensity);
end;

% Update previous value
handles.MaximumMapIntensityPreviousValue = handles.MaximumMapIntensity;

% Update current handles in workspace
assignin('base','currentHandles2',handles)

% Update handles structure
guidata(hObject,handles);

function MaximumMapIntensityEdit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function MaximumMRIIntensityEdit_Callback(hObject, eventdata, handles)
handles.MaximumMRIIntensity = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.MaximumMRIIntensity) > 0) || (isinf(handles.MaximumMRIIntensity) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for maximum MRI intensity.'];
    ErrorMessage2 = ['Error: Maximum MRI intensity set to valid default value (100).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.MaximumMRIIntensity = 100.0;
    set(hObject,'String',handles.MaximumMRIIntensity);
end;

% Force maximum MRI intensity above zero
if (handles.MaximumMRIIntensity <= 0.0)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for maximum MRI intensity.'];
    ErrorMessage2 = ['Error: Maximum MRI intensity set to previous value (' num2str(handles.MaximumMRIIntensityPreviousValue) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.MaximumMRIIntensity = handles.MaximumMRIIntensityPreviousValue;
    set(hObject,'String',handles.MaximumMRIIntensity);
else
    set(hObject,'String',handles.MaximumMRIIntensity);
end;

% Update previous value
handles.MaximumMRIIntensityPreviousValue = handles.MaximumMRIIntensity;

% Update current handles in workspace
assignin('base','currentHandles2',handles)

% Update handles structure
guidata(hObject,handles);

function MaximumMRIIntensityEdit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function MapShiftEdit_Callback(hObject, eventdata, handles)
handles.MapShift = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.MapShift) > 0) || (isinf(handles.MapShift) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for map shift.'];
    ErrorMessage2 = ['Error: Map shift set to valid default value (0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.MapShift = 0;
    set(hObject,'String',handles.MapShift);
end;

% Force map shift to be an integer
if (rem(abs(handles.MapShift),1) > 0.0)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for map shift.'];
    ErrorMessage2 = ['Error: Map shift set to integer value (' num2str(round(handles.MapShift)) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.MapShift = round(handles.MapShift);
    set(hObject,'String',handles.MapShift);
else
    set(hObject,'String',handles.MapShift);
end;

% Update previous value
handles.MapShiftPreviousValue = handles.MapShift;

% Update current handles in workspace
assignin('base','currentHandles2',handles)

% Update handles structure
guidata(hObject,handles);


function MapShiftEdit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end





% Executes the calculation of a new metabolic map based on input 1/2
function CalculateMapPushButton_Callback(hObject, eventdata, handles)

% Retrieve and update GUI data structure from DMIWizard MRSI window
DMIWizard_MRSI_Object = findall(0,'Name','DMIWizard_MRSI');
handlesMRSI = guidata(DMIWizard_MRSI_Object);

% Extract parameters from main DMIWizard window and add to handles
handles.Orientation = handlesMRSI.Orientation;
handles.sp1 = handlesMRSI.sp1;
handles.sp2 = handlesMRSI.sp2;
handles.sp3 = handlesMRSI.sp3;
handles.sp4 = handlesMRSI.sp4;

handles.np1 = handlesMRSI.np1;
handles.np2 = handlesMRSI.np2;
handles.np3 = handlesMRSI.np3;

handles.np1mri = handlesMRSI.np1mri;
handles.np2mri = handlesMRSI.np2mri;
handles.np3mri = handlesMRSI.np3mri;
handles.np1ext = handlesMRSI.np1ext;
handles.np2ext = handlesMRSI.np2ext;
handles.np3ext = handlesMRSI.np3ext;

if (isfield(handles,'ProcessingHistoryFile') > 0)
    handles.ProcessingHistoryFile = handlesMRSI.ProcessingHistoryFile;
end;
handles.MRSIPath = handlesMRSI.MRSIPath;

if (isfield(handlesMRSI,'MRI') == 1)
    handles.MRI = handlesMRSI.MRI;
end;
handles.MRIScale = handlesMRSI.MRIScale;

if (isfield(handles,'ROI') > 0)
    % ROI is loaded and available from file
    handles.ROI = handles.ROI;
else
    if (isfield(handlesMRSI,'ROI') > 0)
        % ROI has been generated in the main DMIWizard window
        handles.ROI = handlesMRSI.ROI;
    else
        [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
        WarningOutput1 = [OperationTime ' - Warning : ROI does not exist.'];
        WarningOutput2 = [OperationTime ' - Warning : Continuing with uniform ROI.'];
        disp(WarningOutput1); disp(WarningOutput2);

        switch handles.Orientation
            case 1       
                % Axial plane 
                handles.ROI = ones(handles.np1ext,handles.np2ext);
            case 2       
                % Coronal plane 
                handles.ROI = ones(handles.np1ext,handles.np3ext);
            case 3       
                % Sagittal plane 
                handles.ROI = ones(handles.np2ext,handles.np3ext);
        end;
    end;
end;

handles.MRIBackground = handlesMRSI.MRIBackground;
handles.Interpolation = handlesMRSI.Interpolation;
handles.KernelWidth = handlesMRSI.KernelWidth;
handles.Transparency = handlesMRSI.Transparency;

% Perform mathematical operation
switch handles.MapOperation
    case 1
        % Addition 1 + 2
        handles.MetabolicMapOutput = handles.MetabolicMapInput1 + handles.MetabolicMapInput2;
    case 2
        % Division 1 / 2
        handles.MetabolicMapOutput = handles.MetabolicMapInput1./handles.MetabolicMapInput2;
    case 3
        % Multiplication 1 x 2
        handles.MetabolicMapOutput = handles.MetabolicMapInput1.*handles.MetabolicMapInput2;
    case 4
        % Subtraction 1 - 2
        handles.MetabolicMapOutput = handles.MetabolicMapInput1 - handles.MetabolicMapInput2;
    case 5
        % Shifting map 1 along dimension 1       
        [x,~] = ndgrid(1:1:size(handles.MetabolicMapInput1,1),1:1:size(handles.MetabolicMapInput1,2));
        ShiftMatrix = exp(2*pi*1i*handles.MapShift*x/size(handles.MetabolicMapInput1,1));
        MapFID = ifftshift(ifft2(ifftshift(handles.MetabolicMapInput1)));
        handles.MetabolicMapOutput = abs(fftshift(fft2(MapFID.*ShiftMatrix)));
    case 6
        % Shifting map 1 along dimension 2
        [~,y] = ndgrid(1:1:size(handles.MetabolicMapInput1,1),1:1:size(handles.MetabolicMapInput1,2));
        ShiftMatrix = exp(2*pi*1i*handles.MapShift*y/size(handles.MetabolicMapInput1,2));
        MapFID = ifftshift(ifft2(ifftshift(handles.MetabolicMapInput1)));
        handles.MetabolicMapOutput = abs(fftshift(fft2(MapFID.*ShiftMatrix)));        
    case 7
        % Shifting map 2 along dimension 1
        [x,~] = ndgrid(1:1:size(handles.MetabolicMapInput2,1),1:1:size(handles.MetabolicMapInput2,2));
        ShiftMatrix = exp(2*pi*1i*handles.MapShift*x/size(handles.MetabolicMapInput2,1));
        MapFID = ifftshift(ifft2(ifftshift(handles.MetabolicMapInput2)));
        handles.MetabolicMapOutput = abs(fftshift(fft2(MapFID.*ShiftMatrix)));        
    case 8
        % Shifting map 2 along dimension 2
        [~,y] = ndgrid(1:1:size(handles.MetabolicMapInput2,1),1:1:size(handles.MetabolicMapInput2,2));
        ShiftMatrix = exp(2*pi*1i*handles.MapShift*y/size(handles.MetabolicMapInput2,2));
        MapFID = ifftshift(ifft2(ifftshift(handles.MetabolicMapInput2)));
        handles.MetabolicMapOutput = abs(fftshift(fft2(MapFID.*ShiftMatrix)));        
end;

% Remove NaN entries
coor = find(isnan(handles.MetabolicMapOutput) > 0);
handles.MetabolicMapOutput(coor) = 0;

fh = figure;
set(fh,'Name','Metabolic map calculation result');
min1 = min(handles.MetabolicMapInput1(:)); max1 = max(handles.MetabolicMapInput1(:));
if (min1 ~= max1)
    subplot(1,3,1), imshow(handles.MetabolicMapInput1,[min1 max1]); title('Input 1 (auto scaled)'); colorbar('horz');
else
    subplot(1,3,1), imshow(handles.MetabolicMapInput1,[max1-1 max1+1]); title('Input 1 (auto scaled)'); colorbar('horz');
end;
min2 = min(handles.MetabolicMapInput2(:)); max2 = max(handles.MetabolicMapInput2(:));
if (min2 ~= max2)
    subplot(1,3,2), imshow(handles.MetabolicMapInput2,[min2 max2]); title('Input 2 (auto scaled)'); colorbar('horz');
else
    subplot(1,3,2), imshow(handles.MetabolicMapInput2,[max2-1 max2+1]); title('Input 2 (auto scaled)'); colorbar('horz'); 
end;
subplot(1,3,3), imshow(handles.MetabolicMapOutput,[-1.0*handles.MaximumMapIntensity handles.MaximumMapIntensity]);
switch handles.MapOperation
    case 1
        title('Output = 1 + 2');
    case 2
        title('Output = 1 / 2');
    case 3
        title('Output = 1 * 2');
    case 4
        title('Output = 1 - 2');
end;
colormap('jet'); colorbar('horz');

if (strcmp(handles.Map3Path,'metabolic map output') > 0)
    [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
    TextOutput1 = [OperationTime ' - Error   : Invalid metabolic map output file. Output map not saved to disk.'];
    TextOutput2 = [OperationTime ' - Solution: Select valid filename and location.'];
    disp(' '); disp(TextOutput1); disp(TextOutput2); disp(' ');
else
    fileID = fopen(handles.Map3Path,'w+');
    fprintf(fileID,'%20.7f\n',reshape(handles.MetabolicMapOutput,1,[]));
    fclose(fileID);
    [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
    TextOutput1 = [OperationTime ' - Output metabolic map written to: ' handles.Map3Path];
    disp(TextOutput1);
end;

% Update current handles in workspace
assignin('base','currentHandles2',handles)

% Update handles structure
guidata(hObject,handles);


% Displays the new metabolic map based on input 1/2
function DisplayMapPushButton_Callback(hObject, eventdata, handles)

% Extract parameters from main window
handles = ExtractParametersFromDMIWizardMainWindow(hObject, eventdata, handles);

switch handles.Orientation
    case 1       
        % Axial plane
        if (handles.MRIBackground < 1)
            handles.MRIslice = ones(handles.np1ext,handles.np2ext);
        else
            handles.MRIslice = abs(squeeze(handles.MRI(:,:,handles.sp4)));
        end;

    case 2
        % Coronal plane
        if (handles.MRIBackground < 1)
            handles.MRIslice = ones(handles.np1ext,handles.np3ext);
        else
            handles.MRIslice = abs(squeeze(handles.MRI(:,handles.sp4,:)));
        end;

    case 3
        % Sagittal plane
        if (handles.MRIBackground < 1)
            handles.MRIslice = ones(handles.np2ext,handles.np3ext);
        else
            handles.MRIslice = abs(squeeze(handles.MRI(handles.sp4,:,:)));
        end;
end;
    
% Exception with 'Display' is pressed before 'Calculate'
if (isfield(handles,'MetabolicMapOutput') == 1)
    handles.MetabolicM0map = abs(handles.MetabolicMapOutput);
else
    switch handles.Orientation
        case 1       
            % Axial plane
            handles.MetabolicM0map = ones(handles.np1,handles.np2);
        case 2       
            % Coronal plane
            handles.MetabolicM0map = ones(handles.np1,handles.np3);
        case 3       
            % Sagittal plane
            handles.MetabolicM0map = ones(handles.np2,handles.np3);
    end;

    [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
    TextOutput1 = [OperationTime ' - Error   : No output map available.'];
    TextOutput2 = [OperationTime ' - Solution: Press Calculate first! Continuing with uniform output map of intensity 1.'];
    disp(' '); disp(TextOutput1); disp(TextOutput2); disp(' '); beep; 
end;

DMIWizard_MRSI_DisplayColorMapOverlayScaled(handles);

% Update current handles in workspace
assignin('base','currentHandles2',handles)

% Update handles structure
guidata(hObject,handles);


% --- Executes on button press in SelectMap1PushButton.
function SelectMap1PushButton_Callback(hObject, eventdata, handles)
% Extract parameters from main window
handles = ExtractParametersFromDMIWizardMainWindow(hObject, eventdata, handles);

% Prepare for when Cancel button is pressed
Map1PathCancel = handles.Map1Path;

% Get new file and path names
[filename, pathname] = uigetfile('*.*','Select metabolic map 1 file',handles.Map1Path);

% Action performed when Cancel button is pressed
if isequal(filename,0) || isequal(pathname,0)
    handles.Map1Path = Map1PathCancel;
else
    handles.Map1Path = [pathname filename];
end

% Read metabolic map 1 from file
switch handles.Orientation
    case 1       
        % Axial plane
        fileID = fopen(handles.Map1Path,'r');
        if (fileID > 0)
            datain = fscanf(fileID,'%g',[1 Inf]);
            fclose(fileID);
            
            if (numel(datain) ~= handles.np1*handles.np2)
                ErrorMessage1 = ['Error   : Metabolic map size (' num2str(numel(datain)) ...
                    ') not in agreement with DMI matrix dimensions (' num2str(handles.np1) 'x' num2str(handles.np2) ').'];
                ErrorMessage2 = ['Solution: Continuing with an uniform metabolic map of intensity 1.'];
                disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');

                handles.MetabolicMapInput1 = ones(handles.np1,handles.np2);
            else
                handles.MetabolicMapInput1 = reshape(datain,handles.np1,handles.np2);
                TextMessage1 = ['Metabolic map ' handles.Map1Path ' successfully loaded.'];
                disp(TextMessage1);
            end;
        else
            ErrorMessage1 = ['Error   : ' handles.Map1Path ' cannot be opened.'];
            ErrorMessage2 = ['Solution: Continuing with an uniform metabolic map of intensity 1.'];
            disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');

            handles.MetabolicMapInput1 = ones(handles.np1,handles.np2);
        end;

    case 2
        % Coronal plane
        fileID = fopen(handles.Map1Path,'r');
        if (fileID > 0)
            datain = fscanf(fileID,'%g',[1 Inf]);
            fclose(fileID);

            if (numel(datain) ~= handles.np1*handles.np3)
                ErrorMessage1 = ['Error   : Metabolic map size (' num2str(numel(datain)) ...
                    ') not in agreement with DMI matrix dimensions (' num2str(handles.np1) 'x' num2str(handles.np3) ').'];
                ErrorMessage2 = ['Solution: Continuing with an uniform metabolic map of intensity 1.'];
                disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');

                handles.MetabolicMapInput1 = ones(handles.np1,handles.np3);
            else
                handles.MetabolicMapInput1 = reshape(datain,handles.np1,handles.np3);
                
                TextMessage1 = ['Metabolic map ' handles.Map1Path ' successfully loaded.'];
                disp(TextMessage1);
            end;
        else
            ErrorMessage1 = ['Error   : ' handles.Map1Path ' cannot be opened.'];
            ErrorMessage2 = ['Solution: Continuing with an uniform metabolic map of intensity 1.'];
            disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');

            handles.MetabolicMapInput1 = ones(handles.np1,handles.np3);
        end;
    case 3
        % Sagital plane
        fileID = fopen(handles.Map1Path,'r');
        if (fileID > 0)
            datain = fscanf(fileID,'%g',[1 Inf]);
            fclose(fileID);

            if (numel(datain) ~= handles.np2*handles.np3)
                ErrorMessage1 = ['Error   : Metabolic map size (' num2str(numel(datain)) ...
                    ') not in agreement with DMI matrix dimensions (' num2str(handles.np2) 'x' num2str(handles.np3) ').'];
                ErrorMessage2 = ['Solution: Continuing with an uniform metabolic map of intensity 1.'];
                disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');

                handles.MetabolicMapInput1 = ones(handles.np2,handles.np3);
            else
                handles.MetabolicMapInput1 = reshape(datain,handles.np2,handles.np3);
                
                TextMessage1 = ['Metabolic map ' handles.Map1Path ' successfully loaded.'];
                disp(TextMessage1);
            end;
        else
            ErrorMessage1 = ['Error   : ' handles.Map1Path ' cannot be opened.'];
            ErrorMessage2 = ['Solution: Continuing with an uniform metabolic map of intensity 1.'];
            disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');

            handles.MetabolicMapInput1 = ones(handles.np2,handles.np3);
        end;
end;

% Remove and NaN or Inf entries
coor = isnan(handles.MetabolicMapInput1);
handles.MetabolicMapInput1(coor) = 0.0;

coor = isinf(handles.MetabolicMapInput1);
handles.MetabolicMapInput1(coor) = 0.0;

% Update current handles in workspace
assignin('base','currentHandles2',handles)

% Update GUI data structure
guidata(hObject,handles)

% Set the edit box string to the new input filename
InputMap1_Object = findall(0,'Tag','InputMap1Edit');
set(InputMap1_Object,'String',handles.Map1Path);

function InputMap1Edit_Callback(hObject, eventdata, handles)
% No manual map 1 input is allowed

% Update current handles in workspace
assignin('base','currentHandles2',handles)

% Update handles structure
guidata(hObject, handles);

function InputMap1Edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in SelectMap2PushButton.
function SelectMap2PushButton_Callback(hObject, eventdata, handles)
% Extract parameters from main window
handles = ExtractParametersFromDMIWizardMainWindow(hObject, eventdata, handles);

% Prepare for when Cancel button is pressed
Map2PathCancel = handles.Map2Path;

% Get new file and path names
[filename, pathname] = uigetfile('*.*','Select metabolic map 2 file',handles.Map2Path);

% Action performed when Cancel button is pressed
if isequal(filename,0) || isequal(pathname,0)
    handles.Map2Path = Map2PathCancel;
else
    handles.Map2Path = [pathname filename];
end

% Read metabolic map 2 from file
switch handles.Orientation
    case 1       
        % Axial plane
        fileID = fopen(handles.Map2Path,'r');
        if (fileID > 0)
            datain = fscanf(fileID,'%g',[1 Inf]);
            fclose(fileID);
            
            if (numel(datain) ~= handles.np1*handles.np2)
                ErrorMessage1 = ['Error   : Metabolic map size (' num2str(numel(datain)) ...
                    ') not in agreement with DMI matrix dimensions (' num2str(handles.np1) 'x' num2str(handles.np2) ').'];
                ErrorMessage2 = ['Solution: Continuing with an uniform metabolic map of intensity 1.'];
                disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');

                handles.MetabolicMapInput2 = ones(handles.np1,handles.np2);
            else
                handles.MetabolicMapInput2 = reshape(datain,handles.np1,handles.np2);
                TextMessage1 = ['Metabolic map ' handles.Map2Path ' successfully loaded.'];
                disp(TextMessage1);
            end;
        else
            ErrorMessage1 = ['Error   : ' handles.Map2Path ' cannot be opened.'];
            ErrorMessage2 = ['Solution: Continuing with an uniform metabolic map of intensity 1.'];
            disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');

            handles.MetabolicMapInput2 = ones(handles.np1,handles.np2);
        end;

    case 2
        % Coronal plane
        fileID = fopen(handles.Map2Path,'r');
        if (fileID > 0)
            datain = fscanf(fileID,'%g',[1 Inf]);
            fclose(fileID);

            if (numel(datain) ~= handles.np1*handles.np3)
                ErrorMessage1 = ['Error   : Metabolic map size (' num2str(numel(datain)) ...
                    ') not in agreement with DMI matrix dimensions (' num2str(handles.np1) 'x' num2str(handles.np3) ').'];
                ErrorMessage2 = ['Solution: Continuing with an uniform metabolic map of intensity 1.'];
                disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');

                handles.MetabolicMapInput2 = ones(handles.np1,handles.np3);
            else
                handles.MetabolicMapInput2 = reshape(datain,handles.np1,handles.np3);
                
                TextMessage1 = ['Metabolic map ' handles.Map2Path ' successfully loaded.'];
                disp(TextMessage1);
            end;
        else
            ErrorMessage1 = ['Error   : ' handles.Map2Path ' cannot be opened.'];
            ErrorMessage2 = ['Solution: Continuing with an uniform metabolic map of intensity 1.'];
            disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');

            handles.MetabolicMapInput2 = ones(handles.np1,handles.np3);
        end;
    case 3
        % Sagital plane
        fileID = fopen(handles.Map2Path,'r');
        if (fileID > 0)
            datain = fscanf(fileID,'%g',[1 Inf]);
            fclose(fileID);

            if (numel(datain) ~= handles.np2*handles.np3)
                ErrorMessage1 = ['Error   : Metabolic map size (' num2str(numel(datain)) ...
                    ') not in agreement with DMI matrix dimensions (' num2str(handles.np2) 'x' num2str(handles.np3) ').'];
                ErrorMessage2 = ['Solution: Continuing with an uniform metabolic map of intensity 1.'];
                disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');

                handles.MetabolicMapInput2 = ones(handles.np2,handles.np3);
            else
                handles.MetabolicMapInput2 = reshape(datain,handles.np2,handles.np3);
                
                TextMessage1 = ['Metabolic map ' handles.Map2Path ' successfully loaded.'];
                disp(TextMessage1);
            end;
        else
            ErrorMessage1 = ['Error   : ' handles.Map2Path ' cannot be opened.'];
            ErrorMessage2 = ['Solution: Continuing with an uniform metabolic map of intensity 1.'];
            disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');

            handles.MetabolicMapInput2 = ones(handles.np2,handles.np3);
        end;
end;

% Remove and NaN or Inf entries
coor = isnan(handles.MetabolicMapInput2);
handles.MetabolicMapInput2(coor) = 0.0;

coor = isinf(handles.MetabolicMapInput2);
handles.MetabolicMapInput2(coor) = 0.0;

% Update current handles in workspace
assignin('base','currentHandles2',handles)

% Update GUI data structure
guidata(hObject,handles)

% Set the edit box string to the new input filename
InputMap2_Object = findall(0,'Tag','InputMap2Edit');
set(InputMap2_Object,'String',handles.Map2Path);

function InputMap2Edit_Callback(hObject, eventdata, handles)
% No manual map 2 input is allowed

% Update current handles in workspace
assignin('base','currentHandles2',handles)

% Update handles structure
guidata(hObject, handles);

function InputMap2Edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in SelectMap3PushButton.
function SelectMap3PushButton_Callback(hObject, eventdata, handles)
% Prepare for when Cancel button is pressed
Map3PathCancel = handles.Map3Path;

% Get new file and path names
[filename, pathname] = uiputfile('*.*','Select output metabolic map file',handles.Map3Path);

% Action performed when Cancel button is pressed
if isequal(filename,0) || isequal(pathname,0)
    handles.Map3Path = Map3PathCancel;
else
    handles.Map3Path = [pathname filename];
end

% Update current handles in workspace
assignin('base','currentHandles2',handles)

% Update GUI data structure
guidata(hObject,handles)

% Set the edit box string to the new input filename
InputMap3_Object = findall(0,'Tag','OutputIDEdit');
set(InputMap3_Object,'String',handles.Map3Path);



function ROIMapEdit_Callback(hObject, eventdata, handles)
% hObject    handle to ROIMapEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ROIMapEdit as text
%        str2double(get(hObject,'String')) returns contents of ROIMapEdit as a double


% --- Executes during object creation, after setting all properties.
function ROIMapEdit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function SelectMap4PushButton_Callback(hObject, eventdata, handles)
% Selection of ROI map from file

% Extract parameters from main window
handles = ExtractParametersFromDMIWizardMainWindow(hObject, eventdata, handles);

% Prepare for when Cancel button is pressed
Map4PathCancel = handles.Map4Path;

% Get new file and path names
[filename, pathname] = uigetfile('*.*','Select ROI map file',handles.Map4Path);

% Action performed when Cancel button is pressed
if isequal(filename,0) || isequal(pathname,0)
    handles.Map4Path = Map4PathCancel;
else
    handles.Map4Path = [pathname filename];
end

% Read metabolic map 2 from file
switch handles.Orientation
    case 1       
        % Axial plane
        fileID = fopen(handles.Map4Path,'r');
        if (fileID > 0)
            datain = fscanf(fileID,'%g',[1 Inf]);
            fclose(fileID);
            
            if (numel(datain) ~= handles.np1ext*handles.np2ext)
                ErrorMessage1 = ['Error   : ROI map size (' num2str(numel(datain)) ...
                    ') not in agreement with MRI matrix dimensions (' num2str(handles.np1ext) 'x' num2str(handles.np2ext) ').'];
                ErrorMessage2 = ['Solution: Continuing with an uniform ROI map of intensity 1.'];
                disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');

                handles.ROI = ones(handles.np1ext,handles.np2ext);
            else
                handles.ROI = reshape(datain,handles.np1ext,handles.np2ext);
                TextMessage1 = ['ROI map ' handles.Map4Path ' successfully loaded.'];
                disp(TextMessage1);
            end;
        else
            ErrorMessage1 = ['Error   : ' handles.Map4Path ' cannot be opened.'];
            ErrorMessage2 = ['Solution: Continuing with an uniform ROI map of intensity 1.'];
            disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');

            handles.ROI = ones(handles.np1ext,handles.np2ext);
        end;

    case 2
        % Coronal plane
        fileID = fopen(handles.Map4Path,'r');
        if (fileID > 0)
            datain = fscanf(fileID,'%g',[1 Inf]);
            fclose(fileID);

            if (numel(datain) ~= handles.np1ext*handles.np3ext)
                ErrorMessage1 = ['Error   : ROI map size (' num2str(numel(datain)) ...
                    ') not in agreement with MRI matrix dimensions (' num2str(handles.np1ext) 'x' num2str(handles.np3ext) ').'];
                ErrorMessage2 = ['Solution: Continuing with an uniform ROI map of intensity 1.'];
                disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');

                handles.ROI = ones(handles.np1ext,handles.np3ext);
            else
                handles.ROI = reshape(datain,handles.np1ext,handles.np3ext);
                
                TextMessage1 = ['ROI map ' handles.Map4Path ' successfully loaded.'];
                disp(TextMessage1);
            end;
        else
            ErrorMessage1 = ['Error   : ' handles.Map4Path ' cannot be opened.'];
            ErrorMessage2 = ['Solution: Continuing with an uniform ROI map of intensity 1.'];
            disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');

            handles.ROI = ones(handles.np1ext,handles.np3ext);
        end;
        
    case 3
        % Sagital plane
        fileID = fopen(handles.Map4Path,'r');
        if (fileID > 0)
            datain = fscanf(fileID,'%g',[1 Inf]);
            fclose(fileID);

            if (numel(datain) ~= handles.np2ext*handles.np3ext)
                ErrorMessage1 = ['Error   : ROI map size (' num2str(numel(datain)) ...
                    ') not in agreement with MRI matrix dimensions (' num2str(handles.np2ext) 'x' num2str(handles.np3ext) ').'];
                ErrorMessage2 = ['Solution: Continuing with an uniform ROI map of intensity 1.'];
                disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');

                handles.ROI = ones(handles.np2ext,handles.np3ext);
            else
                handles.ROI = reshape(datain,handles.np2ext,handles.np3ext);
                
                TextMessage1 = ['ROI map ' handles.Map4Path ' successfully loaded.'];
                disp(TextMessage1);
            end;
        else
            ErrorMessage1 = ['Error   : ' handles.Map4Path ' cannot be opened.'];
            ErrorMessage2 = ['Solution: Continuing with an uniform ROI map of intensity 1.'];
            disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');

            handles.ROI = ones(handles.np2ext,handles.np3ext);
        end;
end;

% Update current handles in workspace
assignin('base','currentHandles2',handles)

% Update GUI data structure
guidata(hObject,handles)

% Set the edit box string to the new input filename
ROIMapEdit_Object = findall(0,'Tag','ROIMapEdit');
set(ROIMapEdit_Object,'String',handles.Map4Path);
