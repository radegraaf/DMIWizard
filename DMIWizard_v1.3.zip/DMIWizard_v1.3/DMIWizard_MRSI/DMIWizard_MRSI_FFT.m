function handles = DMIWizard_MRSI_FFT(handles)
% Performs a spectral and spatial Fourier transformation.

handles.FIDshifted = zeros(handles.np,handles.nrec,handles.np1,handles.np2,handles.np3);
MRSIGridShift = [-1.0*handles.DMIshift1+handles.sp1extra -1.0*handles.DMIshift2+handles.sp2extra -1.0*handles.DMIshift3+handles.sp3extra];
if (sum(abs(MRSIGridShift)) > 0)
    % Apply MRSI grid shift
    kx1 = (handles.np1-1)/handles.np1;
    ky1 = (handles.np2-1)/handles.np2;
    kz1 = (handles.np3-1)/handles.np3;
    
    [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
    TextOutput1 = [OperationTime ' - Apply spatial MRSI grid shift [ ' num2str(handles.sp1extra) ', ' ...
        num2str(handles.sp2extra) ', ' num2str(handles.sp3extra) '].'];
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
    disp(TextOutput1);
    
    [kx,ky,kz] = ndgrid(linspace(-kx1,kx1,handles.np1),linspace(-ky1,ky1,handles.np2),linspace(-kz1,kz1,handles.np3));
    for c1 = 1:handles.np;
        for c2 = 1:handles.nrec;
            handles.FIDshifted(c1,c2,:,:,:) = squeeze(handles.FID(c1,c2,:,:,:)).*exp(-pi*1i*kx*MRSIGridShift(1) - ...
                pi*1i*ky*MRSIGridShift(2) - pi*1i*kz*MRSIGridShift(3));
        end;
    end;
else
    handles.FIDshifted = handles.FID;
end;
% Reshape needed when nrec = 1
handles.FIDshifted = reshape(handles.FIDshifted,handles.np,handles.nrec,handles.np1,handles.np2,handles.np3);

% Perform spatial 3D FFT
[OperationTime,~] = DMIWizard_MRSI_CalculateTime;
TextOutput1 = [OperationTime ' - Spatial 3D FFT.'];
DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
disp(TextOutput1);
FID3Dnrec = zeros(handles.np,handles.nrec,handles.np1,handles.np2,handles.np3);
for c1 = 1:handles.np;
    for c2 = 1:handles.nrec;
        FID3Dnrec(c1,c2,:,:,:) = fftshift(fftn(fftshift(squeeze(handles.FIDshifted(c1,c2,:,:,:)))));
    end;
end;

% Determine optimal Rx phases and weights from MRSI data

% Due to the relatively low SNR, phase correction based on the first FID
% point does not work well. As an alternative, phasing will be based on
% maximizing the spectral integral around the water signal. To start
% determine the frequency boundaries around the water signal.
[Freq1,Freq2] = DMIWizard_MRSI_DetermineIntegrationBoundaries(FID3Dnrec,handles);

handles.OptimalPhase = zeros(handles.np1,handles.np2,handles.np3,handles.nrec);
handles.RecWeight = zeros(handles.np1,handles.np2,handles.np3,handles.nrec);
if (handles.nrec > 1)   
    [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
    TextOutput1 = [OperationTime ' - Multi-receiver phase correction and amplitude weighting.'];
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+',TextOutput1);
    disp(TextOutput1);
    
    % Perform phase correction and amplitude weighting
    % in combining multiple receivers
    handles.FID3D = zeros(handles.np,handles.np1,handles.np2,handles.np3);
    for c1 = 1:handles.np1;
        for c2 = 1:handles.np2;
            for c3 = 1:handles.np3;
                for c4 = 1:handles.nrec;
                    maxint = -Inf;
                    for phs = 0:10:350;
                        handles.FIDphs = FID3Dnrec(:,c4,c1,c2,c3).*exp(1i*(pi/180)*phs);
                        handles.FIDapodized = DMIWizard_MRSI_Apodization(handles.FIDphs,handles);
                        spec = fftshift(fft(handles.FIDapodized));
                        if (sum(real(spec(Freq1:Freq2))) > maxint)
                            maxint = sum(real(spec(Freq1:Freq2)));
                            handles.RecWeight(c1,c2,c3,c4) = sum(real(spec(Freq1:Freq2)));
                            handles.OptimalPhase(c1,c2,c3,c4) = phs;
                        end;
                    end;

                    FID3Dnrec(:,c4,c1,c2,c3) = FID3Dnrec(:,c4,c1,c2,c3)*exp(1i*(pi/180)*handles.OptimalPhase(c1,c2,c3,c4));
                end;

                handles.RecWeight(c1,c2,c3,:) = squeeze(handles.RecWeight(c1,c2,c3,:))/sum(squeeze(handles.RecWeight(c1,c2,c3,:)));

                % Apply amplitude-weighted summation
                for c4 = 1:handles.nrec;
                    handles.FID3D(:,c1,c2,c3) = handles.FID3D(:,c1,c2,c3) + handles.RecWeight(c1,c2,c3,c4)*FID3Dnrec(:,c4,c1,c2,c3);
                end;
            end;
        end;
    end;
else
    handles.FID3D = squeeze(FID3Dnrec(:,1,:,:,:));   
end;

% Receiver-related calculations are completed --> set nrec to 1
handles.nrec = 1;

% Perform spectral 1D FFT
[OperationTime,~] = DMIWizard_MRSI_CalculateTime;
TextOutput1 = [OperationTime ' - Spectral 1D FFT with:'];
TextOutput2 = [OperationTime ' - Spectral width  = ' num2str(handles.sw) ' kHz'];
TextOutput3 = [OperationTime ' - Line broadening = ' num2str(handles.emf) ' Hz'];
TextOutput4 = [OperationTime ' - Spectral points = ' num2str(handles.npzf)];

DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput2);
DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput3);
DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput4);
disp(TextOutput1); disp(TextOutput2); disp(TextOutput3); disp(TextOutput4);

handles.spec3D = zeros(handles.npzf,handles.np1,handles.np2,handles.np3);
for c1 = 1:handles.np1;
    for c2 = 1:handles.np2;
        for c3 = 1:handles.np3;
            handles.FIDapodized = DMIWizard_MRSI_Apodization(squeeze(handles.FID3D(:,c1,c2,c3)),handles);
            handles.spec3D(:,c1,c2,c3) = fftshift(fft(handles.FIDapodized,handles.npzf));
        end;
    end;
end;
handles.maxspec3D = max(max(max(max(abs(handles.spec3D)))));

% Create an inclusion map for data with/without adequate signal
[OperationTime,~] = DMIWizard_MRSI_CalculateTime;
TextOutput1 = [OperationTime ' - Creating inclusion map based on ' num2str(handles.intth) '% amplitude threshold.'];
DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+',TextOutput1);
disp(TextOutput1);
handles.InclusionMap = zeros(handles.np1,handles.np2,handles.np3);
for c1 = 1:handles.np1;
    for c2 = 1:handles.np2;
        for c3 = 1:handles.np3;
            if (max(abs(handles.spec3D(:,c1,c2,c3))) > (handles.intth/100)*handles.maxspec3D);
               handles.InclusionMap(c1,c2,c3) = 1;
            else
               handles.InclusionMap(c1,c2,c3) = 0;
            end;
        end;
    end;
end;

% Reprocess fitted spectra (needed with apodization or spectral points change) 
if (isfield(handles,'spec3Dfit') > 0)
    handles.spec3Dfit = zeros(handles.npzf,handles.np1,handles.np2,handles.np3);
    for c1 = 1:handles.np1;
        for c2 = 1:handles.np2;
            for c3 = 1:handles.np3;
                spec1Dfit = DMIWizard_MRSI_FittingFunction02(handles,c1,c2,c3);
                handles.spec3Dfit(:,c1,c2,c3) = spec1Dfit;
            end;
        end;
    end;
end;