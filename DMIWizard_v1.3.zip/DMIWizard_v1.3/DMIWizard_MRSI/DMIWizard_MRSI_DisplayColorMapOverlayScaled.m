function DMIWizard_MRSI_DisplayColorMapOverlayScaled(handles)

if (max(max(handles.ROI)) == 0)
    handles.ROI = 0*handles.ROI + 1;
end;

% Generate extended and (optionally) extrapolated metabolic maps
% to match the MRI resoltuion.
[handles.MetabolicM0mapExpanded,handles.MetabolicM0mapFFTIP,handles.MetabolicM0mapConvIP,...
    handles.MRIsliceExpanded,handles.ROIExpanded] = DMIWizard_MRSI_GenerateInterpolatedMaps(handles);

% Write extrapolated maps to disk
if (strcmp(handles.Map3Path,'metabolic map output') > 0)
    [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
    TextOutput1 = [OperationTime ' - Error   : Invalid metabolic map output file. Output map not saved to disk.'];
    TextOutput2 = [OperationTime ' - Solution: Select valid filename and location.'];
    disp(' '); disp(TextOutput1); disp(TextOutput2); disp(' ');
else
    fileID = fopen(handles.Map3Path,'w+');
    fprintf(fileID,'%20.7f\n',reshape(handles.MetabolicMapOutput,1,[]));
    fclose(fileID);
    [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
    TextOutput1 = [OperationTime ' - Output metabolic map written to: ' handles.Map3Path];
    disp(TextOutput1);
    
    handles.OutputFileName = [handles.Map3Path '_ConvolutionInterpolated'];
    handles.MMStyle = 'convolution interpolated M0';
    DMIWizard_MRSI_WriteMetabolicMapScaled(handles.MetabolicM0mapConvIP,handles);
end;

% Write extrapolated maps to disk
[OperationTime,~] = DMIWizard_MRSI_CalculateTime;
TextOutput1 = [OperationTime ' - Convolution kernel width = ' num2str(handles.KernelWidth)];
disp(TextOutput1);

% Write information to processing history file
if (isfield(handles,'ProcessingHistoryFile') > 0)
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
end;

% Scale MRI to [0 .. 0.5] and MetabolicM0map to [0.5 .. 1]
ColorScaledM0 = abs(handles.MetabolicM0mapExpanded.*handles.ROIExpanded);
ColorScaledM0 = ColorScaledM0/handles.MaximumMapIntensity;
ColorScaledM0 = 0.5*ColorScaledM0 + 0.5;

ColorScaledMRI = handles.MRIsliceExpanded*10^-handles.MRIScale;
ColorScaledMRI = ColorScaledMRI/handles.MaximumMRIIntensity;
ColorScaledMRI = 0.5*ColorScaledMRI;
coor = find(ColorScaledMRI >= 0.49);
ColorScaledMRI(coor) = 0.49;
ColorScaledMRIOrig = ColorScaledMRI;

% Identify coordinates of all points above the threshold
NumericalThreshold = 0.50;
coor2 = find(ColorScaledM0 > NumericalThreshold);

% Replace Above Threshold Points in MRI image
ColorScaledMRI(coor2) = ColorScaledM0(coor2);

% Create new colormap and display modified MRI image
cmap = [gray(128); jet(128)];

fh = figure;
nn = ['M0 map (slice ' num2str(handles.sp3) ' out of ' num2str(handles.np3) ')'];
set(fh,'Name',nn);
imshow(ColorScaledMRIOrig,[0 .5],'InitialMagnification','fit'); colormap(cmap);
hold on;
h = imshow(ColorScaledMRI, [0 1],'InitialMagnification','fit'); colormap(cmap);
hold off;
set(h,'AlphaData',handles.Transparency)

% Show interpolated maps
if (handles.Interpolation > 0)
    
    % Scale interpolated metabolic maps to [0.5 .. 1]
    ColorScaledM0FFTIP = abs(handles.MetabolicM0mapFFTIP.*handles.ROIExpanded);
    ColorScaledM0FFTIP = ColorScaledM0FFTIP/handles.MaximumMapIntensity;
    ColorScaledM0FFTIP = 0.5*ColorScaledM0FFTIP + 0.5;
    
%     ColorScaledMRI = handles.MRIsliceExpanded;
%     ColorScaledMRI = ColorScaledMRI/max(max(ColorScaledMRI));
%     ColorScaledMRI = 0.5*ColorScaledMRI;
    ColorScaledMRI = ColorScaledMRIOrig;
     
    % Identify coordinates of all points above the threshold
    NumericalThreshold = 0.50;
    coor2 = find(ColorScaledM0FFTIP > NumericalThreshold);
    
    % Replace Above Threshold Points in MRI image
    ColorScaledMRI(coor2) = ColorScaledM0FFTIP(coor2);
    
    % Scale interpolated metabolic maps to [0.5 .. 1]
    ColorScaledM0ConvIP = abs(handles.MetabolicM0mapConvIP.*handles.ROIExpanded);
    ColorScaledM0ConvIP = ColorScaledM0ConvIP/handles.MaximumMapIntensity;
    ColorScaledM0ConvIP = 0.5*ColorScaledM0ConvIP + 0.5;
    
%     ColorScaledMRI = handles.MRIsliceExpanded;
%     ColorScaledMRI = ColorScaledMRI/max(max(ColorScaledMRI));
%     ColorScaledMRI = 0.5*ColorScaledMRI;
%     ColorScaledMRIOrig = ColorScaledMRI;
    ColorScaledMRI = ColorScaledMRIOrig;

    % Identify coordinates of all points above the threshold
    NumericalThreshold = 0.50;
    coor2 = find(ColorScaledM0ConvIP > NumericalThreshold);

    % Replace Above Threshold Points in MRI image
    ColorScaledMRI(coor2) = ColorScaledM0ConvIP(coor2);
    
    fh = figure;
    nn = ['Convolution-based, interpolated M0 map (slice ' num2str(handles.sp3) ' out of ' num2str(handles.np3) ')'];
    set(fh,'Name',nn);
    imshow(ColorScaledMRIOrig,[0 0.5],'InitialMagnification','fit'); colormap(cmap);
    hold on;
    h = imshow(ColorScaledMRI, [0 1],'InitialMagnification','fit'); colormap(cmap);
    hold off;
    set(h,'AlphaData',handles.Transparency)
end;