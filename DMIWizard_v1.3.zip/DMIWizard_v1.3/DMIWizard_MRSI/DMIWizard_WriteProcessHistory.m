function DMIWizard_WriteProcessHistory(FileName,FileOperation,NewContent)

switch FileOperation
    case 'a'
        % Append existing file
        fileID = fopen(FileName,'a');
        fprintf(fileID,'%s\n',NewContent);
        fclose(fileID);
    case 'a+'
        % Append existing file and insert an empty line
        fileID = fopen(FileName,'a');
        fprintf(fileID,'%s\n',NewContent);
        fprintf(fileID,'%s\n','');
        fclose(fileID);
    case 'w+'
        % Create new file
        fileID = fopen(FileName,'w+');
        fprintf(fileID,'%s\n',NewContent);
        fclose(fileID);
end;