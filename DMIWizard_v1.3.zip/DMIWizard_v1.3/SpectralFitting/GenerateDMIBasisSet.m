% GenerateDMIBasisSet.m
%
% Program to generate DMI basisset for a particular magnetic
% field strength and acquisition parameters.

% Spectral width (in Hz)
NMRPars.sw = input('Give spectral width [5000 Hz] : ');
if (isempty(NMRPars.sw) > 0)
    NMRPars.sw = 5000;
end;
    
% Number of acquisition points
NMRPars.np = input('Give number of acquisition points [2048] : ');
if (isempty(NMRPars.np) > 0)
    NMRPars.np = 2048;
end;

% 2H Larmor frequency (MHz)
NMRPars.nu0 = input('Give Larmor frequency [26.17 MHz] : ');
if (isempty(NMRPars.nu0) > 0)
    NMRPars.nu0 = 26.17;
end;

% RF offset (center of spectral width in ppm)
NMRPars.RFoffset = input('Give RF center frequency [4.663 ppm] : ');
if (isempty(NMRPars.RFoffset) > 0)
    NMRPars.RFoffset = 4.663;
end;

% Prior knowledge file
NMRPars.PKFile = input('Give prior knowledge (Excel) file : ');

% Read prior knowledge information
NMRPars.PKData = ReadPriorKnowledgeAndLimits(NMRPars.PKFile,'Y');

NMRPars.dt = 1/NMRPars.sw;      % Dwell time (Hz)
time = 0:NMRPars.dt:(NMRPars.np-1)*NMRPars.dt;
time = reshape(time,[],1);

NMRPars.lw = 1.0;               % Spectral linewidth (Hz, display only)
NMRPars.npzf = 32768;           % Number of zerofilling points (display only)
weight = exp(-time*pi*NMRPars.lw);

freq = -0.5*NMRPars.sw:NMRPars.sw/(NMRPars.npzf-1):0.5*NMRPars.sw;
ppm = NMRPars.RFoffset + (freq/NMRPars.nu0);

NMRPars.nmult = length(NMRPars.PKData.GroupCS);

BasisSetDir = input('Give DMI basisset directory : ');

% Create basisset FIDs
FID = zeros(NMRPars.np,NMRPars.nmult);
for c1 = 1:NMRPars.nmult;
    mult = NMRPars.PKData.GroupRelativeM0(c1);
    switch mult
        case 100
            % Glucose D6/6' signal
            % Note - 2H chemical shifts are very close to 1H chemical
            % shifts, whereas the homonuclear scalar coupling is (6.5x6.5)
            % times smaller.
            RelativeM0 = [0.625 0.375 0.375 0.625];
            cs = [3.882 3.826 3.749 3.707];             % in ppm
            nu = (NMRPars.RFoffset - cs)*NMRPars.nu0;   % in Hz
            
            for c2 = 1:length(cs);
                FID(:,c1) = FID(:,c1) + RelativeM0(c2)*exp(-2*pi*1i*nu(c2)*time);
            end;

        case 200
            % Glucose D1 + D6/6' signal
            % Note - 2H chemical shifts are very close to 1H chemical
            % shifts, whereas the homonuclear scalar coupling is (6.5x6.5)
            % times smaller.
            RelativeM0 = [0.375 0.625 0.625 0.375 0.375 0.625];
            cs = [5.22 4.63 3.882 3.826 3.749 3.707];             % in ppm
            nu = (NMRPars.RFoffset - cs)*NMRPars.nu0;   % in Hz
            
            for c2 = 1:length(cs);
                FID(:,c1) = FID(:,c1) + RelativeM0(c2)*exp(-2*pi*1i*nu(c2)*time);
            end;
        case 300
            % Glucose D1,D2,D3,D4,D5,D6/6' signal
            % Note - 2H chemical shifts are very close to 1H chemical
            % shifts, whereas the homonuclear scalar coupling is (6.5x6.5)
            % times smaller.
            RelativeM0 = [0.375 0.375 0.375 0.375 0.375 0.375 0.375 ...
                0.625 0.625 0.625 0.625 0.625 0.625 0.625];
            cs = [5.22 3.52 3.70 3.40 3.82 3.83 3.75 ...
                4.63 3.23 3.47 3.39 3.45 3.88 3.71];             % in ppm
            nu = (NMRPars.RFoffset - cs)*NMRPars.nu0;   % in Hz
            
            for c2 = 1:length(cs);
                FID(:,c1) = FID(:,c1) + RelativeM0(c2)*exp(-2*pi*1i*nu(c2)*time);
            end;
        otherwise
            % Singlet signal
            FID(:,c1) = mult*exp(-2*pi*1i*(NMRPars.RFoffset - NMRPars.PKData.GroupCS(c1))*NMRPars.nu0*time);
    end;
end;

% Display results
figure(1); hold on;
yoffset = 1e3;
for c1 = 1:NMRPars.nmult;
    spec = fftshift(fft(FID(:,c1).*weight,NMRPars.npzf));
    plot(ppm,real(spec)+c1*yoffset);
end;
hold off;
set(gca,'XDir','Reverse','XLim',[0 10])

% Write basisset FIDs to disk
warning off;
mkdir(BasisSetDir)
warning on;

for c1 = 1:NMRPars.nmult;
    file = [BasisSetDir '\fid_' NMRPars.PKData.MetaboliteName{c1}];
    fileID = fopen(file,'w+');
    fprintf(fileID,'%9.5f   %9.5f\n',[reshape(real(FID(:,c1)),1,[]); reshape(imag(FID(:,c1)),1,[])]);
    fclose(fileID);
end;

% Write basisset parameter file to disk
output1A = ['Spectral width (kHz)      = ' num2str(NMRPars.sw/1000) '\n']; 
output1B = ['Acquisition points        = ' num2str(NMRPars.np) '\n'];
output1C = ['Larmor frequency (MHz)    = ' num2str(NMRPars.nu0) '\n'];
output1D = ['RF center frequency (ppm) = ' num2str(NMRPars.RFoffset) '\n'];
file = [BasisSetDir '\BasisSet.par'];
fileID = fopen(file,'w');
fprintf(fileID,output1A); fprintf(fileID,output1B); 
fprintf(fileID,output1C); fprintf(fileID,output1D);
fclose(fileID);