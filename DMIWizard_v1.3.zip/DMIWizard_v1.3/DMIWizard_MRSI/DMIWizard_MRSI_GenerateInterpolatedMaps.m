function [MetabolicM0mapExpanded,MetabolicM0mapFFTIP,MetabolicM0mapConvIP,...
    MRIsliceExpanded,ROIExpanded] = DMIWizard_MRSI_GenerateInterpolatedMaps(handles)

switch handles.Orientation
    case 1
        % Axial plane
        
        if ((isfield(handles,'MRIslice') ~= 1) || (isfield(handles,'ROI') ~= 1))
            handles.MRIslice = zeros(handles.np1ext,handles.np2ext);
            handles.ROI = zeros(handles.np1ext,handles.np2ext);
        end;
        
        % ROI matrix size is different from MRI matrix size - likely due to:
        % 1. Loading a new MRI without defining a new ROI, or
        % 2. Changing the orientation on data within unequal matrix dimensions.
        if ((size(handles.ROI,1) ~= handles.np1ext) || (size(handles.ROI,2) ~= handles.np2ext))
            handles.ROI = 0.0*handles.MRIslice + 1.0;
        end;
        
        if ((rem(handles.np1ext,handles.np1) == 0) && (rem(handles.np2ext,handles.np2) == 0))
            % MRI matrix is an integer multiple of the MRSI matrix.
            % MRSI matrix will be extrapolated to MRI matrix.
            
            [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
            TextOutput1 = [OperationTime ' - Interpolating (' num2str(handles.np1) 'x' num2str(handles.np2) ...
                ') metabolic map to (' num2str(handles.np1ext) 'x' num2str(handles.np2ext) ...
                ') matrix.'];
            disp(' '); disp(TextOutput1); disp(' ');
            
            % 1. Convolution-based interpolation
            MetabolicM0mapExpanded = zeros(handles.np1ext,handles.np2ext);
            factor1 = round(handles.np1ext/handles.np1);
            factor2 = round(handles.np2ext/handles.np2);
            for c1 = 1:handles.np1;
                for c2 = 1:handles.np2;
                    MetabolicM0mapExpanded((c1-1)*factor1+1:c1*factor1,(c2-1)*factor2+1:c2*factor2) = handles.MetabolicM0map(c1,c2);
                end;
            end;

            p1 = 1:1:handles.np1ext; p1 = p1 - handles.np1ext/2;
            p2 = 1:1:handles.np2ext; p2 = p2 - handles.np2ext/2;
            [x,y] = ndgrid(p1,p2);

            GaussianScale = 1/(2*handles.KernelWidth*handles.KernelWidth);

            ConvKernel = exp(-GaussianScale*(x.^2 + y.^2));
            MetabolicM0mapConvIP = conv2(MetabolicM0mapExpanded,ConvKernel,'same');
            
            % Establish an amplitude-scaling factor for the used
            % convolution parameter settings
            maxM0map = max(max(MetabolicM0mapExpanded));
            maxM0mapConv = max(max(MetabolicM0mapConvIP));
            ConvScaling = maxM0map/maxM0mapConv;
            
            MetabolicM0mapConvIP = MetabolicM0mapConvIP*ConvScaling;
        
            % 2. FFT-based interpolation
            FID = fftshift(ifft2(ifftshift(handles.MetabolicM0map)));
            np1 = size(MetabolicM0mapExpanded,1); np2 = size(MetabolicM0mapExpanded,2);
            FID2 = zeros(np1,np2);

            x1 = round(0.5*handles.np1ext)-round(0.5*handles.np1);
            x2 = x1 + handles.np1 - 1;
            y1 = round(0.5*handles.np2ext)-round(0.5*handles.np2);
            y2 = y1 + handles.np2 - 1;

            FID2(x1:x2,y1:y2) = FID;

            MetabolicM0mapFFTIP = abs(fftshift(fft2(FID2)));
            
            % MRI and ROI remain at original resolution
            MRIsliceExpanded = handles.MRIslice;
            ROIExpanded = handles.ROI;         
        else
            % MRI matrix is NOT an integer multiple of the MRSI matrix.
            % MRI and MRSI matrices will be extrapolated to (MRI x MRSI) matrix.
            
            [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
            TextOutput1 = [OperationTime ' - Interpolating (' num2str(handles.np1) 'x' num2str(handles.np2) ...
                ') metabolic map to (' num2str(handles.np1*handles.np1ext) 'x' num2str(handles.np2*handles.np2ext) ...
                ') matrix.'];
            disp(' '); disp(TextOutput1); disp(' ');
            
            % 1. Convolution-based interpolation
            MetabolicM0mapExpanded = zeros(handles.np1ext*handles.np1,handles.np2ext*handles.np2);
            factor1 = handles.np1ext;
            factor2 = handles.np2ext;
            for c1 = 1:handles.np1;
                for c2 = 1:handles.np2;
                    MetabolicM0mapExpanded((c1-1)*factor1+1:c1*factor1,(c2-1)*factor2+1:c2*factor2) = ...
                        handles.MetabolicM0map(c1,c2);
                end;
            end;

            p1 = 1:1:handles.np1ext*handles.np1; p1 = p1 - (handles.np1ext*handles.np1)/2;
            p2 = 1:1:handles.np2ext*handles.np2; p2 = p2 - (handles.np2ext*handles.np2)/2;
            [x,y] = ndgrid(p1,p2);

            KernelWidth1 = handles.KernelWidth*handles.np1;
            KernelWidth2 = handles.KernelWidth*handles.np2;
            GaussianScale1 = 1/(2*KernelWidth1*KernelWidth1);
            GaussianScale2 = 1/(2*KernelWidth2*KernelWidth2);

            ConvKernel = exp(-GaussianScale1*x.^2 - GaussianScale2*y.^2);
            MetabolicM0mapConvIP = conv2(MetabolicM0mapExpanded,ConvKernel,'same');
            
            % Establish an amplitude-scaling factor for the used
            % convolution parameter settings
            maxM0map = max(max(MetabolicM0mapExpanded));
            maxM0mapConv = max(max(MetabolicM0mapConvIP));
            ConvScaling = maxM0map/maxM0mapConv;
            
            MetabolicM0mapConvIP = MetabolicM0mapConvIP*ConvScaling;
        
            % 2. FFT-based interpolation
            FID = fftshift(ifft2(ifftshift(handles.MetabolicM0map)));
            np1 = size(MetabolicM0mapExpanded,1); np2 = size(MetabolicM0mapExpanded,2);
            FID2 = zeros(np1,np2);

            x1 = round(0.5*handles.np1ext*handles.np1)-round(0.5*handles.np1);
            x2 = x1 + handles.np1 - 1;
            y1 = round(0.5*handles.np2ext*handles.np2)-round(0.5*handles.np2);
            y2 = y1 + handles.np2 - 1;

            FID2(x1:x2,y1:y2) = FID;

            MetabolicM0mapFFTIP = abs(fftshift(fft2(FID2)));
            
            % MRI and ROI
            MRIsliceExpanded = zeros(handles.np1*handles.np1ext,handles.np2*handles.np2ext);
            ROIExpanded = zeros(handles.np1*handles.np1ext,handles.np2*handles.np2ext);
            for c1 = 1:handles.np1ext;
                for c2 = 1:handles.np2ext;
                    MRIsliceExpanded((c1-1)*handles.np1+1:c1*handles.np1,(c2-1)*handles.np2+1:c2*handles.np2) = ...
                        handles.MRIslice(c1,c2);
                    ROIExpanded((c1-1)*handles.np1+1:c1*handles.np1,(c2-1)*handles.np2+1:c2*handles.np2) = ...
                        handles.ROI(c1,c2);
                end;
            end;
        end;
        
    case 2
        % Coronal plane
        
        if ((isfield(handles,'MRIslice') ~= 1) || (isfield(handles,'ROI') ~= 1))
            handles.MRIslice = zeros(handles.np1ext,handles.np3ext);
            handles.ROI = zeros(handles.np1ext,handles.np3ext);
        end;
        
        % ROI matrix size is different from MRI matrix size - likely due to:
        % 1. Loading a new MRI without defining a new ROI, or
        % 2. Changing the orientation on data within unequal matrix dimensions.
        if ((size(handles.ROI,1) ~= handles.np1ext) || (size(handles.ROI,2) ~= handles.np3ext))
            handles.ROI = 0.0*handles.MRIslice + 1.0;
        end;
        
        if ((rem(handles.np1ext,handles.np1) == 0) && (rem(handles.np3ext,handles.np3) == 0))
            % MRI matrix is an integer multiple of the MRSI matrix.
            % MRSI matrix will be extrapolated to MRI matrix.
            
            [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
            TextOutput1 = [OperationTime ' - Interpolating (' num2str(handles.np1) 'x' num2str(handles.np3) ...
                ') metabolic map to (' num2str(handles.np1ext) 'x' num2str(handles.np3ext) ...
                ') matrix.'];
            disp(' '); disp(TextOutput1); disp(' ');

            % 1. Convolution-based interpolation
            MetabolicM0mapExpanded = zeros(handles.np1ext,handles.np3ext);
            factor1 = ceil(handles.np1ext/handles.np1);
            factor2 = ceil(handles.np3ext/handles.np3);
            for c1 = 1:handles.np1;
                for c2 = 1:handles.np3;
                    MetabolicM0mapExpanded((c1-1)*factor1+1:c1*factor1,(c2-1)*factor2+1:c2*factor2) = handles.MetabolicM0map(c1,c2);
                end;
            end;

            p1 = 1:1:handles.np1ext; p1 = p1 - handles.np1ext/2;
            p2 = 1:1:handles.np3ext; p2 = p2 - handles.np3ext/2;
            [x,y] = ndgrid(p1,p2);

            GaussianScale = 1/(2*handles.KernelWidth*handles.KernelWidth);

            ConvKernel = exp(-GaussianScale*(x.^2 + y.^2));
            MetabolicM0mapConvIP = conv2(MetabolicM0mapExpanded,ConvKernel,'same');
            
            % Establish an amplitude-scaling factor for the used
            % convolution parameter settings
            maxM0map = max(max(MetabolicM0mapExpanded));
            maxM0mapConv = max(max(MetabolicM0mapConvIP));
            ConvScaling = maxM0map/maxM0mapConv;
            
            MetabolicM0mapConvIP = MetabolicM0mapConvIP*ConvScaling;
        
            % 2. FFT-based interpolation
            FID = fftshift(ifft2(ifftshift(handles.MetabolicM0map)));
            np1 = size(MetabolicM0mapExpanded,1); np2 = size(MetabolicM0mapExpanded,2);
            FID2 = zeros(np1,np2);

            x1 = round(0.5*handles.np1ext)-round(0.5*handles.np1);
            x2 = x1 + handles.np1 - 1;
            y1 = round(0.5*handles.np3ext)-round(0.5*handles.np3);
            y2 = y1 + handles.np3 - 1;

            FID2(x1:x2,y1:y2) = FID;

            MetabolicM0mapFFTIP = abs(fftshift(fft2(FID2)));
              
            % MRI and ROI remain at original resolution
            MRIsliceExpanded = handles.MRIslice;
            ROIExpanded = handles.ROI;         
        else
            % MRI matrix is NOT an integer multiple of the MRSI matrix.
            % MRI and MRSI matrices will be extrapolated to (MRI x MRSI) matrix.
            
            [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
            TextOutput1 = [OperationTime ' - Interpolating (' num2str(handles.np1) 'x' num2str(handles.np3) ...
                ') metabolic map to (' num2str(handles.np1*handles.np1ext) 'x' num2str(handles.np3*handles.np3ext) ...
                ') matrix.'];
            disp(' '); disp(TextOutput1); disp(' ');
 
            % 1. Convolution-based interpolation
            MetabolicM0mapExpanded = zeros(handles.np1ext*handles.np1,handles.np3ext*handles.np3);
            factor1 = handles.np1ext;
            factor2 = handles.np3ext;
            for c1 = 1:handles.np1;
                for c2 = 1:handles.np3;
                    MetabolicM0mapExpanded((c1-1)*factor1+1:c1*factor1,(c2-1)*factor2+1:c2*factor2) = ...
                        handles.MetabolicM0map(c1,c2);
                end;
            end;

            p1 = 1:1:handles.np1ext*handles.np1; p1 = p1 - (handles.np1ext*handles.np1)/2;
            p2 = 1:1:handles.np3ext*handles.np3; p2 = p2 - (handles.np3ext*handles.np3)/2;
            [x,y] = ndgrid(p1,p2);

            KernelWidth1 = handles.KernelWidth*handles.np1;
            KernelWidth2 = handles.KernelWidth*handles.np3;
            GaussianScale1 = 1/(2*KernelWidth1*KernelWidth1);
            GaussianScale2 = 1/(2*KernelWidth2*KernelWidth2);

            ConvKernel = exp(-GaussianScale1*x.^2 - GaussianScale2*y.^2);
            MetabolicM0mapConvIP = conv2(MetabolicM0mapExpanded,ConvKernel,'same');
            
            % Establish an amplitude-scaling factor for the used
            % convolution parameter settings
            maxM0map = max(max(MetabolicM0mapExpanded));
            maxM0mapConv = max(max(MetabolicM0mapConvIP));
            ConvScaling = maxM0map/maxM0mapConv;
            
            MetabolicM0mapConvIP = MetabolicM0mapConvIP*ConvScaling;
        
            % 2. FFT-based interpolation
            FID = fftshift(ifft2(ifftshift(handles.MetabolicM0map)));
            np1 = size(MetabolicM0mapExpanded,1); np2 = size(MetabolicM0mapExpanded,2);
            FID2 = zeros(np1,np2);

            x1 = round(0.5*handles.np1ext*handles.np1)-round(0.5*handles.np1);
            x2 = x1 + handles.np1 - 1;
            y1 = round(0.5*handles.np3ext*handles.np3)-round(0.5*handles.np3);
            y2 = y1 + handles.np2 - 1;

            FID2(x1:x2,y1:y2) = FID;

            MetabolicM0mapFFTIP = abs(fftshift(fft2(FID2)));
            
            % MRI and ROI
            MRIsliceExpanded = zeros(handles.np1*handles.np1ext,handles.np3*handles.np3ext);
            ROIExpanded = zeros(handles.np1*handles.np1ext,handles.np3*handles.np3ext);
            for c1 = 1:handles.np1ext;
                for c2 = 1:handles.np3ext;
                    MRIsliceExpanded((c1-1)*handles.np1+1:c1*handles.np1,(c2-1)*handles.np3+1:c2*handles.np3) = ...
                        handles.MRIslice(c1,c2);
                    ROIExpanded((c1-1)*handles.np1+1:c1*handles.np1,(c2-1)*handles.np3+1:c2*handles.np3) = ...
                        handles.ROI(c1,c2);
                end;
            end;
            
        end;
                
    case 3
        % Sagital plane
        
        if ((isfield(handles,'MRIslice') ~= 1) || (isfield(handles,'ROI') ~= 1))
            handles.MRIslice = zeros(handles.np2ext,handles.np3ext);
            handles.ROI = zeros(handles.np2ext,handles.np3ext);
        end;
        
        % ROI matrix size is different from MRI matrix size - likely due to:
        % 1. Loading a new MRI without defining a new ROI, or
        % 2. Changing the orientation on data within unequal matrix dimensions.
        if ((size(handles.ROI,1) ~= handles.np2ext) || (size(handles.ROI,2) ~= handles.np3ext))
            handles.ROI = 0.0*handles.MRIslice + 1.0;
        end;
        
        if ((rem(handles.np2ext,handles.np2) == 0) && (rem(handles.np3ext,handles.np3) == 0))
            % MRI matrix is an integer multiple of the MRSI matrix.
            % MRSI matrix will be extrapolated to MRI matrix.
            
            [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
            TextOutput1 = [OperationTime ' - Interpolating (' num2str(handles.np2) 'x' num2str(handles.np3) ...
                ') metabolic map to (' num2str(handles.np2ext) 'x' num2str(handles.np3ext) ...
                ') matrix.'];
            disp(' '); disp(TextOutput1); disp(' ');
            
            % 1. Convolution-based interpolation
            MetabolicM0mapExpanded = zeros(handles.np2ext,handles.np3ext);
            factor1 = ceil(handles.np2ext/handles.np2);
            factor2 = ceil(handles.np3ext/handles.np3);
            for c1 = 1:handles.np2;
                for c2 = 1:handles.np3;
                    MetabolicM0mapExpanded((c1-1)*factor1+1:c1*factor1,(c2-1)*factor2+1:c2*factor2) = handles.MetabolicM0map(c1,c2);
                end;
            end;

            p1 = 1:1:handles.np2ext; p1 = p1 - handles.np2ext/2;
            p2 = 1:1:handles.np3ext; p2 = p2 - handles.np3ext/2;
            [x,y] = ndgrid(p1,p2);

            GaussianScale = 1/(2*handles.KernelWidth*handles.KernelWidth);

            ConvKernel = exp(-GaussianScale*(x.^2 + y.^2));
            MetabolicM0mapConvIP = conv2(MetabolicM0mapExpanded,ConvKernel,'same');
            
            % Establish an amplitude-scaling factor for the used
            % convolution parameter settings
            maxM0map = max(max(MetabolicM0mapExpanded));
            maxM0mapConv = max(max(MetabolicM0mapConvIP));
            ConvScaling = maxM0map/maxM0mapConv;
            
            MetabolicM0mapConvIP = MetabolicM0mapConvIP*ConvScaling;
        
            % 2. FFT-based interpolation
            FID = fftshift(ifft2(ifftshift(handles.MetabolicM0map)));
            np1 = size(MetabolicM0mapExpanded,1); np2 = size(MetabolicM0mapExpanded,2);
            FID2 = zeros(np1,np2);

            x1 = round(0.5*handles.np2ext)-round(0.5*handles.np2);
            x2 = x1 + handles.np2 - 1;
            y1 = round(0.5*handles.np3ext)-round(0.5*handles.np3);
            y2 = y1 + handles.np3 - 1;

            FID2(x1:x2,y1:y2) = FID;

            MetabolicM0mapFFTIP = abs(fftshift(fft2(FID2)));
            
            % MRI and ROI remain at original resolution
            MRIsliceExpanded = handles.MRIslice;
            ROIExpanded = handles.ROI; 
            
        else
            % MRI matrix is NOT an integer multiple of the MRSI matrix.
            % MRI and MRSI matrices will be extrapolated to (MRI x MRSI) matrix.
            
            [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
            TextOutput1 = [OperationTime ' - Interpolating (' num2str(handles.np2) 'x' num2str(handles.np3) ...
                ') metabolic map to (' num2str(handles.np2*handles.np2ext) 'x' num2str(handles.np3*handles.np3ext) ...
                ') matrix.'];
            disp(' '); disp(TextOutput1); disp(' ');
 
            % 1. Convolution-based interpolation
            MetabolicM0mapExpanded = zeros(handles.np2ext*handles.np2,handles.np3ext*handles.np3);
            factor1 = handles.np2ext;
            factor2 = handles.np3ext;
            for c1 = 1:handles.np2;
                for c2 = 1:handles.np3;
                    MetabolicM0mapExpanded((c1-1)*factor1+1:c1*factor1,(c2-1)*factor2+1:c2*factor2) = ...
                        handles.MetabolicM0map(c1,c2);
                end;
            end;

            p1 = 1:1:handles.np2ext*handles.np2; p1 = p1 - (handles.np2ext*handles.np2)/2;
            p2 = 1:1:handles.np3ext*handles.np3; p2 = p2 - (handles.np3ext*handles.np3)/2;
            [x,y] = ndgrid(p1,p2);

            KernelWidth1 = handles.KernelWidth*handles.np2;
            KernelWidth2 = handles.KernelWidth*handles.np3;
            GaussianScale1 = 1/(2*KernelWidth1*KernelWidth1);
            GaussianScale2 = 1/(2*KernelWidth2*KernelWidth2);

            ConvKernel = exp(-GaussianScale1*x.^2 - GaussianScale2*y.^2);
            MetabolicM0mapConvIP = conv2(MetabolicM0mapExpanded,ConvKernel,'same');
            
            % Establish an amplitude-scaling factor for the used
            % convolution parameter settings
            maxM0map = max(max(MetabolicM0mapExpanded));
            maxM0mapConv = max(max(MetabolicM0mapConvIP));
            ConvScaling = maxM0map/maxM0mapConv;
            
            MetabolicM0mapConvIP = MetabolicM0mapConvIP*ConvScaling;
        
            % 2. FFT-based interpolation
            FID = fftshift(ifft2(ifftshift(handles.MetabolicM0map)));
            np1 = size(MetabolicM0mapExpanded,1); np2 = size(MetabolicM0mapExpanded,2);
            FID2 = zeros(np1,np2);

            x1 = round(0.5*handles.np2ext*handles.np2)-round(0.5*handles.np2);
            x2 = x1 + handles.np1 - 1;
            y1 = round(0.5*handles.np3ext*handles.np3)-round(0.5*handles.np3);
            y2 = y1 + handles.np2 - 1;

            FID2(x1:x2,y1:y2) = FID;

            MetabolicM0mapFFTIP = abs(fftshift(fft2(FID2)));
            
            % MRI and ROI
            MRIsliceExpanded = zeros(handles.np2*handles.np2ext,handles.np3*handles.np3ext);
            ROIExpanded = zeros(handles.np2*handles.np2ext,handles.np3*handles.np3ext);
            for c1 = 1:handles.np2ext;
                for c2 = 1:handles.np3ext;
                    MRIsliceExpanded((c1-1)*handles.np2+1:c1*handles.np2,(c2-1)*handles.np3+1:c2*handles.np3) = ...
                        handles.MRIslice(c1,c2);
                    ROIExpanded((c1-1)*handles.np2+1:c1*handles.np2,(c2-1)*handles.np3+1:c2*handles.np3) = ...
                        handles.ROI(c1,c2);
                end;
            end;
        end
end;