function [time, date] = DMIWizard_MRS_CalculateTime

c = fix(clock);

% Year
year = num2str(c(1));

% Months
if (c(2) < 10)
    months = ['0' num2str(c(2))];
else
    months = num2str(c(2));
end;

% Days
if (c(3) < 10)
    days = ['0' num2str(c(3))];
else
    days = num2str(c(3));
end;

% Hours
if (c(4) < 10)
    hours = ['0' num2str(c(4))];
else
    hours = num2str(c(4));
end;

% Minutes
if (c(5) < 10)
    minutes = ['0' num2str(c(5))];
else
    minutes = num2str(c(5));
end;

% Seconds
if (c(6) < 10)
    seconds = ['0' num2str(c(6))];
else
    seconds = num2str(c(6));
end;

time = [hours ':' minutes ':' seconds];
date = [year months days];