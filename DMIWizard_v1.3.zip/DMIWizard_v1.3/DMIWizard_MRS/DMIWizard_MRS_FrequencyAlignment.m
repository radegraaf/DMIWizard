function handles = DMIWizard_MRS_FrequencyAlignment(handles)

% Performs frequency and phase aligment on multi-FID data

if (handles.nfidi > 1) && isfield(handles,'specPhased') == 1
    [OperationTime,~] = DMIWizard_MRS_CalculateTime;
    TextOutput1 = [OperationTime ' - Frequency alignment started ... '];
    disp(TextOutput1);
    
    % Manual input of frequency range for alignment
    figure(2);
    MousePosition = ginput(2);
    AlignmentBoundaryLow = min(MousePosition(:,1));
    AlignmentBoundaryHigh = max(MousePosition(:,1));
    
    if (handles.fcal > 0)
        % Axis in ppm
        freq = -0.5*handles.sw:(handles.sw/(handles.npzf-1)):0.5*handles.sw;
        ppm = (1000*(freq-handles.reffreq)/handles.carfreq) + handles.refppm;
        deltappm = (max(ppm) - min(ppm))/(handles.npzf - 1);
        
        coor = find((ppm > AlignmentBoundaryLow) & (ppm < AlignmentBoundaryHigh));
    else
        % Axis in kHz
        freq = -0.5*handles.sw:(handles.sw/(handles.npzf-1)):0.5*handles.sw;
        deltafreq = (max(freq) - min(freq))/(handles.npzf - 1);
        
        coor = find((freq > AlignmentBoundaryLow) & (freq < AlignmentBoundaryHigh));
    end;

    % Determine maximum signal position (in pixels) for each spectrum
    [~,PeakFreq] = max(abs(handles.specPhased(coor,:)),[],1);
    deltaPeakFreq = PeakFreq-PeakFreq(1);
    
    % Convert pixels to frequency
    deltaPeakFreq = 1000*(deltaPeakFreq/handles.npzf)*handles.sw;
    
    % Perform polynomial fitting to remove noise frequency drifts
    if (handles.FrequencyAlignmentFit > 0)

        xx = 1:1:handles.nfidi;
        yy = deltaPeakFreq;

        ff = polyfit(xx,yy,handles.FrequencyAlignmentOrder);

        deltaPeakFreqfit = ff(handles.FrequencyAlignmentOrder+1);
        for c1 = 1:1:handles.FrequencyAlignmentOrder;
           deltaPeakFreqfit = deltaPeakFreqfit + ff(handles.FrequencyAlignmentOrder-c1+1)*xx.^c1;
        end;
    else
        xx = 1:1:handles.nfidi;
        deltaPeakFreqfit = deltaPeakFreq;
    end;
    
    % Perform frequency shifting on FID signals
    dt = 1/(1000*handles.sw); % Dwell-time (sec)

    switch handles.ConsoleType
        case 'Bruker'
            % No frequency shifting during digital group delay
            time(1:round(handles.dgd)) = 0;
            for c1 = round(handles.dgd)+1:1:handles.np;
                time(c1) = (c1 - round(handles.dgd) - 1)*dt;
            end;
        otherwise
            time = 0:dt:(handles.np-1)*dt;
    end;
    
    FIDcor = zeros(handles.np,handles.nfidi);
    for c1 = 1:1:handles.nfidi;
       % FIDcor is the frequency-corrected FID
       FIDcor(:,c1) = handles.FID(:,c1).*reshape(exp(-2*pi*1i*deltaPeakFreqfit(c1)*time),handles.np,1);
    end;

    clear handles.FID; handles.FID = FIDcor; clear FIDcor;

    % Generate corrected spectra
    clear spec handles.spec2 handles.specPhased;

    % Allocate memory
    handles.spec = zeros(handles.npzf,handles.nfidi);
    handles.specPhased = zeros(handles.npzf,handles.nfidi);

    for c1 = 1:1:handles.nfidi;
        % Time domain multiplication
        FID1 = DMIWizard_MRS_Apodization(handles.FID(:,c1), handles);

        % Fourier transformation (with zerofilling)
        handles.spec(:,c1) = fftshift(fft(FID1,handles.npzf));

        % Phase correction
        handles.specPhased(:,c1) = DMIWizard_MRS_PhaseCorrection(handles.spec(:,c1), handles);
    end;

    % Check frequency alignment performance by reprocessing the shifted data
    
    % Determine maximum signal position (in pixels) for each spectrum
    [~,PeakFreq2] = max(abs(handles.specPhased(coor,:)),[],1);
    deltaPeakFreq2 = PeakFreq2-PeakFreq2(1);
    
    % Convert pixels to frequency
    deltaPeakFreq2 = 1000*(deltaPeakFreq2/handles.npzf)*handles.sw;

    % Perform polynomial fitting to remove noise frequency drifts
    if (handles.FrequencyAlignmentFit > 0)

        xx = 1:1:handles.nfidi;
        yy = deltaPeakFreq2;

        ff = polyfit(xx,yy,handles.FrequencyAlignmentOrder);

        deltaPeakFreqfit2 = ff(handles.FrequencyAlignmentOrder+1);
        for c1 = 1:1:handles.FrequencyAlignmentOrder;
           deltaPeakFreqfit2 = deltaPeakFreqfit2 + ff(handles.FrequencyAlignmentOrder-c1+1)*xx.^c1;
        end;
    else
        xx = 1:1:handles.nfidi;
        deltaPeakFreqfit2 = deltaPeakFreq2;
    end;

    figure(3);
    subplot(2,1,1), plot(xx,deltaPeakFreq,'b',xx,deltaPeakFreqfit,'r');
    axis([1 handles.nfidi -max(abs(deltaPeakFreq))-1 max(abs(deltaPeakFreq))+1])
    xlabel('spectrum number'); ylabel('frequency (Hz)');
    title('Before frequency alignment');

    subplot(2,1,2), plot(xx,deltaPeakFreq2,'b',xx,deltaPeakFreqfit2,'g');
    axis([1 handles.nfidi -max(abs(deltaPeakFreq))-1 max(abs(deltaPeakFreq))+1])
    xlabel('spectrum number'); ylabel('frequency (Hz)');
    title('After frequency alignment');

    [OperationTime,~] = DMIWizard_MRS_CalculateTime;
    TextOutput2 = [OperationTime ' - Frequency alignment finished with a maximum correction of ' ...
        num2str(max(abs(deltaPeakFreq))) ' Hz.'];
    disp(TextOutput2);
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput2);

    % Perform FFT to visualize the results
    handles.ExtendedFFTOutput = 0;
    handles = DMIWizard_MRS_FFT(handles);
    
    % Write frequency alignment values to file
    if (ispc > 0)
       coorslash = find(handles.MetaboliteFile == '\');
    else
       coorslash = find(handles.MetaboliteFile == '/');
    end;
    handles.MetaboliteFileDir = handles.MetaboliteFile(1:max(coorslash));

    OperationTime2 = [OperationTime(1:2) OperationTime(4:5) OperationTime(7:8)];
    MRSpathFreqAlign = [handles.MetaboliteFileDir 'FrequencyAlignment' OperationTime2 '.txt'];
    fileID = fopen(MRSpathFreqAlign,'w+');
    fprintf(fileID,'%9.7f   %9.7f\n',[1:1:handles.nfidi; deltaPeakFreqfit]);
    fclose(fileID);
    
    [OperationTime,~] = DMIWizard_MRS_CalculateTime;
    TextOutput1 = [OperationTime ' - Frequency alignment values saved to file :'];
    TextOutput2 = [OperationTime ' - ' MRSpathFreqAlign];
    disp(TextOutput1); disp(TextOutput2);
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+',TextOutput2);
    
elseif handles.nfidi <= 1
    disp(' ');
    disp('Note: Initial number of FIDs is equal to one.');
    disp('Note: Frequency alignment is not performed.');
elseif isfield(handles,'spec') < 1
    disp(' ');
    disp('Note: Fourier transformation not yet performed');
    disp('Note: Frequency alignment is not performed');
end