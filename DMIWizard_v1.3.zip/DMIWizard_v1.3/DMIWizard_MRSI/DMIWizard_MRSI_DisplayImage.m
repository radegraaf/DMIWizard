function DMIWizard_MRSI_DisplayImage(MRI,handles)

fh1 = figure(1);
    set(fh1,'Units','points','Name','Image domain',...
        'Position',[handles.Fig1XPos handles.Fig1YPos handles.Fig1Width handles.Fig1Height])

% Define voxel coordinates
voxelsize1 = (handles.np1ext/handles.np1);
voxelsize2 = (handles.np2ext/handles.np2);
voxelsize3 = (handles.np3ext/handles.np3);

xx1 = 1 + (handles.sp1-1)*voxelsize1; xx2 = 1 + handles.sp1*voxelsize1;
yy1 = 1 + (handles.sp2-1)*voxelsize2; yy2 = 1 + handles.sp2*voxelsize2;
zz1 = 1 + (handles.sp3-1)*voxelsize3; zz2 = 1 + handles.sp3*voxelsize3;

% Convert pixel positions to distances
xx1d = xx1*(handles.FOV1/handles.np1ext) - 0.5*handles.FOV1;
xx2d = xx2*(handles.FOV1/handles.np1ext) - 0.5*handles.FOV1;
yy1d = yy1*(handles.FOV2/handles.np2ext) - 0.5*handles.FOV2;
yy2d = yy2*(handles.FOV2/handles.np2ext) - 0.5*handles.FOV2;
zz1d = zz1*(handles.FOV3/handles.np3ext) - 0.5*handles.FOV3;
zz2d = zz2*(handles.FOV3/handles.np3ext) - 0.5*handles.FOV3;

switch handles.Orientation
    case 1
        % Axial orientation
        imshow(abs(MRI(:,:,handles.sp4)),[0 handles.MRIHigh*10^handles.MRIScale],'InitialMagnification','fit',...
            'XData',[-0.5*handles.FOV2 0.5*handles.FOV2],'YData',[-0.5*handles.FOV1 0.5*handles.FOV1]);
        xlabel('Y (mm)'); ylabel('X (mm)'); axis on;

        if ((handles.sp4 >= zz1) && (handles.sp4 < zz2))
            % X and Y coordinates are reversed since Matlab imshow puts
            % pixel (X, Y) at position (Y, X)
            hh1 = line([yy1d yy2d], [xx1d xx1d]); set(hh1,'Color','r','Linewidth',1.5);
            hh2 = line([yy1d yy2d], [xx2d xx2d]); set(hh2,'Color','r','Linewidth',1.5);
            hh3 = line([yy1d yy1d], [xx1d xx2d]); set(hh3,'Color','r','Linewidth',1.5);
            hh4 = line([yy2d yy2d], [xx1d xx2d]); set(hh4,'Color','r','Linewidth',1.5);
        end;
        
     case 2
        % Coronal orientation

        imshow(abs(squeeze(MRI(:,handles.sp4,:))),[0 handles.MRIHigh*10^handles.MRIScale],'InitialMagnification','fit',...
            'XData',[-0.5*handles.FOV3 0.5*handles.FOV3],'YData',[-0.5*handles.FOV1 0.5*handles.FOV1]);
        xlabel('Z (mm)'); ylabel('X (mm)'); axis on;
        
        if ((handles.sp4 >= yy1) && (handles.sp4 < yy2))
            % X and Z coordinates are reversed since Matlab imshow puts
            % pixel (X, Z) at position (Z, X)
            hh1 = line([zz1d zz2d],[xx1d xx1d]); set(hh1,'Color','r','Linewidth',1.5);
            hh2 = line([zz1d zz2d],[xx2d xx2d]); set(hh2,'Color','r','Linewidth',1.5);
            hh3 = line([zz1d zz1d],[xx1d xx2d]); set(hh3,'Color','r','Linewidth',1.5);
            hh4 = line([zz2d zz2d],[xx1d xx2d]); set(hh4,'Color','r','Linewidth',1.5);
        end;
        
     case 3
        % Sagital orientation

        imshow(abs(squeeze(MRI(handles.sp4,:,:))),[0 handles.MRIHigh*10^handles.MRIScale],'InitialMagnification','fit',...
            'XData',[-0.5*handles.FOV3 0.5*handles.FOV3],'YData',[-0.5*handles.FOV2 0.5*handles.FOV2]);
        xlabel('Z (mm)'); ylabel('Y (mm)'); axis on;

        if ((handles.sp4 >= xx1) && (handles.sp4 < xx2))
            % Y and Z coordinates are reversed since Matlab imshow puts
            % pixel (Y, Z) at position (Z, Y)
            hh1 = line([zz1d zz2d],[yy1d yy1d]); set(hh1,'Color','r','Linewidth',1.5);
            hh2 = line([zz1d zz2d],[yy2d yy2d]); set(hh2,'Color','r','Linewidth',1.5);
            hh3 = line([zz1d zz1d],[yy1d yy2d]); set(hh3,'Color','r','Linewidth',1.5);
            hh4 = line([zz2d zz2d],[yy1d yy2d]); set(hh4,'Color','r','Linewidth',1.5);
        end;
        
end;
