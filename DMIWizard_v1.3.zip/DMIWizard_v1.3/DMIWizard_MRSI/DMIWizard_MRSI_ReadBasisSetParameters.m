function [sw, np, nu0, RFoffset] = DMIWizard_MRSI_ReadBasisSetParameters(filename)

% Read parameters from NMRWizard parameter file
fileID = fopen(filename,'r+');
if (fileID > 0)
    Data = textscan(fileID, '%s', 'delimiter', '\n', 'whitespace', '');
    CStr = Data{1};
    
    % Scanning for particular parameters
    % Spectral width used in simulations
    IndexParameter = strfind(CStr, 'Spectral width');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    sw = str2num(LineParameter(28:end));
    
    % Number of acquisition points used in simulations
    IndexParameter = strfind(CStr, 'Acquisition points');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    np = str2num(LineParameter(28:end));
        
    % Larmor frequency used in simulations
    IndexParameter = strfind(CStr, 'Larmor frequency');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    nu0 = str2num(LineParameter(28:end));
        
    % RF center frequency used in simulations
    IndexParameter = strfind(CStr, 'RF center frequency');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    RFoffset = str2num(LineParameter(28:end));
    
    fclose(fileID);
    
    % Display parameters
    disp(' ');
    [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
    TextOutput0 = [OperationTime ' - Reading basisset simulation parameters from ' filename];
    TextOutput1 = [OperationTime ' - Spectral width = ' num2str(sw,3) ' kHz'];
    TextOutput2 = [OperationTime ' - Number of acquisition points = ' num2str(np)];
    TextOutput3 = [OperationTime ' - Larmor frequency = ' num2str(nu0) ' MHz'];
    TextOutput4 = [OperationTime ' - RF center frequency = ' num2str(RFoffset) ' ppm'];
    disp(TextOutput0);
    disp(TextOutput1); disp(TextOutput2); disp(TextOutput3); 
    disp(TextOutput4); disp(' ');
end;