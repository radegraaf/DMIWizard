function FIDlp = DMIWizard_MRSI_LinearPredictionFunction(FID,amp,frq,decay,phs,handles)

%***********************************************************
% Function to calculate an extrapolated FID through
% backward linear prediciton (LP) following a HSVD.
%
% Robin A. de Graaf
% MRRC, Yale University
% January, 2017
%***********************************************************

nHSVD = length(amp);
dt = 1/(1000*handles.sw);

% Backward prediction
if (handles.nplp > 0)
    timestart = -handles.nplp*dt;
else
    timestart = 0;
end;

% Forward prediction
if (handles.nplp2 > 0)
    timeend = (handles.np-1)*dt + handles.nplp2*dt;
else
    timeend = (handles.np-1)*dt;
end;
time = timestart:dt:timeend;

FIDfit = zeros(1,handles.np+handles.nplp+handles.nplp2);
for c1 = 1:1:nHSVD;
    FIDfit = FIDfit + amp(c1).*exp(2*pi*1i*frq(c1)*time).*exp(time*decay(c1)).*exp(1i*phs(c1));
end;
    
% Combine the extrapolated FID points with the original FID
if (handles.nplp2 == 0)
    % Only backward prediction - keep overall FID length identical
    FIDlp(1:handles.nplp) = FIDfit(1:handles.nplp);
    FIDlp(handles.nplp+1:handles.np) = FID(1:handles.np-handles.nplp);
else
    % Forward prediction (and possible backward prediction) - the FID
    % signal becomes longer.
    FIDlp = FIDfit;
    FIDlp(handles.nplp+1:handles.nplp+handles.np) = FID(1:handles.np);
end;