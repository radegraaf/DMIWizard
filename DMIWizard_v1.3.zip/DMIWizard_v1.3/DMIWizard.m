function varargout = DMIWizard(varargin)
% DMIWIZARD MATLAB code for DMIWizard.fig
%      DMIWIZARD, by itself, creates a new DMIWIZARD or raises the existing
%      singleton*.
%
%      H = DMIWIZARD returns the handle to a new DMIWIZARD or the handle to
%      the existing singleton*.
%
%      DMIWIZARD('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DMIWIZARD.M with the given input arguments.
%
%      DMIWIZARD('Property','Value',...) creates a new DMIWIZARD or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before DMIWizard_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to DMIWizard_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help DMIWizard

% Last Modified by GUIDE v2.5 26-Sep-2019 17:04:05

addpath(genpath(pwd));

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @DMIWizard_OpeningFcn, ...
                   'gui_OutputFcn',  @DMIWizard_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before DMIWizard is made visible.
function DMIWizard_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to DMIWizard (see VARARGIN)

% Choose default command line output for DMIWizard
handles.output = hObject;

set(handles.Exit_pushbutton,'TooltipString','Closes all windows except the main DMIWizard window');

% Set Position/Size of Figure Based on Screen Size
set(groot,'Units','points');
ScreenSize = get(groot,'ScreenSize');
ScreenWidth = ScreenSize(3);
ScreenHeight = ScreenSize(4);

FigXPos = .02*ScreenWidth; % .02
FigYPos = .15*ScreenHeight; % .2275
FigWidth = .2*ScreenWidth; % .18
FigHeight = .75*ScreenHeight; %.6725

% Extract DMIWizard settings from file
handles = DMIWizard_ReadSettings(handles);
        
set(handles.figure1,'Units','points','Position',[FigXPos FigYPos FigWidth FigHeight],...
    'Color',handles.GUIBackgroundColor1)

% Initialize object settings to enhance cross-platform compatibility.
DMIWizard_InitializeSettings(handles);

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes DMIWizard wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = DMIWizard_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in MRS_pushbutton.
function MRS_pushbutton_Callback(hObject, eventdata, handles)

% Close windows associated with MRSI
hObject = findall(0,'Name','DMIWizard_MRSI');
if (isempty(hObject) < 1)
    delete(hObject);
end;

if ishandle(1)
    close(1);
end;

if ishandle(2)
    close(2);
end;

CloseWindows_pushbutton_Callback;

DMIWizard_MRS;


% --- Executes on button press in MRSI_Main_pushbutton.
function MRSI_Main_pushbutton_Callback(hObject, eventdata, handles)

% Close windows associated with 1D MRS
hObject = findall(0,'Name','DMIWizard_MRS');
if (isempty(hObject) < 1)
    delete(hObject);
end;

if ishandle(1)
    close(1);
end;

if ishandle(2)
    close(2);
end;

CloseWindows_pushbutton_Callback;

DMIWizard_MRSI;

% --- Executes on button press in Exit_pushbutton.
function Exit_pushbutton_Callback(hObject, eventdata, handles)
% Function executes on Exit button push.
clc;

close all force;

function CloseWindows_pushbutton_Callback(hObject, eventdata, handles)

% Close all windows except 1 and 2
for c1 = 3:100;
    if ishandle(c1)
        close(c1);
    end;
end;
