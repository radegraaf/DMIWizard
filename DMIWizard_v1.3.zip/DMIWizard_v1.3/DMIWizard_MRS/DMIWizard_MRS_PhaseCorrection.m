function outdata = DMIWizard_MRS_PhaseCorrection(indata, handles)

%*************************************************
% PhaseCorrection.m
%
% Phase corrects a NMR spectrum using zero- and 
% first order phase correction.
%**************************************************
np = length(indata);
freq = 0.5*handles.sw:-handles.sw/(np-1):-0.5*handles.sw;
freq = reshape(freq,np,1);

specA = real(indata).*cos((pi/180)*(handles.ph0+(handles.ph1+360*handles.dgd/handles.sw)*freq))+...
   imag(indata).*sin((pi/180)*(handles.ph0+(handles.ph1+360*handles.dgd/handles.sw)*freq));
specD = -real(indata).*sin((pi/180)*(handles.ph0+(handles.ph1+360*handles.dgd/handles.sw)*freq))+...
   imag(indata).*cos((pi/180)*(handles.ph0+(handles.ph1+360*handles.dgd/handles.sw)*freq));

outdata = specA + 1i*specD;