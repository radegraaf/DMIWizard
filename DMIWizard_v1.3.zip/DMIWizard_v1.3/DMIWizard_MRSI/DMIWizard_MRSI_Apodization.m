function outdata = DMIWizard_MRSI_Apodization(indata,handles)

handles.gmf = 0.0;
handles.gmfs = 0.0;

%********************************************************
% Apodization applies time domain multiplication of
% exponential and (shifted) Gaussian functions to a FID
%*******************************************************
np = size(indata,1);                % Number of real datapoints
dt = 1/(handles.sw*1000);           % Dwell time (sec)

%***************************************************************
% Exponential function : f(t) = exp(-t/T2)
% FT partner : g(v) = T2/(1+4*pi*pi*(v-v0)^2*T2^2)
% FWHM = 1/(pi*T2)
%
% Gaussian function : f(t) = (1/(T2*sqrt(pi)))*exp(-t^2/T2^2)
% FT partner : g(v) = (1/sqrt(2*pi))*exp(-pi*(v-v0)^2*T2^2)
% FWHM = 2*sqrt(log(2))/(pi*T2)
%***************************************************************
handles.emf = handles.emf*pi;
handles.gmf = handles.gmf*pi/(2*sqrt(log(2)));

t = 0:dt:(np-1)*dt;
em = exp(-t*handles.emf);
gm = exp(-((t-0.001*handles.gmfs)*handles.gmf).^2);

em = reshape(em,[],1);
gm = reshape(gm,[],1);

outdata = indata.*em.*gm;