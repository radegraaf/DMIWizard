function DMIWizard_MRSI_InitializeSettings(handles)

% Object with general background/foreground colors
DMIWizard_MRSI.Object1{1} = 'Text_KSpaceSampling';
DMIWizard_MRSI.Object1{2} = 'Text_DMIMatrix';
DMIWizard_MRSI.Object1{3} = 'Text_DMIFOV';
DMIWizard_MRSI.Object1{4} = 'Text_MRIMatrix';
DMIWizard_MRSI.Object1{5} = 'Text_AveragingLoop';
DMIWizard_MRSI.Object1{6} = 'Text_DataFormat';
DMIWizard_MRSI.Object1{7} = 'Text_AcquisitionOrder';
DMIWizard_MRSI.Object1{8} = 'Text_DataFlip';

DMIWizard_MRSI.Object1{9} = 'Text_SpectralWidth';
DMIWizard_MRSI.Object1{10} = 'Text_EM';
DMIWizard_MRSI.Object1{11} = 'Text_SpectralPoints';
DMIWizard_MRSI.Object1{12} = 'Text_LPDataPoints';
DMIWizard_MRSI.Object1{13} = 'Text_ZeroOrderPhase';
DMIWizard_MRSI.Object1{14} = 'Text_FirstOrderPhase';

DMIWizard_MRSI.Object1{15} = 'Text_FrequencyLow';
DMIWizard_MRSI.Object1{16} = 'Text_FrequencyHigh';
DMIWizard_MRSI.Object1{17} = 'Text_SignalLow';
DMIWizard_MRSI.Object1{18} = 'Text_SignalHigh';
DMIWizard_MRSI.Object1{19} = 'Text_SignalScale';

DMIWizard_MRSI.Object1{20} = 'Text_Position1';
DMIWizard_MRSI.Object1{21} = 'Text_Position2';
DMIWizard_MRSI.Object1{22} = 'Text_Position3';
DMIWizard_MRSI.Object1{23} = 'Text_MRISlice';
DMIWizard_MRSI.Object1{24} = 'Text_MRISignalHigh';
DMIWizard_MRSI.Object1{25} = 'Text_MRISignalScale';

DMIWizard_MRSI.Object1{26} = 'Text_Threshold';
DMIWizard_MRSI.Object1{27} = 'Text_Transparency';

% Checkboxes
DMIWizard_MRSI.Object1{28} = 'XFlip_checkbox';
DMIWizard_MRSI.Object1{29} = 'YFlip_checkbox';
DMIWizard_MRSI.Object1{30} = 'ZFlip_checkbox';
DMIWizard_MRSI.Object1{31} = 'Magnitude_checkbox';
DMIWizard_MRSI.Object1{32} = 'AbsoluteValue_checkbox';
DMIWizard_MRSI.Object1{33} = 'SNR_checkbox';
DMIWizard_MRSI.Object1{34} = 'LineWidth_checkbox';
DMIWizard_MRSI.Object1{35} = 'LineShift_checkbox';
DMIWizard_MRSI.Object1{36} = 'MRIbackground_checkbox';
DMIWizard_MRSI.Object1{37} = 'Interpolation_checkbox';

DMIWizard_MRSI.Object1{38} = 'SelectFIDSavePath_pushbutton';
DMIWizard_MRSI.Object1{39} = 'SaveFID_pushbutton';
DMIWizard_MRSI.Object1{40} = 'SelectImageSavePath_pushbutton';
DMIWizard_MRSI.Object1{41} = 'SaveImage_pushbutton';
DMIWizard_MRSI.Object1{42} = 'LinearPrediction_pushbutton';
DMIWizard_MRSI.Object1{43} = 'AutoPhasing_pushbutton';

DMIWizard_MRSI.Object1{44} = 'ConstantPhaseIncrease_pushbutton';
DMIWizard_MRSI.Object1{45} = 'LinearPhaseIncrease_pushbutton';
DMIWizard_MRSI.Object1{46} = 'FrequencyLowIncrease_pushbutton';
DMIWizard_MRSI.Object1{47} = 'FrequencyHighIncrease_pushbutton';
DMIWizard_MRSI.Object1{48} = 'SignalLowIncrease_pushbutton';
DMIWizard_MRSI.Object1{49} = 'SignalHighIncrease_pushbutton';
DMIWizard_MRSI.Object1{50} = 'SignalScalingFactorIncrease_pushbutton';

DMIWizard_MRSI.Object1{51} = 'ConstantPhaseDecrease_pushbutton';
DMIWizard_MRSI.Object1{52} = 'LinearPhaseDecrease_pushbutton';
DMIWizard_MRSI.Object1{53} = 'FrequencyLowDecrease_pushbutton';
DMIWizard_MRSI.Object1{54} = 'FrequencyHighDecrease_pushbutton';
DMIWizard_MRSI.Object1{55} = 'SignalLowDecrease_pushbutton';
DMIWizard_MRSI.Object1{56} = 'SignalHighDecrease_pushbutton';
DMIWizard_MRSI.Object1{57} = 'SignalScalingFactorDecrease_pushbutton';

DMIWizard_MRSI.Object1{58} = 'SpatialPosition1SmallIncrease_pushbutton';
DMIWizard_MRSI.Object1{59} = 'SpatialPosition2SmallIncrease_pushbutton';
DMIWizard_MRSI.Object1{60} = 'SpatialPosition3SmallIncrease_pushbutton';
DMIWizard_MRSI.Object1{61} = 'MRISliceIncrease_pushbutton';
DMIWizard_MRSI.Object1{62} = 'MRIHighIncrease_pushbutton';
DMIWizard_MRSI.Object1{63} = 'MRIScalingIncrease_pushbutton';

DMIWizard_MRSI.Object1{64} = 'SpatialPosition1SmallDecrease_pushbutton';
DMIWizard_MRSI.Object1{65} = 'SpatialPosition2SmallDecrease_pushbutton';
DMIWizard_MRSI.Object1{66} = 'SpatialPosition3SmallDecrease_pushbutton';
DMIWizard_MRSI.Object1{67} = 'MRISliceDecrease_pushbutton';
DMIWizard_MRSI.Object1{68} = 'MRIHighDecrease_pushbutton';
DMIWizard_MRSI.Object1{69} = 'MRIScalingDecrease_pushbutton';

DMIWizard_MRSI.Object1{70} = 'SpatialPosition1Increase_pushbutton';
DMIWizard_MRSI.Object1{71} = 'SpatialPosition2Increase_pushbutton';
DMIWizard_MRSI.Object1{72} = 'SpatialPosition3Increase_pushbutton';
DMIWizard_MRSI.Object1{73} = 'SpatialPosition1Decrease_pushbutton';
DMIWizard_MRSI.Object1{74} = 'SpatialPosition2Decrease_pushbutton';
DMIWizard_MRSI.Object1{75} = 'SpatialPosition3Decrease_pushbutton';

for c1 = 1:numel(DMIWizard_MRSI.Object1);
    DMIWizard_MRS_Object = findall(0,'Tag',char(DMIWizard_MRSI.Object1(c1)));
    set(DMIWizard_MRS_Object,'BackgroundColor',handles.GUIBackgroundColor1);
    set(DMIWizard_MRS_Object,'ForegroundColor',handles.GUIForegroundColor1);
    set(DMIWizard_MRS_Object,'FontName',handles.GUIFontName);
    set(DMIWizard_MRS_Object,'FontSize',handles.GUIFontSize);
end;

% Objects with MRSI/DMI-related colors
DMIWizard_MRSI.Object2{1} = 'MRSIPath_edit';
DMIWizard_MRSI.Object2{2} = 'SelectMRSIPath_pushbutton';
DMIWizard_MRSI.Object2{3} = 'LoadDMI_pushbutton';
DMIWizard_MRSI.Object2{4} = 'KSpaceSampling_popupmenu';
DMIWizard_MRSI.Object2{5} = 'FFTMRSI_pushbutton';
DMIWizard_MRSI.Object2{6} = 'PhaseIncrements1_edit';
DMIWizard_MRSI.Object2{7} = 'PhaseIncrements2_edit';
DMIWizard_MRSI.Object2{8} = 'PhaseIncrements3_edit';

DMIWizard_MRSI.Object2{9} = 'DataAcqOrder_popupmenu';
DMIWizard_MRSI.Object2{10} = 'AveragingLoop_popupmenu';
DMIWizard_MRSI.Object2{11} = 'SpatialPosition1_edit';
DMIWizard_MRSI.Object2{12} = 'SpatialPosition2_edit';
DMIWizard_MRSI.Object2{13} = 'SpatialPosition3_edit';

for c1 = 1:numel(DMIWizard_MRSI.Object2);
    DMIWizard_MRS_Object = findall(0,'Tag',char(DMIWizard_MRSI.Object2(c1)));
    set(DMIWizard_MRS_Object,'BackgroundColor',handles.GUIMRSIColor1);
    set(DMIWizard_MRS_Object,'ForegroundColor',handles.GUIForegroundColor2);
    set(DMIWizard_MRS_Object,'FontName',handles.GUIFontName);
    set(DMIWizard_MRS_Object,'FontSize',handles.GUIFontSize);
end;

% Objects with frequency-domain-related colors
DMIWizard_MRSI.Object3{1} = 'SpectralBandwidth_edit';
DMIWizard_MRSI.Object3{2} = 'ExponentialMultiply_edit';
DMIWizard_MRSI.Object3{3} = 'ZerofillingPoints_edit';
DMIWizard_MRSI.Object3{4} = 'LinearPredicDataPoints_edit';

DMIWizard_MRSI.Object3{5} = 'ConstantPhase_edit';
DMIWizard_MRSI.Object3{6} = 'LinearPhase_edit';

DMIWizard_MRSI.Object3{7} = 'FrequencyLow_edit';
DMIWizard_MRSI.Object3{8} = 'FrequencyHigh_edit';
DMIWizard_MRSI.Object3{9} = 'SignalLow_edit';
DMIWizard_MRSI.Object3{10} = 'SignalHigh_edit';
DMIWizard_MRSI.Object3{11} = 'SignalScalingFactor_edit';

DMIWizard_MRSI.Object3{12} = 'ZoomIn_pushbutton';
DMIWizard_MRSI.Object3{13} = 'ZoomOut_pushbutton';

for c1 = 1:numel(DMIWizard_MRSI.Object3);
    DMIWizard_MRS_Object = findall(0,'Tag',char(DMIWizard_MRSI.Object3(c1)));
    set(DMIWizard_MRS_Object,'BackgroundColor',handles.GUIMRSIColor2);
    set(DMIWizard_MRS_Object,'ForegroundColor',handles.GUIForegroundColor2);
    set(DMIWizard_MRS_Object,'FontName',handles.GUIFontName);
    set(DMIWizard_MRS_Object,'FontSize',handles.GUIFontSize);
end;

% Objects with MRI-related colors
DMIWizard_MRSI.Object4{1} = 'MRIPath_edit';
DMIWizard_MRSI.Object4{2} = 'SelectMRIPath_pushbutton';
DMIWizard_MRSI.Object4{3} = 'LoadMRI_pushbutton';
DMIWizard_MRSI.Object4{4} = 'FFTMRI_pushbutton';

DMIWizard_MRSI.Object4{5} = 'MRIDimension1_edit';
DMIWizard_MRSI.Object4{6} = 'MRIDimension2_edit';
DMIWizard_MRSI.Object4{7} = 'MRIDimension3_edit';
DMIWizard_MRSI.Object4{8} = 'MRISlice_edit';
DMIWizard_MRSI.Object4{9} = 'MRIHigh_edit';
DMIWizard_MRSI.Object4{10} = 'MRIScaling_edit';

for c1 = 1:numel(DMIWizard_MRSI.Object4);
    DMIWizard_MRS_Object = findall(0,'Tag',char(DMIWizard_MRSI.Object4(c1)));
    set(DMIWizard_MRS_Object,'BackgroundColor',handles.GUIMRSIColor3);
    set(DMIWizard_MRS_Object,'ForegroundColor',handles.GUIForegroundColor2);
    set(DMIWizard_MRS_Object,'FontName',handles.GUIFontName);
    set(DMIWizard_MRS_Object,'FontSize',handles.GUIFontSize);
end;

% Objects with metabolic mapping-related colors
DMIWizard_MRSI.Object5{1} = 'Threshold_edit';
DMIWizard_MRSI.Object5{2} = 'ROI_pushbutton';
DMIWizard_MRSI.Object5{3} = 'KernelWidth_edit';
DMIWizard_MRSI.Object5{4} = 'Transparency_edit';
DMIWizard_MRSI.Object5{5} = 'ParameterMap_pushbutton';
DMIWizard_MRSI.Object5{6} = 'MRSI_pushbutton';
DMIWizard_MRSI.Object5{7} = 'MRSIType_popupmenu';

for c1 = 1:numel(DMIWizard_MRSI.Object5);
    DMIWizard_MRS_Object = findall(0,'Tag',char(DMIWizard_MRSI.Object5(c1)));
    set(DMIWizard_MRS_Object,'BackgroundColor',handles.GUIMRSIColor4);
    set(DMIWizard_MRS_Object,'ForegroundColor',handles.GUIForegroundColor2);
    set(DMIWizard_MRS_Object,'FontName',handles.GUIFontName);
    set(DMIWizard_MRS_Object,'FontSize',handles.GUIFontSize);
end;

% Objects with generic color 2 (typically white entry boxes)
DMIWizard_MRSI.Object6{1} = 'SaveFIDPath_edit';
DMIWizard_MRSI.Object6{2} = 'SaveImagePath_edit';
DMIWizard_MRSI.Object6{3} = 'SystemType_popupmenu';
DMIWizard_MRSI.Object6{4} = 'FOV1_edit';
DMIWizard_MRSI.Object6{5} = 'FOV2_edit';
DMIWizard_MRSI.Object6{6} = 'FOV3_edit';

for c1 = 1:numel(DMIWizard_MRSI.Object6);
    DMIWizard_MRS_Object = findall(0,'Tag',char(DMIWizard_MRSI.Object6(c1)));
    set(DMIWizard_MRS_Object,'BackgroundColor',handles.GUIBackgroundColor2);
    set(DMIWizard_MRS_Object,'ForegroundColor',handles.GUIForegroundColor2);
    set(DMIWizard_MRS_Object,'FontName',handles.GUIFontName);
    set(DMIWizard_MRS_Object,'FontSize',handles.GUIFontSize);
end;

MRSIPath_edit_Object = findall(0,'Tag','MRSIPath_edit');
set(MRSIPath_edit_Object,'String',handles.GUIDefaultPath);

MRIPath_edit_Object = findall(0,'Tag','MRIPath_edit');
set(MRIPath_edit_Object,'String',handles.GUIDefaultPath);

SaveFIDPath_edit_Object = findall(0,'Tag','SaveFIDPath_edit');
set(SaveFIDPath_edit_Object,'String',handles.GUIDefaultPath);

SaveImagePath_edit_Object = findall(0,'Tag','SaveImagePath_edit');
set(SaveImagePath_edit_Object,'String',handles.GUIDefaultPath);