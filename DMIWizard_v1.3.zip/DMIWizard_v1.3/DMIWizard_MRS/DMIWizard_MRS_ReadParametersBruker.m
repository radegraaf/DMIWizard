function [SWH, B0, DGD] = DMIWizard_MRS_ReadParametersBruker(MRSParameterFileBruker)

% Reading entire acqu parameter file
fileID = fopen(MRSParameterFileBruker,'r');
Data = textscan(fileID, '%s', 'delimiter', '\n', 'whitespace', '');
CStr = Data{1};

% Scanning for particular parameters
% 1. Spectral width
IndexSWH = strfind(CStr, '##$SW_h= ');
Index = find(~cellfun('isempty', IndexSWH), 1);
LineSWH = char(CStr(Index));

SWH = str2num(LineSWH(10:end));

if (isempty(SWH) > 0)
    % 1. Spectral width (in vivo systems)
    IndexSWH = strfind(CStr, '##$SW_h=');
    Index = find(~cellfun('isempty', IndexSWH), 1);
    LineSWH = char(CStr(Index));

    SWH = str2num(LineSWH(9:end));
end;

% 2. Carrier frequency
IndexB0 = strfind(CStr, '##$BF1= ');
Index = find(~cellfun('isempty', IndexB0), 1);
LineB0 = char(CStr(Index));

B0 = str2num(LineB0(9:end));

if (isempty(B0) > 0)
    % 2. Carrier frequency (in vivo systems)
    IndexB0 = strfind(CStr, '##$BF1=');
    Index = find(~cellfun('isempty', IndexB0), 1);
    LineB0 = char(CStr(Index));

    B0 = str2num(LineB0(8:end));
end;

% 3. Digital group delay
IndexDGD = strfind(CStr, '##$GRPDLY= ');
Index = find(~cellfun('isempty', IndexDGD), 1);
LineDGD = char(CStr(Index));

DGD = str2num(LineDGD(12:end));

if (isempty(DGD) > 0)
    % 3. Digital group delay (in vivo systems)
    IndexDGD = strfind(CStr, '##$GRPDLY=');
    Index = find(~cellfun('isempty', IndexDGD), 1);
    LineDGD = char(CStr(Index));

    DGD = str2num(LineDGD(11:end));
end;

if (isempty(DGD) > 0)
    disp('Warning: Digital group delay could not be extracted from parameter file - value left unchanged.');
    DGD = [];
end;

if (DGD < 0)
    disp('Warning: Digital group delay could not be extracted from parameter file - value left unchanged.');
    DGD = [];
end;

% Display parameters
disp(' ');
disp('Reading Bruker parameters ...');
dd1 = ['Spectral width = ' num2str(SWH,6) ' Hz'];
dd2 = ['Carrier frequency = ' num2str(B0,6) ' MHz'];
dd3 = ['Digital group delay = ' num2str(DGD,6) ''];
disp(dd1); disp(dd2); disp(dd3);
disp('... done.');

fclose(fileID);