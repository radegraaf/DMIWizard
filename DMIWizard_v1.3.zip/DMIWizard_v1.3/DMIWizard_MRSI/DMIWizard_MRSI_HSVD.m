function [ampred,frqred,decayred,phsred] = DMIWizard_MRSI_HSVD(FID,freqmin,freqmax,handles)

%***********************************************************
% Function to decompose an FID into a limited number of
% exponentials using Hankel singular value decomposition.
%
% By Robin A. de Graaf
% MRRC, Yale University
% Original : March, 1999
% Modified : January, 2017
%***********************************************************

nHSVD = 3;%32;

%*************************************************************
% Algorithm to remove 'zero' points at the end of the FID
% due to the Bruker digital receiver delay. These zeros
% will be added again following the SVD.
%*************************************************************
th = 0;
count = handles.np;
while (th < 1)
    if (abs(FID(count)) == abs(FID(count-1)))
        count = count - 1;
    else
        th = 1;
    end;
end;

npzero = handles.np - count;
FIDsvd = FID(1:handles.np-npzero);

npnonzero = length(FIDsvd);

tacq = npnonzero/(1000*handles.sw);               % Acquisition time (in s)
dt = tacq/npnonzero;                       % Dwell-time (in s)
time = 0:dt:(npnonzero-1)*dt;              % Time base of FID
time = reshape(time,npnonzero,1);

Lmax = round(0.4*npnonzero);               % Dimension 1 for LxM SVD matrix
Mmax = npnonzero+1-Lmax;                   % Dimension 2 for LxM SVD matrix

%*****************
% Allocate memory
%*****************
H = zeros(Lmax,Mmax);

%**********************************************
% Create Hankel matrix from original FID data
%**********************************************
for L = 1:1:Lmax;
    M = 1:1:Mmax;
    H(L,M) = FIDsvd(L+M-1);
end;

%**********************************************
% Perform SVD on Hankel matrix
%**********************************************
[U,~,~] = svd(H);

Uup = zeros(Lmax-1,nHSVD);
Udown = zeros(Lmax-1,nHSVD);

%**********************************************
% Calculate truncated SVD matrix
%**********************************************
Utr = U(:,1:1:nHSVD);

for kk1 = 2:Lmax;
   for kk2 = 1:nHSVD;
      Uup(kk1-1,kk2) = Utr(kk1,kk2);
      Udown(kk1-1,kk2) = Utr(kk1-1,kk2);
   end;
end;

q = log(eig(pinv(Udown)*Uup));

%******************************************************
% Determination of frequencies and T2 constants from D
%******************************************************
clear frq decay;

% Frequency (in Hz)
frq = imag(q)/(2*pi*dt);
% Time constant (in s)
decay = real(q)/dt;

clear ampcomplex amp phs basis;

time = 0:dt:(npnonzero-1)*dt;              % Time base of FID
time = reshape(time,npnonzero,1);

% Calculate basis functions
basis = zeros(npnonzero,nHSVD);
for kk1 = 1:1:nHSVD;
    basis(:,kk1) = exp((decay(kk1)+2*pi*1i*frq(kk1))*time);
end;

% Amplitude estimates
ampcomplex = pinv(basis)*FIDsvd;

amp = abs(ampcomplex);
phs = atan2(imag(ampcomplex),real(ampcomplex));

%***********************************************************************
% Extract signals in the frequency range [freqmin, freqmax]
% Eliminate signals with T2 < 0.001 s
%***********************************************************************
coor = find((frq > 1000*freqmin) & (frq < 1000*freqmax) & (abs(decay) < 1/(pi*0.001)));

ampred = amp(coor);
frqred = frq(coor);
decayred = decay(coor);
phsred = phs(coor);