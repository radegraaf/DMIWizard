function DMIWizard_MRSI_WriteMetabolicMap(MetabolicMap,handles)

% Extract directory
if ismac
    % Mac plaform
    coor = find(handles.MRSIPath == '/');
elseif isunix
    % Linux plaform
    coor = find(handles.MRSIPath == '/');
elseif ispc
    % Windows platform
    coor = find(handles.MRSIPath == '\');
end;
MRSIpath1Dir = handles.MRSIPath(1:max(coor));
% Create a directory specifically for metabolic maps
[status,message] = mkdir(MRSIpath1Dir,'maps\text');
MRSI3DpathSave1 = [MRSIpath1Dir 'maps\text\' handles.OutputFileName];

fileID = fopen(MRSI3DpathSave1,'w+');
fprintf(fileID,'%20.7f\n',reshape(MetabolicMap,1,[]));
fclose(fileID);

% Save map in DICOM format
[status,message] = mkdir(MRSIpath1Dir,'maps\dicom');
MRSI3DpathSave2 = [MRSIpath1Dir 'maps\dicom\' handles.OutputFileName '.dcm'];
dicomwrite(MetabolicMap/max(max(abs(MetabolicMap))),MRSI3DpathSave2);

[OperationTime,~] = DMIWizard_MRSI_CalculateTime;
TextOutput1 = [OperationTime ' - Metabolic ' num2str(handles.MMStyle) ' map written to disk in:'];
TextOutput2 = [OperationTime ' - ' MRSI3DpathSave1];
TextOutput3 = [OperationTime ' - ' MRSI3DpathSave2];
disp(TextOutput1); disp(TextOutput2); disp(TextOutput3);
DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+',TextOutput2);
DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+',TextOutput3);