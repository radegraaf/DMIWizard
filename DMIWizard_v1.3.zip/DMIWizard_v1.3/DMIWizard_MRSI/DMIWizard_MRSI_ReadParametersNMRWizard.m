function [FOV1, FOV2, FOV3, np1, np2, np3, sw, np, npb, nav, nrec, nu0] = DMIWizard_MRSI_ReadParametersNMRWizard(MRSIParameterFileNMRWizard)

npb = 0;    % Parameter specific for Bruker raw data

% Read parameters from NMRWizard parameter file
fileID = fopen(MRSIParameterFileNMRWizard,'r+');
if (fileID > 0)
    Data = textscan(fileID, '%s', 'delimiter', '\n', 'whitespace', '');
    CStr = Data{1};
    
    % Scanning for particular parameters
    % Field-of-view 1
    IndexParameter = strfind(CStr, 'FOV1');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    FOV1 = str2num(LineParameter(8:end));
    
    % Field-of-view 2
    IndexParameter = strfind(CStr, 'FOV2');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    FOV2 = str2num(LineParameter(8:end));
        
    % Field-of-view 3
    IndexParameter = strfind(CStr, 'FOV3');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    FOV3 = str2num(LineParameter(8:end));
        
    % Number of points 1
    IndexParameter = strfind(CStr, 'np1');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    np1 = str2num(LineParameter(8:end));
        
    % Number of points 2
    IndexParameter = strfind(CStr, 'np2');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    np2 = str2num(LineParameter(8:end));
    
    % Number of points 3
    IndexParameter = strfind(CStr, 'np3');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    np3 = str2num(LineParameter(8:end));   
    
    % Spectral width
    IndexParameter = strfind(CStr, 'sw');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    sw = str2num(LineParameter(8:end));   
      
    % Number of points
    IndexParameter = strfind(CStr, 'np ');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    np = str2num(LineParameter(8:end));      
    
    % Number of digital filter points
    IndexParameter = strfind(CStr, 'npb');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    npb = str2num(LineParameter(8:end));
    
    % Number of averages
    IndexParameter = strfind(CStr, 'nav');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    nav = str2num(LineParameter(8:end));  
    
    % Number of receivers
    IndexParameter = strfind(CStr, 'nrec');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    nrec = str2num(LineParameter(8:end));
    
    % Larmor frequency
    IndexParameter = strfind(CStr, 'nu0');
    Index = find(~cellfun('isempty', IndexParameter),1);
    if (isempty(Index) > 0)
        [OperationTime,OperationDate] = DMIWizard_MRSI_CalculateTime;
        TextOutput10 = [OperationTime ' - Warning : Larmor frequency could not be loaded from parameter file.'];
        TextOutput11 = [OperationTime ' - Solution: Add Larmor frequency to pre-v1.3-parameter file ... continuing with 100 MHz for now.'];
        disp(' '); disp(TextOutput10); disp(TextOutput11);
        nu0 = 100; beep;
    else
        TextOutput10 = ''; TextOutput11 = '';
        LineParameter = char(CStr(Index));
        nu0 = str2num(LineParameter(8:end));
    end;
    
    fclose(fileID);
    
    % Display parameters
    disp(' ');
    [OperationTime,OperationDate] = DMIWizard_MRSI_CalculateTime;
    TextOutput0 = [OperationTime ' - Reading DMIWizard 3D MRSI parameters from ' MRSIParameterFileNMRWizard];
    TextOutput1 = [OperationTime ' - [FOV1, FOV2, FOV3] = [ ' num2str(round(FOV1)) ', ' num2str(round(FOV2)) ', ' num2str(round(FOV3)) '] mm'];
    TextOutput2 = [OperationTime ' - [np1, np2, np3] = [ ' num2str(round(np1)) ', ' num2str(round(np2)) ', ' num2str(round(np3)) ']'];
    TextOutput3 = [OperationTime ' - Spectral width = ' num2str(sw,3) ' kHz'];
    TextOutput4 = [OperationTime ' - Number of acquisition points = ' num2str(np)];
    TextOutput5 = [OperationTime ' - Number of averages = ' num2str(nav)];
    TextOutput6 = [OperationTime ' - Number of receivers = ' num2str(nrec)];
    TextOutput7 = [OperationTime ' - Larmor frequency = ' num2str(nu0) ' MHz'];
    disp(TextOutput0);
    disp(TextOutput1); disp(TextOutput2); disp(TextOutput3); 
    disp(TextOutput4); disp(TextOutput5); disp(TextOutput6);
    disp(TextOutput7); 
    disp(TextOutput10); disp(TextOutput11); disp(' ');
    
    % Write parameters to processing history file
    coor = find(MRSIParameterFileNMRWizard == '\');
    MRSIPathDir = MRSIParameterFileNMRWizard(1:max(coor));

    ProcessingHistoryFile = [MRSIPathDir 'ProcessingHistory' OperationDate  '.txt'];
    DMIWizard_WriteProcessHistory(ProcessingHistoryFile,'a',TextOutput0);
    DMIWizard_WriteProcessHistory(ProcessingHistoryFile,'a',TextOutput1);
    DMIWizard_WriteProcessHistory(ProcessingHistoryFile,'a',TextOutput2);
    DMIWizard_WriteProcessHistory(ProcessingHistoryFile,'a',TextOutput3);
    DMIWizard_WriteProcessHistory(ProcessingHistoryFile,'a',TextOutput4);
    DMIWizard_WriteProcessHistory(ProcessingHistoryFile,'a',TextOutput5);
    DMIWizard_WriteProcessHistory(ProcessingHistoryFile,'a',TextOutput6);
    DMIWizard_WriteProcessHistory(ProcessingHistoryFile,'a+',TextOutput7);
    DMIWizard_WriteProcessHistory(ProcessingHistoryFile,'a',TextOutput10);
    DMIWizard_WriteProcessHistory(ProcessingHistoryFile,'a+',TextOutput11);
end;