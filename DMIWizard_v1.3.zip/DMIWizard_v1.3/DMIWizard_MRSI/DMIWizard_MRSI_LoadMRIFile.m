function handles = DMIWizard_MRSI_LoadMRIFile(handles);
%------------------------------------------------------
% Function for reading MRI data
%
% Note - The direct reading of vendor-specific MRI
% data has been discontinued (except Bruker), due to
% the unknown k-space sampling, averaging and looping.
% It is recommended to convert vendor-specific MRI data
% to DMIWizard compatible data with external scripts.
%------------------------------------------------------

switch handles.ConsoleType
    case {'Bruker-PV6','Bruker-PV360','DMIWizard'}
        % Bruker/DMIWizard MRI data
        fileID = fopen(handles.MRIPath,'r+');
    case {'DICOM (2D)','DICOM (3D)','NifTI'}
        % Standard-format DICOM or NifTI MRI data
        fileID = exist(handles.MRIPath,'file');
        fileID = fileID - 1;
    otherwise
        clc;
        disp('Error     : Direct reading of MRI data for GE, Philips and Siemens is not supported.');
        disp('Solution  : Write an stand-alone script to convert the data to a DMIWizard-compatible format.');
        fileID = -1;
end;

if (fileID < 0)
    disp(' '); 
    disp('Error   : File does not exist or can not be opened.'); 
    disp('Solution: Check file location and/or permissions.'); 
    disp(' ');
else
    switch handles.ConsoleType
        case {'Bruker-PV6','Bruker-PV360','DMIWizard'}
            % Read k-space-based MRI data in Bruker or DMIWizard format
            OperationTime = DMIWizard_MRSI_CalculateTime;
            switch handles.ConsoleType
                case {'Bruker-PV6','Bruker-PV360'}
                    TextOutput1 = [OperationTime ' - Reading Bruker MRI data file:'];
                case 'DMIWizard'
                    TextOutput1 = [OperationTime ' - Reading DMIWizard MRI data file:'];
            end;
            TextOutput2 = [OperationTime ' - ' handles.MRIPath];
            disp(TextOutput1); disp(TextOutput2);
                
            switch handles.ConsoleType
                case {'Bruker-PV6','DMIWizard'}
                    indata1 = fread(fileID, inf, 'long');
                case 'Bruker-PV360'
                    indata1 = fread(fileID, inf, 'float64');
            end;
            fclose(fileID);
            
            OperationTime = DMIWizard_MRSI_CalculateTime;
            switch handles.ConsoleType
                case {'Bruker-PV6','Bruker-PV360'}
                    TextOutput1 = [OperationTime ' - Reading Bruker MRI data file completed.'];
                case 'DMIWizard'
                    TextOutput1 = [OperationTime ' - Reading DMIWizard MRI data file completed.'];
            end;
            disp(TextOutput1);
            
            % Read parameters from Bruker parameter file
            if ismac
                % Mac plaform
                coor = find(handles.MRIPath == '/');
            elseif isunix
                % Linux plaform
                coor = find(handles.MRIPath == '/');
            elseif ispc
                % Windows platform
                coor = find(handles.MRIPath == '\');
            end
            MRIpath2Dir = handles.MRIPath(1:max(coor));

            MRIParameterFileBruker = [MRIpath2Dir 'method'];
            if (exist(MRIParameterFileBruker,'file') > 0)
               [handles.FOV1mri, handles.FOV2mri, handles.FOV3mri, ...
                   handles.np1mri, handles.np2mri, handles.np3mri] = DMIWizard_MRSI_MRIReadParametersBruker(MRIParameterFileBruker);
            end;
            
            % Update parameters, np1mri, np2mri, np3mri
            set(handles.MRIDimension1_edit, 'String', handles.np1mri);
            set(handles.MRIDimension2_edit, 'String', handles.np2mri);
            set(handles.MRIDimension3_edit, 'String', handles.np3mri);
            
            % Make extended matrix equal to acquisition matrix
            handles.np1ext = handles.np1mri;
            handles.np2ext = handles.np2mri;
            handles.np3ext = handles.np3mri;
            set(handles.MRIExtDimension1_edit, 'String', handles.np1ext);
            set(handles.MRIExtDimension2_edit, 'String', handles.np2ext);
            set(handles.MRIExtDimension3_edit, 'String', handles.np3ext);
            
            handles.FIDMRI = indata1(1:2:end) + 1i*indata1(2:2:end);
            
            if (rem(numel(handles.FIDMRI)/(handles.np2mri*handles.np3mri),1) > 0)
                % MRI file size is different from extracted matrix dimensions
                [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
                ErrorOutput1 = [OperationTime ' - Error   : MRI file size (' ...
                    num2str(numel(handles.FIDMRI)) ') is not in agreement with MRI matrix dimensions (' ...
                    num2str(handles.np1mri) ', ' num2str(handles.np2mri) ', ' num2str(handles.np3mri) ').'];
                ErrorOutput2 = [OperationTime ' - Solution: Continuing with empty, zero-amplitude MRI matrix of size (' ...
                    num2str(handles.np1mri) ', ' num2str(handles.np2mri) ', ' num2str(handles.np3mri) ')'];
                disp(ErrorOutput1); disp(ErrorOutput2);
                
                handles.FIDMRI = zeros(handles.np1mri,handles.np2mri,handles.np3mri);
            else     
                handles.FIDMRI = reshape(handles.FIDMRI,[],handles.np2mri,handles.np3mri);
                handles.np1mri = size(handles.FIDMRI,1);
                set(handles.MRIDimension1_edit, 'String', handles.np1mri);
            end;
            % Added step in case GO_block_size = Standard
            handles.FIDMRI = handles.FIDMRI(1:handles.np1mri,:,:);
            handles.FIDMRI = handles.FIDMRI(:,:,end:-1:1);
            
            % Check if MRI slice number is larger than MRI matrix size (due
            % to previously loaded, larger MRI dataset).
            switch handles.Orientation
                case 1
                    % Axial orientation
                    if (handles.sp4 > handles.np3ext)
                        handles.sp4 = handles.np3ext;
                        set(handles.MRISlice_edit, 'String', handles.sp4);
                    end;
                case 2
                    % Coronal orientation
                    if (handles.sp4 > handles.np2ext)
                        handles.sp4 = handles.np2ext;
                        set(handles.MRISlice_edit, 'String', handles.sp4);
                    end;
                case 3
                    % Sagittal orientation
                    if (handles.sp4 > handles.np1ext)
                        handles.sp4 = handles.np1ext;
                        set(handles.MRISlice_edit, 'String', handles.sp4);
                    end;
            end;
            
            % Read MRI pixel shift (if it exist)
            MRIShiftFileBruker = [MRIpath2Dir 'MRIshift.txt'];
            if (exist(MRIShiftFileBruker,'file') > 0)
                fileID = fopen(MRIShiftFileBruker,'r');
                if (fileID > 0)
                    datain = fscanf(fileID,'%g',[1 Inf]);
                    fclose(fileID);
                    
                    handles.MRIshift1 = round(datain(1));
                    handles.MRIshift2 = round(datain(2));
                    handles.MRIshift3 = round(datain(3));
                    
                    OperationTime = DMIWizard_MRSI_CalculateTime;
                    TextOutput1 = [OperationTime ' - MRI pixel shift file (' MRIShiftFileBruker ') found and read.'];
                    TextOutput2 = [OperationTime ' - MRI will be shifted by [' num2str(handles.MRIshift1) ', ' ...
                        num2str(handles.MRIshift2) ', ' num2str(handles.MRIshift3) ' ] pixels during FFT.'];
                    disp(TextOutput1); disp(TextOutput2);
                else
                    handles.MRIshift1 = 0.0;
                    handles.MRIshift2 = 0.0;
                    handles.MRIshift3 = 0.0;
                end;
            else
                handles.MRIshift1 = 0.0;
                handles.MRIshift2 = 0.0;
                handles.MRIshift3 = 0.0;               
            end;
       
            disp('... done.');
            
        case {'DICOM (2D)','DICOM (3D)','NifTI'}
            % Read image-space MRI data in DICOM or NifTI format
            switch handles.ConsoleType
                case 'DICOM (2D)'
                    % Multi-file DICOM format with one 2D image per file
                    if ispc
                        % Windows platform
                        coor = find(handles.MRIPath == '\');
                    else
                        % Linux plaform
                        coor = find(handles.MRIPath == '/');
                    end;
                    MRIpath2Dir = handles.MRIPath(1:max(coor));
                    MRIpath2Files = dir(MRIpath2Dir);
                    nfiles = numel(MRIpath2Files);
                    
                    count = 1;
                    for c1 = 1:nfiles;
                        if (double(MRIpath2Files(c1).isdir) < 1)
                            file = [MRIpath2Dir '\' MRIpath2Files(c1).name];
                            if (exist(file,'file') > 0)
                                data1 = dicomread(file);
                                data(:,:,count) = data1;
                                count = count + 1;
                            end;
                        end;
                    end;
                    
                    % Perform ifftn to retain compatibility with overall
                    % DMIWizard flow (i.e. load MRI > FFT MRI).
                    handles.FIDMRI = ifftshift(ifftn(ifftshift(squeeze(data))));
                    
                    handles.MRIshift1 = 0.0;
                    handles.MRIshift2 = 0.0;
                    handles.MRIshift3 = 0.0;  
                    
                    handles.np1mri = size(handles.FIDMRI,1);
                    handles.np2mri = size(handles.FIDMRI,2);
                    handles.np3mri = size(handles.FIDMRI,3);
                    
                    % Update parameters, np1mri, np2mri, np3mri
                    set(handles.MRIDimension1_edit, 'String', handles.np1mri);
                    set(handles.MRIDimension2_edit, 'String', handles.np2mri);
                    set(handles.MRIDimension3_edit, 'String', handles.np3mri);
                    
                case 'DICOM (3D)'
                    % Single-file DICOM format with volumetric 3D data
                    [data, info] = dicomreadVolume(handles.MRIPath);
                    
                    % Perform ifftn to retain compatibility with overall
                    % DMIWizard flow (i.e. load MRI > FFT MRI).
                    handles.FIDMRI = ifftshift(ifftn(ifftshift(squeeze(data))));
                    
                    handles.MRIshift1 = 0.0;
                    handles.MRIshift2 = 0.0;
                    handles.MRIshift3 = 0.0;  
                    
                    handles.np1mri = size(handles.FIDMRI,1);
                    handles.np2mri = size(handles.FIDMRI,2);
                    handles.np3mri = size(handles.FIDMRI,3);
                    
                    % Update parameters, np1mri, np2mri, np3mri
                    set(handles.MRIDimension1_edit, 'String', handles.np1mri);
                    set(handles.MRIDimension2_edit, 'String', handles.np2mri);
                    set(handles.MRIDimension3_edit, 'String', handles.np3mri);
                case 'NifTI'
                    % Single-file NifTI format
                    
            end;
    end;
end;