function DMIWizard_MRSI_WriteFittingIDs(handles)

%**************************************************************************
% DMIWizard_MRSI_WriteFittingIDs.m
%
% Write file to link fitting results to specific metabolites.
%**************************************************************************

% Extract directory for saving purposes
if ismac
    % Mac plaform
    coor = find(handles.MRSIPath == '/');
elseif isunix
    % Linux plaform
    coor = find(handles.MRSIPath == '/');
elseif ispc
    % Windows platform
    coor = find(handles.MRSIPath == '\');
end               
MRSIPathDir = handles.MRSIPath(1:max(coor));

file = [MRSIPathDir '\FittingResultsID.txt'];
fileID = fopen(file,'w');

for c1 = 1:handles.nres;
    GroupCSkHz = -0.001*(handles.RFCenterFrequency - handles.PKData.GroupCS(c1,1))*handles.nu0;
    output = [handles.PKData.MetaboliteName{c1} '   ' num2str(handles.PKData.GroupCS(c1,1)) '   ' num2str(GroupCSkHz) '\n'];
    fprintf(fileID,output);
end;

fclose(fileID);

[OperationTime,~] = DMIWizard_MRSI_CalculateTime;
TextOutput1 = [OperationTime ' - Fitting IDs written to: ' file];
disp(' '); disp(TextOutput1);