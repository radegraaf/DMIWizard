function handles = DMIWizard_MRSI_DisplaySpectrum(handles)

freq = -0.5*handles.sw:handles.sw/(handles.npzf-1):0.5*handles.sw;
freq = reshape(freq,[],1);

% Check if indicated spatial positions (sp1, sp2, sp3) are valid for
% the current dataset of size (np1, np2, np3)
if (handles.sp1 > handles.np1)
    handles.sp1 = round(handles.np1/2);
    SpatialPosition1_Object = findall(0,'Tag','SpatialPosition1_edit');
    set(SpatialPosition1_Object,'String',handles.sp1);
end;

if (handles.sp2 > handles.np2)
    handles.sp2 = round(handles.np2/2);
    SpatialPosition2_Object = findall(0,'Tag','SpatialPosition2_edit');
    set(SpatialPosition2_Object,'String',handles.sp2);
end;

if (handles.sp3 > handles.np3)
    handles.sp3 = round(handles.np3/2);
    SpatialPosition3_Object = findall(0,'Tag','SpatialPosition3_edit');
    set(SpatialPosition3_Object,'String',handles.sp3);
end;

sp1 = round(handles.sp1); handles.sp1extra = handles.sp1 - sp1;
sp2 = round(handles.sp2); handles.sp2extra = handles.sp2 - sp2;
sp3 = round(handles.sp3); handles.sp3extra = handles.sp3 - sp3;

% Phase-shift k-space followed by FFT when MRSI grid is shifted
if ((abs(handles.sp1extra) > 0) || (abs(handles.sp2extra) > 0) || (abs(handles.sp3extra) > 0))
    handles = DMIWizard_MRSI_FFT(handles);
end;

% Extract 1D spectrum from 3D dataset
spec = handles.spec3D(:,sp1,sp2,sp3);
spec = DMIWizard_MRSI_PhaseCorrection(spec,handles);

if (isfield(handles,'spec3Dfit') > 0)
    specfit = handles.spec3Dfit(:,sp1,sp2,sp3);
    specfit = DMIWizard_MRSI_PhaseCorrection(specfit,handles);
end;

% Display experimental spectrum only

fh2 = figure(2);
clf;
set(fh2,'Units','points','Name','Frequency domain',...
    'Position',[handles.Fig2XPos handles.Fig2YPos handles.Fig2Width handles.Fig2Height]);

axes('XDir','reverse','XLim',[handles.ZxLow handles.ZxHigh],'YLim',[handles.ZyLow handles.ZyHigh],'NextPlot','add');

if (handles.av < 1)
    % Phase-sensitive display
    if (isfield(handles,'spec3Dfit') > 0)
        plot(freq,(real(spec)/(10^handles.ZyScale)),'b',freq,(real(specfit)/(10^handles.ZyScale)),'r')
    else
        plot(freq,(real(spec)/(10^handles.ZyScale)),'b')
    end;
    xlabel('Frequency (kHz)')
else
    % Absolute-value display
    if (isfield(handles,'spec3Dfit') > 0)
        plot(freq,(abs(spec)/(10^handles.ZyScale)),'b',freq,(abs(specfit)/(10^handles.ZyScale)),'r')
    else
        plot(freq,(abs(spec)/(10^handles.ZyScale)),'b')
    end;
    xlabel('Frequency (kHz)')
end;