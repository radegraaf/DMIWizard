function [FOV1, FOV2, FOV3, sw, np1, np2, np3, nav, np, npb, ...
    nrec, KSpaceSamplingScheme, nu0] = DMIWizard_MRSI_ReadParametersBruker(MRSIParameterFileBruker)

% Reading entire method parameter file
fileID = fopen(MRSIParameterFileBruker,'r');
Data = textscan(fileID, '%s', 'delimiter', '\n', 'whitespace', '');
CStr = Data{1};

% Scanning for particular parameters
% FOV1, FOV2, FOV3
IndexFOV = strfind(CStr, '##$MRSIFOV1=');
Index = find(~cellfun('isempty', IndexFOV), 1);
LineFOV = char(CStr(Index));
FOV1 = str2num(LineFOV(13:end));

IndexFOV = strfind(CStr, '##$MRSIFOV2=');
Index = find(~cellfun('isempty', IndexFOV), 1);
LineFOV = char(CStr(Index));
FOV2 = str2num(LineFOV(13:end));

IndexFOV = strfind(CStr, '##$MRSIFOV3=');
Index = find(~cellfun('isempty', IndexFOV), 1);
LineFOV = char(CStr(Index));
FOV3 = str2num(LineFOV(13:end));

% np1, np2, np3
IndexNP = strfind(CStr, '##$MRSIEncodingSteps1=');
Index = find(~cellfun('isempty', IndexNP), 1);
LineNP = char(CStr(Index));
np1 = str2num(LineNP(23:end));

IndexNP = strfind(CStr, '##$MRSIEncodingSteps2=');
Index = find(~cellfun('isempty', IndexNP), 1);
LineNP = char(CStr(Index));
np2 = str2num(LineNP(23:end));

IndexNP = strfind(CStr, '##$MRSIEncodingSteps3=');
Index = find(~cellfun('isempty', IndexNP), 1);
LineNP = char(CStr(Index));
np3 = str2num(LineNP(23:end));

% sw
IndexSW = strfind(CStr, '##$PVM_SpecSWH=');
Index = find(~cellfun('isempty', IndexSW), 1);
LineSW = char(CStr(Index+1));
sw = str2num(LineSW);
sw = sw/1000;

% nav, number of averages
IndexNAV = strfind(CStr, '##$PVM_NAverages=');
Index = find(~cellfun('isempty', IndexNAV), 1);
LineNAV = char(CStr(Index));
nav = str2num(LineNAV(18:end));

% np, number of acquisition points
IndexNP = strfind(CStr, '##$PVM_SpecMatrix=');
Index = find(~cellfun('isempty', IndexNP), 1);
LineNP = char(CStr(Index+1));
np = str2num(LineNP);

% npb, number of digital group delay points
IndexNPB = strfind(CStr, '##$PVM_DigShift=');
Index = find(~cellfun('isempty', IndexNPB), 1);
LineNPB = char(CStr(Index));
npb = round(str2num(LineNPB(17:end)));

% nrec, number of receivers
IndexNREC = strfind(CStr, '##$PVM_EncNReceivers=');
Index = find(~cellfun('isempty', IndexNREC), 1);
LineNREC = char(CStr(Index));
nrec = str2num(LineNREC(22:end));

% K-space sampling pattern
IndexKSP = strfind(CStr, '##$KSpacePattern=');
Index = find(~cellfun('isempty', IndexKSP), 1);
IndexKSP = char(CStr(Index));
KSpaceSamplingName = IndexKSP(18:end);

% Larmor frequency, nu0
IndexLF = strfind(CStr, '##$PVM_FrqRef=');
Index = find(~cellfun('isempty', IndexLF), 1);
LineNF = char(CStr(Index+1));
nu0 = str2num(LineNF(1:6));

fclose(fileID);

switch KSpaceSamplingName
    case 'Cubic_linear'
        KSpaceSamplingScheme = 1;
    case 'Spherical_linear'
        KSpaceSamplingScheme = 2;
end;

% Display parameters
disp(' ');
[OperationTime,OperationDate] = DMIWizard_MRSI_CalculateTime;
TextOutput0 = [OperationTime ' - Reading Bruker 3D MRSI parameters from ' MRSIParameterFileBruker];
TextOutput1 = [OperationTime ' - [FOV1, FOV2, FOV3] = [ ' num2str(round(FOV1)) ', ' num2str(round(FOV2)) ', ' num2str(round(FOV3)) '] mm'];
TextOutput2 = [OperationTime ' - [np1, np2, np3] = [ ' num2str(round(np1)) ', ' num2str(round(np2)) ', ' num2str(round(np3)) ']'];
TextOutput3 = [OperationTime ' - Spectral width = ' num2str(sw,3) ' kHz'];
TextOutput4 = [OperationTime ' - Number of acquisition points = ' num2str(np)];
TextOutput5 = [OperationTime ' - Digital group delay points = ' num2str(npb)];
TextOutput6 = [OperationTime ' - Number of averages = ' num2str(nav)];
TextOutput7 = [OperationTime ' - Number of receivers = ' num2str(nrec)];
TextOutput8 = [OperationTime ' - K-space sampling scheme = ' KSpaceSamplingName];
TextOutput9 = [OperationTime ' - Larmor frequency = ' num2str(nu0) ' MHz'];
disp(TextOutput0);
disp(TextOutput1); disp(TextOutput2); disp(TextOutput3); 
disp(TextOutput4); disp(TextOutput5); disp(TextOutput6);
disp(TextOutput7); disp(TextOutput8); disp(TextOutput9);
disp(' ');

% Write parameters to processing history file
coor = find(MRSIParameterFileBruker == '\');
MRSIPathDir = MRSIParameterFileBruker(1:max(coor));

ProcessingHistoryFile = [MRSIPathDir 'ProcessingHistory' OperationDate  '.txt'];
DMIWizard_WriteProcessHistory(ProcessingHistoryFile,'a',TextOutput0);
DMIWizard_WriteProcessHistory(ProcessingHistoryFile,'a',TextOutput1);
DMIWizard_WriteProcessHistory(ProcessingHistoryFile,'a',TextOutput2);
DMIWizard_WriteProcessHistory(ProcessingHistoryFile,'a',TextOutput3);
DMIWizard_WriteProcessHistory(ProcessingHistoryFile,'a',TextOutput4);
DMIWizard_WriteProcessHistory(ProcessingHistoryFile,'a',TextOutput5);
DMIWizard_WriteProcessHistory(ProcessingHistoryFile,'a',TextOutput6);
DMIWizard_WriteProcessHistory(ProcessingHistoryFile,'a',TextOutput7);
DMIWizard_WriteProcessHistory(ProcessingHistoryFile,'a',TextOutput8);
DMIWizard_WriteProcessHistory(ProcessingHistoryFile,'a+',TextOutput9);
