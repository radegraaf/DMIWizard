function outdata = DMIWizard_MRSI_FittingFunction02(handles,c1,c2,c3)

%--------------------------------------------------------------------------
% Function for spectral fitting with (distorted) Gaussian or Lorentzian
% lines, low-order baseline and prior knowledge limits on line widths
% and line shifts.
%
% Called by DMIWizard_Fitting.m
%--------------------------------------------------------------------------
dt = 1/handles.sw;                  % Dwell-time (ms)
time = 0:dt:(handles.np-1)*dt;      % Time base (ms)
time = reshape(time,[],1);

% Calculate lineshape distortion, common to all resonances
M0LSD = handles.LCMFit.LSD(1,c1,c2,c3);
nuLSD0 = 0.001*handles.LCMFit.LSD(2,c1,c2,c3);
phsLSD = handles.LCMFit.LSD(3,c1,c2,c3);
FIDLSD = M0LSD*exp(2*pi*1i*nuLSD0*time).*exp(1i*phsLSD);
    
for c4 = 2:handles.MaxLSD;
    M0LSD = handles.LCMFit.LSD(3*c4-2,c1,c2,c3);
    nuLSD = 0.001*handles.LCMFit.LSD(3*c4-1,c1,c2,c3);
    phsLSD = handles.LCMFit.LSD(3*c4-0,c1,c2,c3);
    FIDLSD = FIDLSD + M0LSD*exp(2*pi*1i*(nuLSD0+nuLSD)*time).*exp(1i*phsLSD);
end;

% Normalize lineshape distortion based on first datapoint
realFID1 = (10^-8)*round(real((10^8)*FIDLSD(1)));
FIDLSD = FIDLSD/realFID1;

specfit = 0;
for c0 = 1:handles.nresFit;
    % Amplitude, M0
    M0 = handles.LCMFit.M0(c0,c1,c2,c3)*handles.LCMFit.BasisFID(:,c0)*10^handles.ZyScaleFit;
    % Frequency shift
    nu = 0.001*handles.LCMFit.LineShift(c0,c1,c2,c3);
    % Line width
    switch handles.LineshapeFit
        case 'Gaussian'
            T2 = 2000*sqrt(log(2))/(pi*handles.LCMFit.LineWidth(c0,c1,c2,c3));
            FIDfit = M0.*exp(2*pi*1i*nu*time).*exp(-time.*time/(T2*T2));
        case 'Lorentzian'
            T2 = 1000/(pi*handles.LCMFit.LineWidth(c0,c1,c2,c3));
            FIDfit = M0.*exp(2*pi*1i*nu*time).*exp(-time/T2);
    end;
    
    % Add phase term
    GroupCSkHz = 0.001*(handles.LCMFit.MetaboliteCS(c0) - handles.RFCenterFrequency)*handles.nu0;
    nutotal = GroupCSkHz + 0.001*nu; 
    FIDPH = exp(1i*(pi/180)*handles.LCMFit.Phase(1,c1,c2,c3) + ...
        1i*(pi/180)*handles.LCMFit.Phase(2,c1,c2,c3)*nutotal);
    FIDfit = FIDfit.*FIDPH;
    
    % Apply lineshape distortion in time domain
    FIDfit = FIDfit.*FIDLSD;
    
    % Apodization and Fourier transformation
    FIDapodized = DMIWizard_MRSI_Apodization(reshape(FIDfit,[],1),handles);
    specfit1 = fftshift(fft(FIDapodized,handles.npzf));

    specfit1 = DMIWizard_MRSI_PhaseCorrection(specfit1,handles);
    
    specfit = specfit + specfit1;
end;

% Add low-order baseline
freq = -0.5*handles.sw:handles.sw/(handles.npzf-1):0.5*handles.sw;
freq = reshape(freq,[],1);

for c0 = 1:3;
    specfit = specfit + (10^handles.ZyScale)*handles.LCMFit.Baseline(c0,c1,c2,c3)*freq.^(c0-1);
end;

outdata = specfit;