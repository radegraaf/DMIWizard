function [MetaboliteName, ChemicalShift, Frequency, ErrorFlag] = ...
    DMIWizard_MRSI_ReadFittingIDs(handles)

%**************************************************************************
% DMIWizard_MRSI_ReadFittingIDs.m
%
% Read file to link fitting results to specific metabolites.
%**************************************************************************

% Extract directory for saving purposes
if ismac
    % Mac plaform
    coor = find(handles.MRSIPath == '/');
elseif isunix
    % Linux plaform
    coor = find(handles.MRSIPath == '/');
elseif ispc
    % Windows platform
    coor = find(handles.MRSIPath == '\');
end               
MRSIPathDir = handles.MRSIPath(1:max(coor));

file = [MRSIPathDir '\FittingResultsID.txt'];
fileID = fopen(file,'r');

ErrorFlag = 0;
if (fileID > 0)
    datain = textscan(fileID,'%s %f %f');
    MetaboliteName = datain{1};
    ChemicalShift = datain{2};
    Frequency = datain{3};

    fclose(fileID);
    
    [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
    TextOutput1 = [OperationTime ' - Fitting IDs read from: ' file];
    disp(TextOutput1);
else
    MetaboliteName = []; ChemicalShift = []; Frequency = [];
    ErrorFlag = 1;
end;

