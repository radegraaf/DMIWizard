function handles = DMIWizard_MRS_LoadMetaboliteFile(handles)

%---------------------------------------------------
% Function for reading vendor-specific FID files
%---------------------------------------------------

switch handles.ConsoleType
    case 'Bruker'
        if (handles.be > 0)
            fileID = fopen(handles.MetaboliteFile,'r','b');
        else
            fileID = fopen(handles.MetaboliteFile,'r');
        end;
    case 'DMIWizard'
        fileID = fopen(handles.MetaboliteFile,'r');
    case 'Varian'
        fileID = fopen(handles.MetaboliteFile,'r','b');
    case 'Philips'
        fileID = 1;
    case 'Siemens'
        fileID = fopen(handles.MetaboliteFile,'r');
end

if fileID < 0
    errordlg('Selected data file cannot be found or read.','File Error');
    
    % Assign default values to parameters
    handles.FID = zeros(1,1024);
    
    [OperationTime,OperationDate] = DMIWizard_MRS_CalculateTime; 
    ErrorMessage1 = [OperationTime ' - Error   : Selected data file cannot be found or read.'];
    ErrorMessage2 = [OperationTime ' - Solution: Continuing with an (1x1024) zero-amplitude FID and default parameters.'];
    disp(' '); disp(ErrorMessage1); disp(ErrorMessage2);
    
    % Create processing history file name
    % Find the appropriate output directory
    dirs = regexp(path, pathsep,'split');
    if ismac
        % Mac plaform
        SearchTerm = '/DMIWizard/Results';
    elseif isunix
        % Linux plaform
        SearchTerm = '/DMIWizard/Results';
    elseif ispc
        % Windows platform
        SearchTerm = '\DMIWizard\Results';
    end

    for c1 = 1:length(dirs);
       DirOne = char(dirs(c1));
       if (length(DirOne) > 17)
           DirMatch = strcmp(DirOne(end-17:end),SearchTerm);
           if (DirMatch > 0)
               OutputDirBase = DirOne;
           end;
       end;
    end;
    
    if ismac
        % Mac plaform
        handles.ProcessingHistoryFile = [OutputDirBase '/ProcessingHistory' OperationDate  '.txt'];
    elseif isunix
        % Linux plaform
        handles.ProcessingHistoryFile = [OutputDirBase '/ProcessingHistory' OperationDate  '.txt'];
    elseif ispc
        % Windows platform
        handles.ProcessingHistoryFile = [OutputDirBase '\ProcessingHistory' OperationDate  '.txt'];
    end
    
else   
    switch handles.ConsoleType
        case 'Bruker'
            [OperationTime,~] = DMIWizard_MRS_CalculateTime;
            TextOutput1 = [OperationTime ' - Reading Bruker FID data file:'];
            TextOutput2 = [OperationTime ' - ' handles.MetaboliteFile];
            disp(TextOutput1); disp(TextOutput2);
            
            indata1 = fread(fileID, Inf, 'long');
            fclose(fileID);
            
            if (mod(length(indata1),2) == 0)
                handles.FID = indata1(1:2:length(indata1)) + 1i*indata1(2:2:length(indata1));
            else
                handles.FID = zeros(1,1024);
                TextOutput4 = [OperationTime ' - Error   : Odd number of data points.'];
                TextOutput5 = [OperationTime ' - Solution: Check data format selection.'];
                disp(TextOutput4); disp(TextOutput5);
            end;
            
            [OperationTime,~] = DMIWizard_MRS_CalculateTime;
            TextOutput3 = [OperationTime ' - Reading Bruker FID data file completed.'];
            disp(TextOutput3);
            
            if (handles.ParUpdate > 0)
                % Read parameters from Bruker parameter file(s)
                if ismac
                    % Mac plaform
                    coor = find(handles.MetaboliteFile == '/');
                elseif isunix
                    % Linux plaform
                    coor = find(handles.MetaboliteFile == '/');
                elseif ispc
                    % Windows platform
                    coor = find(handles.MetaboliteFile == '\');
                end        
                MRSpathLoadDir = handles.MetaboliteFile(1:max(coor));

                % ParaVision data
                MRSParameterFileBruker = [MRSpathLoadDir 'acqp'];
                if (exist(MRSParameterFileBruker,'file') > 0)
                    [handles.sw, handles.carfreq, handles.dgd2] = DMIWizard_MRS_ReadParametersBruker(MRSParameterFileBruker);
                    if (isempty(handles.dgd2) < 1)
                        handles.dgd = handles.dgd2;
                    end;
                    handles.sw = handles.sw/1000;   % Hz -> kHz conversion
                else
                    % Topspin data
                    MRSParameterFileBruker = [MRSpathLoadDir 'acqus'];
                    if (exist(MRSParameterFileBruker,'file') > 0)
                        [handles.sw, handles.carfreq, handles.dgd2] = ...
                            DMIWizard_MRS_ReadParametersBruker(MRSParameterFileBruker);
                        if (isempty(handles.dgd2) < 1)
                            handles.dgd = handles.dgd2;
                        end;
                        handles.sw = handles.sw/1000;   % Hz -> kHz conversion
                    else
                        TextOutput4 = [OperationTime ' - Warning : Bruker parameters could not be accessed.'];
                        TextOutput5 = [OperationTime ' - Solution: Continuing with default parameters.'];
                        disp(TextOutput4); disp(TextOutput5);  
                    end;
                end;
            end;
            
            % Create new processing history file
            if ismac
                % Mac plaform
                coor = find(handles.MetaboliteFile == '/');
            elseif isunix
                % Linux plaform
                coor = find(handles.MetaboliteFile == '/');
            elseif ispc
                % Windows platform
                coor = find(handles.MetaboliteFile == '\');
            end     
            MRSpathLoadDir = handles.MetaboliteFile(1:max(coor));
                
            [~,OperationDate] = DMIWizard_MRS_CalculateTime;
            handles.ProcessingHistoryFile = [MRSpathLoadDir 'ProcessingHistory' OperationDate  '.txt'];
            DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'w+',TextOutput1);
            DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput2);
            DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+',TextOutput3);
        
        case 'DMIWizard'
            [OperationTime,~] = DMIWizard_MRS_CalculateTime;
            TextOutput1 = [OperationTime ' - Reading DMIWizard FID data file:'];
            TextOutput2 = [OperationTime ' - ' handles.MetaboliteFile];
            disp(TextOutput1); disp(TextOutput2);
            
            indata1 = fscanf(fileID,'%g		%g',[2 inf]);

            if (isempty(indata1) > 0)
                [OperationTime,~] = DMIWizard_MRS_CalculateTime;
                ErrorOutput1 = [OperationTime ' - Error : FID file format does not match DMIWizard data format.'];
                ErrorOutput2 = [OperationTime ' - Advice: File format should be two-column text format with real/imaginary time domain points.'];
                disp(ErrorOutput1); disp(ErrorOutput2); beep;
                
                [OperationTime,~] = DMIWizard_MRS_CalculateTime;
                TextOutput3 = [OperationTime ' - Reading DMIWizard FID data file completed.'];
                disp(TextOutput3);
            else
                fclose(fileID);

                handles.FID = indata1(1,:) + 1i*indata1(2,:);
                
                [OperationTime,~] = DMIWizard_MRS_CalculateTime;
                TextOutput3 = [OperationTime ' - Reading DMIWizard FID data file completed.'];
                disp(TextOutput3);

                % Read parameters from DMIWizard parameter file
                coor = find(handles.MetaboliteFile == '.');
                
                if (isempty(coor) > 0)
                    MRSParameterFileDMIWizard = [handles.MetaboliteFile '.par'];
                else
                    MetaboliteFileDir = handles.MetaboliteFile(1:max(coor));
                    MRSParameterFileDMIWizard = [MetaboliteFileDir 'par'];
                end;
                
                if (exist(MRSParameterFileDMIWizard,'file') > 0)
                   [handles.sw, handles.carfreq] = DMIWizard_MRS_ReadParametersDMIWizard(MRSParameterFileDMIWizard);
                   handles.dgd = 0;
                end;
            end;
            
            % Create new processing history file
            if ismac
                % Mac plaform
                coor = find(handles.MetaboliteFile == '/');
            elseif isunix
                % Linux plaform
                coor = find(handles.MetaboliteFile == '/');
            elseif ispc
                % Windows platform
                coor = find(handles.MetaboliteFile == '\');
            end     
            MRSpathLoadDir = handles.MetaboliteFile(1:max(coor));
                
            [~,OperationDate] = DMIWizard_MRS_CalculateTime;
            handles.ProcessingHistoryFile = [MRSpathLoadDir 'ProcessingHistory' OperationDate  '.txt'];
            DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'w+',TextOutput1);
            DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput2);
            DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+',TextOutput3);
            
        case 'Varian'
            [OperationTime,~] = DMIWizard_MRS_CalculateTime;
            TextOutput1 = [OperationTime ' - Reading Varian FID data file:'];
            TextOutput2 = [OperationTime ' - ' handles.MetaboliteFile];
            disp(TextOutput1); disp(TextOutput2);
            
            % Read file header
            FileHeader = fread(fileID,8,'long');
            %************************************
            % File header structure:
            % 1 = number of blocks
            % 2 = number of traces per block
            % 3 = number of elements per trace
            %************************************
            nbtemp = FileHeader(1);
            nttemp = FileHeader(2);
            nptemp = FileHeader(3);

            disp(' ');
            disp('File header information: ');
            TextOutput4 = ['Number of blocks per file = ' num2str(nbtemp)];
            TextOutput5 = ['Number of traces per block = ' num2str(nttemp)];
            TextOutput6 = ['Number of points per trace = ' num2str(nptemp)];
            disp(TextOutput4); disp(TextOutput5); disp(TextOutput6); disp(' ');
            
            indata1 = zeros(nbtemp*nttemp*nptemp,1);
            for c1 = 1:1:nbtemp;
                BlockHeader = fread(fileID,7,'long');
                if (handles.be > 0)
                    % Older SUN Varian data
                    indata1((c1-1)*nttemp*nptemp+1:1:c1*nttemp*nptemp) = fread(fileID,nttemp*nptemp,'long');
                else
                    % Newer LINUX Varian data
                    indata1((c1-1)*nttemp*nptemp+1:1:c1*nttemp*nptemp) = fread(fileID,nttemp*nptemp,'float');
                end;
            end;
            fclose(fileID);

            if (length(indata1) < 1)
                % No data in FID, likely due to incorrect vendor selection
                [OperationTime,~] = DMIWizard_MRS_CalculateTime;
                TextOutput1 = [OperationTime ' - Warning : No data in FID file, likely due to incorrect vendor format selection.'];
                TextOutput2 = [OperationTime ' - Solution: Continuing with an (1x1024) zero-amplitude FID and default parameters.'];
                disp(TextOutput1); disp(TextOutput2);
                handles.FID = zeros(1,1024);
            else
                indata1 = reshape(indata1,nptemp*nttemp*nbtemp,1);
                handles.FID = zeros(round(0.5*nbtemp*nttemp*nptemp),1);
            end;
            
            % Note: Varian data = (I, R)
            for c1 = 1:1:round(0.5*length(indata1))
                handles.FID(c1) = indata1(2*c1) + 1i*indata1(2*c1-1);
            end
            
            [OperationTime,~] = DMIWizard_MRS_CalculateTime;
            TextOutput3 = [OperationTime ' - Reading Varian FID data file completed.'];
            disp(TextOutput3);
            
            % Create new processing history file
            if ismac
                % Mac plaform
                coor = find(handles.MetaboliteFile == '/');
            elseif isunix
                % Linux plaform
                coor = find(handles.MetaboliteFile == '/');
            elseif ispc
                % Windows platform
                coor = find(handles.MetaboliteFile == '\');
            end     
            MRSpathLoadDir = handles.MetaboliteFile(1:max(coor));
                
            [~,OperationDate] = DMIWizard_MRS_CalculateTime;
            handles.ProcessingHistoryFile = [MRSpathLoadDir 'ProcessingHistory' OperationDate  '.txt'];
            DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'w+',TextOutput1);
            DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput2);
            DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+',TextOutput3);
            
            MRSParameterFileVarian = [MRSpathLoadDir 'procpar'];
            if (exist(MRSParameterFileVarian,'file') > 0)
               [handles.sw, handles.carfreq] = DMIWizard_MRS_ReadParametersVarian(MRSParameterFileVarian);
               handles.dgd = 0;
            end; 

        case 'Philips'
            disp('Reading Philips raw data ...');
                        
            [FID,info] = DMIWizard_MRS_LoadPhilipsData(handles.MetaboliteFile);
            
            disp('... done.');

            FID = reshape(FID,numel(FID),1);
            
            dsf = 8;
                 
            dd = ['Downsampling Philips data by a factor of ' num2str(dsf) ' ...'];
            disp(dd);
            
            FID = reshape(FID,8,round(numel(FID)/8));
            
            FID = squeeze(sum(FID,1));  
            
            disp('... done.');
        case 'Siemens'
            FID = fopen(handles.MetaboliteFile,'r','l','US-ASCII');
            fseek(FID,0,'eof');
            fileSize = ftell(FID);
            fseek(FID,0,'bof');
            firstInt  = fread(FID,1,'uint32');
            fclose(FID);
    end
end;

handles.np = length(handles.FID)/handles.nfidi;

if (mod(handles.np,1) > 0)
    OperationTime = DMIWizard_MRS_CalculateTime;   
    ErrorMessage1 = [OperationTime ' - Error   : Total number of FID points is not in agreement with indicated initial number of FIDs.'];
    ErrorMessage2 = [OperationTime ' - Solution: Continuing with initial number of FIDs set to one.'];
    disp(' '); disp(ErrorMessage1); disp(ErrorMessage2);
    
    handles.nfidi = 1;
    
    handles.np = length(FID);
end;

% Separate FID into 2 dimensions
handles.FID = reshape(handles.FID,handles.np,handles.nfidi);

% Replace final FID points with zeros
if ((handles.np > handles.FIDtrunc) && (handles.FIDtrunc ~= 0))
    handles.FID(handles.FIDtrunc+1:handles.np,:) = 0;
end;

% Display first FID
fh1 = figure(1);
set(fh1,'Name','Time domain','Units','points','NextPlot','replace',...
    'Position',[handles.Fig1XPos handles.Fig1YPos handles.Fig1Width handles.Fig1Height]);

subplot(1,1,1), plot(1:handles.np,imag(handles.FID(:,1)),'r',1:handles.np,real(handles.FID(:,1)),'b');
if (min(abs(handles.FID(:,1))) ~= max(abs(handles.FID(:,1))))
    axis([1 handles.np -1*max(abs(handles.FID(:,1))) max(abs(handles.FID(:,1)))])
else
    axis([1 handles.np -1*max(abs(handles.FID(:,1)))-1 max(abs(handles.FID(:,1)))+1])
end;
xlabel('Acquisition points');
ylabel('Signal intensity');