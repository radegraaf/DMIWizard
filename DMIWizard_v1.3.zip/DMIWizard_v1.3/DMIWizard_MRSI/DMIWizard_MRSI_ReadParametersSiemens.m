function [FOV1, FOV2, FOV3, np1start, np1end, np1dim, ...
    np2start, np2end, np2dim, np3start, np3end, np3dim, ...
    sw, npstart, npend, npdim, navstart, navend, navdim, ...
    nrecstart, nrecend, nrecdim, ErrorFlag] = DMIWizard_MRSI_ReadParametersSiemens(MRSIParameterFileSiemens)

ErrorFlag = 0;

% Read parameters from Siemens parameter file
fileID = fopen(MRSIParameterFileSiemens,'r+');
if (fileID > 0)
    Data = textscan(fileID, '%s', 'delimiter', '\n', 'whitespace', '');
    CStr = Data{1};
    
    % Scanning for particular parameters
    % Field-of-view 1
    IndexParameter = strfind(CStr, 'FOV1');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    FOV1 = str2num(LineParameter(8:end));
    
    % Field-of-view 2
    IndexParameter = strfind(CStr, 'FOV2');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    FOV2 = str2num(LineParameter(8:end));
        
    % Field-of-view 3
    IndexParameter = strfind(CStr, 'FOV3');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    FOV3 = str2num(LineParameter(8:end));
        
    % Number of points 1
    IndexParameter = strfind(CStr, 'np1');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    coor1 = strfind(LineParameter,'=');
    coor2 = strfind(LineParameter,':');
    coor3 = strfind(LineParameter,'(');
    coor4 = strfind(LineParameter,')');
    np1start = str2num(LineParameter(coor1+1:coor2-1));
    np1end = str2num(LineParameter(coor2+1:coor3-1));
    np1dim = str2num(LineParameter(coor3+1:coor4-1));
    if ((isempty(np1start) > 0) || (isempty(np1end) > 0) || (isempty(np1dim) > 0))
        np1start = 1; np1end = 1; np1dim = 12; ErrorFlag = 1;
        [OperationTime,~] = DMIWizard_MRSI_CalculateTime;   
        ErrorMessage1 = [OperationTime ' - Error   : Parameter file has incorrect format.'];
        ErrorMessage2 = [OperationTime ' - Solution: Continuing with default settings'];
        disp(' '); disp(ErrorMessage1); disp(ErrorMessage2);
    end;
    np1 = np1end - np1start + 1;
        
    % Number of points 2
    IndexParameter = strfind(CStr, 'np2');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    coor1 = strfind(LineParameter,'=');
    coor2 = strfind(LineParameter,':');
    coor3 = strfind(LineParameter,'(');
    coor4 = strfind(LineParameter,')');
    np2start = str2num(LineParameter(coor1+1:coor2-1));
    np2end = str2num(LineParameter(coor2+1:coor3-1));
    np2dim = str2num(LineParameter(coor3+1:coor4-1));
    if ((isempty(np2start) > 0) || (isempty(np2end) > 0) || (isempty(np2dim) > 0))
        np2start = 1; np2end = 1; np2dim = 13; ErrorFlag = 1;
        [OperationTime,~] = DMIWizard_MRSI_CalculateTime;   
        ErrorMessage1 = [OperationTime ' - Error   : Parameter file has incorrect format.'];
        ErrorMessage2 = [OperationTime ' - Solution: Continuing with default settings'];
        disp(' '); disp(ErrorMessage1); disp(ErrorMessage2);
    end;
    np2 = np2end - np2start + 1;
    
    % Number of points 3
    IndexParameter = strfind(CStr, 'np3');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    coor1 = strfind(LineParameter,'=');
    coor2 = strfind(LineParameter,':');
    coor3 = strfind(LineParameter,'(');
    coor4 = strfind(LineParameter,')');
    np3start = str2num(LineParameter(coor1+1:coor2-1));
    np3end = str2num(LineParameter(coor2+1:coor3-1));
    np3dim = str2num(LineParameter(coor3+1:coor4-1));
    if ((isempty(np3start) > 0) || (isempty(np3end) > 0) || (isempty(np3dim) > 0))
        np3start = 1; np3end = 1; np3dim = 14; ErrorFlag = 1;
        [OperationTime,~] = DMIWizard_MRSI_CalculateTime;   
        ErrorMessage1 = [OperationTime ' - Error   : Parameter file has incorrect format.'];
        ErrorMessage2 = [OperationTime ' - Solution: Continuing with default settings'];
        disp(' '); disp(ErrorMessage1); disp(ErrorMessage2);
    end;
    np3 = np3end - np3start + 1;   
    
    % Spectral width
    IndexParameter = strfind(CStr, 'sw');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    sw = str2num(LineParameter(8:end));   
      
    % Number of points
    IndexParameter = strfind(CStr, 'np ');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    coor1 = strfind(LineParameter,'=');
    coor2 = strfind(LineParameter,':');
    coor3 = strfind(LineParameter,'(');
    coor4 = strfind(LineParameter,')');
    npstart = str2num(LineParameter(coor1+1:coor2-1));
    npend = str2num(LineParameter(coor2+1:coor3-1));
    npdim = str2num(LineParameter(coor3+1:coor4-1));
    if ((isempty(npstart) > 0) || (isempty(npend) > 0) || (isempty(npdim) > 0))
        npstart = 1; npend = 512; npdim = 1; ErrorFlag = 1;
        [OperationTime,~] = DMIWizard_MRSI_CalculateTime;   
        ErrorMessage1 = [OperationTime ' - Error   : Parameter file has incorrect format.'];
        ErrorMessage2 = [OperationTime ' - Solution: Continuing with default settings'];
        disp(' '); disp(ErrorMessage1); disp(ErrorMessage2);
    end;
    np = npend - npstart + 1;       
    
    % Number of averages
    IndexParameter = strfind(CStr, 'nav');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    coor1 = strfind(LineParameter,'=');
    coor2 = strfind(LineParameter,':');
    coor3 = strfind(LineParameter,'(');
    coor4 = strfind(LineParameter,')');
    navstart = str2num(LineParameter(coor1+1:coor2-1));
    navend = str2num(LineParameter(coor2+1:coor3-1));
    navdim = str2num(LineParameter(coor3+1:coor4-1));
    if ((isempty(navstart) > 0) || (isempty(navend) > 0) || (isempty(navdim) > 0))
        navstart = 1; navend = 1; navdim = 15; ErrorFlag = 1;
        [OperationTime,~] = DMIWizard_MRSI_CalculateTime;   
        ErrorMessage1 = [OperationTime ' - Error   : Parameter file has incorrect format.'];
        ErrorMessage2 = [OperationTime ' - Solution: Continuing with default settings'];
        disp(' '); disp(ErrorMessage1); disp(ErrorMessage2);
    end;
    nav = navend - navstart + 1;   
    
    % Number of receivers
    IndexParameter = strfind(CStr, 'nrec');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    coor1 = strfind(LineParameter,'=');
    coor2 = strfind(LineParameter,':');
    coor3 = strfind(LineParameter,'(');
    coor4 = strfind(LineParameter,')');
    nrecstart = str2num(LineParameter(coor1+1:coor2-1));
    nrecend = str2num(LineParameter(coor2+1:coor3-1));
    nrecdim = str2num(LineParameter(coor3+1:coor4-1));
    if ((isempty(nrecstart) > 0) || (isempty(nrecend) > 0) || (isempty(nrecdim) > 0))
        nrecstart = 1; nrecend = 1; nrecdim = 16; ErrorFlag = 1;
        [OperationTime,~] = DMIWizard_MRSI_CalculateTime;   
        ErrorMessage1 = [OperationTime ' - Error   : Parameter file has incorrect format.'];
        ErrorMessage2 = [OperationTime ' - Solution: Continuing with default settings'];
        disp(' '); disp(ErrorMessage1); disp(ErrorMessage2);
    end;
    nrec = nrecend - nrecstart + 1;  
    
    fclose(fileID);
    
    % Display parameters
    disp(' ');
    [OperationTime,OperationDate] = DMIWizard_MRSI_CalculateTime;
    TextOutput0 = [OperationTime ' - Reading Siemens 3D MRSI parameters from ' MRSIParameterFileSiemens];
    TextOutput1 = [OperationTime ' - [FOV1, FOV2, FOV3] = [ ' num2str(round(FOV1)) ', ' num2str(round(FOV2)) ', ' num2str(round(FOV3)) '] mm'];
    TextOutput2 = [OperationTime ' - [np1, np2, np3] = [ ' num2str(round(np1)) ', ' num2str(round(np2)) ', ' num2str(round(np3)) ...
        '] (dimension [ ' num2str(round(np1dim)) ', ' num2str(round(np2dim)) ', ' num2str(round(np3dim)) '])'];
    TextOutput3 = [OperationTime ' - Spectral width = ' num2str(sw,3) ' kHz'];
    TextOutput4 = [OperationTime ' - Number of acquisition points = ' num2str(np) ' (dimension ' num2str(npdim) ')'];
    TextOutput5 = [OperationTime ' - Number of averages = ' num2str(nav) ' (dimension ' num2str(navdim) ')'];
    TextOutput6 = [OperationTime ' - Number of receivers = ' num2str(nrec) ' (dimension ' num2str(nrecdim) ')'];
    disp(TextOutput0);
    disp(TextOutput1); disp(TextOutput2); disp(TextOutput3); 
    disp(TextOutput4); disp(TextOutput5); disp(TextOutput6);
    disp(' ');
    
    % Write parameters to processing history file
    coor = find(MRSIParameterFileSiemens == '\');
    MRSIPathDir = MRSIParameterFileSiemens(1:max(coor));

    ProcessingHistoryFile = [MRSIPathDir 'ProcessingHistory' OperationDate  '.txt'];
    DMIWizard_WriteProcessHistory(ProcessingHistoryFile,'a',TextOutput0);
    DMIWizard_WriteProcessHistory(ProcessingHistoryFile,'a',TextOutput1);
    DMIWizard_WriteProcessHistory(ProcessingHistoryFile,'a',TextOutput2);
    DMIWizard_WriteProcessHistory(ProcessingHistoryFile,'a',TextOutput3);
    DMIWizard_WriteProcessHistory(ProcessingHistoryFile,'a',TextOutput4);
    DMIWizard_WriteProcessHistory(ProcessingHistoryFile,'a',TextOutput5);
    DMIWizard_WriteProcessHistory(ProcessingHistoryFile,'a+',TextOutput6);
end;