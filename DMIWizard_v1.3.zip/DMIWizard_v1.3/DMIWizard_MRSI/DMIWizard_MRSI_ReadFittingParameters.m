function [nresFit, ZxLowFit, ZxHighFit, ZyScaleFit, intthFit, BasisSetDirFit, PKFileFit, ShiftReference, ShiftReferencekHz, ...
    MaxGlobalOffsetFit, RFoffsetFit, bloFit, NumberOfIter, LSDFit, LineshapeFit, PhaseFit, FirstOrderPhaseFit, ...
    FixedFirstOrderPhaseFit, ErrorFlag] = DMIWizard_MRSI_ReadFittingParameters(handles)

%**************************************************************************
% DMIWizard_MRSI_ReadFittingParameters.m
%
% Read spectral fitting parameters from disk (fitting results are extracted
% from a separate file).
%**************************************************************************

if ismac
    % Mac plaform
    coor = find(handles.MRSIPath == '/');
elseif isunix
    % Linux plaform
    coor = find(handles.MRSIPath == '/');
elseif ispc
    % Windows platform
    coor = find(handles.MRSIPath == '\');
end               
MRSIPathDir = handles.MRSIPath(1:max(coor));
    
file = [MRSIPathDir '\FittingParameters.txt'];
fileID = fopen(file,'r+');
ErrorFlag = 0;
if (fileID > 0)

    Data = textscan(fileID, '%s', 'delimiter', '\n', 'whitespace', '');
    CStr = Data{1};
    
    % Scanning for particular parameters
    % Number of resonances used during spectral fitting
    IndexParameter = strfind(CStr, 'Number of resonances');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    nresFit = str2num(LineParameter(30:end));
    ErrorFlag = ErrorFlag + isempty(nresFit);
    
    IndexParameter = strfind(CStr, 'Frequency low (kHz)');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    ZxLowFit = str2num(LineParameter(30:end));
    ErrorFlag = ErrorFlag + isempty(ZxLowFit);
    
    IndexParameter = strfind(CStr, 'Frequency high (kHz)');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    ZxHighFit = str2num(LineParameter(30:end));
    ErrorFlag = ErrorFlag + isempty(ZxHighFit);
    
    % Intensity scaling factor used during spectral fitting
    IndexParameter = strfind(CStr, 'Intensity scaling factor');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    ZyScaleFit = str2num(LineParameter(30:end));
    ErrorFlag = ErrorFlag + isempty(ZyScaleFit);
    
    % Signal intensity threshold
    IndexParameter = strfind(CStr, 'Threshold (percent)');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    intthFit = str2num(LineParameter(30:end));
    ErrorFlag = ErrorFlag + isempty(intthFit);
    
    % Basisset directory
    IndexParameter = strfind(CStr, 'Basis set directory');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    BasisSetDirFit = LineParameter(30:end);
    ErrorFlag = ErrorFlag + isempty(BasisSetDirFit);
    
    % Prior knowledge file
    IndexParameter = strfind(CStr, 'Prior knowledge file');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    PKFileFit = LineParameter(30:end);
    ErrorFlag = ErrorFlag + isempty(PKFileFit);
    
    % Chemical shift reference (ppm)
    IndexParameter = strfind(CStr, 'Shift reference (ppm)');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    ShiftReference = str2num(LineParameter(30:end));
    ErrorFlag = ErrorFlag + isempty(ShiftReference);
    
    % Chemical shift reference (kHz)
    IndexParameter = strfind(CStr, 'Shift reference (kHz)');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    ShiftReferencekHz = str2num(LineParameter(30:end));
    ErrorFlag = ErrorFlag + isempty(ShiftReferencekHz);
    
    % RF center frequency (ppm) 
    IndexParameter = strfind(CStr, 'RF center frequency (ppm)');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    RFoffsetFit = str2num(LineParameter(30:end));
    ErrorFlag = ErrorFlag + isempty(RFoffsetFit);
        
    % Baseline order used during spectral fitting
    IndexParameter = strfind(CStr, 'Baseline order');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    bloFit = str2num(LineParameter(30:end));
    ErrorFlag = ErrorFlag + isempty(bloFit);
    
    % Number of iterations
    IndexParameter = strfind(CStr, 'Number of iterations');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    NumberOfIter = str2num(LineParameter(30:end));
    ErrorFlag = ErrorFlag + isempty(NumberOfIter);
        
    % Line shape used during spectral fitting
    IndexParameter = strfind(CStr, 'Base line shape');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    LineshapeFit = char(LineParameter(30:end));
    ErrorFlag = ErrorFlag + isempty(LineshapeFit);
    
    % Lineshape distortion used during spectral fitting
    IndexParameter = strfind(CStr, 'Line shape distortion');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    LSDFit = str2num(LineParameter(30:end));
    ErrorFlag = ErrorFlag + isempty(LSDFit);
    
    % RF center frequency used during spectral fitting
    IndexParameter = strfind(CStr, 'RF center frequency');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    RFoffsetFit = str2num(LineParameter(30:end));
    ErrorFlag = ErrorFlag + isempty(RFoffsetFit);
    
    % Maximum global frequency offset
    IndexParameter = strfind(CStr, 'Maximum global offset (Hz)');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    MaxGlobalOffsetFit = str2num(LineParameter(30:end));
    ErrorFlag = ErrorFlag + isempty(MaxGlobalOffsetFit);
    
    % Phase correction used during spectral fitting
    IndexParameter = strfind(CStr, 'Phase correction');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    PhaseFit = char(LineParameter(30:end));
    ErrorFlag = ErrorFlag + isempty(PhaseFit);
    
    % First-order phase estimate
    IndexParameter = strfind(CStr, 'First-order phase estimate');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    FirstOrderPhaseFit = str2num(LineParameter(30:end));
    ErrorFlag = ErrorFlag + isempty(FirstOrderPhaseFit);
    
    % Fixed first-order phase
    IndexParameter = strfind(CStr, 'Fixed first-order phase');
    Index = find(~cellfun('isempty', IndexParameter),1);
    LineParameter = char(CStr(Index));
    FixedFirstOrderPhaseFit = char(LineParameter(30:end));
    ErrorFlag = ErrorFlag + isempty(FixedFirstOrderPhaseFit);
    
    fclose(fileID);
    
    % Display parameters
    disp(' ');
    [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
    disp([OperationTime ' - Reading spectral fitting parameters from ' file]);
    disp([OperationTime ' - Number of resonances       = ' num2str(nresFit)]);
    disp([OperationTime ' - Frequency low              = ' num2str(ZxLowFit) ' kHz']);
    disp([OperationTime ' - Frequency high             = ' num2str(ZxHighFit) ' kHz']);
    disp([OperationTime ' - Intensity scaling factor   = ' num2str(ZyScaleFit)]);
    disp([OperationTime ' - Signal intensity threshold = ' num2str(intthFit) ' %']); disp(' ');
    
    disp([OperationTime ' - Basis set directory        = ' BasisSetDirFit]);
    disp([OperationTime ' - Prior knowledge file       = ' PKFileFit]); disp(' ');
    
    disp([OperationTime ' - Shift reference            = ' num2str(ShiftReference) ' ppm']);
    disp([OperationTime ' - Shift reference            = ' num2str(ShiftReferencekHz) ' kHz']);
    disp([OperationTime ' - RF center frequency        = ' num2str(RFoffsetFit) ' ppm']);
    disp([OperationTime ' - Baseline order             = ' num2str(bloFit)]);
    disp([OperationTime ' - Number of iterations       = ' num2str(NumberOfIter)]);
    disp([OperationTime ' - Line shape distortion      = ' num2str(LSDFit)]);
    disp([OperationTime ' - Base line shape            = ' LineshapeFit]);
    disp([OperationTime ' - Maximum global offset      = ' num2str(MaxGlobalOffsetFit) ' Hz']);
    disp([OperationTime ' - Phase correction           = ' PhaseFit]);
    disp([OperationTime ' - First-order phase estimate = ' num2str(FirstOrderPhaseFit) ' deg/kHz']);
    disp([OperationTime ' - Fixed first-order phase    = ' FixedFirstOrderPhaseFit]); disp(' ');
else
    % File cannot be read or opened - assign default values to parameters
    ErrorFlag = 1;
    
    nresFit = 1; ZxLowFit = -1; ZxHighFit = 1; ZyScaleFit = 1; intthFit = 15;
    ShiftReference = 0; ShiftReferencekHz = 0; RFoffsetFit = 4.67;
    BasisSetDirFit = ''; PKFileFit = '';
    bloFit = 1;  NumberOfIter = 100; LSDFit = 1; MaxGlobalOffsetFit = 10;
    LineshapeFit = 'Gaussian';  PhaseFit = 'Zero-order phase';
    FirstOrderPhaseFit = 0; FixedFirstOrderPhaseFit = 'N';
end;