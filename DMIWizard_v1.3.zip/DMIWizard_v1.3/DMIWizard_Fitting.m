function varargout = DMIWizard_Fitting(varargin)
% DMIWIZARD_FITTING MATLAB code for DMIWizard_Fitting.fig
%      DMIWIZARD_FITTING, by itself, creates a new DMIWIZARD_FITTING or raises the existing
%      singleton*.
%
%      H = DMIWIZARD_FITTING returns the handle to a new DMIWIZARD_FITTING or the handle to
%      the existing singleton*.
%
%      DMIWIZARD_FITTING('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DMIWIZARD_FITTING.M with the given input arguments.
%
%      DMIWIZARD_FITTING('Property','Value',...) creates a new DMIWIZARD_FITTING or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before DMIWizard_Fitting_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to DMIWizard_Fitting_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help DMIWizard_Fitting

% Last Modified by GUIDE v2.5 01-Jul-2022 13:41:41

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @DMIWizard_Fitting_OpeningFcn, ...
                   'gui_OutputFcn',  @DMIWizard_Fitting_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before DMIWizard_Fitting is made visible.
function DMIWizard_Fitting_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to DMIWizard_Fitting (see VARARGIN)

% Choose default command line output for DMIWizard_Fitting
handles.output = hObject;

% Set Position/Size of Figure Based on Screen Size
set(groot,'Units','points');
ScreenSize = get(groot,'ScreenSize');
ScreenWidth = ScreenSize(3);
ScreenHeight = ScreenSize(4);

FigXPos = .605*ScreenWidth; % .02
FigYPos = .5425*ScreenHeight; % .2275
FigWidth = .30*ScreenWidth; % .18
FigHeight = .3575*ScreenHeight; %.6725

% Read DMIWizard settings
handles = DMIWizard_MRSI_ReadSettings(handles);

set(hObject,'Units','points','Position',[FigXPos FigYPos FigWidth FigHeight],...
    'Color',handles.GUIBackgroundColor1);

% Update handles structure
guidata(hObject, handles);

Initialize_GUI(hObject,eventdata,handles);


% --- Outputs from this function are returned to the command line.
function varargout = DMIWizard_Fitting_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

function Initialize_GUI(hObject,eventdata,handles)

handles.BasisSetDir = 'C:\Robin\Data';
BasisSetDir_Object = findall(0,'Tag','BasisSetDir_Edit');
set(BasisSetDir_Object,'TooltipString','Basisset directory');

BasisSetDirSelect_Object = findall(0,'Tag','BasisSetDirSelect_PushButton');
set(BasisSetDirSelect_Object,'TooltipString','Select basisset directory.');

handles.PKFile = 'C:\Robin\Data';
PKFile_Object = findall(0,'Tag','PKFile_Edit');
set(PKFile_Object,'TooltipString','Prior knowledge file');
% Disable manual input
set(PKFile_Object,'Enable','Off');

PKFileSelect_Object = findall(0,'Tag','PKFileSelect_PushButton');
set(PKFileSelect_Object,'TooltipString','Select Excel prior knowledge file.');

handles.ShiftReference = 3.82;
handles.ShiftReferencekHz = 0.0;
ShiftReference_Object = findall(0,'Tag','ShiftReference_Edit');
set(ShiftReference_Object,'TooltipString','Chemical shift reference (ppm).');
handles.ShiftReferencePreviousValue = 3.82;

ShiftReferenceSelect_Object = findall(0,'Tag','ShiftReferenceSelect_PushButton');
set(ShiftReferenceSelect_Object,'TooltipString','Select frequency reference (kHz) signal with 1 click.');

handles.BaselineOrder = 1;
BaselineOrder_Object = findall(0,'Tag','BaselineOrder_Edit');
set(BaselineOrder_Object,'TooltipString','0 = offset, 1 = linear, 2 = quadratic');
handles.BaselineOrderPreviousValue = 1;

handles.NumberOfIterations = 100;
NumberOfIterations_Object = findall(0,'Tag','NumberOfIterations_Edit');
set(NumberOfIterations_Object,'TooltipString','Maximum number of iterations allowed to find the optimal spectral fit.');
handles.NumberOfIterationsPreviousValue = 100;

handles.LineShapeDistortion = 1;
LineShapeDistortion_Object = findall(0,'Tag','LineShapeDistortion_Edit');
set(LineShapeDistortion_Object,'TooltipString','Number of frequency components contributing to a lineshape distortion common to all resonances.');
handles.LineShapeDistortionPreviousValue = 1;

handles.MaximumGlobalOffset = 20;
MaximumGlobalOffset_Object = findall(0,'Tag','MaximumGlobalOffset_Edit');
set(MaximumGlobalOffset_Object,'TooltipString','Global frequency span limited to +/- maximum global offset (in Hz).');

handles.LineShapeSelection = 'Gaussian';
LineShapeSelection_Object = findall(0,'Tag','LineShapeSelectionMenu');
set(LineShapeSelection_Object,'TooltipString','Base lineshape (before lineshape distortion)');

handles.PhaseSelection = 'Zero-order phase';
PhaseSelection_Object = findall(0,'Tag','PhaseSelectionMenu');
set(PhaseSelection_Object,'TooltipString','Constant or linear phase dependence.');

handles.FirstOrderPhaseEstimate = 0;
FirstOrderPhaseEstimate_Object = findall(0,'Tag','FirstOrderPhaseEstimate_Edit');
set(FirstOrderPhaseEstimate_Object,'TooltipString','First-order phase estimate (deg/kHz), roughly equal to 360 x delay (ms).');

handles.FirstOrderFix = 0;
FirstOrderFix_Object = findall(0,'Tag','FirstOrderFix_CheckBox');
set(FirstOrderFix_Object,'TooltipString','Fix first-order phase estimate.');

handles.VoxelPK = 0;
VoxelPK_Object = findall(0,'Tag','VoxelPK_CheckBox');
set(VoxelPK_Object,'TooltipString','Use prior knowledge from previously fitted data.');

handles.SVFit = 0;
SVFit_Object = findall(0,'Tag','SVFit_CheckBox');
set(SVFit_Object,'TooltipString','Limit spectral fit to the spectrum at the selected voxel position.');

StartFitPushButton_Object = findall(0,'Tag','StartFit_PushButton');
set(StartFitPushButton_Object,'TooltipString','Start spectral fitting for all MRSI voxels above the threshold.');

% Retrieve and update GUI data structure from DMIWizard MRSI window
DMIWizard_MRSI_Object = findall(0,'Name','DMIWizard_MRSI');
handlesMRSI = guidata(DMIWizard_MRSI_Object);

% Extract parameters from main DMIWizard window and add to handles
handles.MaxLSD = handlesMRSI.MaxLSD;
if (isfield(handlesMRSI,'LCMFit') > 0)
    % Transfer LCM fitting parameters from DMIWizard if they exist
    handles.LCMFit = handlesMRSI.LCMFit;
end;

% Update current handles in workspace
assignin('base','currentHandles3',handles)

% Update handles structure
guidata(hObject, handles);


function ShiftReference_Edit_Callback(hObject, eventdata, handles)
handles.ShiftReference = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.ShiftReference) > 0) || (isinf(handles.ShiftReference) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for chemical shift reference.'];
    ErrorMessage2 = ['Error: Chemical shift reference set to a valid value (' ...
        num2str(handles.ShiftReferencePreviousValue) ' ppm).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.ShiftReference = handles.ShiftReferencePreviousValue;
    set(hObject,'String',handles.ShiftReference);
end;

% Retrieve and update GUI data structure from DMIWizard MRSI window
DMIWizard_MRSI_Object = findall(0,'Name','DMIWizard_MRSI');
handlesMRSI = guidata(DMIWizard_MRSI_Object);

% Extract parameters from main DMIWizard window and add to handles
%handles.sw = handlesMRSI.sw;
handles.nu0 = handlesMRSI.nu0;

handles.RFCenterFrequency = handles.ShiftReference - (1000*handles.ShiftReferencekHz/handlesMRSI.nu0);
[OperationTime,OperationDate] = DMIWizard_MRSI_CalculateTime;
TextOutput0 = [OperationTime ' - Frequency reference = ' num2str(handles.ShiftReferencekHz) ...
    ' kHz assigned to chemical shift reference = ' num2str(handles.ShiftReference) ' ppm.'];
TextOutput1 = [OperationTime ' - Derived RF center frequency = ' num2str(handles.RFCenterFrequency) ' ppm'];
TextOutput2 = [OperationTime ' - Use Select button to change frequency reference (kHz).'];
disp(''); disp(TextOutput0); disp(TextOutput1); disp(TextOutput2);

% Update previous value
handles.ShiftReferencePreviousValue = handles.ShiftReference;

% Update current handles in workspace
assignin('base','currentHandles3',handles)

% Update handles structure
guidata(hObject,handles);

function ShiftReference_Edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in ShiftReferenceSelect_PushButton.
function ShiftReferenceSelect_PushButton_Callback(hObject, eventdata, handles)

% Retrieve and update GUI data structure from DMIWizard MRSI window
DMIWizard_MRSI_Object = findall(0,'Name','DMIWizard_MRSI');
handlesMRSI = guidata(DMIWizard_MRSI_Object);

% Extract parameters from main DMIWizard window and add to handles
%handles.sw = handlesMRSI.sw;
handles.nu0 = handlesMRSI.nu0;

% Check to see if RF center frequency already exists ...
if (isfield(handles,'RFCenterFrequency') > 0)
    if (isempty(handles.RFCenterFrequency) < 1)
        disp(['Warning - RF center frequency (' num2str(handles.RFCenterFrequency) ' kHz) already exists.']);
        ContinueYN = input('Continue with definition of new RF center frequency (Y/[N])? : ');
        if isempty(ContinueYN)
            ContinueYN = 'N';
        end;
    end;
else
    ContinueYN = 'Y';
end;

if ((ContinueYN == 'Y') || (ContinueYN == 'y'))
    figure(2);
    r = ginput(1);
    handles.ShiftReferencekHz = r(1,1);

    handles.RFCenterFrequency = handles.ShiftReference - (1000*handles.ShiftReferencekHz/handlesMRSI.nu0);
    [OperationTime,OperationDate] = DMIWizard_MRSI_CalculateTime;
    TextOutput0 = [OperationTime ' - Frequency reference = ' num2str(handles.ShiftReferencekHz) ...
        ' kHz assigned to chemical shift reference = ' num2str(handles.ShiftReference) ' ppm.'];
    TextOutput1 = [OperationTime ' - Derived RF center frequency = ' num2str(handles.RFCenterFrequency) ' ppm'];
    TextOutput2 = [OperationTime ' - Use entry box to change chemical shift reference (ppm).'];
    disp(' '); disp(TextOutput0); disp(TextOutput1); disp(TextOutput2);
end;

% Update current handles in workspace
assignin('base','currentHandles3',handles)

% Update handles structure
guidata(hObject,handles);


function LineShapeDistortion_Edit_Callback(hObject, eventdata, handles)
handles.LineShapeDistortion = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.LineShapeDistortion) > 0) || (isinf(handles.LineShapeDistortion) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for lineshape distortion.'];
    ErrorMessage2 = ['Error: Lineshape disortion set to a valid value (' num2str(handles.LineShapeDistortionPreviousValue) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.LineShapeDistortion = handles.LineShapeDistortionPreviousValue;
    set(hObject,'String',handles.LineShapeDistortion);
end;

if ((rem(handles.LineShapeDistortion,1) ~= 0) || (handles.LineShapeDistortion < 0))
    % Positive, integer number for lineshape distortion
    handles.LineShapeDistortion = abs(round(handles.LineShapeDistortion));
    set(hObject,'String',handles.LineShapeDistortion);
end;

if (handles.LineShapeDistortion > handles.MaxLSD)
    WarningMessage1 = ['Warning: Lineshape distortion is limited to ' num2str(handles.MaxLSD) '.'];
    WarningMessage2 = ['Action : Lineshape disortion set to ' num2str(handles.MaxLSD) '.'];
    disp(' '); disp(WarningMessage1); disp(WarningMessage2);
      
    handles.LineShapeDistortion = handles.MaxLSD;
    set(hObject,'String',handles.LineShapeDistortion);    
end;

% Update previous value
handles.LineShapeDistortionPreviousValue = handles.LineShapeDistortion;

% Update current handles in workspace
assignin('base','currentHandles3',handles)

% Update handles structure
guidata(hObject,handles);

function LineShapeDistortion_Edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function BaselineOrder_Edit_Callback(hObject, eventdata, handles)
handles.BaselineOrder = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.BaselineOrder) > 0) || (isinf(handles.BaselineOrder) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for polynoimial baseline order.'];
    ErrorMessage2 = ['Error: Polynomial baseline order set to a valid value (' num2str(handles.BaselineOrderPreviousValue) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.BaselineOrder = handles.BaselineOrderPreviousValue;
    set(hObject,'String',handles.BaselineOrder);
end;

if ((rem(handles.BaselineOrder,1) ~= 0) || (handles.BaselineOrder < 0))
    % Positive, integer number for baseline order
    handles.BaselineOrder = abs(round(handles.BaselineOrder));
    set(hObject,'String',handles.BaselineOrder);
end;

% Update previous value
handles.BaselineOrderPreviousValue = handles.BaselineOrder;

% Update current handles in workspace
assignin('base','currentHandles3',handles)

% Update handles structure
guidata(hObject,handles);

function BaselineOrder_Edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function NumberOfIterations_Edit_Callback(hObject, eventdata, handles)
handles.NumberOfIterations = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.NumberOfIterations) > 0) || (isinf(handles.NumberOfIterations) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for number of iterations.'];
    ErrorMessage2 = ['Error: Number of iterations set to a valid value (' num2str(handles.NumberOfIterationsPreviousValue) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.NumberOfIterations = handles.NumberOfIterationsPreviousValue;
    set(hObject,'String',handles.NumberOfIterations);
end;

if ((rem(handles.NumberOfIterations,1) ~= 0) || (handles.NumberOfIterations < 1))
    % Positive, integer number for number of iterations
    handles.NumberOfIterations = abs(round(handles.NumberOfIterations));
    set(hObject,'String',handles.NumberOfIterations);
end;

% Update previous value
handles.NumberOfIterationsPreviousValue = handles.NumberOfIterations;

% Update current handles in workspace
assignin('base','currentHandles3',handles)

% Update handles structure
guidata(hObject,handles);

function NumberOfIterations_Edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in BasisSetDirSelect_PushButton.
function BasisSetDirSelect_PushButton_Callback(hObject, eventdata, handles)
% Prepare for when Cancel button is pressed
BasisSetPathCancel = handles.BasisSetDir;

% Get new file and path names
dirname = uigetdir(handles.BasisSetDir,'Select basisset directory');

% Action performed when Cancel button is pressed
if isequal(dirname,0)
    handles.BasisSetDir = BasisSetPathCancel;
else
    handles.BasisSetDir = dirname;
end

% Update current handles in workspace
assignin('base','currentHandles3',handles)

% Update GUI data structure
guidata(hObject,handles)

% Set the edit box string to the new basisset directory
set(handles.BasisSetDir_Edit,'String',handles.BasisSetDir);


% Starts spectral fitting for all voxels above threshold
function StartFit_PushButton_Callback(hObject, eventdata, handles)

% Retrieve and update GUI data structure from DMIWizard MRSI window
DMIWizard_MRSI_Object = findall(0,'Name','DMIWizard_MRSI');
handlesMRSI = guidata(DMIWizard_MRSI_Object);

% Extract parameters from main DMIWizard window and add to handles
handles.MRSIPath = handlesMRSI.MRSIPath;

handles.sp1 = handlesMRSI.sp1;
handles.sp2 = handlesMRSI.sp2;
handles.sp3 = handlesMRSI.sp3;

handles.np1 = handlesMRSI.np1;
handles.np2 = handlesMRSI.np2;
handles.np3 = handlesMRSI.np3;

handles.sw = handlesMRSI.sw;
handles.np = handlesMRSI.np;
handles.npzf = handlesMRSI.npzf;
handles.nu0 = handlesMRSI.nu0;
handles.emf = handlesMRSI.emf;
handles.ph0 = handlesMRSI.ph0;
handles.ph1 = handlesMRSI.ph1;

handles.ZxLow = handlesMRSI.ZxLow;
handles.ZxHigh = handlesMRSI.ZxHigh;
handles.ZyLow = handlesMRSI.ZyLow;
handles.ZyHigh = handlesMRSI.ZyHigh;
handles.ZyScale = handlesMRSI.ZyScale;
handles.intth = handlesMRSI.intth;
handles.av = handlesMRSI.av;

handles.spec3D = handlesMRSI.spec3D;
handles.InclusionMap = handlesMRSI.InclusionMap;

if (isfield(handlesMRSI,'LCMFit') > 0)
    % Transfer LCM fitting parameters from DMIWizard if they exist
    handles.LCMFit = handlesMRSI.LCMFit;
end;

handles.Fig2XPos = handlesMRSI.Fig2XPos;
handles.Fig2YPos = handlesMRSI.Fig2YPos;
handles.Fig2Width = handlesMRSI.Fig2Width;
handles.Fig2Height = handlesMRSI.Fig2Height;

handles.ProcessingHistoryFile = handlesMRSI.ProcessingHistoryFile;

% Read basisset directory for included metabolite files
ErrorFlag = 0;

%--- 1. Parameter file ---
BasisSetParameterFile = [handles.BasisSetDir '\BasisSet.par'];
if (exist(BasisSetParameterFile,'file') > 0)
   [handles.swSim, handles.npSim, handles.nu0Sim, handles.RFoffsetSim] = ...
       DMIWizard_MRSI_ReadBasisSetParameters(BasisSetParameterFile);
else
    [OperationTime,OperationDate] = DMIWizard_MRSI_CalculateTime;
    ErrorOutput0 = [OperationTime ' - Error: Basisset parameter file ' BasisSetParameterFile ' not found.'];
    ErrorOutput1 = [OperationTime ' - Error: Spectral fitting algorithm aborted.'];
    disp(' '); disp(ErrorOutput0); disp(ErrorOutput1); beep;
    
    ErrorFlag = 1;
end;

% Verify that experimental and simulated spectral widths are identical
if (handles.swSim ~= handles.sw)
    [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
    ErrorOutput0 = [OperationTime ' - Error   : Experimental spectral width (' num2str(handles.sw) ... 
        ' kHz) and simulated spectral width (' num2str(handles.swSim) ' kHz) are not equal.'];
    ErrorOutput1 = [OperationTime ' - Error   : Spectral fitting algorithm aborted as basisset is inappropriate for experimental data.'];
    ErrorOutput2 = [OperationTime ' - Solution: Generate basisset with appropriate spectral width.'];
    disp(' '); disp(ErrorOutput0); disp(ErrorOutput1); disp(ErrorOutput2); beep;
    
    ErrorFlag = 1;   
end;

% Verify that experimental and simulated Larmor frequencies are identical
if (handles.nu0Sim ~= handles.nu0)
    [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
    ErrorOutput0 = [OperationTime ' - Error   : Experimental Larmor frequency (' num2str(handles.nu0) ... 
        ' MHz) and simulated Larmor frequency (' num2str(handles.nu0Sim) ' MHz ) are not equal.'];
    ErrorOutput1 = [OperationTime ' - Error   : Spectral fitting algorithm aborted as basisset is inappropriate for experimental data.'];
    ErrorOutput2 = [OperationTime ' - Solution: Generate basisset with appropriate Larmor frequency.'];
    disp(' '); disp(ErrorOutput0); disp(ErrorOutput1); disp(ErrorOutput2); beep;
    
    ErrorFlag = 1;   
end;

% Verify that experimental and simulated number of acquisition points are identical
if (handles.npSim ~= handles.np)
    [OperationTime,~] = DMIWizard_MRSI_CalculateTime;

    if (handles.npSim > handles.np)
        if (ErrorFlag < 1)
           WarningOutput0 = [OperationTime ' - Warning : Experimental acquisition points (' num2str(handles.np) ... 
            ') and simulated acquisition points (' num2str(handles.npSim) ') are not equal.'];
           WarningOutput1 = [OperationTime ' - Solution: Simulated number of acquisition points truncated to match experimental data.'];
           disp(' '); disp(WarningOutput0); disp(WarningOutput1);
        end;
    else
       ErrorOutput0 = [OperationTime ' - Error : Experimental acquisition points (' num2str(handles.np) ... 
        ') and simulated acquisition points (' num2str(handles.npSim) ') are not equal.'];
       ErrorOutput1 = [OperationTime ' - Error : Spectral fitting algorithm aborted.'];
       disp(' '); disp(ErrorOutput0); disp(ErrorOutput1);        
       ErrorFlag = 1; 
    end; 
end;
         
% Reload the prior knowledge file content
handles.PKData = DMIWizard_MRSI_ReadPriorKnowledgeAndLimits(handles.PKFile,'N');

%--- 2. Included metabolite basisset FIDs ---
if ((isfield(handles,'PKData') == 1) && (ErrorFlag < 1))

    nmeta = length(handles.PKData.NumberOfGroups);  % Maximum number of included metabolites
    
    if (isfield(handles,'RFCenterFrequency') == 1)
        ppmhigh = handles.RFCenterFrequency + 1000*handles.ZxHigh/handles.nu0;
        ppmlow = handles.RFCenterFrequency + 1000*handles.ZxLow/handles.nu0;
    else
        [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
        ErrorOutput1 = [OperationTime ' - Error   : RF Center Frequency is unknown.'];
        ErrorOutput2 = [OperationTime ' - Solution: Select Chemical Shift Reference in DMIWizard_Fitting window.'];
        disp(' '); disp(ErrorOutput1); disp(ErrorOutput2);
        ErrorFlag = 1;
    end;
   
    % Remove BasisFID field from an earlier fit (potentially with a different zoom)
    if (isfield(handles,'BasisFID') > 0)
        handles = rmfield(handles,'BasisFID');
    end;
    
    if (ErrorFlag < 1)
        metacount = 1;
        coorZoom = 1;
        for c1 = 1:nmeta;
            if ((handles.PKData.GroupCS(c1,1) > ppmlow) && (handles.PKData.GroupCS(c1,1) < ppmhigh))
                filename = [handles.BasisSetDir '\' handles.PKData.FileName{c1}];
                fileID = fopen(filename,'r');
                if (fileID > 0)

                    datain1 = fscanf(fileID,'%g %g',[2 Inf]);
                    fclose(fileID);

                    datain2 = datain1(1,:) + 1i*datain1(2,:);
                    handles.BasisFID(:,metacount) = datain2(1:handles.np);
                    coorZoom(metacount) = c1;

                    [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
                    TextOutput1 = [OperationTime ' - Basisset FID ' handles.PKData.FileName{c1} ' successfully loaded.'];
                    disp(TextOutput1);
                    metacount = metacount + 1;
                else
                    [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
                    ErrorOutput1 = [OperationTime ' - Basisset FID ' handles.PKData.FileName{c1} ' cannot be loaded.'];
                    disp(' '); disp(ErrorOutput1);

                    ErrorFlag = 1;
                end;
            end;
        end;
    end;
end;

if ((isfield(handles,'PKData') == 1) && (ErrorFlag < 1))
    % Reload the prior knowledge file content
    handles.PKData = DMIWizard_MRSI_ReadPriorKnowledgeAndLimits(handles.PKFile,'N');

    % Update prior knowledge to reflect exclusion based on spectral zoom
    handles.PKData.GroupLWLink = handles.PKData.GroupLWLink(coorZoom);
    handles.PKData.GroupLWLow = handles.PKData.GroupLWLow(coorZoom);
    handles.PKData.GroupLWHigh = handles.PKData.GroupLWHigh(coorZoom);

    handles.PKData.GroupShiftLow = handles.PKData.GroupShiftLow(coorZoom);
    handles.PKData.GroupShiftHigh = handles.PKData.GroupShiftHigh(coorZoom);

    handles.PKData.GroupCS = handles.PKData.GroupCS(coorZoom,1);
    handles.PKData.MetaboliteName = handles.PKData.MetaboliteName(coorZoom);
    
    % Check if signal for absolute linewidth fitting is indicated
    minLWLink = min(handles.PKData.GroupLWLink);
    if (minLWLink >= 0)
        [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
        ErrorOutput1 = [OperationTime ' - Error   : None of the included signals is indicated for total linewidth fitting.'];
        ErrorOutput2 = [OperationTime ' - Solution: Indicate one of the included signals with LWLink = -1 in the Prior Knowledge file.'];
        disp(' '); disp(ErrorOutput1); disp(ErrorOutput2);
        ErrorFlag = 1;
    end;
end;

% Correct Basis FIDs for difference between simulated and 
% experimental RF center frequency.
if (ErrorFlag < 1)
    FreqDiff = 0.001*(handles.RFoffsetSim - handles.RFCenterFrequency)*handles.nu0;
    time = 0:(1/handles.sw):(handles.np-1)/handles.sw;
    
    if (isfield(handles,'BasisFID') > 0)
        nres = size(handles.BasisFID,2);
        for c1 = 1:nres;
            handles.BasisFID(:,c1) = handles.BasisFID(:,c1).*exp(2*pi*1i*FreqDiff*time');
        end;
        
        [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
        TextOutput1 = [OperationTime ' - Difference between experimental (' num2str(handles.RFCenterFrequency) ...
            ' ppm) and simulated (' num2str(handles.RFoffsetSim) ' ppm) RF center frequency removed by shifting the basisset FIDs.'];
        disp(' '); disp(TextOutput1);
    else
        [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
        ErrorOutput1 = [OperationTime ' - Error   : No basisset FID available for spectral fitting.'];
        ErrorOutput2 = [OperationTime ' - Solution: Check prior knowledge/inclusion file and/or spectral zoom.'];
        disp(' '); disp(ErrorOutput1); disp(ErrorOutput2);      
        ErrorFlag = 1;
    end;
end;

% Spectral fitting
if (ErrorFlag < 1)
    
    % 1. Set up initial estimates and lower/upp bounds 
    % based on prior knowledge.
    handles.nres = size(handles.BasisFID,2);
    
    cf = []; lb = []; ub = [];
    M0est = 1;
    for c0 = 1:handles.nres;
        if (c0 > 1)
            coorLW = find(handles.PKData.GroupLWLink(1:c0-1,1) == handles.PKData.GroupLWLink(c0,1));
            if (isempty(coorLW) > 0)
                % Resonance linewidth is NOT linked to a previous one
                LWest = (handles.PKData.GroupLWLow(c0) + handles.PKData.GroupLWHigh(c0))/2;
                % Initial estimates for (M0, nu (Hz), line width (Hz))
                cf = [cf M0est 0 LWest];
                lb = [lb 0 handles.PKData.GroupShiftLow(c0) handles.PKData.GroupLWLow(c0)];
                ub = [ub Inf handles.PKData.GroupShiftHigh(c0) handles.PKData.GroupLWHigh(c0)];
            else
                % Resonance linewidth is linked to a previous one
                cf = [cf M0est 0];
                lb = [lb 0 handles.PKData.GroupShiftLow(c0)];
                ub = [ub Inf handles.PKData.GroupShiftHigh(c0)];
            end;
        else
            LWest = (handles.PKData.GroupLWLow(c0) + handles.PKData.GroupLWHigh(c0))/2;
            % Initial estimates for (M0, nu (Hz), line width (Hz))
            cf = [cf M0est 0 LWest];
            lb = [lb 0 handles.PKData.GroupShiftLow(c0) handles.PKData.GroupLWLow(c0)];
            ub = [ub Inf handles.PKData.GroupShiftHigh(c0) handles.PKData.GroupLWHigh(c0)];           
        end;
    end;
    
    % Add initial estimate for phase
    switch handles.PhaseSelection
        case 'Zero-order phase'
            cf = [cf 0]; lb = [lb -Inf]; ub = [ub Inf];
        case 'First-order phase'
            if (handles.FirstOrderFix > 0)
                cf = [cf 0]; 
                lb = [lb -Inf]; 
                ub = [ub Inf];                
            else
                cf = [cf 0 handles.FirstOrderPhaseEstimate]; 
                lb = [lb -Inf handles.FirstOrderPhaseEstimate-1000]; 
                ub = [ub Inf handles.FirstOrderPhaseEstimate+1000];
            end;
    end;
    
    % Add low-order baseline
    if ((handles.BaselineOrder >= 0) && (handles.BaselineOrder <= 2))
        cf = [cf zeros(1,handles.BaselineOrder+1)];
        lb = [lb -Inf*ones(1,handles.BaselineOrder+1)];
        ub = [ub Inf*ones(1,handles.BaselineOrder+1)];
    end;

    % Add lineshape distortion common to all resonances
    if (handles.LineShapeDistortion > 0)
        switch handles.LineShapeDistortion
            case 1
                % Essentially global frequency shift
                cf = [cf 0.5 0 0];                                          % Estimate (M0, nu, phs)
                lb = [lb 0.1 -handles.MaximumGlobalOffset -0.01*pi];        % Lower bound (M0, nu, phs)
                ub = [ub 1 handles.MaximumGlobalOffset 0.01*pi];            % Upper bound (M0, nu, phs)
            case 2
                cf = [cf 0.75 0 0 0.5 0 0];                                         % Estimate (M0, nu, phs)
                lb = [lb 0.5 -handles.MaximumGlobalOffset -0.01*pi 0 -5 -0.95*pi];	% Lower bound (M0, nu, phs)
                ub = [ub 1 handles.MaximumGlobalOffset 0.01*pi 0.5 5 0.95*pi];      % Upper bound (M0, nu, phs)                
            case 3
                cf = [cf 0.75 0 0 0.166 0 0 0.166 0 0];                             % Estimate (M0, nu, phs)
                lb = [lb 0.66 -handles.MaximumGlobalOffset -0.01*pi 0.0 -5 -0.95*pi 0.0 -5 -0.95*pi];	% Lower bound (M0, nu, phs)
                ub = [ub 1 handles.MaximumGlobalOffset 0.01*pi 0.33 5 0.95*pi 0.33 5 0.95*pi];          % Upper bound (M0, nu, phs)
        end;   
    end;
    
    % Store initial estimates as 'global' estimates
    cfglobal = cf; lbglobal = lb; ubglobal = ub;
    
    NumberOfEvaluations = handles.NumberOfIterations*(length(cf)+1);
    opt = optimset('maxiter',handles.NumberOfIterations,'maxFunEvals',NumberOfEvaluations,...
        'TolX',1e-8,'TolFun',1e-8,'Display','none');

    % 2. Perform pixel-wise spectral fitting.
    freq = -0.5*handles.sw:handles.sw/(handles.npzf-1):0.5*handles.sw;
    coor = find((freq > handles.ZxLow) & (freq < handles.ZxHigh));
    freqselect = freq(coor);
    
    % Allocate memory for fitting results
    handles.spec3Dfit = zeros(handles.npzf,handles.np1,handles.np2,handles.np3);
    % Allocate memory when LCMFit matrices do not exist.
    if (isfield(handles,'LCMFit') < 1)
        handles.LCMFit.M0 = zeros(handles.nres,handles.np1,handles.np2,handles.np3);
        handles.LCMFit.LineShift = zeros(handles.nres,handles.np1,handles.np2,handles.np3);
        handles.LCMFit.LineWidth = zeros(handles.nres,handles.np1,handles.np2,handles.np3);
    
        switch handles.PhaseSelection
            case 'Zero-order phase'
                handles.LCMFit.Phase = zeros(1,handles.np1,handles.np2,handles.np3);
             case 'First-order phase'
                handles.LCMFit.Phase = zeros(2,handles.np1,handles.np2,handles.np3);
        end;
        handles.LCMFit.Baseline = zeros(3,handles.np1,handles.np2,handles.np3);
        handles.LCMFit.LSD = zeros(9,handles.np1,handles.np2,handles.np3);
        % Set first amplitude to one, in case LSD is 'off'
        handles.LCMFit.LSD(1,:,:,:) = ones(handles.np1,handles.np2,handles.np3);
    end;
    
    % Allocate memory when the LCMFit matrix size does not match the current data.
    if ((isfield(handles,'LCMFit') > 0) && ...
            (numel(handles.LCMFit.M0) ~= handles.nres*handles.np1*handles.np2*handles.np3))
        handles.LCMFit.M0 = zeros(handles.nres,handles.np1,handles.np2,handles.np3);
        handles.LCMFit.LineShift = zeros(handles.nres,handles.np1,handles.np2,handles.np3);
        handles.LCMFit.LineWidth = zeros(handles.nres,handles.np1,handles.np2,handles.np3);
    
        switch handles.PhaseSelection
            case 'Zero-order phase'
                handles.LCMFit.Phase = zeros(1,handles.np1,handles.np2,handles.np3);
             case 'First-order phase'
                 handles.LCMFit.Phase = zeros(2,handles.np1,handles.np2,handles.np3);
        end;
        handles.LCMFit.Baseline = zeros(3,handles.np1,handles.np2,handles.np3);
        handles.LCMFit.LSD = zeros(9,handles.np1,handles.np2,handles.np3);
        % Set first amplitude to one, in case LSD is 'off'
        handles.LCMFit.LSD(1,:,:,:) = ones(handles.np1,handles.np2,handles.np3);
    end;
    
    count1 = 1; 
    if (handles.SVFit > 0)
        % Single voxel fit
        totalcount = 1;
    else
        % Number of fitted voxels above the threshold
        totalcount = sum(handles.InclusionMap(:));
    end;
    for c1 = 1:handles.np1;
        for c2 = 1:handles.np2;
            for c3 = 1:handles.np3;
                
                clear specselect;
                if (handles.SVFit < 1)
                    % Fit all spectra above the threshold
                    if (handles.InclusionMap(c1,c2,c3) > 0)
                        spec = real(handles.spec3D(:,c1,c2,c3));
                        specselect = spec(coor);
                    end;
                else
                    if ((c1 == handles.sp1) && (c2 == handles.sp2) && (c3 == handles.sp3))
                        spec = real(handles.spec3D(:,c1,c2,c3));
                        specselect = spec(coor);
                    end;
                end;
                    
                if (handles.VoxelPK > 0)
                    % Use fitting parameters from a previous fit for
                    % voxel-specific initial estimates.
                    
                    % Determine signal for which full linewidth is fitted, instead of 
                    % the linewidth differences. Signal with GroupLWLink < 0 indicates
                    % signal for which full linewidth is fitted.
                    coorFullLW = find(handles.PKData.GroupLWLink(:,1) < 0);
                    FullLW = handles.LCMFit.LineWidth(coorFullLW,c1,c2,c3);

                    if (isfield(handles,'LCMFit') > 0)
                        count2 = 1;
                        for c0 = 1:handles.nres;
                            cf(count2) = handles.LCMFit.M0(c0,c1,c2,c3);
                            cf(count2+1) = handles.LCMFit.LineShift(c0,c1,c2,c3);
                            if (c0 == coorFullLW)
                                cf(count2+2) = FullLW;
                            else
                                cf(count2+2) = handles.LCMFit.LineWidth(c0,c1,c2,c3) - FullLW;
                            end;
                            count2 = count2 + 3;                            
                       end;

                       switch handles.PhaseSelection
                          case 'Zero-order phase'
                             cf(count2) = handles.LCMFit.Phase(1,c1,c2,c3);
                             count2 = count2 + 1;
                          case 'First-order phase'
                             if (handles.FirstOrderFix > 0)
                                 cf(count2) = handles.LCMFit.Phase(1,c1,c2,c3);
                                 count2 = count2 + 1;
                             else
                                 cf(count2) = handles.LCMFit.Phase(1,c1,c2,c3);
                                 cf(count2+1) = handles.LCMFit.Phase(2,c1,c2,c3);
                                 count2 = count2 + 2;
                             end;
                       end;

                       switch handles.BaselineOrder
                          case 0
                             cf(count2) = handles.LCMFit.Baseline(1,c1,c2,c3);
                             count2  = count2 + 1;
                          case 1
                             cf(count2) = handles.LCMFit.Baseline(1,c1,c2,c3);
                             cf(count2+1) = handles.LCMFit.Baseline(2,c1,c2,c3);
                             count2  = count2 + 2;
                          case 2
                             cf(count2) = handles.LCMFit.Baseline(1,c1,c2,c3);
                             cf(count2+1) = handles.LCMFit.Baseline(2,c1,c2,c3);
                             cf(count2+2) = handles.LCMFit.Baseline(3,c1,c2,c3);
                             count2  = count2 + 3;
                      end;

                      if (handles.LineShapeDistortion > 0)
                          switch handles.LineShapeDistortion
                              case 1
                                  cf(count2:count2+2) = handles.LCMFit.LSD(1:3,c1,c2,c3);
                                  count2 = count2 + 3;
                              case 2
                                  cf(count2:count2+5) = handles.LCMFit.LSD(1:6,c1,c2,c3);
                                  count2 = count2 + 6;
                              case 3
                                  cf(count2:count2+8) = handles.LCMFit.LSD(1:9,c1,c2,c3);
                                  count2 = count2 + 9;
                          end;  
                      end;

                      if (length(cf) ~= length(cfglobal))
                          % Number of parameters needed for current fit
                          % is not in agreement with number of
                          % parameters from a previous fit (likely due
                          % to a change in the Prior Knowledge Excel
                          % file) - use global estimates.
                          cf = cfglobal; lb = lbglobal; ub = ubglobal;

                          if ((handles.SVFit < 1) && (handles.InclusionMap(c1,c2,c3) > 0))
                              % Only display warning message when fitting
                              % multiple voxels (i.e. suppress in single
                              % voxel mode).
                              [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
                              TextOutput1 = [OperationTime ' - Warning : Number of voxel-specific fitting parameters not in'];
                              TextOutput2 = [OperationTime ' - Warning : agreement with number of global fitting parameters.'];     
                              TextOutput3 = [OperationTime ' - Solution: Continuing with global initial estimates.'];
                              disp(TextOutput1); disp(TextOutput2); disp(TextOutput3);
                          end;
                      end;

                      if (sum(abs(handles.LCMFit.M0(:,c1,c2,c3))) < 0.001)
                          % Voxel position was not previously fitted
                          % and does not provide voxel-specific prior
                          % knowledge (likely due to a different
                          % threshold setting) - use global estimates.
                          cf = cfglobal; lb = lbglobal; ub = ubglobal;

                          if ((handles.SVFit < 1) && (handles.InclusionMap(c1,c2,c3) > 0))
                              % Only display warning message when fitting
                              % multiple voxels (i.e. suppress in single
                              % voxel mode).
                              [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
                              TextOutput1 = [OperationTime ' - Warning : Previous fitting results not available.'];
                              TextOutput2 = [OperationTime ' - Solution: Continuing with global initial estimates.'];
                              disp(TextOutput1); disp(TextOutput2);
                          end;
                      end;

                    else
                        [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
                        TextOutput1 = [OperationTime ' - Warning : No voxel-specific prior knowledge available.'];
                        TextOutput2 = [OperationTime ' - Solution: Continuing with global initial estimates.'];
                        disp(TextOutput1); disp(TextOutput2);
                    end;
                end;
                     
                if (exist('specselect','var') > 0)
                    [LCMFit,resnorm,~,exitflag,~] = lsqcurvefit('DMIWizard_MRSI_FittingFunction01',cf,freqselect,specselect,lb,ub,opt,handles,coor);
                    
                    spec1Dfit = DMIWizard_MRSI_FittingFunction01(LCMFit,freq,handles,1:handles.npzf);
                    handles.spec3Dfit(:,c1,c2,c3) = spec1Dfit;
                    
                    % Determine signal for which full linewidth is fitted, instead of 
                    % the linewidth differences. Signal with GroupLWLink < 0 indicates
                    % signal for which full linewidth is fitted.
                    coorFullLW = find(handles.PKData.GroupLWLink(:,1) < 0);
                    FullLW = LCMFit(3*coorFullLW);

                    % Extract individual parameter (for saving purposes)
                    count2 = 1;
                    for c0 = 1:handles.nres;
                        handles.LCMFit.M0(c0,c1,c2,c3) = LCMFit(count2);
                        handles.LCMFit.LineShift(c0,c1,c2,c3) = LCMFit(count2+1);
                        if (c0 == coorFullLW)
                            handles.LCMFit.LineWidth(c0,c1,c2,c3) = LCMFit(count2+2);
                        else
                            handles.LCMFit.LineWidth(c0,c1,c2,c3) = FullLW + LCMFit(count2+2);
                        end;
                        count2 = count2 + 3;                            
                    end;
                    
                    switch handles.PhaseSelection
                        case 'Zero-order phase'
                            handles.LCMFit.Phase(1,c1,c2,c3) = rem(LCMFit(count2),360);
                            handles.LCMFit.Phase(2,c1,c2,c3) = 0.0;
                            count2 = count2 + 1;
                         case 'First-order phase'
                             if (handles.FirstOrderFix > 0)
                                 handles.LCMFit.Phase(1,c1,c2,c3) = rem(LCMFit(count2),360);
                                 handles.LCMFit.Phase(2,c1,c2,c3) = handles.FirstOrderPhaseEstimate;
                                 count2 = count2 + 1;                                
                             else                                 
                                 handles.LCMFit.Phase(1,c1,c2,c3) = rem(LCMFit(count2),360);
                                 handles.LCMFit.Phase(2,c1,c2,c3) = LCMFit(count2+1);
                                 count2 = count2 + 2;
                             end;
                    end;
                    
                    switch handles.BaselineOrder
                        case 0
                            handles.LCMFit.Baseline(1,c1,c2,c3) = LCMFit(count2);
                            handles.LCMFit.Baseline(2:3,c1,c2,c3) = 0.0;
                         case 1
                            handles.LCMFit.Baseline(1,c1,c2,c3) = LCMFit(count2);
                            handles.LCMFit.Baseline(2,c1,c2,c3) = LCMFit(count2+1);
                            handles.LCMFit.Baseline(3,c1,c2,c3) = 0.0;
                         case 2
                            handles.LCMFit.Baseline(1,c1,c2,c3) = LCMFit(count2);
                            handles.LCMFit.Baseline(2,c1,c2,c3) = LCMFit(count2+1);
                            handles.LCMFit.Baseline(3,c1,c2,c3) = LCMFit(count2+2);
                    end;
                     
                    switch handles.LineShapeDistortion
                        case 1
                             handles.LCMFit.LSD(1:3,c1,c2,c3) = LCMFit(end-3+1:end);
                             handles.LCMFit.LSD(4:9,c1,c2,c3) = 0.0;                               
                        case 2
                             handles.LCMFit.LSD(1:6,c1,c2,c3) = LCMFit(end-6+1:end);
                             handles.LCMFit.LSD(7:9,c1,c2,c3) = 0.0;
                        case 3
                            handles.LCMFit.LSD(1:3*handles.LineShapeDistortion,c1,c2,c3) = ...
                                LCMFit(end-3*handles.LineShapeDistortion+1:end);
                    end;
                    
                    TextOutput = ['Spectral fitting completed for spectrum ' num2str(count1) ' of ' num2str(totalcount) ' at ( ' ...
                        num2str(c1) ', ' num2str(c2) ', ' num2str(c3) ')'];
                    disp(TextOutput);
                    count1 = count1 + 1;
                end;
            end;
        end;
    end;
    
    % Force fitting results for voxels below threshold to zero.
    % This is relevant when a fit is performed with a threshold that is
    % higher than used during a previous fit.
    % If 'Single Voxel Fit' is selected, this routine is bypassed to
    % allow single spectra below the threshold to be fitted and included.
    % Note that a subsequent fit of all voxels will remove any
    % fitting results for single voxels below the threshold.
    % In other words, single voxels below the threshold should
    % always be pursued AFTER the fitting of 'All' voxels is completed.
    if (handles.SVFit < 1)
        for c1 = 1:handles.np1;
            for c2 = 1:handles.np2;
                for c3 = 1:handles.np3;
                    if (handles.InclusionMap(c1,c2,c3) < 1)
                        handles.LCMFit.M0(:,c1,c2,c3) = 0.0;
                        handles.LCMFit.LineShift(:,c1,c2,c3) = 0.0;
                        handles.LCMFit.LineWidth(:,c1,c2,c3) = 0.0;
                        handles.LCMFit.Phase(:,c1,c2,c3) = 0.0;
                        handles.LCMFit.Baseline(:,c1,c2,c3) = 0.0;
                        handles.LCMFit.LSD(1,c1,c2,c3) = 1.0;
                        handles.LCMFit.LSD(2:end,c1,c2,c3) = 0.0;
                    end;
                end;
            end;
        end;
    end;
    
    % Display fitted and experimental spectra
    DMIWizard_MRSI_DisplaySpectrum(handles);
    
    % Write fitting parameters to disk
    DMIWizard_MRSI_WriteFittingParameters(handles)
    
    % Write fitting results to disk
    DMIWizard_MRSI_WriteFittingResults(handles)
    
    % Write metabolite identification to disk
    DMIWizard_MRSI_WriteFittingIDs(handles)
    
    % Write basisset to disk
    DMIWizard_MRSI_WriteFittingBasisSet(handles)
    
    % Write baseline parameters to disk
    DMIWizard_MRSI_WriteFittingBaseline(handles)
    
    % Write lineshape distortion parameters to disk
    DMIWizard_MRSI_WriteFittingLSD(handles)
    
    % Force a data reload in the main window, effectively
    % to transfer fitting results for general display.   
    DMIWizard_MRSI_Object = findall(0,'Tag','DMIWizard_MRSI');
    DMIWizard_MRSI('LoadDMI_pushbutton_Callback',DMIWizard_MRSI_Object,[],guidata(DMIWizard_MRSI_Object));
end;

% Update current handles in workspace
assignin('base','currentHandles3',handles)

% Update handles structure
guidata(hObject,handles);


function BasisSetDir_Edit_Callback(hObject, eventdata, handles)
handles.BasisSetDir = get(hObject,'String');

% Update current handles in workspace
assignin('base','currentHandles3',handles)

% Update handles structure
guidata(hObject, handles);


function BasisSetDir_Edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in LineShapeSelectionMenu.
function LineShapeSelectionMenu_Callback(hObject, eventdata, handles)
contents = cellstr(get(hObject,'String'));
handles.LineShapeSelection = contents{get(hObject,'Value')};

% Update current handles in workspace
assignin('base','currentHandles3',handles)

% Update handles structure
guidata(hObject, handles);


function LineShapeSelectionMenu_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on selection change in PhaseSelectionMenu.
function PhaseSelectionMenu_Callback(hObject, eventdata, handles)
contents = cellstr(get(hObject,'String'));
handles.PhaseSelection = contents{get(hObject,'Value')};

% Update current handles in workspace
assignin('base','currentHandles3',handles)

% Update handles structure
guidata(hObject, handles);

function PhaseSelectionMenu_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function PKFile_Edit_Callback(hObject, eventdata, handles)
% Manual input of the prior knowledge file is disabled.
% Select the prior knowledge file using the 'Select' button.

function PKFile_Edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function PKFileSelect_PushButton_Callback(hObject, eventdata, handles)
% Prepare for when Cancel button is pressed
PKFileCancel = handles.PKFile;

% Get new file and path names
[filename, pathname] = uigetfile('*.xlsx','Select Excel prior knowledge file',handles.PKFile);

% Action performed when Cancel button is pressed
if isequal(filename,0) || isequal(pathname,0)
    handles.PKFile = PKFileCancel;
else
    handles.PKFile = [pathname filename];
end

% Set the edit box string to the new basisset directory
set(handles.PKFile_Edit,'String',handles.PKFile);

% Read the prior knowledge file content
handles.PKData = DMIWizard_MRSI_ReadPriorKnowledgeAndLimits(handles.PKFile,'N');

% Update current handles in workspace
assignin('base','currentHandles3',handles)

% Update GUI data structure
guidata(hObject,handles)


% --- Executes on button press in VoxelPK_CheckBox.
function VoxelPK_CheckBox_Callback(hObject, eventdata, handles)
handles.VoxelPK = get(hObject,'Value');

if (handles.VoxelPK > 0)
    % Reload settings from previous fitting sessions
    
    % Retrieve and update GUI data structure from DMIWizard MRSI window
    DMIWizard_MRSI_Object = findall(0,'Name','DMIWizard_MRSI');
    handlesMRSI = guidata(DMIWizard_MRSI_Object);

    % Extract parameters from main DMIWizard window and add to handles
    % 1. Shift reference
    handles.ShiftReference = handlesMRSI.ShiftReference;
    ShiftReference_Object = findall(0,'Tag','ShiftReference_Edit');
    set(ShiftReference_Object,'String',handles.ShiftReference);
    
    % 2. Shift reference (kHz) and  RF center frequency (ppm)
    handles.ShiftReferencekHz = handlesMRSI.ShiftReferencekHz;
    handles.RFCenterFrequency = handlesMRSI.RFCenterFrequency;
    
    % 3. Maximum global offset
    handles.MaximumGlobalOffset = handlesMRSI.MaximumGlobalOffsetFit;
    MaximumGlobalOffset_Object = findall(0,'Tag','MaximumGlobalOffset_Edit');
    set(MaximumGlobalOffset_Object,'String',handles.MaximumGlobalOffset);
    
    % 4. Baseline order
    handles.BaselineOrder = handlesMRSI.BLOFit;
    BaselineOrder_Object = findall(0,'Tag','BaselineOrder_Edit');
    set(BaselineOrder_Object,'String',handles.BaselineOrder);
 
    % 5. Number of iterations
    handles.NumberOfIterations = handlesMRSI.NumberOfIterations;
    NumberOfIterations_Object = findall(0,'Tag','NumberOfIterations_Edit');
    set(NumberOfIterations_Object,'String',handles.NumberOfIterations);
    
    % 6. Base lineshape
    handles.LineShapeSelection = handlesMRSI.LineshapeFit;
    LineShapeSelection_Object = findall(0,'Tag','LineShapeSelectionMenu');
    switch handles.LineShapeSelection
        case 'Gaussian'
            set(LineShapeSelection_Object,'Value',1);
        case 'Lorentzian'
            set(LineShapeSelection_Object,'Value',2);
    end;
    
    % 7. Lineshape distortion
    handles.LineShapeDistortion = handlesMRSI.LSDFit;
    LineShapeDistortion_Object = findall(0,'Tag','LineShapeDistortion_Edit');
    set(LineShapeDistortion_Object,'String',handles.LineShapeDistortion);
    
    % 8. Phase-related parameters
    handles.PhaseSelection = handlesMRSI.PhaseFit;
    PhaseSelection_Object = findall(0,'Tag','PhaseSelectionMenu');
    switch handles.PhaseSelection
        case 'Zero-order phase'
            set(PhaseSelection_Object,'Value',1);
        case 'First-order phase'
            set(PhaseSelection_Object,'Value',2);
    end;
    
    handles.FirstOrderPhaseEstimate = handlesMRSI.FirstOrderPhaseEstimateFit;
    FirstOrderPhaseEstimate_Object = findall(0,'Tag','FirstOrderPhaseEstimate_Edit');
    set(FirstOrderPhaseEstimate_Object,'String',handles.FirstOrderPhaseEstimate);
    
    handles.FirstOrderFixYN = handlesMRSI.FirstOrderFixFit;
    if (handles.FirstOrderFixYN == 'Y')
        handles.FirstOrderFix = 1.0;
    else
        handles.FirstOrderFix = 0.0;
    end;
    FirstOrderFix_Object = findall(0,'Tag','FirstOrderFix_CheckBox');
    set(FirstOrderFix_Object,'Value',handles.FirstOrderFix);
    
    % 9. Basisset and prior knowledge file
    handles.BasisSetDir = handlesMRSI.BasisSetDirFit;
    BasisSetDir_Object = findall(0,'Tag','BasisSetDir_Edit');
    set(BasisSetDir_Object,'String',handles.BasisSetDir);
    
    handles.PKFile = handlesMRSI.PKFileFit;
    PKFile_Object = findall(0,'Tag','PKFile_Edit');
    set(PKFile_Object,'String',handles.PKFile);
    
    % Read the prior knowledge file content
    handles.PKData = DMIWizard_MRSI_ReadPriorKnowledgeAndLimits(handles.PKFile,'N');
end;

% Update current handles in workspace
assignin('base','currentHandles3',handles)

% Update handles structure
guidata(hObject, handles);

function FirstOrderPhaseEstimate_Edit_Callback(hObject, eventdata, handles)
handles.FirstOrderPhaseEstimate = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.FirstOrderPhaseEstimate) > 0) || (isinf(handles.FirstOrderPhaseEstimate) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for first-order phase estimate.'];
    ErrorMessage2 = ['Error: First-order phase estimate set to a valid value (0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.FirstOrderPhaseEstimate = 0;
    set(hObject,'String',handles.FirstOrderPhaseEstimate);
end;

% Update current handles in workspace
assignin('base','currentHandles3',handles)

% Update handles structure
guidata(hObject,handles);

function FirstOrderPhaseEstimate_Edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function MaximumGlobalOffset_Edit_Callback(hObject, eventdata, handles)
handles.MaximumGlobalOffset = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.MaximumGlobalOffset) > 0) || (isinf(handles.MaximumGlobalOffset) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for maximum global offset.'];
    ErrorMessage2 = ['Error: Maximum global offset set to a valid value (20).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.MaximumGlobalOffset = 20;
    set(hObject,'String',handles.MaximumGlobalOffset);
end;

if (handles.MaximumGlobalOffset < 0)
    % Positive number for maximum global offset
    handles.MaximumGlobalOffset = abs(handles.MaximumGlobalOffset);
    set(hObject,'String',handles.MaximumGlobalOffset);
end;

% Update current handles in workspace
assignin('base','currentHandles3',handles)

% Update handles structure
guidata(hObject,handles);


function MaximumGlobalOffset_Edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function SVFit_CheckBox_Callback(hObject, eventdata, handles)
handles.SVFit = get(hObject,'Value');

% Update current handles in workspace
assignin('base','currentHandles3',handles)

% Update handles structure
guidata(hObject,handles);


function FirstOrderFix_CheckBox_Callback(hObject, eventdata, handles)
handles.FirstOrderFix = get(hObject,'Value');

% Update current handles in workspace
assignin('base','currentHandles3',handles)

% Update handles structure
guidata(hObject,handles);
