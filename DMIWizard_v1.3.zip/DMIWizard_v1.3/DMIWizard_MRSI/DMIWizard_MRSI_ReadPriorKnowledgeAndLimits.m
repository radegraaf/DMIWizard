function PKData = DMIWizard_MRSI_ReadPriorKnowledgeAndLimits(filename,IncludeAll)

[ndata, text, alldata] = xlsread(filename);

 NumberOfLines = size(alldata,1);
 
 OperationTime = DMIWizard_MRSI_CalculateTime;
 TextOutput1 = [OperationTime ' - Prior knowledge on included metabolites : '];
 disp(' '); disp(TextOutput1);
 
 % Column 1 - filename
 LineNumber = 1; 
 MetaboliteCount = 1;
 GroupCount = 1;
 while (LineNumber < NumberOfLines + 1)
     % Check for comments (starts with %)
     LineText = char(alldata{LineNumber,1});
     if (strcmp(LineText(1),'%') > 0)
         %disp('Comment');
     else  
        if (IncludeAll == 'Y')
            alldata{LineNumber,2} = 'Y';
        end;
            
        % Check for cells with strings and a positive inclusion
        if ((iscellstr(alldata(LineNumber,1)) > 0) && ((char(alldata{LineNumber,2}) == 'Y') || ...
                (char(alldata{LineNumber,2}) == 'y')))
            % String in cell
            PKData.FileName{MetaboliteCount} = char(alldata{LineNumber,1});
            PKData.IncludeYN{MetaboliteCount} = char(alldata{LineNumber,2});
            PKData.MetaboliteName{MetaboliteCount} = char(alldata{LineNumber,3});
            PKData.LabelPosition{MetaboliteCount,GroupCount} = char(alldata{LineNumber,4});
            PKData.GroupCS(MetaboliteCount,GroupCount) = alldata{LineNumber,5};
            PKData.GroupRelativeM0(MetaboliteCount,GroupCount) = alldata{LineNumber,6};
            PKData.GroupM0Link(MetaboliteCount,GroupCount) = alldata{LineNumber,7};
            PKData.GroupLWLink(MetaboliteCount,GroupCount) = alldata{LineNumber,8};
            PKData.GroupLWLow(MetaboliteCount,GroupCount) = alldata{LineNumber,9};
            PKData.GroupLWHigh(MetaboliteCount,GroupCount) = alldata{LineNumber,10};
            PKData.GroupShiftLow(MetaboliteCount,GroupCount) = alldata{LineNumber,11};
            PKData.GroupShiftHigh(MetaboliteCount,GroupCount) = alldata{LineNumber,12};
            
            % Check for multiple groups within one molecule
            if (LineNumber < NumberOfLines)
                NextLine = char(alldata{LineNumber+1,3});
                while ((strcmp(char(alldata{LineNumber,3}),NextLine) > 0))
                    GroupCount = GroupCount + 1;
                    LineNumber = LineNumber + 1;
                    PKData.LabelPosition{MetaboliteCount,GroupCount} = char(alldata{LineNumber,4});
                    PKData.GroupCS(MetaboliteCount,GroupCount) = alldata{LineNumber,5};
                    PKData.GroupRelativeM0(MetaboliteCount,GroupCount) = alldata{LineNumber,6};
                    PKData.GroupM0Link(MetaboliteCount,GroupCount) = alldata{LineNumber,7};
                    PKData.GroupLWLink(MetaboliteCount,GroupCount) = alldata{LineNumber,8};
                    PKData.GroupLWLow(MetaboliteCount,GroupCount) = alldata{LineNumber,9};
                    PKData.GroupLWHigh(MetaboliteCount,GroupCount) = alldata{LineNumber,10};
                    PKData.GroupShiftLow(MetaboliteCount,GroupCount) = alldata{LineNumber,11};
                    PKData.GroupShiftHigh(MetaboliteCount,GroupCount) = alldata{LineNumber,12};
                    if (LineNumber < NumberOfLines)
                        NextLine = char(alldata{LineNumber+1,3});
                    else
                        NextLine = '';
                    end;
                end;
            end;
            PKData.NumberOfGroups(MetaboliteCount) = length(find(PKData.GroupCS(MetaboliteCount,:))> 0);

            % Display the included metabolites to Matlab command window
            TextOutput2 = [num2str(MetaboliteCount) ' - ' PKData.MetaboliteName{MetaboliteCount} ', ' ...
                num2str(PKData.GroupCS(MetaboliteCount,1)) ' ppm, LW limits [' ...
                num2str(PKData.GroupLWLow(MetaboliteCount,1)) ' ... ' num2str(PKData.GroupLWHigh(MetaboliteCount,1)) ...
                '] Hz, shift limits [' num2str(PKData.GroupShiftLow(MetaboliteCount,1)) ' ... ' ...
                num2str(PKData.GroupShiftHigh(MetaboliteCount,1)) '] Hz, LW link ID ' num2str(PKData.GroupLWLink(MetaboliteCount,1))];
            disp(TextOutput2);
                
            MetaboliteCount = MetaboliteCount + 1;
            GroupCount = 1;
        end;
     end;
     
     LineNumber = LineNumber + 1;
     GroupCount = 1;
 end;
 
 if (MetaboliteCount == 1)
     OperationTime = DMIWizard_MRSI_CalculateTime;
     ErrorMessage1 = [OperationTime ' - Error   : No included metabolites are found in the prior knowledge file.'];
     ErrorMessage2 = [OperationTime ' - Solution: Continuing with the inclusion of water at 4.67 ppm.'];
     disp(ErrorMessage1); disp(ErrorMessage2);
     
     PKData.FileName{1} = 'fid_Water';
     PKData.IncludeYN{1} = 'Y';
     PKData.MetaboliteName{1} = 'Water';
     PKData.LabelPosition{1,1} = 'H1';
     PKData.GroupCS(1,1) = 4.67;
     PKData.GroupRelativeM0(1,1) = 2;
     PKData.GroupM0Link(1,1) = 1;
     PKData.GroupLWLink(1,1) = 1;
     PKData.GroupLWLow(1,1) = 1;
     PKData.GroupLWHigh(1,1) = 100;
     PKData.GroupShiftLow(1,1) = -10;
     PKData.GroupShiftHigh(1,1) = 10;
     PKData.NumberOfGroups(1) = 1;
 end;