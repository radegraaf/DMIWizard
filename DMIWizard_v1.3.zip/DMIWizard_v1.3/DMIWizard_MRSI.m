function varargout = DMIWizard_MRSI(varargin)
% DMIWIZARD_MRSI MATLAB code for DMIWizard_MRSI.fig
%      DMIWIZARD_MRSI, by itself, creates a new DMIWIZARD_MRSI or raises the existing
%      singleton*.
%
%      H = DMIWIZARD_MRSI returns the handle to a new DMIWIZARD_MRSI or the handle to
%      the existing singleton*.
%
%      DMIWIZARD_MRSI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DMIWIZARD_MRSI.M with the given input arguments.
%
%      DMIWIZARD_MRSI('Property','Value',...) creates a new DMIWIZARD_MRSI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before DMIWizard_MRSI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to DMIWizard_MRSI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help DMIWizard_MRSI

% Last Modified by GUIDE v2.5 24-Sep-2021 10:54:38

addpath(genpath(pwd));

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @DMIWizard_MRSI_OpeningFcn, ...
                   'gui_OutputFcn',  @DMIWizard_MRSI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before DMIWizard_MRSI is made visible.
function DMIWizard_MRSI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to DMIWizard_MRSI (see VARARGIN)

% Choose default command line output for DMIWizard_MRSI
handles.output = hObject;

% Set Position/Size of Figure Based on Screen Size
set(groot,'Units','points');
ScreenSize = get(groot,'ScreenSize');
ScreenWidth = ScreenSize(3);
ScreenHeight = ScreenSize(4);

FigXPos = .2275*ScreenWidth; % .02
FigYPos = .15*ScreenHeight; % .2275
FigWidth = .37*ScreenWidth; % .18
FigHeight = .75*ScreenHeight; %.6725

% Read DMIWizard settings
handles = DMIWizard_MRSI_ReadSettings(handles);

set(hObject,'Units','points','Position',[FigXPos FigYPos FigWidth FigHeight],...
    'Color',handles.GUIBackgroundColor1);

% Initialize DMIWizard settings
DMIWizard_MRSI_InitializeSettings(handles);

% Update handles structure
guidata(hObject, handles);

Initialize_GUI(hObject,eventdata,handles);

% --- Outputs from this function are returned to the command line.
function varargout = DMIWizard_MRSI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

function Initialize_GUI(hObject,eventdata,handles)
handles.MRSIPath = handles.GUIDefaultPath;
handles.MRIPath = handles.GUIDefaultPath;
handles.SaveFIDPath = handles.GUIDefaultPath;
handles.SaveImagePath = handles.GUIDefaultPath;
handles.ConsoleType = 'DMIWizard';
SystemType_Object = findall(0,'Tag','SystemType_popupmenu');
set(SystemType_Object,'TooltipString','Vendor-specific MRSI or MRI data format.');
SystemTypeOptions = cellstr(get(SystemType_Object,'String'));

% Determine system type value
SystemTypeValue = 1;
for c1 = 1:length(SystemTypeOptions)
    if (strcmp(char(SystemTypeOptions(c1)),handles.ConsoleType) > 0)
        SystemTypeValue = c1;
    end;
end;
set(SystemType_Object,'Value',SystemTypeValue);
SystemType_popupmenu_Callback(SystemType_Object, eventdata, handles);
handles = guidata(SystemType_Object);

% Define position and size for supporting figures
set(groot,'Units','points');
ScreenSize = get(groot,'ScreenSize');
ScreenWidth = ScreenSize(3);
ScreenHeight = ScreenSize(4);

handles.Fig1XPos = 0.605*ScreenWidth;
handles.Fig1YPos = 0.545*ScreenHeight;
handles.Fig1Width = 0.3*ScreenWidth;
handles.Fig1Height = 0.2945*ScreenHeight;

handles.Fig2XPos = 0.605*ScreenWidth;
handles.Fig2YPos = 0.15*ScreenHeight;
handles.Fig2Width = 0.3*ScreenWidth;
handles.Fig2Height = 0.298*ScreenHeight;

% DMI/MRSI-related parametets
handles.np1 = 19; handles.np1previous = handles.np1;
PhaseIncrements1_Object = findall(0,'Tag','PhaseIncrements1_edit');
set(PhaseIncrements1_Object,'TooltipString','MRSI matrix size, dimension 1');

handles.np2 = 29; handles.np2previous = handles.np2;
PhaseIncrements2_Object = findall(0,'Tag','PhaseIncrements2_edit');
set(PhaseIncrements2_Object,'TooltipString','MRSI matrix size, dimension 2');

handles.np3 = 13; handles.np3previous = handles.np3;
PhaseIncrements3_Object = findall(0,'Tag','PhaseIncrements3_edit');
set(PhaseIncrements3_Object,'TooltipString','MRSI matrix size, dimension 3');

handles.FOV1 = 19;
FOV1_Object = findall(0,'Tag','FOV1_edit');
set(FOV1_Object,'TooltipString','MRSI FOV (mm), dimension 1');

handles.FOV2 = 28;
FOV2_Object = findall(0,'Tag','FOV2_edit');
set(FOV2_Object,'TooltipString','MRSI FOV (mm), dimension 2');

handles.FOV3 = 13;
FOV3_Object = findall(0,'Tag','FOV3_edit');
set(FOV3_Object,'TooltipString','MRSI FOV (mm), dimension 3');

% Parameters defining data structure
handles.KSpaceSamplingScheme = 2;
KSpaceSamplingScheme_Object = findall(0,'Tag','KSpaceSampling_popupmenu');
set(KSpaceSamplingScheme_Object,'TooltipString','K-space data structure.');

handles.naloop = 1;

handles.AcquisitionOrder = [1 2 3];
DataAcqOrder_Object = findall(0,'Tag','DataAcqOrder_popupmenu');
set(DataAcqOrder_Object,'TooltipString','MRSI acquistion order (fast to slow) - requires data reload and FFT.');

handles.XFlip = 0;
XFlip_Object = findall(0,'Tag','XFlip_checkbox');
set(XFlip_Object,'TooltipString','MRSI data flip in X direction - requires data reload and FFT.');

handles.YFlip = 0;
YFlip_Object = findall(0,'Tag','YFlip_checkbox');
set(YFlip_Object,'TooltipString','MRSI data flip in Y direction - requires data reload and FFT.');

handles.ZFlip = 0;
ZFlip_Object = findall(0,'Tag','ZFlip_checkbox');
set(ZFlip_Object,'TooltipString','MRSI data flip in Z direction - requires data reload and FFT.');

handles.KSpaceDataFlip = [handles.XFlip handles.YFlip handles.ZFlip];
handles.MRSIGridShift = [0 0 0];

% MRI-related parameters
handles.np1mri = 101;
MRIDimension1_Object = findall(0,'Tag','MRIDimension1_edit');
set(MRIDimension1_Object,'TooltipString','MRI matrix size, dimension 1');

handles.np2mri = 151;
MRIDimension2_Object = findall(0,'Tag','MRIDimension2_edit');
set(MRIDimension2_Object,'TooltipString','MRI matrix size, dimension 2');

handles.np3mri = 71;
MRIDimension3_Object = findall(0,'Tag','MRIDimension3_edit');
set(MRIDimension3_Object,'TooltipString','MRI matrix size, dimension 3');

handles.np1ext = 101; handles.np1extprevious = handles.np1ext;
MRIExtDimension1_Object = findall(0,'Tag','MRIExtDimension1_edit');
set(MRIExtDimension1_Object,'TooltipString','Extended (zero-filled) MRI matrix size, dimension 1');

handles.np2ext = 151; handles.np2extprevious = handles.np2ext;
MRIExtDimension2_Object = findall(0,'Tag','MRIExtDimension2_edit');
set(MRIExtDimension2_Object,'TooltipString','Extended (zero-filled) MRI matrix size, dimension 2');

handles.np3ext = 71; handles.np3extprevious = handles.np3ext;
MRIExtDimension3_Object = findall(0,'Tag','MRIExtDimension3_edit');
set(MRIExtDimension3_Object,'TooltipString','Extended (zero-filled) MRI matrix size, dimension 3');

% Spectral parameters
handles.sw = 5;
SpectralBandwidth_Object = findall(0,'Tag','SpectralBandwidth_edit');
set(SpectralBandwidth_Object,'TooltipString','Spectral width (kHz)');

handles.emf = 1;
ExponentialMultiply_Object = findall(0,'Tag','ExponentialMultiply_edit');
set(ExponentialMultiply_Object,'TooltipString','Exponential line broadening (Hz)');

handles.npzf = 2048;
SpectralPoints_Object = findall(0,'Tag','ZerofillingPoints_edit');
set(SpectralPoints_Object,'TooltipString','Spectral points following FFT');

handles.nplp = 4;
LinearPredicDataPoints_Object = findall(0,'Tag','LinearPredicDataPoints_edit');
set(LinearPredicDataPoints_Object,'TooltipString','Number of backward prediction time domain points.');

handles.nplp2 = 0;
LinearPredicDataPoints2_Object = findall(0,'Tag','LinearPredicDataPoints2_edit');
set(LinearPredicDataPoints2_Object,'TooltipString','Number of forward prediction time domain points.');

LP_Object = findall(0,'Tag','LinearPrediction_pushbutton');
set(LP_Object,'TooltipString','Linear prediction to calculate missing time domain points (two clicks).');

handles.ph0 = 0;
ZeroOrderPhase_Object = findall(0,'Tag','ConstantPhase_edit');
set(ZeroOrderPhase_Object,'TooltipString','Zero order phase correction (deg)');

handles.ph1 = 0;
FirstOrderPhase_Object = findall(0,'Tag','LinearPhase_edit');
set(FirstOrderPhase_Object,'TooltipString','First order phase correction (deg/kHz)');

AP_Object = findall(0,'Tag','AutoPhasing_pushbutton');
set(AP_Object,'TooltipString','Automatic phase correction of spectral region selected with two clicks.');

handles.av = 0;
AbsoluteValue_Object = findall(0,'Tag','Magnitude_checkbox');
set(AbsoluteValue_Object,'TooltipString','Display spectrum in absolute value.');

handles.RxCombinationsFromFile = 0;
handles.MaxLSD = 3;     % Maximum lineshape distortion (used during spectral fitting)

% Amplitude threshold
handles.intth = 15;
Threshold_Object = findall(0,'Tag','Threshold_edit');
set(Threshold_Object,'TooltipString','Peak height threshold (%).');

% Mapping parameters
handles.Interpolation = 0;
Interpolation_Object = findall(0,'Tag','Interpolation_checkbox');
set(Interpolation_Object,'TooltipString','Additional interpolated M0 maps are created.');
set(Interpolation_Object,'Visible','Off');

handles.KernelWidth = 3;
KernelWidth_Object = findall(0,'Tag','KernelWidth_edit');
set(KernelWidth_Object,'TooltipString','Gaussian kernel width (pixels) for interpolation.');
set(KernelWidth_Object,'Visible','Off');

handles.Transparency = 0.75;
Transparency_Object = findall(0,'Tag','Transparency_edit');
set(Transparency_Object,'TooltipString','Transparency of colormap overlay, [0 = 100% transparent, 1 = not transparent].');
set(Transparency_Object,'Visible','Off');
set(findall(0,'Tag','Text_Transparency'),'Visible','Off');

handles.MRIBackground = 0;
MRIbackground_Object = findall(0,'Tag','MRIbackground_checkbox');
set(MRIbackground_Object,'TooltipString','Visualize M0 map on an MRI background.');
set(MRIbackground_Object,'Visible','Off');

ROISelection_Object = findall(0,'Tag','ROI_pushbutton');
set(ROISelection_Object,'Visible','Off');

handles.SNRDisplay = 0;
SNR_Object = findall(0,'Tag','SNR_checkbox');
set(SNR_Object,'TooltipString','Parameter maps will include peak height/integral SNR maps.');

handles.LSDisplay = 0;
LineShift_Object = findall(0,'Tag','LineShift_checkbox');
set(LineShift_Object,'TooltipString','Parameter maps will include line shift (Hz) maps.');

handles.LWDisplay = 0;
LineWidth_Object = findall(0,'Tag','LineWidth_checkbox');
set(LineWidth_Object,'TooltipString','Parameter maps will include line width (Hz) maps.');

handles.Orientation = 1;
Orientation_Object = findall(0,'Tag','MRSIType_popupmenu');
set(Orientation_Object,'TooltipString','Slice display orientation.');

ParameterMap_Object = findall(0,'Tag','ParameterMap_pushbutton');
set(ParameterMap_Object,'TooltipString','2D parameter mapping of a spectral region indicated with two (or four) clicks.');

MRSI_Object = findall(0,'Tag','MRSI_pushbutton');
set(MRSI_Object,'TooltipString','2D MRSI spectral display using current spectral zoom.');

handles.MapID = 'water';
MapID_Object = findall(0,'Tag','MapID_edit');
set(MapID_Object,'TooltipString','Parameter map name used for identification in advanced mapping.');

handles.BC = 0;
BC_Object = findall(0,'Tag','BaselineCorrection_checkbox');
set(BC_Object,'TooltipString','Enable baseline correction with first-order polynomial.');

% Display parameters
handles.sp1 = 1; handles.sp1extra = 0;
SpatialPosition1_Object = findall(0,'Tag','SpatialPosition1_edit');
set(SpatialPosition1_Object,'TooltipString','MRSI voxel position, dimension 1.');
handles.sp1PreviousValue = 1;

handles.sp2 = 8; handles.sp2extra = 0;
SpatialPosition2_Object = findall(0,'Tag','SpatialPosition2_edit');
set(SpatialPosition2_Object,'TooltipString','MRSI voxel position, dimension 2.');
handles.sp2PreviousValue = 8;

handles.sp3 = 1; handles.sp3extra = 0;
SpatialPosition3_Object = findall(0,'Tag','SpatialPosition3_edit');
set(SpatialPosition3_Object,'TooltipString','MRSI voxel position, dimension 3.');
handles.sp3PreviousValue = 1;

handles.sp4 = 1;
MRISlice_Object = findall(0,'Tag','MRISlice_edit');
set(MRISlice_Object,'TooltipString','MRI slice number.');
handles.sp4PreviousValue = 1;

handles.MRIHigh = 200;
MRIHigh_Object = findall(0,'Tag','MRIHigh_edit');
set(MRIHigh_Object,'TooltipString','Maximum MRI intensity (linear scale).');
handles.MRIHighPreviousValue = 200;

handles.MRIScale = 3;
MRIScale_Object = findall(0,'Tag','MRIScaling_edit');
set(MRIScale_Object,'TooltipString','Maximum MRI intensity (10-base power scale).');
handles.MRIScalePreviousValue = 3;

handles.ZxLow = -1;
LowFrequencyBoundary_Object = findall(0,'Tag','FrequencyLow_edit');
set(LowFrequencyBoundary_Object,'TooltipString','Lower spectral zoom frequency (kHz).');
handles.ZxLowPreviousValue = -1;

handles.ZxHigh = 1;
HighFrequencyBoundary_Object = findall(0,'Tag','FrequencyHigh_edit');
set(HighFrequencyBoundary_Object,'TooltipString','Higher spectral zoom frequency (kHz).');
handles.ZxHighPreviousValue = 1;

handles.ZyLow = -200;
LowIntensityBoundary_Object = findall(0,'Tag','SignalLow_edit');
set(LowIntensityBoundary_Object,'TooltipString','Lower spectral zoom intensity.');
handles.ZyLowPreviousValue = -200;

handles.ZyHigh = 2000;
HighIntensityBoundary_Object = findall(0,'Tag','SignalHigh_edit');
set(HighIntensityBoundary_Object,'TooltipString','Higher spectral zoom intensity.');
handles.ZyHighPreviousValue = 2000;

handles.ZyScale = 4;
IntensityScalingFactor_Object = findall(0,'Tag','SignalScalingFactor_edit');
set(IntensityScalingFactor_Object,'TooltipString','Ten-fold intensity scaling.');
handles.ZyScalePreviousValue = 4;

ZoomIn_Object = findall(0,'Tag','ZoomIn_pushbutton');
set(ZoomIn_Object,'TooltipString','Zoom in frequeny axis with two clicks.');

ZoomOut_Object = findall(0,'Tag','ZoomOut_pushbutton');
set(ZoomOut_Object,'TooltipString','Maximum zoom out of frequeny axis.');

handles.NumOfCommands = 1;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function MRSIPath_edit_Callback(hObject, eventdata, handles)
handles.MRSIPath = get(hObject,'String');

% Display image
if (isfield(handles,'MRI') == 1)
    DMIWizard_MRSI_DisplayImage(handles.MRI,handles);
end;

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function MRSIPath_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function SelectMRSIPath_pushbutton_Callback(hObject, eventdata, handles)
% Prepare for when Cancel button is pressed
MRSIPathCancel = handles.MRSIPath;

% Get new file and path names
[filename, pathname] = uigetfile('*.*','Select MRSI file',handles.MRSIPath);

% Action performed when Cancel button is pressed
if isequal(filename,0) || isequal(pathname,0)
    handles.MRSIPath = MRSIPathCancel;
else
    handles.MRSIPath = [pathname filename];
    handles.SaveFIDPath = pathname;
end

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

% Set the edit box string to the new input filename
set(handles.MRSIPath_edit,'String',handles.MRSIPath);

function LoadDMI_pushbutton_Callback(hObject, eventdata, handles)

% Clear Matlab command window
clc;
handles = DMIWizard_MRSI_LoadDataFile(handles);

if ((handles.np1 ~= handles.np1previous) || (handles.np2 ~= handles.np2previous) || ...
        (handles.np3 ~= handles.np3previous))
    % DMI matrix size is different from a previously loaded DMI dataset.
    % Close the Advanced Mapping window (if open) to prevent potential 
    % matrix size discrepancies.
    
    % 1. Set Advanced Mapping checkbox to 'off'
    AM_Object = findall(0,'Tag','AdvancedMapping_CheckBox');
    set(AM_Object,'Value',0);

    % 2. Close open window associated with Advanced Mapping
    hObject2 = findall(0,'Name','DMIWizard_Mapping');
    if (isempty(hObject2) < 1)
        delete(hObject2);
        
        OperationTime = DMIWizard_MRSI_CalculateTime;
        TextOutput1 = [OperationTime ' - Warning: DMI matrix size has changed compared to previously loaded DMI dataset.'];
        TextOutput2 = [OperationTime ' - Warning: Closing Advanced Mapping window to avoid potential matrix size discrepancies.'];
        disp(' '); disp(TextOutput1); disp(TextOutput2);
    end; 
 
    % 3. Hide advanced mapping parameters in main MRSI window visible
    set(findall(0,'Tag','Interpolation_checkbox'),'Visible','Off');
    set(findall(0,'Tag','KernelWidth_edit'),'Visible','Off');

    set(findall(0,'Tag','Transparency_edit'),'Visible','Off');
    set(findall(0,'Tag','Text_Transparency'),'Visible','Off');

    set(findall(0,'Tag','MRIbackground_checkbox'),'Visible','Off');
    set(findall(0,'Tag','ROI_pushbutton'),'Visible','Off');

    handles.np1previous = handles.np1;
    handles.np2previous = handles.np2;
    handles.np3previous = handles.np3;
end;

% Update GUI elements
PhaseIncrements1_Object = findall(0,'Tag','PhaseIncrements1_edit');
set(PhaseIncrements1_Object,'String',handles.np1);

PhaseIncrements2_Object = findall(0,'Tag','PhaseIncrements2_edit');
set(PhaseIncrements2_Object,'String',handles.np2);

PhaseIncrements3_Object = findall(0,'Tag','PhaseIncrements3_edit');
set(PhaseIncrements3_Object,'String',handles.np3);

FOV1_Object = findall(0,'Tag','FOV1_edit');
set(FOV1_Object,'String',handles.FOV1);

FOV2_Object = findall(0,'Tag','FOV2_edit');
set(FOV2_Object,'String',handles.FOV2);

FOV3_Object = findall(0,'Tag','FOV3_edit');
set(FOV3_Object,'String',handles.FOV3);

SpectralBandwidth_Object = findall(0,'Tag','SpectralBandwidth_edit');
set(SpectralBandwidth_Object,'String',handles.sw);

KSpaceSamplingScheme_Object = findall(0,'Tag','KSpaceSampling_popupmenu');
set(KSpaceSamplingScheme_Object,'Value',handles.KSpaceSamplingScheme);

% Set extended MRI matrix size to an integer multiple of the DMI matrix size.
handles.np1ext = ceil(handles.np1mri/handles.np1)*handles.np1;
MRIExtDimension1_Object = findall(0,'Tag','MRIExtDimension1_edit');
set(MRIExtDimension1_Object, 'String', handles.np1ext);

handles.np2ext = ceil(handles.np2mri/handles.np2)*handles.np2;
MRIExtDimension2_Object = findall(0,'Tag','MRIExtDimension2_edit');
set(MRIExtDimension2_Object, 'String', handles.np2ext);

handles.np3ext = ceil(handles.np3mri/handles.np3)*handles.np3;
MRIExtDimension3_Object = findall(0,'Tag','MRIExtDimension3_edit');
set(MRIExtDimension3_Object, 'String', handles.np3ext);

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function MRIPath_edit_Callback(hObject, eventdata, handles)
handles.MRIPath = get(hObject,'String');

% Display image
if (isfield(handles,'MRI') == 1)
    DMIWizard_MRSI_DisplayImage(handles.MRI,handles);
end;

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function MRIPath_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function SelectMRIPath_pushbutton_Callback(hObject, eventdata, handles)
% Prepare for when Cancel button is pressed
MRIPathCancel = handles.MRIPath;

% Get new file and path names
[filename, pathname] = uigetfile('*.*','Select MRI file',handles.MRIPath);

% Action performed when Cancel button is pressed
if isequal(filename,0) || isequal(pathname,0)
    handles.MRIPath = MRIPathCancel;
else
    handles.MRIPath = [pathname filename];
end

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

% Set the edit box string to the new input filename
set(handles.MRIPath_edit,'String',handles.MRIPath);

function LoadMRI_pushbutton_Callback(hObject, eventdata, handles)

handles = DMIWizard_MRSI_LoadMRIFile(handles);
    
fh1 = figure(1);
set(fh1,'Units','points','Name','K-space domain',...
    'Position',[handles.Fig1XPos handles.Fig1YPos handles.Fig1Width handles.Fig1Height])

% Display FID
imshow(abs(handles.FIDMRI(:,:,round(handles.np3mri/2))),[],'InitialMagnification','fit');

% Set extended MRI matrix size to an integer multiple of the DMI matrix size.
handles.np1ext = ceil(handles.np1mri/handles.np1)*handles.np1;
MRIExtDimension1_Object = findall(0,'Tag','MRIExtDimension1_edit');
set(MRIExtDimension1_Object, 'String', handles.np1ext);

handles.np2ext = ceil(handles.np2mri/handles.np2)*handles.np2;
MRIExtDimension2_Object = findall(0,'Tag','MRIExtDimension2_edit');
set(MRIExtDimension2_Object, 'String', handles.np2ext);

handles.np3ext = ceil(handles.np3mri/handles.np3)*handles.np3;
MRIExtDimension3_Object = findall(0,'Tag','MRIExtDimension3_edit');
set(MRIExtDimension3_Object, 'String', handles.np3ext);

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function SaveFIDPath_edit_Callback(hObject, eventdata, handles)
handles.SaveFIDPath = get(hObject,'String');

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function SaveFIDPath_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function SelectFIDSavePath_pushbutton_Callback(hObject, eventdata, handles)
% Prepare for when Cancel button is pressed
FIDPathCancel = handles.SaveFIDPath;

% Get new file and path names
[filename, pathname] = uiputfile('*.*','Select FID Save Location',handles.SaveFIDPath);

% Action performed when Cancel button is pressed
if isequal(filename,0) || isequal(pathname,0)
    handles.SaveFIDPath = FIDPathCancel;
else
    handles.SaveFIDPath = [pathname filename];
end

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

% Set the edit box string to the new input filename
set(handles.SaveFIDPath_edit,'String',handles.SaveFIDPath);

function SaveFID_pushbutton_Callback(hObject, eventdata, handles)
% Saves a single-pixel FID to disk 
[SavePathDir,~,~] = fileparts(handles.SaveFIDPath);
if isdir(SavePathDir) > 0 && strcmp(handles.SaveFIDPath,'C:\') < 1
    [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
    TextOutput1 = [OperationTime ' - Saving FID from location [' num2str(handles.sp1) ', ' num2str(handles.sp2) ', ' num2str(handles.sp3) '] to: '];
    disp(' '); disp(TextOutput1);

    sp1extra = round(10*(handles.sp1 - floor(handles.sp1)));
    sp2extra = round(10*(handles.sp2 - floor(handles.sp2)));
    sp3extra = round(10*(handles.sp3 - floor(handles.sp3)));
    if (handles.sp1 < 10)
        if (handles.sp2 < 10)
            if (handles.sp3 < 10)
                handles.SaveFIDPathComplete = [handles.SaveFIDPath '_0' num2str(floor(handles.sp1)) ...
                    'd' num2str(sp1extra) '_0' num2str(floor(handles.sp2)) ...
                    'd' num2str(sp2extra) '_0' num2str(floor(handles.sp3)) ...
                    'd' num2str(sp3extra)];
            else
                handles.SaveFIDPathComplete = [handles.SaveFIDPath '_0' num2str(floor(handles.sp1)) ...
                    'd' num2str(sp1extra) '_0' num2str(floor(handles.sp2)) ...
                    'd' num2str(sp2extra) '_' num2str(floor(handles.sp3)) ...
                    'd' num2str(sp3extra)];
            end;
        else
            if (handles.sp3 < 10)
                handles.SaveFIDPathComplete = [handles.SaveFIDPath '_0' num2str(floor(handles.sp1)) ...
                    'd' num2str(sp1extra) '_' num2str(floor(handles.sp2)) ...
                    'd' num2str(sp2extra) '_0' num2str(floor(handles.sp3)) ...
                    'd' num2str(sp3extra)];
            else
                handles.SaveFIDPathComplete = [handles.SaveFIDPath '_0' num2str(floor(handles.sp1)) ...
                    'd' num2str(sp1extra) '_' num2str(floor(handles.sp2)) ...
                    'd' num2str(sp2extra) '_' num2str(floor(handles.sp3)) ...
                    'd' num2str(sp3extra)];
            end;
        end;
    else
        if (handles.sp2 < 10)
            if (handles.sp3 < 10)
                handles.SaveFIDPathComplete = [handles.SaveFIDPath '_' num2str(floor(handles.sp1)) ...
                    'd' num2str(sp1extra) '_0' num2str(floor(handles.sp2)) ...
                    'd' num2str(sp2extra) '_0' num2str(floor(handles.sp3)) ...
                    'd' num2str(sp3extra)];
            else
                handles.SaveFIDPathComplete = [handles.SaveFIDPath '_' num2str(floor(handles.sp1)) ...
                    'd' num2str(sp1extra) '_0' num2str(floor(handles.sp2)) ...
                    'd' num2str(sp2extra) '_' num2str(floor(handles.sp3)) ...
                    'd' num2str(sp3extra)];
            end;
        else
            if (handles.sp3 < 10)
                handles.SaveFIDPathComplete = [handles.SaveFIDPath '_' num2str(floor(handles.sp1)) ...
                    'd' num2str(sp1extra) '_' num2str(floor(handles.sp2)) ...
                    'd' num2str(sp2extra) '_0' num2str(floor(handles.sp3)) ...
                    'd' num2str(sp3extra)];
            else
                handles.SaveFIDPathComplete = [handles.SaveFIDPath '_' num2str(floor(handles.sp1)) ...
                    'd' num2str(sp1extra) '_' num2str(floor(handles.sp2)) ...
                    'd' num2str(sp2extra) '_' num2str(floor(handles.sp3)) ...
                    'd' num2str(sp3extra)];
            end;
        end;
    end;

    handles.FIDselect = handles.FID3D(:,round(handles.sp1),round(handles.sp2),round(handles.sp3));
    fileID = fopen(handles.SaveFIDPathComplete,'w+');
    fprintf(fileID,'%9.5f		%9.5f\n',[reshape(real(handles.FIDselect),1,[]); reshape(imag(handles.FIDselect),1,[])]);
    fclose(fileID);

    real(handles.FIDselect(1:4))


    TextOutput2 = [OperationTime ' - ' handles.SaveFIDPathComplete];
    disp(TextOutput2);

    % Save parameter file
    handles.SaveFIDPathPar = [handles.SaveFIDPathComplete '.par'];

    handles.carfreq = 100;  % Place holder value
    output1A = ['sw      = ' num2str(handles.sw) '\n'];
    output1B = ['carfreq = ' num2str(handles.carfreq) '\n']; 

    fileID2 = fopen(handles.SaveFIDPathPar,'w');
    fprintf(fileID2,output1A); fprintf(fileID2,output1B); 
    fclose(fileID2);

    % Write information to processing history file
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+',TextOutput2);
else
    [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
    ErrorOutput1 = [OperationTime ' - Error   : Invalid FID save path.'];
    ErrorOutput2 = [OperationTime ' - Error   : FID file not saved.'];
    ErrorOutput3 = [OperationTime ' - Solution: Select valid FID save path.'];
    disp(' '); disp(ErrorOutput1); disp(ErrorOutput2); disp(ErrorOutput3);
end

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function SaveImagePath_edit_Callback(hObject, eventdata, handles)
handles.SaveImagePath = get(hObject,'String');

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function SaveImagePath_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function SelectImageSavePath_pushbutton_Callback(hObject, eventdata, handles)
% Prepare for when Cancel button is pressed
SaveImagePathCancel = handles.SaveImagePath;

% Get new file and path names
[filename, pathname] = uigetfile('*.*','Select Image Save Location',handles.SaveImagePath);

% Action performed when Cancel button is pressed
if isequal(filename,0) || isequal(pathname,0)
    handles.SaveImagePath = SaveImagePathCancel;
else
    handles.SaveImagePath = [pathname filename];
end

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

% Set the edit box string to the new input filename
set(handles.SaveImagePath_edit,'String',handles.SaveImagePath);

function SaveImage_pushbutton_Callback(hObject, eventdata, handles)
[SavePathDir,~,~] = fileparts(handles.SaveImagePath);
if isdir(SavePathDir) > 0 && strcmp(handles.SaveImagePath,'C:\') < 1
    fileID = fopen(handles.SaveImagePath,'w+');
    fprintf(fileID,'%9.5f\n',reshape(abs(handles.MRI),1,handles.np1mri*handles.np2mri*handles.np3mri));
    fclose(fileID);

    dd = ['3D MRI saved as ' handles.SaveImagePath];
    disp(' '); disp(dd);
else
    [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
    ErrorOutput1 = [OperationTime ' - Error   : Invalid image save path.'];
    ErrorOutput2 = [OperationTime ' - Error   : Image file not saved.'];
    ErrorOutput3 = [OperationTime ' - Solution: Select valid image save path.'];
    disp(' '); disp(ErrorOutput1); disp(ErrorOutput2); disp(ErrorOutput3);
end

function KSpaceSampling_popupmenu_Callback(hObject, eventdata, handles)
contents = cellstr(get(hObject,'String'));
KSpaceSamplingScheme = contents{get(hObject,'Value')};

switch KSpaceSamplingScheme
    case 'Cubic-linear'
        handles.KSpaceSamplingScheme = 1;
    case 'Spherical-linear'
        handles.KSpaceSamplingScheme = 2;
end

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function KSpaceSampling_popupmenu_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function PhaseIncrements1_edit_Callback(hObject, eventdata, handles)
handles.np1 = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.np1) > 0) || (isinf(handles.np1) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for DMI matrix size, element 1.'];
    ErrorMessage2 = ['Error: DMI matrix size, element 1 set to valid default value (19).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.np1 = 19;
    set(hObject,'String',handles.np1);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function PhaseIncrements1_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function PhaseIncrements2_edit_Callback(hObject, eventdata, handles)
handles.np2 = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.np2) > 0) || (isinf(handles.np2) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for DMI matrix size, element 2.'];
    ErrorMessage2 = ['Error: DMI matrix size, element 2 set to valid default value (29).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.np2 = 29;
    set(hObject,'String',handles.np2);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function PhaseIncrements2_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function PhaseIncrements3_edit_Callback(hObject, eventdata, handles)
handles.np3 = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.np3) > 0) || (isinf(handles.np3) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for DMI matrix size, element 3.'];
    ErrorMessage2 = ['Error: DMI matrix size, element 3 set to valid default value (13).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.np3 = 13;
    set(hObject,'String',handles.np3);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function PhaseIncrements3_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function SystemType_popupmenu_Callback(hObject, eventdata, handles)
contents = cellstr(get(hObject,'String'));
handles.ConsoleType = contents{get(hObject,'Value')};

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function SystemType_popupmenu_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function AveragingLoop_popupmenu_Callback(hObject, eventdata, handles)
contents = cellstr(get(hObject,'String'));
NAloopString = (contents{get(hObject,'Value')});

for c1 = 1:1:length(contents)
    if strcmp(cellstr(contents(c1)),NAloopString) == 1
        handles.naloop = c1;
    end
end

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function AveragingLoop_popupmenu_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function SpectralBandwidth_edit_Callback(hObject, eventdata, handles)
handles.sw = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.sw) > 0) || (isinf(handles.sw) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for spectral bandwidth.'];
    ErrorMessage2 = ['Error: Spectral bandwidth set to valid default value (5.0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.sw = 5.0;
    set(hObject,'String',handles.sw);
end;

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function SpectralBandwidth_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function ExponentialMultiply_edit_Callback(hObject, eventdata, handles)
handles.emf = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.emf) > 0) || (isinf(handles.emf) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for exponential multiplication factor.'];
    ErrorMessage2 = ['Error: Exponential multiplication factor set to valid default value (1.0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.emf = 1.0;
    set(hObject,'String',handles.emf);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject,handles);

function ExponentialMultiply_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function ZerofillingPoints_edit_Callback(hObject, eventdata, handles)
handles.npzf = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.npzf) > 0) || (isinf(handles.npzf) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for spectral (or zerofilling) points.'];
    ErrorMessage2 = ['Error: Spectral/zerofilling points set to valid default value (2048).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.npzf = 2048;
    set(hObject,'String',handles.npzf);
end;

% Perform FFT to update spectral points
handles = DMIWizard_MRSI_FFT(handles);

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
else
    ErrorMessage1 = ['Error   : FID for 3D MRSI/DMI does not exist.'];
    ErrorMessage2 = ['Solution: Select and load a 3D MRSI FID file before attempting FFT.'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject,handles);

function ZerofillingPoints_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function LinearPrediction_pushbutton_Callback(hObject, eventdata, handles)
%**************************************************************************
% Program to perform linear back prediction for missing points
% due to delayed acquisition (primary due to phase-encoding duration).
%**************************************************************************

figure(2);

rfreq = ginput(2);
rfreq2 = [rfreq(1,1) rfreq(2,1)];

freqmin = min(rfreq2);
freqmax = max(rfreq2);

% Linear prediction to restore missing points and phase correction
count = 1;
nlps = length(find(handles.InclusionMap > 0));

[OperationTime,~] = DMIWizard_MRSI_CalculateTime;
TextOutput1 = [OperationTime ' - Start linear prediction with ' num2str(handles.nplp) ' data points.'];
disp(' '); disp(TextOutput1);

% Write information to processing history file
DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);

if (handles.nplp2 > 0)
    % FID following forward prediction will be longer
    handles.FID3DLP = zeros(handles.nplp+handles.np+handles.nplp2,handles.np1,handles.np2,handles.np3);
else
    % FID following backward prediction will have identical size
    handles.FID3DLP = 0.0*handles.FID3D;
end;

for c1 = 1:handles.np1
    for c2 = 1:handles.np2
        for c3 = 1:handles.np3
            
            if ((handles.nplp > 0) || (handles.nplp2 > 0))
                % Linear prediction
                if (handles.InclusionMap(c1,c2,c3) > 0)

                    % HSVD
                    [amp,frq,decay,phs] = DMIWizard_MRSI_HSVD(handles.FID3D(:,c1,c2,c3),freqmin,freqmax,handles);
                    
                    % Linear prediction
                    handles.FID3DLP(:,c1,c2,c3) = DMIWizard_MRSI_LinearPredictionFunction(handles.FID3D(:,c1,c2,c3),amp,frq,decay,phs,handles);
                    
                    TextOutput = ['Linear prediction completed for spectrum ' num2str(count) ' of ' num2str(nlps) ' at ( ' ...
                        num2str(c1) ', ' num2str(c2) ', ' num2str(c3) ')'];
                    disp(TextOutput);
                    count = count + 1;
                end;

                % Phase correction
                if (handles.InclusionMap(c1,c2,c3) > 0)
                    if (abs(handles.FID3D(1,c1,c2,c3)) > 0)
                        if (abs(handles.FID3DLP(1,c1,c2,c3)) > 0)
                            handles.FID3DLP(:,c1,c2,c3) = handles.FID3DLP(:,c1,c2,c3)*(abs(handles.FID3DLP(1,c1,c2,c3))/handles.FID3DLP(1,c1,c2,c3));
                        end;
                    else
                        [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
                        TextOutput1 = [OperationTime ' - Warning: Data at ( ' num2str(c1) ', ' num2str(c2) ', ' num2str(c3) ...
                            ') not phase-corrected due to zero initial amplitude.'];
                        disp(TextOutput1);
                        
                        % Write information to processing history file
                        DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
                    end;
                end;
            else
                % No linear prediction
                handles.FID3DLP = handles.FID3D;
            end;
        end;
    end;
end;
% FID size (number of points) can change with forward prediction
handles.np = size(handles.FID3DLP,1);

aa1=find(isnan(handles.FID)>0); length(aa1)
aa2=find(isinf(handles.FID)>0); length(aa2)
% Recalculate and replace FID signal
handles.FID = 0.0*handles.FID3DLP;
for c1 = 1:handles.np;
    handles.FID(c1,:,:,:) = ifftshift(ifftn(ifftshift(squeeze(handles.FID3DLP(c1,:,:,:)))));
end;
handles.FID = reshape(handles.FID,handles.np,handles.nrec,handles.np1,handles.np2,handles.np3);

bb1=find(isnan(handles.FID)>0); length(bb1)
bb2=find(isinf(handles.FID)>0); length(bb2)

[OperationTime,~] = DMIWizard_MRSI_CalculateTime;
TextOutput2 = [OperationTime ' - Linear prediction completed for ' num2str(count-1) ' MRSI voxels.'];
disp(TextOutput2);

% Save linear prediction phased  FID to file
FID4file2(1:2:2*handles.np,:,:,:) = real(handles.FID);
FID4file2(2:2:2*handles.np,:,:,:) = imag(handles.FID);

% 1. Write FID data
if ismac
    % Mac plaform
    coor = find(handles.MRSIPath == '/');
elseif isunix
    % Linux plaform
    coor = find(handles.MRSIPath == '/');
elseif ispc
    % Windows platform
    coor = find(handles.MRSIPath == '\');
end
MRSIPathDir = handles.MRSIPath(1:max(coor));

[~,OperationDate] = DMIWizard_MRSI_CalculateTime;
file1 = [MRSIPathDir 'fid_' OperationDate '.lpp'];
fileID1 = fopen(file1,'w+');
fwrite(fileID1, reshape(FID4file2,1,[]), 'long');
fclose(fileID1);

% 2. Write parameters
output1A = ['FOV1 = ' num2str(handles.FOV1) '\n']; 
output1B = ['FOV2 = ' num2str(handles.FOV2) '\n'];
output1C = ['FOV3 = ' num2str(handles.FOV3) '\n'];

output2A = ['np1  = ' num2str(handles.np1) '\n']; 
output2B = ['np2  = ' num2str(handles.np2) '\n'];
output2C = ['np3  = ' num2str(handles.np3) '\n'];

output3A = ['sw   = ' num2str(handles.sw) '\n'];
output3B = ['np   = ' num2str(handles.np) '\n']; 
output3C = ['npb  = ' num2str(handles.npb) '\n'];

output4A = ['nav  = ' num2str(handles.nav) '\n'];
output4B = ['nrec = ' num2str(handles.nrec) '\n'];
output4C = ['nu0  = ' num2str(handles.nu0) '\n'];

file2 = [MRSIPathDir 'fid_' OperationDate '.par'];
fileID2 = fopen(file2,'w');
fprintf(fileID2,output1A); fprintf(fileID2,output1B); fprintf(fileID2,output1C);
fprintf(fileID2,output2A); fprintf(fileID2,output2B); fprintf(fileID2,output2C);
fprintf(fileID2,output3A); fprintf(fileID2,output3B); fprintf(fileID2,output3C);
fprintf(fileID2,output4A); fprintf(fileID2,output4B); fprintf(fileID2,output4C);
fclose(fileID2);

[OperationTime,~] = DMIWizard_MRSI_CalculateTime;
TextOutput3 = [OperationTime ' - Linear-prediction corrected FID written to ' file1];
TextOutput4 = [OperationTime ' - Linear-prediction corrected FID parameters written to ' file2];
disp(' ' ); disp(TextOutput3); disp(TextOutput4);

% Perform spectral 1D FFT
handles.spec3D = zeros(handles.npzf,handles.np1,handles.np2,handles.np3);
handles.FID3D = handles.FID3DLP;
for c1 = 1:handles.np1;
    for c2 = 1:handles.np2;
        for c3 = 1:handles.np3;
            FIDapodized = DMIWizard_MRSI_Apodization(squeeze(handles.FID3D(:,c1,c2,c3)),handles);
            handles.spec3D(:,c1,c2,c3) = fftshift(fft(FIDapodized,handles.npzf));
        end;
    end;
end;

% Display spectrum
handles = DMIWizard_MRSI_DisplaySpectrum(handles);

% Write information to processing history file
DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput2);
DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput3);
DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+',TextOutput4);

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject,handles);

function LinearPredicDataPoints_edit_Callback(hObject, eventdata, handles)
handles.nplp = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.nplp) > 0) || (isinf(handles.nplp) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for backward prediction data points.'];
    ErrorMessage2 = ['Error: Backward prediction data points set to valid default value (4).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.nplp = 4;
    set(hObject,'String',handles.nplp);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject,handles);

function LinearPredicDataPoints_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function LinearPredicDataPoints2_edit_Callback(hObject, eventdata, handles)
handles.nplp2 = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.nplp2) > 0) || (isinf(handles.nplp2) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for forward prediction data points.'];
    ErrorMessage2 = ['Error: Forward prediction data points set to valid default value (0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.nplp2 = 0;
    set(hObject,'String',handles.nplp);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject,handles);

function LinearPredicDataPoints2_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%---------------------------------------------------------------
% Phasing-related parameters and functions
%---------------------------------------------------------------
function ConstantPhase_edit_Callback(hObject, eventdata, handles)
handles.ph0 = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.ph0) > 0) || (isinf(handles.ph0) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for constant or zero-order phase.'];
    ErrorMessage2 = ['Error: Constant or zero-order phase set to valid default value (0.0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.ph0 = 0.0;
    set(hObject,'String',handles.ph0);
end;

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject,handles);

function ConstantPhase_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function ConstantPhaseIncrease_pushbutton_Callback(hObject, eventdata, handles)
handles.ph0 = handles.ph0 + 5;
if (handles.ph0 > 180)
    handles.ph0 = handles.ph0 - 360;
end;
set(handles.ConstantPhase_edit, 'String', num2str(handles.ph0));

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject,handles);

function ConstantPhaseDecrease_pushbutton_Callback(hObject, eventdata, handles)
handles.ph0 = handles.ph0 - 5;
if (handles.ph0 < -180)
    handles.ph0 = handles.ph0 + 360;
end;
set(handles.ConstantPhase_edit, 'String', num2str(handles.ph0));

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject,handles);

function LinearPhase_edit_Callback(hObject, eventdata, handles)
handles.ph1 = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.ph1) > 0) || (isinf(handles.ph1) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for linear or first-order phase.'];
    ErrorMessage2 = ['Error: Linear or first-order phase set to valid default value (0.0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.ph1 = 0.0;
    set(hObject,'String',handles.ph1);
end;

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject,handles);

function LinearPhase_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function LinearPhaseIncrease_pushbutton_Callback(hObject, eventdata, handles)
handles.ph1 = handles.ph1 + 0.05;
set(handles.LinearPhase_edit, 'String', num2str(handles.ph1));

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject,handles);

function LinearPhaseDecrease_pushbutton_Callback(hObject, eventdata, handles)
handles.ph1 = handles.ph1 - 0.05;
set(handles.LinearPhase_edit, 'String', num2str(handles.ph1));

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject,handles);

function Magnitude_checkbox_Callback(hObject, eventdata, handles)
handles.av = get(hObject,'Value');

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

[OperationTime,~] = DMIWizard_MRSI_CalculateTime;
if (handles.av > 0)
    TextOutput1 = [OperationTime ' - Magnitude processing and display enabled.'];
    disp(TextOutput1);
else
    TextOutput1 = [OperationTime ' - Phase-sensitive processing and display enabled.'];
    disp(TextOutput1);   
end;

% Write information to processing history file
DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+',TextOutput1);

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

%----------------------------------------------------------------
% Spectral zoom parameters and functions
%----------------------------------------------------------------
function FrequencyLow_edit_Callback(hObject, eventdata, handles)
handles.ZxLow = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.ZxLow) > 0) || (isinf(handles.ZxLow) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for lower frequency boundary.'];
    ErrorMessage2 = ['Error: Lower frequency boundary set to previous value (' num2str(handles.ZxLowPreviousValue) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.ZxLow = handles.ZxLowPreviousValue;
    set(hObject,'String',handles.ZxLow);
end;

% Force lower boundary below higher boundary
if (handles.ZxLow >= handles.ZxHigh)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for lower frequency boundary.'];
    ErrorMessage2 = ['Error: Lower frequency boundary set to previous value (' num2str(handles.ZxLowPreviousValue) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.ZxLow = handles.ZxLowPreviousValue;
    set(hObject,'String',handles.ZxLow);
else
    set(hObject,'String',handles.ZxLow);
end;

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update previous value
handles.ZxLowPreviousValue = handles.ZxLow;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject,handles);

function FrequencyLow_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function FrequencyHigh_edit_Callback(hObject, eventdata, handles)
handles.ZxHigh = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.ZxHigh) > 0) || (isinf(handles.ZxHigh) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for higher frequency boundary.'];
    ErrorMessage2 = ['Error: Higher frequency boundary set to previous value (' num2str(handles.ZxHighPreviousValue) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.ZxHigh = handles.ZxHighPreviousValue;
    set(hObject,'String',handles.ZxHigh);
end;

% Force higher boundary above lower boundary
if (handles.ZxHigh <= handles.ZxLow)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for higher frequency boundary.'];
    ErrorMessage2 = ['Error: Higher frequency boundary set to previous value (' num2str(handles.ZxHighPreviousValue) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.ZxHigh = handles.ZxHighPreviousValue;
    set(hObject,'String',handles.ZxHigh);
else
    set(hObject,'String',handles.ZxHigh);
end;

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update previous value
handles.ZxHighPreviousValue = handles.ZxHigh;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject,handles);

function FrequencyHigh_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function SignalLow_edit_Callback(hObject, eventdata, handles)
handles.ZyLow = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.ZyLow) > 0) || (isinf(handles.ZyLow) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for lower intensity boundary.'];
    ErrorMessage2 = ['Error: Lower intensity boundary set to previous value (' num2str(handles.ZyLowPreviousValue) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.ZyLow = handles.ZyLowPreviousValue;
    set(hObject,'String',handles.ZyLow);
end;

% Force lower intensity boundary below higher intensity boundary
if (handles.ZyLow >= handles.ZyHigh)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for lower intensity boundary.'];
    ErrorMessage2 = ['Error: Lower intensity boundary set to previous value (' num2str(handles.ZyLowPreviousValue) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.ZyLow = handles.ZyLowPreviousValue;
    set(hObject,'String',handles.ZyLow);
else
    set(hObject,'String',handles.ZyLow);
end;

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update previous value
handles.ZyLowPreviousValue = handles.ZyLow;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject,handles);

function SignalLow_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function SignalHigh_edit_Callback(hObject, eventdata, handles)
handles.ZyHigh = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.ZyHigh) > 0) || (isinf(handles.ZyHigh) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for higher intensity boundary.'];
    ErrorMessage2 = ['Error: Higher intensity boundary set to previous value (' num2str(handles.ZyHighPreviousValue) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.ZyHigh = handles.ZyHighPreviousValue;
    set(hObject,'String',handles.ZyHigh);
end;

% Force higher intensity boundary above lower intensity boundary
if (handles.ZyHigh <= handles.ZyLow)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for higher intensity boundary.'];
    ErrorMessage2 = ['Error: Higher intensity boundary set to previous value (' num2str(handles.ZyHighPreviousValue) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.ZyHigh = handles.ZyHighPreviousValue;
    set(hObject,'String',handles.ZyHigh);
else
    set(hObject,'String',handles.ZyHigh);
end;

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update previous value
handles.ZyHighPreviousValue = handles.ZyHigh;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject,handles);

function SignalHigh_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function SignalScalingFactor_edit_Callback(hObject, eventdata, handles)
handles.ZyScale = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.ZyScale) > 0) || (isinf(handles.ZyScale) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for intensity scaling factor.'];
    ErrorMessage2 = ['Error: Intensity scaling factor set to previous value (' num2str(handles.ZyScalePreviousValue) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.ZyScale = handles.ZyScalePreviousValue;
    set(hObject,'String',handles.ZyScale);
end;

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update previous value
handles.ZyScalePreviousValue = handles.ZyScale;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject,handles);

function SignalScalingFactor_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function FrequencyLowIncrease_pushbutton_Callback(hObject, eventdata, handles)
handles.ZxLow = handles.ZxLow + 0.05;
if (handles.ZxLow > handles.ZxHigh)
    handles.ZxLow = handles.ZxLow - 0.05;
end;
set(handles.FrequencyLow_edit,'String',num2str(handles.ZxLow));

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update previous value
handles.ZxLowPreviousValue = handles.ZxLow;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject,handles);

function FrequencyHighIncrease_pushbutton_Callback(hObject, eventdata, handles)
handles.ZxHigh = handles.ZxHigh + 0.05;
if (handles.ZxHigh > 0.5*handles.sw)
    handles.ZxHigh = handles.ZxHigh - 0.05;
end;
set(handles.FrequencyHigh_edit,'String',num2str(handles.ZxHigh));

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update previous value
handles.ZxHighPreviousValue = handles.ZxHigh;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject,handles);

function FrequencyLowDecrease_pushbutton_Callback(hObject, eventdata, handles)
handles.ZxLow = handles.ZxLow - 0.05;
if (handles.ZxLow < -0.5*handles.sw)
    handles.ZxLow = handles.ZxLow + 0.05;
end;
set(handles.FrequencyLow_edit,'String',num2str(handles.ZxLow));

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update previous value
handles.ZxLowPreviousValue = handles.ZxLow;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject,handles);

function FrequencyHighDecrease_pushbutton_Callback(hObject, eventdata, handles)
handles.ZxHigh = handles.ZxHigh - 0.05;
if (handles.ZxHigh < handles.ZxLow)
    handles.ZxHigh = handles.ZxHigh + 0.05;
end;
set(handles.FrequencyHigh_edit,'String',num2str(handles.ZxHigh));

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update previous value
handles.ZxHighPreviousValue = handles.ZxHigh;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject,handles);

function SignalLowIncrease_pushbutton_Callback(hObject, eventdata, handles)
ZyLowPrevious = handles.ZyLow;
handles.ZyLow = round(handles.ZyLow+0.1*abs(handles.ZyLow));
if (handles.ZyLow > handles.ZyHigh)
    handles.ZyLow = ZyLowPrevious;
end
set(handles.SignalLow_edit,'String',num2str(handles.ZyLow));

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update previous value
handles.ZyLowPreviousValue = handles.ZyLow;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject,handles);

function SignalLowDecrease_pushbutton_Callback(hObject, eventdata, handles)
handles.ZyLow = round(handles.ZyLow-0.1*abs(handles.ZyLow));

set(handles.SignalLow_edit,'String',num2str(handles.ZyLow));

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update previous value
handles.ZyLowPreviousValue = handles.ZyLow;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject,handles);

function SignalHighIncrease_pushbutton_Callback(hObject, eventdata, handles)
handles.ZyHigh = round(handles.ZyHigh+0.1*abs(handles.ZyHigh));
set(handles.SignalHigh_edit,'String',num2str(handles.ZyHigh));

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update previous value
handles.ZyHighPreviousValue = handles.ZyHigh;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject,handles);

function SignalHighDecrease_pushbutton_Callback(hObject, eventdata, handles)
ZyHighPrevious = handles.ZyHigh;
handles.ZyHigh = round(handles.ZyHigh-0.1*abs(handles.ZyHigh));
if (handles.ZyHigh < handles.ZyLow)
    handles.ZyHigh = ZyHighPrevious;
    clear ZyHighPrevious;
end;
set(handles.SignalHigh_edit,'String',num2str(handles.ZyHigh));

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update previous value
handles.ZyHighPreviousValue = handles.ZyHigh;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject,handles);

function SignalScalingFactorIncrease_pushbutton_Callback(hObject, eventdata, handles)
handles.ZyScale = handles.ZyScale + 1;
set(handles.SignalScalingFactor_edit,'String',num2str(handles.ZyScale));

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update previous value
handles.ZyScalePreviousValue = handles.ZyScale;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject,handles);

function SignalScalingFactorDecrease_pushbutton_Callback(hObject, eventdata, handles)
handles.ZyScale = handles.ZyScale - 1;
set(handles.SignalScalingFactor_edit,'String',num2str(handles.ZyScale));

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update previous value
handles.ZyScalePreviousValue = handles.ZyScale;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject,handles);

%----------------------------------------------------------------
% MRI-related parameters and functions
%----------------------------------------------------------------

function MRIDimension1_edit_Callback(hObject, eventdata, handles)
handles.np1mri = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.np1mri) > 0) || (isinf(handles.np1mri) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for MRI matrix size, element 1.'];
    ErrorMessage2 = ['Error: MRI matrix size, element 1, set to valid default value (101).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.np1mri = 101;
    set(hObject,'String',handles.np1mri);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function MRIDimension1_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function MRIDimension2_edit_Callback(hObject, eventdata, handles)
handles.np2mri = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.np2mri) > 0) || (isinf(handles.np2mri) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for MRI matrix size, element 2.'];
    ErrorMessage2 = ['Error: MRI matrix size, element 2, set to valid default value (151).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.np2mri = 151;
    set(hObject,'String',handles.np2mri);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function MRIDimension2_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function MRIDimension3_edit_Callback(hObject, eventdata, handles)
handles.np3mri = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.np3mri) > 0) || (isinf(handles.np3mri) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for MRI matrix size, element 3.'];
    ErrorMessage2 = ['Error: MRI matrix size, element 3, set to valid default value (71).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.np3mri = 71;
    set(hObject,'String',handles.np3mri);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function MRIDimension3_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function MRIExtDimension1_edit_Callback(hObject, eventdata, handles)
handles.np1ext = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.np1ext) > 0) || (isinf(handles.np1ext) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for extended MRI matrix size, element 1.'];
    ErrorMessage2 = ['Error: Extended MRI matrix size, element 1, set to valid default value (101).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.np1ext = 101;
    set(hObject,'String',handles.np1ext);
end;

% Zero-filled, extended MRI matrix is always larger than acquired MRI matrix
if (handles.np1ext < handles.np1mri)
    handles.np1ext = handles.np1mri;
    set(handles.MRIExtDimension1_edit, 'String', handles.np1ext);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function MRIExtDimension1_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function MRIExtDimension2_edit_Callback(hObject, eventdata, handles)
handles.np2ext = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.np2ext) > 0) || (isinf(handles.np2ext) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for extended MRI matrix size, element 2.'];
    ErrorMessage2 = ['Error: Extended MRI matrix size, element 2, set to valid default value (151).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.np2ext = 151;
    set(hObject,'String',handles.np2ext);
end;

% Zero-filled, extended MRI matrix is always larger than acquired MRI matrix
if (handles.np2ext < handles.np2mri)
    handles.np2ext = handles.np2mri;
    set(handles.MRIExtDimension2_edit, 'String', handles.np2ext);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function MRIExtDimension2_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function MRIExtDimension3_edit_Callback(hObject, eventdata, handles)
handles.np3ext = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.np3ext) > 0) || (isinf(handles.np3ext) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for extended MRI matrix size, element 3.'];
    ErrorMessage2 = ['Error: Extended MRI matrix size, element 3, set to valid default value (71).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.np3ext = 71;
    set(hObject,'String',handles.np3ext);
end;

% Zero-filled, extended MRI matrix is always larger than acquired MRI matrix
if (handles.np3ext < handles.np3mri)
    handles.np3ext = handles.np3mri;
    set(handles.MRIExtDimension3_edit, 'String', handles.np3ext);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function MRIExtDimension3_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function FOV1_edit_Callback(hObject, eventdata, handles)
handles.FOV1 = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.FOV1) > 0) || (isinf(handles.FOV1) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for FOV matrix, element 1.'];
    ErrorMessage2 = ['Error: FOV matrix, element 1 set to valid default value (19).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.FOV1 = 19;
    set(hObject,'String',handles.FOV1);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function FOV1_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function FOV2_edit_Callback(hObject, eventdata, handles)
handles.FOV2 = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.FOV2) > 0) || (isinf(handles.FOV2) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for FOV matrix, element 2.'];
    ErrorMessage2 = ['Error: FOV matrix, element 2 set to valid default value (29).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.FOV2 = 29;
    set(hObject,'String',handles.FOV2);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function FOV2_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function FOV3_edit_Callback(hObject, eventdata, handles)
handles.FOV3 = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.FOV3) > 0) || (isinf(handles.FOV3) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for FOV matrix, element 3.'];
    ErrorMessage2 = ['Error: FOV matrix, element 3 set to valid default value (13).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.FOV3 = 13;
    set(hObject,'String',handles.FOV3);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function FOV3_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function FFTMRI_pushbutton_Callback(hObject, eventdata, handles)

% FFT MRI
if (isfield(handles,'FIDMRI') == 1)
    [KSpaceMatrix1, KSpaceMatrix2, KSpaceMatrix3] = ndgrid(1:handles.np1mri,1:handles.np2mri,1:handles.np3mri);
    ShiftMatrix = exp(2*pi*1i*KSpaceMatrix1*handles.MRIshift1/handles.np1mri).*...
        exp(2*pi*1i*KSpaceMatrix2*handles.MRIshift2/handles.np2mri).*...
        exp(2*pi*1i*KSpaceMatrix3*handles.MRIshift3/handles.np3mri);
    
    handles.MRI = abs(fftshift(fftn(handles.FIDMRI.*ShiftMatrix,[handles.np1ext handles.np2ext handles.np3ext])));
    
    if (rem(handles.np1ext,handles.np1) ~= 0 || rem(handles.np2ext,handles.np2) ~= 0 || ...
            rem(handles.np3ext,handles.np3) ~= 0)
        OperationTime = DMIWizard_MRSI_CalculateTime;
        TextOutput1 = [OperationTime ' - Warning: MRI matrix size is not an integer multiple of the DMI matrix size.'];
        TextOutput2 = [OperationTime ' - Warning: This MAY lead to excessive matrix sizes during Advanced Mapping.'];
        TextOutput3 = [OperationTime ' - Warning: MRI matrix size can be modified through the extended matrix option.'];
        disp(' '); disp(TextOutput1); disp(TextOutput2); disp(TextOutput3);
    end;
else
    OperationTime = DMIWizard_MRSI_CalculateTime;
    ErrorMessage1 = [OperationTime ' - Error   : FID for 3D MRI does not exist.'];
    ErrorMessage2 = [OperationTime ' - Solution: Select and load a 3D MRI FID file before attempting FFT.'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
end;

% Display image
if (isfield(handles,'MRI') == 1)
    DMIWizard_MRSI_DisplayImage(handles.MRI,handles);
    
    if ((handles.np1ext ~= handles.np1extprevious) || (handles.np2ext ~= handles.np2extprevious) || ...
        (handles.np3ext ~= handles.np3extprevious))
        % MRI matrix size is different from a previously MRI dataset.
        % Close the Advanced Mapping window (if open) to prevent potential 
        % matrix size discrepancies.

        % 1. Set Advanced Mapping checkbox to 'off'
        AM_Object = findall(0,'Tag','AdvancedMapping_CheckBox');
        set(AM_Object,'Value',0);

        % 2. Close open window associated with Advanced Mapping
        hObject2 = findall(0,'Name','DMIWizard_Mapping');
        if (isempty(hObject2) < 1)
            delete(hObject2);

            OperationTime = DMIWizard_MRSI_CalculateTime;
            TextOutput1 = [OperationTime ' - Warning: MRI matrix size has changed compared to previously MRI dataset.'];
            TextOutput2 = [OperationTime ' - Warning: Closing Advanced Mapping window to avoid potential matrix size discrepancies.'];
            disp(' '); disp(TextOutput1); disp(TextOutput2);
        end; 

        % 3. Hide advanced mapping parameters in main MRSI window visible
        set(findall(0,'Tag','Interpolation_checkbox'),'Visible','Off');
        set(findall(0,'Tag','KernelWidth_edit'),'Visible','Off');

        set(findall(0,'Tag','Transparency_edit'),'Visible','Off');
        set(findall(0,'Tag','Text_Transparency'),'Visible','Off');

        set(findall(0,'Tag','MRIbackground_checkbox'),'Visible','Off');
        set(findall(0,'Tag','ROI_pushbutton'),'Visible','Off');

        handles.np1extprevious = handles.np1ext;
        handles.np2extprevious = handles.np2ext;
        handles.np3extprevious = handles.np3ext;
    end;
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function FFTMRSI_pushbutton_Callback(hObject, eventdata, handles)
if (isfield(handles,'FID') == 1)
    handles = DMIWizard_MRSI_FFT(handles);
end;
    
% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
else
    ErrorMessage1 = ['Error   : FID for 3D MRSI/DMI does not exist.'];
    ErrorMessage2 = ['Solution: Select and load a 3D MRSI FID file before attempting FFT.'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function Threshold_edit_Callback(hObject, eventdata, handles)
handles.intth = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.intth) > 0) || (isinf(handles.intth) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for signal threshold.'];
    ErrorMessage2 = ['Error: Signal threshold set to valid default value (15).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.intth = 15;
    set(hObject,'String',handles.intth);
end;

% Check for invalid entry
if ((handles.intth <= 0) || (handles.intth > 100))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for signal threshold.'];
    ErrorMessage2 = ['Error: Signal threshold set to valid default value (15).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.intth = 15;
    set(hObject,'String',handles.intth);
end;

if ((isfield(handles,'spec3D') > 0) && (isfield(handles,'maxspec3D') > 0))
    % Regenerate inclusion map based on new threshold
    disp('Generating inclusion map based on new threshold ...');
    handles.InclusionMap = zeros(handles.np1,handles.np2,handles.np3);
    for c1 = 1:handles.np1;
        for c2 = 1:handles.np2;
            for c3 = 1:handles.np3;
                if (max(abs(handles.spec3D(:,c1,c2,c3))) > (handles.intth/100)*handles.maxspec3D);
                   handles.InclusionMap(c1,c2,c3) = 1;
                else
                   handles.InclusionMap(c1,c2,c3) = 0;
                end;
            end;
        end;
    end;
    disp('... done.');
end;

% Display image
if (isfield(handles,'MRI') == 1)
    DMIWizard_MRSI_DisplayImage(handles.MRI,handles);
end;

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function Threshold_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function SNR_checkbox_Callback(hObject, eventdata, handles)
handles.SNRDisplay = get(hObject,'Value');

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function LineWidth_checkbox_Callback(hObject, eventdata, handles)
handles.LWDisplay = get(hObject,'Value');

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function LineShift_checkbox_Callback(hObject, eventdata, handles)
handles.LSDisplay = get(hObject,'Value');

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function Interpolation_checkbox_Callback(hObject, eventdata, handles)
handles.Interpolation = get(hObject,'Value');

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function KernelWidth_edit_Callback(hObject, eventdata, handles)
handles.KernelWidth = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.KernelWidth) > 0) || (isinf(handles.KernelWidth) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for kernel width.'];
    ErrorMessage2 = ['Error: Kernel width set to valid default value (3.0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.KernelWidth = 3.0;
    set(hObject,'String',handles.KernelWidth);
end;

% Check for invalid entry
if (handles.KernelWidth == 0)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for kernel width.'];
    ErrorMessage2 = ['Error: Kernel width set to valid default value (3.0).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.KernelWidth = 3.0;
    set(hObject,'String',handles.KernelWidth);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function KernelWidth_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function MRIbackground_checkbox_Callback(hObject, eventdata, handles)
handles.MRIBackground = get(hObject,'Value');

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function ParameterMap_pushbutton_Callback(hObject, eventdata, handles)
handles = DMIWizard_MRSI_ParameterMapping(handles);

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function MRSI_pushbutton_Callback(hObject, eventdata, handles)
handles = DMIWizard_MRSI_DisplayMRSI(handles);

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function MRSIType_popupmenu_Callback(hObject, eventdata, handles)
contents = cellstr(get(hObject,'String'));
Orientation = contents{get(hObject,'Value')};

for c1 = 1:1:length(contents)
    if strcmp(cellstr(contents(c1)),Orientation) == 1
        handles.Orientation = c1;
    end;
end;

% Check if MRI slice number is larger than MRI matrix size (due
% to previously selected image orientation).
switch handles.Orientation
    case 1
        % Axial orientation
        if (handles.sp4 > handles.np3ext)
            handles.sp4 = handles.np3ext;
            set(handles.MRISlice_edit, 'String', handles.sp4);
        end;
    case 2
        % Coronal orientation
        if (handles.sp4 > handles.np2ext)
            handles.sp4 = handles.np2ext;
            set(handles.MRISlice_edit, 'String', handles.sp4);
        end;
    case 3
        % Sagittal orientation
        if (handles.sp4 > handles.np1ext)
            handles.sp4 = handles.np1ext;
            set(handles.MRISlice_edit, 'String', handles.sp4);
        end;
end;

% Update MR image
if (isfield(handles,'MRI') == 1)
    DMIWizard_MRSI_DisplayImage(handles.MRI,handles);
end;

% When changing orienation remove windows and parameters
% related to Advanced Mapping to avoid data size inconsistencies.
% 1. Set Advanced Mapping checkbox to 'off'
AM_Object = findall(0,'Tag','AdvancedMapping_CheckBox');
set(AM_Object,'Value',0);

% 2. Close open window associated with Advanced Mapping
hObject2 = findall(0,'Name','DMIWizard_Mapping');
if (isempty(hObject2) < 1)
    delete(hObject2);
    
    OperationTime = DMIWizard_MRSI_CalculateTime;
    TextOutput1 = [OperationTime ' - Warning: DMI and MRI orientation has changed.'];
    TextOutput2 = [OperationTime ' - Warning: Closing Advanced Mapping window to avoid potential matrix size discrepancies.'];
    disp(' '); disp(TextOutput1); disp(TextOutput2);
end; 
 
% 3. Hide advanced mapping parameters in main MRSI window visible
set(findall(0,'Tag','Interpolation_checkbox'),'Visible','Off');
set(findall(0,'Tag','KernelWidth_edit'),'Visible','Off');

set(findall(0,'Tag','Transparency_edit'),'Visible','Off');
set(findall(0,'Tag','Text_Transparency'),'Visible','Off');

set(findall(0,'Tag','MRIbackground_checkbox'),'Visible','Off');
set(findall(0,'Tag','ROI_pushbutton'),'Visible','Off');

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function MRSIType_popupmenu_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function SpatialPosition1_edit_Callback(hObject, eventdata, handles)
handles.sp1 = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.sp1) > 0) || (isinf(handles.sp1) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for MRSI spatial position 1.'];
    ErrorMessage2 = ['Error: MRSI spatial position 1 set to previous value (' num2str(handles.sp1PreviousValue) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.sp1 = handles.sp1PreviousValue;
    set(hObject,'String',handles.sp1);
end;

% Force valid MRSI spatial position 1 value
if ((handles.sp1 <= 0) || (handles.sp1 > handles.np1))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for MRSI spatial position 1.'];
    ErrorMessage2 = ['Error: MRSI spatial position 1 set to previous value (' num2str(handles.sp1PreviousValue) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.sp1 = handles.sp1PreviousValue;
    set(hObject,'String',handles.sp1);
else
    set(hObject,'String',handles.sp1);
end;

% Update previous value
handles.sp1PreviousValue = handles.sp1;

% Display image
if (isfield(handles,'MRI') == 1)
    DMIWizard_MRSI_DisplayImage(handles.MRI,handles);
end;

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function SpatialPosition1_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function SpatialPosition2_edit_Callback(hObject, eventdata, handles)
handles.sp2 = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.sp2) > 0) || (isinf(handles.sp2) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for MRSI spatial position 2.'];
    ErrorMessage2 = ['Error: MRSI spatial position 2 set to previous value (' num2str(handles.sp2PreviousValue) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.sp2 = handles.sp2PreviousValue;
    set(hObject,'String',handles.sp2);
end;

% Force valid MRSI spatial position 2 value
if ((handles.sp2 <= 0) || (handles.sp2 > handles.np2))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for MRSI spatial position 2.'];
    ErrorMessage2 = ['Error: MRSI spatial position 2 set to previous value (' num2str(handles.sp2PreviousValue) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.sp2 = handles.sp2PreviousValue;
    set(hObject,'String',handles.sp2);
else
    set(hObject,'String',handles.sp2);
end;

% Update previous value
handles.sp2PreviousValue = handles.sp2;

% Display image
if (isfield(handles,'MRI') == 1)
    DMIWizard_MRSI_DisplayImage(handles.MRI,handles);
end;

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function SpatialPosition2_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function SpatialPosition3_edit_Callback(hObject, eventdata, handles)
handles.sp3 = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.sp3) > 0) || (isinf(handles.sp3) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for MRSI spatial position 3.'];
    ErrorMessage2 = ['Error: MRSI spatial position 3 set to previous value (' num2str(handles.sp3PreviousValue) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.sp3 = handles.sp3PreviousValue;
    set(hObject,'String',handles.sp3);
end;

% Force valid MRSI spatial position 3 value
if ((handles.sp3 <= 0) || (handles.sp3 > handles.np3))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for MRSI spatial position 3.'];
    ErrorMessage2 = ['Error: MRSI spatial position 3 set to previous value (' num2str(handles.sp3PreviousValue) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
    
    handles.sp3 = handles.sp3PreviousValue;
    set(hObject,'String',handles.sp3);
else
    set(hObject,'String',handles.sp3);
end;

% Update previous value
handles.sp3PreviousValue = handles.sp3;

% Display image
if (isfield(handles,'MRI') == 1)
    DMIWizard_MRSI_DisplayImage(handles.MRI,handles);
end;

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function SpatialPosition3_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function SpatialPosition1Increase_pushbutton_Callback(hObject, eventdata, handles)
handles.sp1 = handles.sp1 + 1;
if (handles.sp1 > handles.np1)
    handles.sp1 = handles.sp1 - 1;
end;

set(handles.SpatialPosition1_edit, 'String', num2str(handles.sp1));

% Display image
if (isfield(handles,'MRI') == 1)
    DMIWizard_MRSI_DisplayImage(handles.MRI,handles);
end;

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update previous value
handles.sp1PreviousValue = handles.sp1;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function SpatialPosition2Increase_pushbutton_Callback(hObject, eventdata, handles)
handles.sp2 = handles.sp2 + 1;
if (handles.sp2 > handles.np2)
    handles.sp2 = handles.sp2 - 1;
end;

set(handles.SpatialPosition2_edit, 'String', num2str(handles.sp2));

% Display image
if (isfield(handles,'MRI') == 1)
    DMIWizard_MRSI_DisplayImage(handles.MRI,handles);
end;

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update previous value
handles.sp2PreviousValue = handles.sp2;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function SpatialPosition3Increase_pushbutton_Callback(hObject, eventdata, handles)
handles.sp3 = handles.sp3 + 1;
if (handles.sp3 > handles.np3)
    handles.sp3 = handles.sp3 - 1;
end;

set(handles.SpatialPosition3_edit, 'String', num2str(handles.sp3));

% Display image
if (isfield(handles,'MRI') == 1)
    DMIWizard_MRSI_DisplayImage(handles.MRI,handles);
end;

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update previous value
handles.sp3PreviousValue = handles.sp3;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function SpatialPosition1Decrease_pushbutton_Callback(hObject, eventdata, handles)
handles.sp1 = handles.sp1 - 1;
if (handles.sp1 < 1)
    handles.sp1 = handles.sp1 + 1;
end;

set(handles.SpatialPosition1_edit, 'String', num2str(handles.sp1));

% Display image
if (isfield(handles,'MRI') == 1)
    DMIWizard_MRSI_DisplayImage(handles.MRI,handles);
end;

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update previous value
handles.sp1PreviousValue = handles.sp1;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function SpatialPosition2Decrease_pushbutton_Callback(hObject, eventdata, handles)
handles.sp2 = handles.sp2 - 1;
if (handles.sp2 < 1)
    handles.sp2 = handles.sp2 + 1;
end;

set(handles.SpatialPosition2_edit, 'String', num2str(handles.sp2));

% Display image
if (isfield(handles,'MRI') == 1)
    DMIWizard_MRSI_DisplayImage(handles.MRI,handles);
end;

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update previous value
handles.sp2PreviousValue = handles.sp2;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function SpatialPosition3Decrease_pushbutton_Callback(hObject, eventdata, handles)
handles.sp3 = handles.sp3 - 1;
if (handles.sp3 < 1)
    handles.sp3 = handles.sp3 + 1;
end;

set(handles.SpatialPosition3_edit, 'String', num2str(handles.sp3));

% Display image
if (isfield(handles,'MRI') == 1)
    DMIWizard_MRSI_DisplayImage(handles.MRI,handles);
end;

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update previous value
handles.sp3PreviousValue = handles.sp3;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function SpatialPosition1SmallDecrease_pushbutton_Callback(hObject, eventdata, handles)
handles.sp1 = handles.sp1 - .1;
if (handles.sp1 < 1)
    handles.sp1 = handles.sp1 + .1;
end;
set(handles.SpatialPosition1_edit, 'String', num2str(handles.sp1));

% Display image
if (isfield(handles,'MRI') == 1)
    DMIWizard_MRSI_DisplayImage(handles.MRI,handles);
end;

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update previous value
handles.sp1PreviousValue = handles.sp1;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function SpatialPosition2SmallDecrease_pushbutton_Callback(hObject, eventdata, handles)
handles.sp2 = handles.sp2 - .1;
if (handles.sp2 < 1)
    handles.sp2 = handles.sp2 + .1;
end;

set(handles.SpatialPosition2_edit, 'String', num2str(handles.sp2));

% Display image
if (isfield(handles,'MRI') == 1)
    DMIWizard_MRSI_DisplayImage(handles.MRI,handles);
end;

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update previous value
handles.sp2PreviousValue = handles.sp2;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function SpatialPosition3SmallDecrease_pushbutton_Callback(hObject, eventdata, handles)
handles.sp3 = handles.sp3 - .1;
if (handles.sp3 < 1)
    handles.sp3 = handles.sp3 + .1;
end;

set(handles.SpatialPosition3_edit, 'String', num2str(handles.sp3));

% Display image
if (isfield(handles,'MRI') == 1)
    DMIWizard_MRSI_DisplayImage(handles.MRI,handles);
end;

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update previous value
handles.sp3PreviousValue = handles.sp3;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function SpatialPosition1SmallIncrease_pushbutton_Callback(hObject, eventdata, handles)
handles.sp1 = handles.sp1 + .1;
if (handles.sp1 > handles.np1)
    handles.sp1 = handles.sp1 - .1;
end;

set(handles.SpatialPosition1_edit, 'String', num2str(handles.sp1));

% Display image
if (isfield(handles,'MRI') == 1)
    DMIWizard_MRSI_DisplayImage(handles.MRI,handles);
end;

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update previous value
handles.sp1PreviousValue = handles.sp1;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function SpatialPosition2SmallIncrease_pushbutton_Callback(hObject, eventdata, handles)
handles.sp2 = handles.sp2 + .1;
if (handles.sp2 > handles.np1)
    handles.sp2 = handles.sp2 - .1;
end;

set(handles.SpatialPosition2_edit, 'String', num2str(handles.sp2));

% Display image
if (isfield(handles,'MRI') == 1)
    DMIWizard_MRSI_DisplayImage(handles.MRI,handles);
end;

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update previous value
handles.sp2PreviousValue = handles.sp2;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function SpatialPosition3SmallIncrease_pushbutton_Callback(hObject, eventdata, handles)
handles.sp3 = handles.sp3 + .1;
if (handles.sp3 > handles.np1)
    handles.sp3 = handles.sp3 - .1;
end;

set(handles.SpatialPosition3_edit, 'String', num2str(handles.sp3));

% Display image
if (isfield(handles,'MRI') == 1)
    DMIWizard_MRSI_DisplayImage(handles.MRI,handles);
end;

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update previous value
handles.sp3PreviousValue = handles.sp3;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function MRISlice_edit_Callback(hObject, eventdata, handles)
handles.sp4 = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.sp4) > 0) || (isinf(handles.sp4) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for MRI slice position.'];
    ErrorMessage2 = ['Error: MRI slice position set to previous value (' num2str(handles.sp4PreviousValue) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.sp4 = handles.sp4PreviousValue;
    set(hObject,'String',handles.sp4);
end;

% Only allow integer values
handles.sp4 = round(handles.sp4);
set(hObject,'String',handles.sp4);

% Check for negative slice positions
if (handles.sp4 < 1)
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for MRI slice position.'];
    ErrorMessage2 = ['Error: MRI slice position set to previous value (' num2str(handles.sp4PreviousValue) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.sp4 = handles.sp4PreviousValue;
    set(hObject,'String',handles.sp4);
end;

% Check for out-of-range slice positions
switch handles.Orientation
    case 1
        % Axial orientation
        if (handles.sp4 > handles.np3mri)
            ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for MRI slice position.'];
            ErrorMessage2 = ['Error: MRI slice position set to previous value (' num2str(handles.sp4PreviousValue) ').'];
            disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');

            handles.sp4 = handles.sp4PreviousValue;
            set(hObject,'String',handles.sp4);
        end;

    case 2
        % Coronal orientation
        if (handles.sp4 > handles.np2mri)
            ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for MRI slice position.'];
            ErrorMessage2 = ['Error: MRI slice position set to previous value (' num2str(handles.sp4PreviousValue) ').'];
            disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');

            handles.sp4 = handles.sp4PreviousValue;
            set(hObject,'String',handles.sp4);
        end;       
    case 3
        % Sagital orientation
        if (handles.sp4 > handles.np1mri)
            ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for MRI slice position.'];
            ErrorMessage2 = ['Error: MRI slice position set to previous value (' num2str(handles.sp4PreviousValue) ').'];
            disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');

            handles.sp4 = handles.sp4PreviousValue;
            set(hObject,'String',handles.sp4);
        end; 
end;

% Display image
if (isfield(handles,'MRI') == 1)
    DMIWizard_MRSI_DisplayImage(handles.MRI,handles);
end;

% Update previous value
handles.sp4PreviousValue = handles.sp4;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function MRISlice_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function MRIHigh_edit_Callback(hObject, eventdata, handles)
handles.MRIHigh = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.MRIHigh) > 0) || (isinf(handles.MRIHigh) > 0) || (handles.MRIHigh < 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for MRI signal intensity.'];
    ErrorMessage2 = ['Error: MRSI spatial position 3 set to previous value (' num2str(handles.MRIHighPreviousValue) ').'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.MRIHigh = handles.MRIHighPreviousValue;
    set(hObject,'String',handles.MRIHigh);
end;

% Display image
if (isfield(handles,'MRI') == 1)
    DMIWizard_MRSI_DisplayImage(handles.MRI,handles);
end;

% Update previous value
handles.MRIHighPreviousValue = handles.MRIHigh;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function MRIHigh_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function MRISliceIncrease_pushbutton_Callback(hObject, eventdata, handles)
handles.sp4 = handles.sp4 + 1;
switch handles.Orientation
    case 1
        % Axial orientation
        if (handles.sp4 > handles.np3ext)
            handles.sp4 = handles.sp4 - 1;
        end;

    case 2
        % Coronal orientation
        if (handles.sp4 > handles.np2ext)
            handles.sp4 = handles.sp4 - 1;
        end;       
    case 3
        % Sagital orientation
        if (handles.sp4 > handles.np1ext)
            handles.sp4 = handles.sp4 - 1;
        end; 
end;
set(handles.MRISlice_edit, 'String', num2str(handles.sp4));

% Display image
if (isfield(handles,'MRI') == 1)
    DMIWizard_MRSI_DisplayImage(handles.MRI,handles);
end;

% Update previous value
handles.sp4PreviousValue = handles.sp4;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function MRISliceDecrease_pushbutton_Callback(hObject, eventdata, handles)
handles.sp4 = handles.sp4 - 1;
if (handles.sp4 < 1)
    handles.sp4 = handles.sp4 + 1;
end;

set(handles.MRISlice_edit, 'String', num2str(handles.sp4));

% Display image
if (isfield(handles,'MRI') == 1)
    DMIWizard_MRSI_DisplayImage(handles.MRI,handles);
end;

% Update previous value
handles.sp4PreviousValue = handles.sp4;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function MRIHighIncrease_pushbutton_Callback(hObject, eventdata, handles)
handles.MRIHigh = round(handles.MRIHigh+0.1*abs(handles.MRIHigh));

set(handles.MRIHigh_edit, 'String', num2str(handles.MRIHigh));

% Display image
if (isfield(handles,'MRI') == 1)
    DMIWizard_MRSI_DisplayImage(handles.MRI,handles);
end;

% Update previous value
handles.MRIHighPreviousValue = handles.MRIHigh;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function MRIHighDecrease_pushbutton_Callback(hObject, eventdata, handles)
handles.MRIHigh = round(handles.MRIHigh-0.1*abs(handles.MRIHigh));

set(handles.MRIHigh_edit, 'String', num2str(handles.MRIHigh));

% Display image
if (isfield(handles,'MRI') == 1)
    DMIWizard_MRSI_DisplayImage(handles.MRI,handles);
end;

% Update previous value
handles.MRIHighPreviousValue = handles.MRIHigh;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function MRIScaling_edit_Callback(hObject, eventdata, handles)
handles.MRIScale = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.MRIScale) > 0) || (isinf(handles.MRIScale) > 0))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for MRI signal scaling.'];
    ErrorMessage2 = ['Error: MRI signal scaling set to valid default value (3).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.MRIScale = 3;
    set(hObject,'String',handles.MRIScale);
end;

% Display image
if (isfield(handles,'MRI') == 1)
    DMIWizard_MRSI_DisplayImage(handles.MRI,handles);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function MRIScaling_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function MRIScalingIncrease_pushbutton_Callback(hObject, eventdata, handles)
handles.MRIScale = handles.MRIScale + 1;

set(handles.MRIScaling_edit, 'String', num2str(handles.MRIScale));

% Display image
if (isfield(handles,'MRI') == 1)
    DMIWizard_MRSI_DisplayImage(handles.MRI,handles);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function MRIScalingDecrease_pushbutton_Callback(hObject, eventdata, handles)
handles.MRIScale = handles.MRIScale - 1;

set(handles.MRIScaling_edit, 'String', num2str(handles.MRIScale));

% Display image
if (isfield(handles,'MRI') == 1)
    DMIWizard_MRSI_DisplayImage(handles.MRI,handles);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function AutoPhasing_pushbutton_Callback(hObject, eventdata, handles)
figure(2);

UserInput = ginput(2);
FreqInput = UserInput(:,1);

FreqRange = -0.5*handles.sw:handles.sw/(handles.npzf-1):0.5*handles.sw;
FreqCoor = find((FreqRange > min(FreqInput)) & (FreqRange < max(FreqInput)));

OperationTime = DMIWizard_MRSI_CalculateTime;
TextOutput1 = [OperationTime ' - Starting automatic phase correction of all voxels over frequency range [' ...
    num2str(min(FreqInput),4) ' .. ' num2str(max(FreqInput),4) '] kHz.'];
disp(TextOutput1);

% Perform spectral 1D FFT
handles.spec3D = zeros(handles.npzf,handles.np1,handles.np2,handles.np3);
count = 1;
APCounterFraction = 0.1;
for c1 = 1:handles.np1;
    for c2 = 1:handles.np2;
        for c3 = 1:handles.np3;
            maxint = -Inf;
            for phs = 0:10:350;
                FIDphs = handles.FID3D(:,c1,c2,c3).*exp(1i*(pi/180)*phs);
                FIDapodized = DMIWizard_MRSI_Apodization(FIDphs,handles);
                handles.spec = fftshift(fft(FIDapodized,handles.npzf));
                if (sum(real(handles.spec(FreqCoor))) > maxint)
                    maxint = sum(real(handles.spec(FreqCoor)));
                    optphs = phs;
                end;
            end;
            handles.FID3D(:,c1,c2,c3) = handles.FID3D(:,c1,c2,c3)*exp(1i*(pi/180)*optphs);
            FIDapodized = DMIWizard_MRSI_Apodization(squeeze(handles.FID3D(:,c1,c2,c3)),handles);
            handles.spec3D(:,c1,c2,c3) = fftshift(fft(FIDapodized,handles.npzf));
            
            if (count > APCounterFraction*handles.np1*handles.np2*handles.np3)
                dd = [num2str(APCounterFraction*100) ' % completed ...'];
                disp(dd);
                APCounterFraction = APCounterFraction + 0.1;
            end; 
            count = count + 1;    
        end;
    end;
end;

% Recalculate and replace FID signal
handles.FID = squeeze(handles.FID); % Remove number of receivers dimension (= 1)
for c1 = 1:handles.np;
    handles.FID(c1,:,:,:) = ifftshift(ifftn(ifftshift(squeeze(handles.FID3D(c1,:,:,:)))));
end;
handles.FID = reshape(handles.FID,handles.np,handles.nrec,handles.np1,handles.np2,handles.np3);

OperationTime = DMIWizard_MRSI_CalculateTime;
TextOutput2 = [OperationTime ' - Automatic phase correction completed.'];
disp(TextOutput2);

% Write information to processing history file
DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+',TextOutput2);

% Display spectrum
handles = DMIWizard_MRSI_DisplaySpectrum(handles);

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function XFlip_checkbox_Callback(hObject, eventdata, handles)
handles.XFlip = get(hObject,'Value');
handles.KSpaceDataFlip = [handles.XFlip handles.YFlip handles.ZFlip];

% Display image
if (isfield(handles,'MRI') == 1)
    DMIWizard_MRSI_DisplayImage(handles.MRI,handles);
end;

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function YFlip_checkbox_Callback(hObject, eventdata, handles)
handles.YFlip = get(hObject,'Value');
handles.KSpaceDataFlip = [handles.XFlip handles.YFlip handles.ZFlip];

% Display image
if (isfield(handles,'MRI') == 1)
    DMIWizard_MRSI_DisplayImage(handles.MRI,handles);
end;

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function ZFlip_checkbox_Callback(hObject, eventdata, handles)
handles.ZFlip = get(hObject,'Value');
handles.KSpaceDataFlip = [handles.XFlip handles.YFlip handles.ZFlip];

% Display image
if (isfield(handles,'MRI') == 1)
    DMIWizard_MRSI_DisplayImage(handles.MRI,handles);
end;

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function DataAcqOrder_popupmenu_Callback(hObject, eventdata, handles)
DataAcqOrderOptions = cellstr(get(hObject,'String'));
DataAcqOrderSelected = DataAcqOrderOptions{get(hObject,'Value')};

switch DataAcqOrderSelected
    case 'XYZ'
        handles.AcquisitionOrder = [1 2 3];
    case 'XZY'
        handles.AcquisitionOrder = [1 3 2];        
    case 'YXZ'
        handles.AcquisitionOrder = [2 1 3];
    case 'YZX'
        handles.AcquisitionOrder = [2 3 1];
    case 'ZXY'
        handles.AcquisitionOrder = [3 1 2];
    case 'ZYX'
        handles.AcquisitionOrder = [3 2 1];
end;

% Display image
if (isfield(handles,'MRI') == 1)
    DMIWizard_MRSI_DisplayImage(handles.MRI,handles);
end;

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function DataAcqOrder_popupmenu_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function ZoomIn_pushbutton_Callback(hObject, eventdata, handles)

figure(2);

r = ginput(2);
handles.ZxLow = min([r(1,1) r(2,1)]);
handles.ZxHigh = max([r(1,1) r(2,1)]);

% Update GUI - lower frequency boundary
LowFreq_Object = findall(0,'Tag','FrequencyLow_edit');
set(LowFreq_Object,'String',handles.ZxLow);

% Update GUI - higher frequency boundary
HighFreq_Object = findall(0,'Tag','FrequencyHigh_edit');
set(HighFreq_Object,'String',handles.ZxHigh);

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function ZoomOut_pushbutton_Callback(hObject, eventdata, handles)

handles.ZxLow = -0.5*handles.sw;
handles.ZxHigh = 0.5*handles.sw;

LowFrequencyBoundary_Object = findall(0,'Tag','FrequencyLow_edit');
set(LowFrequencyBoundary_Object,'String',handles.ZxLow);

HighFrequencyBoundary_Object = findall(0,'Tag','FrequencyHigh_edit');
set(HighFrequencyBoundary_Object,'String',handles.ZxHigh);

% Display spectrum
if (isfield(handles,'spec3D') == 1)
    handles = DMIWizard_MRSI_DisplaySpectrum(handles);
end;

% Update previous values
handles.ZxLowPreviousValue = handles.ZxLow;
handles.ZxHighPreviousValue = handles.ZxHigh;
    
% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update GUI data structure
guidata(hObject,handles)

function DMIWizard_MRSI_SizeChangedFcn(hObject, eventdata, handles)
% Update GUI data structure
guidata(hObject,handles)

function Transparency_edit_Callback(hObject, eventdata, handles)
handles.Transparency = str2double(get(hObject,'String'));

% Check for invalid entry
if ((isnan(handles.Transparency) > 0) || (isinf(handles.Transparency) > 0) || ...
        (handles.Transparency < 0) || (handles.Transparency > 1))
    ErrorMessage1 = ['Error: Invalid entry (' get(hObject,'String') ') for transparency.'];
    ErrorMessage2 = ['Error: Transparency set to valid default value (0.75).'];
    disp(ErrorMessage1); disp(ErrorMessage2); disp(' ');
      
    handles.Transparency = 0.75;
    set(hObject,'String',handles.Transparency);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);


function Transparency_edit_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function ROI_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to ROI_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

figure(1);
coorROI = roipoly;

% Extract directory
coor = find(handles.MRSIPath == '\');
MRSIpath1Dir = handles.MRSIPath(1:max(coor));

switch handles.Orientation
    case 1
        % Axial plane
        ROI2D = zeros(handles.np1ext,handles.np2ext);
        ROI2D(coorROI) = 1.0; handles.ROI = ROI2D;
        
        [OperationTime,OperationDate] = DMIWizard_MRSI_CalculateTime;
        TextOutput1 = [OperationTime ' - ROI selection for axial slice ' num2str(handles.sp4) ' completed.'];
        TextOutput2 = [OperationTime ' - ROI written to file as:'];
        handles.OutputFileName = ['ROIMap_' num2str(handles.np1ext) 'x' num2str(handles.np2ext) ...
            '_Zslice' num2str(round(handles.sp3)) '_MRIslice' num2str(round(handles.sp4))];
        handles.OutputFileName = [MRSIpath1Dir 'maps\text\' handles.OutputFileName];
        TextOutput3 = [OperationTime ' - ' handles.OutputFileName];
        disp(TextOutput1); disp(TextOutput2); disp(TextOutput3);
        
    case 2
        % Coronal plane
        ROI2D = zeros(handles.np1ext,handles.np3ext);
        ROI2D(coorROI) = 1.0; handles.ROI = ROI2D;
        
        [OperationTime,OperationDate] = DMIWizard_MRSI_CalculateTime;
        TextOutput1 = [OperationTime ' - ROI selection for coronal slice ' num2str(handles.sp4) ' completed.'];
        TextOutput2 = [OperationTime ' - ROI written to file as:'];
        handles.OutputFileName = ['ROIMap_' num2str(handles.np1ext) 'x' num2str(handles.np3ext) ...
            '_Yslice' num2str(round(handles.sp2)) '_MRIslice' num2str(round(handles.sp4))];
        handles.OutputFileName = [MRSIpath1Dir 'maps\text\' handles.OutputFileName];
        TextOutput3 = [OperationTime ' - ' handles.OutputFileName];
        disp(TextOutput1); disp(TextOutput2); disp(TextOutput3);
        
    case 3
        % Sagital plane
        ROI2D = zeros(handles.np2ext,handles.np3ext);
        ROI2D(coorROI) = 1.0; handles.ROI = ROI2D;
        
        [OperationTime,OperationDate] = DMIWizard_MRSI_CalculateTime;
        TextOutput1 = [OperationTime ' - ROI selection for sagital slice ' num2str(handles.sp4) ' completed.'];
        TextOutput2 = [OperationTime ' - ROI written to file as:'];
        handles.OutputFileName = ['ROIMap_' num2str(handles.np2ext) 'x' num2str(handles.np3ext) ...
            '_Xslice' num2str(round(handles.sp1)) '_MRIslice' num2str(round(handles.sp4))];
        handles.OutputFileName = [MRSIpath1Dir 'maps\text\' handles.OutputFileName];
        TextOutput3 = [OperationTime ' - ' handles.OutputFileName];
        disp(TextOutput1); disp(TextOutput2); disp(TextOutput3);
end;

% Save 2D ROI map to disk
fileID = fopen(handles.OutputFileName,'w+');
fprintf(fileID,'%1.0f\n',reshape(ROI2D,1,[]));
fclose(fileID);

% Write information to processing history file
DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput2);
DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+',TextOutput3);

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);

function AdvancedMapping_CheckBox_Callback(hObject, eventdata, handles)
handles.AMcheck = get(hObject,'Value');

if (handles.AMcheck > 0)
    % Open additional GUI window for advanced mapping options
    DMIWizard_Mapping;
    
    % Make advanced mapping parameters in main MRSI window visible
    set(findall(0,'Tag','Interpolation_checkbox'),'Visible','On');
    set(findall(0,'Tag','KernelWidth_edit'),'Visible','On');

    set(findall(0,'Tag','Transparency_edit'),'Visible','On');
    set(findall(0,'Tag','Text_Transparency'),'Visible','On');
    
    set(findall(0,'Tag','MRIbackground_checkbox'),'Visible','On');
    set(findall(0,'Tag','ROI_pushbutton'),'Visible','On');

    % Update current handles in workspace
    assignin('base','currentHandles',handles)

    % Update handles structure
    guidata(hObject, handles);
else
    % Hide advanced mapping parameters in main MRSI window visible
    set(findall(0,'Tag','Interpolation_checkbox'),'Visible','Off');
    set(findall(0,'Tag','KernelWidth_edit'),'Visible','Off');

    set(findall(0,'Tag','Transparency_edit'),'Visible','Off');
    set(findall(0,'Tag','Text_Transparency'),'Visible','Off');
    
    set(findall(0,'Tag','MRIbackground_checkbox'),'Visible','Off');
    set(findall(0,'Tag','ROI_pushbutton'),'Visible','Off');
    
    % Close open window associated with Advanced Mapping
    hObject = findall(0,'Name','DMIWizard_Mapping');
    if (isempty(hObject) < 1)
        delete(hObject);
    end; 
end;


function MapID_edit_Callback(hObject, eventdata, handles)
handles.MapID = get(hObject,'String');

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject,handles);

function MapID_edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function BaselineCorrection_checkbox_Callback(hObject, eventdata, handles)
handles.BC = get(hObject,'Value');

[OperationTime,~] = DMIWizard_MRSI_CalculateTime;
if (handles.BC > 0)
    TextOutput1 = [OperationTime ' - Baseline correction during Parameter Mapping enabled.'];
    TextOutput2 = [OperationTime ' - Parameter Mapping requires four clicks to indicate [baseline - signal - baseline].'];
    disp(' '); disp(TextOutput1); disp(TextOutput2);
    
    % Write information to processing history file
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+',TextOutput1);
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+',TextOutput2);
else
    TextOutput1 = [OperationTime ' - Baseline correction during Parameter Mapping disabled.'];
    disp(' '); disp(TextOutput1);
    
    % Write information to processing history file
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a+',TextOutput1);
end;

% Update current handles in workspace
assignin('base','currentHandles',handles)

% Update handles structure
guidata(hObject, handles);


% --- Executes on button press in SpectralFitting_CheckBox.
function SpectralFitting_CheckBox_Callback(hObject, eventdata, handles)
handles.SFcheck = get(hObject,'Value');

if (handles.SFcheck > 0)
    % Open additional GUI window for advanced mapping options
    DMIWizard_Fitting;
    
    % Update current handles in workspace
    assignin('base','currentHandles3',handles)

    % Update handles structure
    guidata(hObject, handles);
else
    
    % Close open window associated with Advanced Mapping
    hObject = findall(0,'Name','DMIWizard_Fitting');
    if (isempty(hObject) < 1)
        delete(hObject);
    end; 
end;
