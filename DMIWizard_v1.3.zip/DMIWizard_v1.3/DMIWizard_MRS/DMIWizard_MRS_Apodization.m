function outdata = DMIWizard_MRS_Apodization(indata, handles)

npdgd = round(handles.dgd);

%********************************************************
% Apodization applies time domain multiplication of
% exponential and (shifted) Gaussian functions to a FID
%*******************************************************
npr = size(indata,1);               % Number of real datapoints
at = npr/(handles.sw*1000);         % Acquisition time (s)

%*********************************************
% No apodization during digital group delay
%*********************************************
em = ones(1,npdgd);
gm = ones(1,npdgd);

%***************************************************************
% Exponential function : f(t) = exp(-t/T2)
% FT partner : g(v) = T2/(1+4*pi*pi*(v-v0)^2*T2^2)
% FWHM = 1/(pi*T2)
%
% Gaussian function : f(t) = (1/(T2*sqrt(pi)))*exp(-t^2/T2^2)
% FT partner : g(v) = (1/sqrt(2*pi))*exp(-pi*(v-v0)^2*T2^2)
% FWHM = 2*sqrt(log(2))/(pi*T2)
%***************************************************************
emf = handles.emf*pi;
gmf = handles.gmf*pi/(2*sqrt(log(2)));

c1 = (npdgd+1):1:npr;
t(c1-npdgd) = (c1-npdgd-1)*at/(npr-npdgd-1);
em(c1) = exp(-t(c1-npdgd)*emf);
gm(c1) = exp(-((t(c1-npdgd)-0.001*handles.gmfs)*gmf).^2);

em = reshape(em,npr,1);
gm = reshape(gm,npr,1);

outdata = indata.*em.*gm;
