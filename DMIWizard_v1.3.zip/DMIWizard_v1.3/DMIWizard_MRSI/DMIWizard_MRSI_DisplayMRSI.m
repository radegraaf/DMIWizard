function handles = DMIWizard_MRSI_DisplayMRSI(handles)

if isfield(handles,'spec3D') == 1
    freq = -0.5*handles.sw:handles.sw/(handles.npzf-1):0.5*handles.sw;
    coor = find((freq > handles.ZxLow) & (freq < handles.ZxHigh));
    npcoor = length(coor); npgap = round(0.1*npcoor);

    switch handles.Orientation
        case 1
            % Axial plane
            spec2D = squeeze(handles.spec3D(:,:,:,round(handles.sp3)));

            % Display axial orientation
            fh = figure;
            nn = ['Axial orientation (slice ' num2str(round(handles.sp3)) ' out of ' num2str(handles.np3) ')'];
            set(fh,'Name',nn);
            for c1 = 1:handles.np1;
                
                subplot(handles.np1,1,c1),
                hold on;
                for c2 = 1:handles.np2;
                    spec1D = squeeze(spec2D(:,c1,c2))*10^-handles.ZyScale;
%                     spec1D = squeeze(spec2D(:,c2,handles.np2-c1+1))*10^-handles.ZyScale;
                    if (handles.av > 0)
                        spec1D = abs(spec1D);
                    else
                        spec1D = real(spec1D);
                    end; 
                    if (handles.InclusionMap(c1,c2,round(handles.sp3)) > 0)
                        ph = plot((c2-1)*(npcoor+npgap)+1:(c2-1)*(npcoor+npgap)+npcoor,spec1D(coor(end:-1:1)),'r');
%                          set(ph,'Linewidth',1.5,'Color','y');
                    else
                        ph = plot((c2-1)*(npcoor+npgap)+1:(c2-1)*(npcoor+npgap)+npcoor,spec1D(coor(end:-1:1)),'b');
%                          set(ph,'Linewidth',1.5,'Color','y');
                    end;
                    axis([1 handles.np2*(npcoor+npgap) handles.ZyLow handles.ZyHigh]); axis off;
                    
                end; 
                sub_pos = get(gca,'position');             % Get subplot axis position
                set(gca,'position',sub_pos.*[1 1 1 1.2])   % Stretch its height
                hold off;
%                 set(gcf,'color','w');
            end;


          case 2    
            % Coronal plane
            spec2D = squeeze(handles.spec3D(:,:,round(handles.sp2),:));

            % Display coronal orientation
            fh = figure;
            nn = ['Coronal orientation (slice ' num2str(round(handles.sp2)) ' out of ' num2str(handles.np2) ')'];
            set(fh,'Name',nn);
            for c1 = 1:handles.np1;
                
                subplot(handles.np1,1,c1),
                hold on;
                for c2 = 1:handles.np3;
                    spec1D = squeeze(spec2D(:,c1,c2))*10^-handles.ZyScale;
                    if (handles.av > 0)
                        spec1D = abs(spec1D);
                    else
                        spec1D = real(spec1D);
                    end; 
                    if (handles.InclusionMap(c1,round(handles.sp2),c2) > 0)
                        plot((c2-1)*(npcoor+npgap)+1:(c2-1)*(npcoor+npgap)+npcoor,spec1D(coor(end:-1:1)),'r');
                    else
                        plot((c2-1)*(npcoor+npgap)+1:(c2-1)*(npcoor+npgap)+npcoor,spec1D(coor(end:-1:1)),'b');
                    end;
                    axis([1 handles.np3*(npcoor+npgap) handles.ZyLow handles.ZyHigh]); axis off;
                end; 
                sub_pos = get(gca,'position');             % Get subplot axis position
                set(gca,'position',sub_pos.*[1 1 1 1.2])   % Stretch its height
                hold off;
            end;


          case 3
            % Sagittal plane
            spec2D = squeeze(handles.spec3D(:,round(handles.sp1),:,:));

            % Display sagittal orientation
            fh = figure;
            nn = ['Sagittal orientation (slice ' num2str(round(handles.sp1)) ' out of ' num2str(handles.np1) ')'];
            set(fh,'Name',nn);
            for c1 = 1:handles.np2;
                
                subplot(handles.np2,1,c1),
                hold on;
                for c2 = 1:handles.np3;
                    spec1D = squeeze(spec2D(:,c1,c2))*10^-handles.ZyScale;
                    if (handles.av > 0)
                        spec1D = abs(spec1D);
                    else
                        spec1D = real(spec1D);
                    end; 
                    if (handles.InclusionMap(round(handles.sp1),c1,c2) > 0)
                        plot((c2-1)*(npcoor+npgap)+1:(c2-1)*(npcoor+npgap)+npcoor,spec1D(coor(end:-1:1)),'r');
                    else
                        plot((c2-1)*(npcoor+npgap)+1:(c2-1)*(npcoor+npgap)+npcoor,spec1D(coor(end:-1:1)),'b');
                    end;
                    axis([1 handles.np3*(npcoor+npgap) handles.ZyLow handles.ZyHigh]); axis off;
                end; 
                sub_pos = get(gca,'position');             % Get subplot axis position
                set(gca,'position',sub_pos.*[1 1 1 1.2])   % Stretch its height
                hold off;
            end;

    end;
else
    [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
    ErrorOutput1 = [OperationTime ' - Error   : FFT not yet conducted.'];
    ErrorOutput2 = [OperationTime ' - Solution: Conduct a FFT to continue.'];
    disp(' '); disp(ErrorOutput1); disp(ErrorOutput2);
end