% ConvertNrukerMSME.m
%
% Conversion of Bruker MSME data to 3D MRI data.

clear;

MRIPars.orient{1} = [1 2 3];
MRIPars.flip{1} = [1 1 1];

file1 = input('Give Bruker 3D MRI file and path : ');

% Determine and read parameter file
coor1 = find(file1 == '\');
file1dir = file1(1:coor1(end));
file1par = [file1dir 'method'];

[MRIPars.FOV1(1),MRIPars.FOV2(1),MRIPars.FOV3(1),...
    MRIPars.np1(1),MRIPars.np2(1),MRIPars.np3(1)] = ReadParametersBruker3DMRI(file1par);

% Additional parameters
MRIPars.FOV1offset(1) = 0;
MRIPars.FOV2offset(1) = 0;
MRIPars.FOV3offset(1) = 0;

% Read actual 3D MRI data
fileID1 = fopen(file1,'r+');
indata1 = fread(fileID1, inf, 'long');
fclose(fileID1);

FID1 = indata1(1:2:end) + 1i*indata1(2:2:end);
FID1 = reshape(FID1,[],MRIPars.np2(1),MRIPars.np3(1));
FID1 = FID1(1:MRIPars.np1(1),:,:);

% Remove readout FOV offset
[p1,~,~] = ndgrid(1:1:MRIPars.np1(1),ones(1,MRIPars.np2(1)),ones(1,MRIPars.np3(1)));
FID1 = FID1.*exp(2*pi*1i*p1*(MRIPars.FOV1offset(1)/MRIPars.FOV1(1)));

MRI1 = abs(fftshift(fftn(FID1)));

% Change image orientation
MRI1 = permute(MRI1,abs(MRIPars.orient{1}));
np = [MRIPars.np1(1) MRIPars.np2(1) MRIPars.np3(1)];
FOV = [MRIPars.FOV1(1) MRIPars.FOV2(1) MRIPars.FOV3(1)];
np = np(abs(MRIPars.orient{1}));
FOV = FOV(abs(MRIPars.orient{1}));
MRIPars.np1(1) = np(1); MRIPars.np2(1) = np(2); MRIPars.np3(1) = np(3);
MRIPars.FOV1(1) = FOV(1); MRIPars.FOV2(1) = FOV(2); MRIPars.FOV3(1) = FOV(3);

% Perform image flips
MRIFlips = MRIPars.flip{1};
if (MRIFlips(1) < 0)
    MRI1 = MRI1(MRIPars.np1(1):-1:1,:,:);
end;
if (MRIFlips(2) < 0)
    MRI1 = MRI1(:,MRIPars.np2(1):-1:1,:);
end;
if (MRIFlips(3) < 0)
    MRI1 = MRI1(:,:,MRIPars.np3(1):-1:1);
end;

% Extract parameters from method file in future
% MRIPars.orient{2} = [2 1 3];
% MRIPars.flip{2} = [1 1 -1];

file2 = input('Give Bruker MSME file and path : ');

% Determine and read parameter file
coor2 = find(file2 == '\');
file2dir = file2(1:coor2(end));
file2par = [file2dir 'method'];

[MRIPars.FOV1(2),MRIPars.FOV2(2),MRIPars.FOV3(2),...
    MRIPars.np1(2),MRIPars.np2(2),MRIPars.np3(2),...
    MRIPars.FOV1offset(2),MRIPars.FOV2offset(2),...
    MRIPars.FOV3offset(2)] = ReadParametersBrukerMSME(file2par);

% Read actual MSME data
fileID2 = fopen(file2,'r+');
indata2 = fread(fileID2, inf, 'long');
fclose(fileID2);

FID2 = indata2(1:2:end) + 1i*indata2(2:2:end);
FID2 = reshape(FID2,[],MRIPars.np3(2),MRIPars.np2(2));
FID2 = FID2(1:MRIPars.np1(2),:,:);

% Remove readout FOV offset
[p2,~,~] = ndgrid(1:1:MRIPars.np1(2),ones(1,MRIPars.np3(2)),ones(1,MRIPars.np2(2)));
FID2 = FID2.*exp(2*pi*1i*p2*(MRIPars.FOV1offset(2)/MRIPars.FOV1(2)));
MRIPars.FOV1offset(2) = 0.0;

MRI2 = zeros(MRIPars.np1(2),MRIPars.np2(2),MRIPars.np3(2));
for c1 = 1:MRIPars.np3(2);
    MRI2(:,:,c1) = abs(fftshift(fft2(squeeze(FID2(:,c1,:)))));
end;

figure(1);
subplot(3,2,1), imshow(squeeze(MRI1(:,:,round(MRIPars.np3(1)/2))),[]);
title('3D MRI - XYZ');
subplot(3,2,2), imshow(squeeze(MRI2(:,:,round(MRIPars.np3(2)/2))),[]);
title('MSME');
subplot(3,2,3), imshow(squeeze(MRI1(:,round(MRIPars.np2(1)/2),:)),[]);
subplot(3,2,4), imshow(squeeze(MRI2(:,round(MRIPars.np2(2)/2),:)),[]);

subplot(3,2,5), imshow(squeeze(MRI1(round(MRIPars.np1(1)/2),:,:)),[]);
subplot(3,2,6), imshow(squeeze(MRI2(round(MRIPars.np1(2)/2),:,:)),[]);

disp('MSME image orientation (read, phase, slice) options : ');
disp('1. Axial    - (X, Y, Z)');
disp('2. Axial    - (Y, X, Z)');
disp('3. Coronal  - (Z, X, Y)');
disp('4. Coronal  - (X, Z, Y)');
disp('5. Sagittal - (Z, Y, X)');
disp('6. Sagittal - (Y, Z, X)');
MSMEorient = input('Give MSME image orientation [1] : ');
if isempty(MSMEorient)
    MSMEorient = 1;
end;

switch MSMEorient
    case 1
        % Axial - (X, Y, Z)
        MRIPars.orient{2} = [1 2 3];
    case 2
        % Axial - (Y, X, Z)
        MRIPars.orient{2} = [2 1 3];
    case 3
        % Coronal - (Z, X, Y)
        MRIPars.orient{2} = [2 3 1];
    case 4
        % Coronal - (X, Z, Y)
        MRIPars.orient{2} = [1 3 2];
    case 5
        % Sagittal - (Z, Y, X)
        MRIPars.orient{2} = [3 2 1];
    case 6
        % Sagittal - (Y, Z, X)
        MRIPars.orient{2} = [3 1 2];
end;

% Change image orientation
MRI2 = permute(MRI2,abs(MRIPars.orient{2}));
np = [MRIPars.np1(2) MRIPars.np2(2) MRIPars.np3(2)];
FOV = [MRIPars.FOV1(2) MRIPars.FOV2(2) MRIPars.FOV3(2)];
FOVoffset = [MRIPars.FOV1offset(2) MRIPars.FOV2offset(2) MRIPars.FOV3offset(2)];
np = np(abs(MRIPars.orient{2}));
FOV = FOV(abs(MRIPars.orient{2}));
FOVoffset = FOVoffset(abs(MRIPars.orient{2}));
MRIPars.np1(2) = np(1); MRIPars.np2(2) = np(2); MRIPars.np3(2) = np(3);
MRIPars.FOV1(2) = FOV(1); MRIPars.FOV2(2) = FOV(2); MRIPars.FOV3(2) = FOV(3);
MRIPars.FOV1offset(2) = FOVoffset(1); MRIPars.FOV2offset(2) = FOVoffset(2); MRIPars.FOV3offset(2) = FOVoffset(3);

figure(1);
subplot(3,2,1), imshow(squeeze(MRI1(:,:,round(MRIPars.np3(1)/2))),[]);
title('3D MRI');
subplot(3,2,2), imshow(squeeze(MRI2(:,:,round(MRIPars.np3(2)/2))),[]);
title('MSME');
subplot(3,2,3), imshow(squeeze(MRI1(:,round(MRIPars.np2(1)/2),:)),[]);
subplot(3,2,4), imshow(squeeze(MRI2(:,round(MRIPars.np2(2)/2),:)),[]);

subplot(3,2,5), imshow(squeeze(MRI1(round(MRIPars.np1(1)/2),:,:)),[]);
subplot(3,2,6), imshow(squeeze(MRI2(round(MRIPars.np1(2)/2),:,:)),[]);

% Perform image flips
MRIFlip1 = input('Flip X direction (Y/[N]) : ');
if isempty(MRIFlip1 > 0)
    MRIFlip1 ='N';
end;

MRIFlip2 = input('Flip Y direction (Y/[N]) : ');
if isempty(MRIFlip2 > 0)
    MRIFlip2 ='N';
end;

MRIFlip3 = input('Flip Z direction (Y/[N]) : ');
if isempty(MRIFlip3 > 0)
    MRIFlip3 ='N';
end;
    
if ((MRIFlip1 == 'Y') || ((MRIFlip1 == 'y')))
    MRI2 = MRI2(MRIPars.np1(2):-1:1,:,:);
    % Change slice offset after flipping first dimension
    MRIPars.FOV1offset(2) = -1.0*MRIPars.FOV1offset(2);
end;
if ((MRIFlip2 == 'Y') || ((MRIFlip2 == 'y')))
    MRI2 = MRI2(:,MRIPars.np2(2):-1:1,:);
    % Change slice offset after flipping second dimension
    MRIPars.FOV2offset(2) = -1.0*MRIPars.FOV2offset(2);
end;
if ((MRIFlip3 == 'Y') || ((MRIFlip3 == 'y')))
    MRI2 = MRI2(:,:,MRIPars.np3(2):-1:1);
    % Change slice offset after flipping third dimension
    MRIPars.FOV3offset(2) = -1.0*MRIPars.FOV3offset(2);
end;

figure(1);
subplot(3,2,1), imshow(squeeze(MRI1(:,:,round(MRIPars.np3(1)/2))),[]);
title('3D MRI');
subplot(3,2,2), imshow(squeeze(MRI2(:,:,round(MRIPars.np3(2)/2))),[]);
title('MSME');
subplot(3,2,3), imshow(squeeze(MRI1(:,round(MRIPars.np2(1)/2),:)),[]);
subplot(3,2,4), imshow(squeeze(MRI2(:,round(MRIPars.np2(2)/2),:)),[]);

subplot(3,2,5), imshow(squeeze(MRI1(round(MRIPars.np1(1)/2),:,:)),[]);
subplot(3,2,6), imshow(squeeze(MRI2(round(MRIPars.np1(2)/2),:,:)),[]);

% Possible regridding choices
disp('Reformating options: ');
TextMessage1 = ['FOV = [' num2str(MRIPars.FOV1(1)) ', ' num2str(MRIPars.FOV2(1)) ...
    ', ' num2str(MRIPars.FOV3(1)) '] mm'];
TextMessage2 = ['Matrix option 1 = [' num2str(MRIPars.np1(1)) ', ' num2str(MRIPars.np2(1)) ...
    ', ' num2str(MRIPars.np3(1)) ']'];
TextMessage3 = ['Matrix option 2 = [' num2str(MRIPars.np1(2)) ', ' num2str(MRIPars.np2(2)) ...
    ', ' num2str(MRIPars.np3(1)) ']'];
disp(TextMessage1); disp(TextMessage2); disp(TextMessage3);

MatrixOption = input('Give matrix option ([1]/2) : ');
if isempty(MatrixOption)
    MatrixOption = 1;
end;

% Image matching through regridding
switch MatrixOption
    case 1
        p1 = -0.5*MRIPars.FOV1(1):MRIPars.FOV1(1)/(MRIPars.np1(1)-1):0.5*MRIPars.FOV1(1);
        p2 = -0.5*MRIPars.FOV2(1):MRIPars.FOV2(1)/(MRIPars.np2(1)-1):0.5*MRIPars.FOV2(1);
        p3 = -0.5*MRIPars.FOV3(1):MRIPars.FOV3(1)/(MRIPars.np3(1)-1):0.5*MRIPars.FOV3(1);
    case 2
        p1 = -0.5*MRIPars.FOV1(1):MRIPars.FOV1(1)/(MRIPars.np1(2)-1):0.5*MRIPars.FOV1(1);
        p2 = -0.5*MRIPars.FOV2(1):MRIPars.FOV2(1)/(MRIPars.np2(2)-1):0.5*MRIPars.FOV2(1);
        p3 = -0.5*MRIPars.FOV3(1):MRIPars.FOV3(1)/(MRIPars.np3(1)-1):0.5*MRIPars.FOV3(1);
end;
[p1_1,p2_1,p3_1] = ndgrid(p1,p2,p3);

p1 = -0.5*MRIPars.FOV1(2):MRIPars.FOV1(2)/(MRIPars.np1(2)-1):0.5*MRIPars.FOV1(2);
p2 = -0.5*MRIPars.FOV2(2):MRIPars.FOV2(2)/(MRIPars.np2(2)-1):0.5*MRIPars.FOV2(2);
p3 = -0.5*MRIPars.FOV3(2):MRIPars.FOV3(2)/(MRIPars.np3(2)-1):0.5*MRIPars.FOV3(2);
p1 = p1 + MRIPars.FOV1offset(2);
p2 = p2 + MRIPars.FOV2offset(2);
p3 = p3 + MRIPars.FOV3offset(2);
[p1_2,p2_2,p3_2] = ndgrid(p1,p2,p3);

MRI2_regrid = griddata(p1_2,p2_2,p3_2,MRI2,p1_1,p2_1,p3_1);

coor1 = find(isnan(MRI2_regrid) > 0);
MRI2_regrid(coor1) = 0;
coor2 = find(isinf(MRI2_regrid) > 0);
MRI2_regrid(coor2) = 0;

figure(2);
subplot(3,2,1), imshow(squeeze(MRI1(:,:,round(MRIPars.np3(1)/2))),[]);
subplot(3,2,2), imshow(squeeze(MRI2_regrid(:,:,round(MRIPars.np3(1)/2))),[]);

subplot(3,2,3), imshow(squeeze(MRI1(:,round(MRIPars.np2(1)/2),:)),[]);
subplot(3,2,4), imshow(squeeze(MRI2_regrid(:,round(MRIPars.np2(1)/2),:)),[]);

subplot(3,2,5), imshow(squeeze(MRI1(round(MRIPars.np1(1)/2),:,:)),[]);
subplot(3,2,6), imshow(squeeze(MRI2_regrid(round(MRIPars.np1(1)/2),:,:)),[]);

% Copy MSME directory name and 3D MRI parameters to new directory
coor1 = find(file1 == '\');
file1dir = file1(1:coor1(end));

coor2 = find(file2 == '\');
file2dir = file2(1:coor2(end)-1);

file3dir = [file2dir '_converted'];
warning('off'); mkdir(file3dir); warning('on');
file3 = [file3dir '\fid'];

file1par = [file1dir 'method'];
copyfile(file1par,file3dir);

% Modify parameter file for new matrix dimensions
file3par = [file3dir '\method'];
fileparID = fopen(file3par,'a');
output1 = '##$PVM_Matrix=( 3 )\n';
output2 = [num2str(size(MRI2_regrid,1)) ' ' num2str(size(MRI2_regrid,2)) ' ' num2str(size(MRI2_regrid,3)) '\n'];
fprintf(fileparID,output1);
fprintf(fileparID,output2);
fclose(fileparID);

FID2i = ifftshift(ifftn(ifftshift(MRI2_regrid)));
FID2i = reshape(FID2i,1,[]);
FID2c(1:2:2*length(FID2i)) = real(FID2i);
FID2c(2:2:2*length(FID2i)) = imag(FID2i);

fileID3 = fopen(file3,'w+');
fwrite(fileID3, FID2c, 'long');
fclose(fileID3);

