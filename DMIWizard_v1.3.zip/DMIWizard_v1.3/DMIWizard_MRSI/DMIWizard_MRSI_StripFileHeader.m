function [nb,nt,np] = DMIWizard_MRSI_StripFileHeader(openfile)

% Read file header
FileHeader = fread(openfile,8,'long');

%************************************
% File header structure:
% 1 = number of blocks
% 2 = number of traces per block
% 3 = number of elements per trace
%************************************
nb = FileHeader(1);
nt = FileHeader(2);
np = FileHeader(3);

disp(' ');
disp('File header information: ');
dd1 = ['Number of blocks per file = ' num2str(nb)];
dd2 = ['Number of traces per block = ' num2str(nt)];
dd3 = ['Number of points per trace = ' num2str(np)];
disp(dd1); disp(dd2); disp(dd3); disp(' ');