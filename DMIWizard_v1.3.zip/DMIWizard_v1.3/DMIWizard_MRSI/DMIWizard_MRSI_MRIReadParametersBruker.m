function [FOV1mri,FOV2mri,FOV3mri,np1mri,np2mri,np3mri]  = DMIWizard_MRSI_MRIReadParametersBruker(MRIParameterFileBruker)

% Reading entire method parameter file
fileID = fopen(MRIParameterFileBruker,'r');
Data = textscan(fileID, '%s', 'delimiter', '\n', 'whitespace', '');
CStr = Data{1};

% Scanning for particular parameters
% 1. FOV1
IndexFOV = strfind(CStr, '##$PVM_FovCm');
Index = find(~cellfun('isempty', IndexFOV), 1);
LineFOV = char(CStr(Index+1));

FOV = str2num(LineFOV);
FOV1mri = 10*FOV(1);        % cm -> mm
FOV2mri = 10*FOV(2);        % cm -> mm
FOV3mri = 10*FOV(3);        % cm -> mm

% 2. Matrix size
IndexMatrixSize = strfind(CStr, '##$PVM_Matrix');
% PVM_Matrix may occur twice in case of MSME to 3D MRI conversion
Index = find(~cellfun('isempty', IndexMatrixSize));
Index = Index(end);
LineMatrixSize = char(CStr(Index+1));

MatrixSize = str2num(LineMatrixSize);
np1mri = MatrixSize(1);
np2mri = MatrixSize(2);
np3mri = MatrixSize(3);

% Display parameters
disp(' ');
disp('Reading Bruker 3D MRI parameters ...');
dd1 = ['[FOV1, FOV2, FOV3] = [ ' num2str(round(FOV1mri)) ', ' num2str(round(FOV2mri)) ', ' num2str(round(FOV3mri)) '] mm'];
dd2 = ['[np1, np2, np3] = [ ' num2str(round(np1mri)) ', ' num2str(round(np2mri)) ', ' num2str(round(np3mri)) ']'];
disp(dd1); disp(dd2);
disp(' ');

fclose(fileID);