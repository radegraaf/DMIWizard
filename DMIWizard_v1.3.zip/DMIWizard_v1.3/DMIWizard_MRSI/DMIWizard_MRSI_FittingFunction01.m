function outdata = DMIWizard_MRSI_FittingFunction01(cf,~,handles,coor)

%--------------------------------------------------------------------------
% Function for spectral fitting with (distorted) Gaussian or Lorentzian
% lines, low-order baseline and prior knowledge limits on line widths
% and line shifts.
%
% Called by DMIWizard_Fitting.m
%--------------------------------------------------------------------------
dt = 1/handles.sw;                  % Dwell-time (ms)
time = 0:dt:(handles.np-1)*dt;      % Time base (ms)
time = reshape(time,[],1);

% Calculate lineshape distortion, common to all resonances
if (handles.LineShapeDistortion > 0)
    % Extract parameters related to lineshape distortion
    cfLSD = cf(end-3*handles.LineShapeDistortion+1:1:end);
    FIDLSD = 0;
    switch handles.LineShapeDistortion
        case 1
            % Single-component (non-distored, shifted) signal
            M0LSD = cfLSD(1);
            nuLSD = 0.001*cfLSD(2);
            phsLSD = cfLSD(3);
            FIDLSD = M0LSD*exp(2*pi*1i*nuLSD*time).*exp(1i*phsLSD);
        case 2
            % Double-component signal
            M0LSD1 = cfLSD(1); M0LSD2 = cfLSD(4);
            nuLSD1 = 0.001*cfLSD(2); nuLSD2 = 0.001*cfLSD(5);
            phsLSD1 = cfLSD(3); phsLSD2 = cfLSD(6);
            FIDLSD = M0LSD1*exp(2*pi*1i*nuLSD1*time).*exp(1i*phsLSD1) + ...
                M0LSD2*exp(2*pi*1i*(nuLSD1+nuLSD2)*time).*exp(1i*phsLSD2);            
        case 3
            % Triple-component signal
            M0LSD1 = cfLSD(1); M0LSD2 = cfLSD(4); M0LSD3 = cfLSD(7);
            nuLSD1 = 0.001*cfLSD(2); nuLSD2 = 0.001*cfLSD(5); nuLSD3 = 0.001*cfLSD(8);
            phsLSD1 = cfLSD(3); phsLSD2 = cfLSD(6); phsLSD3 = cfLSD(9);
            FIDLSD = M0LSD1*exp(2*pi*1i*nuLSD1*time).*exp(1i*phsLSD1) + ...
                M0LSD2*exp(2*pi*1i*(nuLSD1+nuLSD2)*time).*exp(1i*phsLSD2) + ...
                M0LSD3*exp(2*pi*1i*(nuLSD1+nuLSD3)*time).*exp(1i*phsLSD3); 
    end;
    % Normalize lineshape distortion based on first datapoint
    realFID1 = (10^-8)*round(real((10^8)*FIDLSD(1)));
    FIDLSD = FIDLSD/realFID1;
else
    FIDLSD = ones(handles.np,1);
end;

% Extract phase related parameters
switch handles.PhaseSelection
    case 'Zero-order phase'
        cfPH(1) = cf(end-3*handles.LineShapeDistortion-handles.BaselineOrder-1:1:...
            end-3*handles.LineShapeDistortion-handles.BaselineOrder-1);
        cfPH(2) = 0.0;
    case 'First-order phase'
        if (handles.FirstOrderFix > 0)
            cfPH(1) = cf(end-3*handles.LineShapeDistortion-handles.BaselineOrder-1);
            cfPH(2) = handles.FirstOrderPhaseEstimate;
        else
            cfPH(1:2) = cf(end-3*handles.LineShapeDistortion-handles.BaselineOrder-2:1:...
                end-3*handles.LineShapeDistortion-handles.BaselineOrder-1);
        end;
end;

% Determine signal for which full linewidth is fitted, instead of 
% the linewidth differences. Signal with GroupLWLink < 0 indicates
% signal for which full linewidth is fitted.
coorFullLW = find(handles.PKData.GroupLWLink(:,1) < 0);
FullLW = cf(3*coorFullLW);

count = 1; specfit = 0;
nu = zeros(1,handles.nres);
T2 = zeros(1,handles.nres);
for c1 = 1:handles.nres;      
    % Amplitude, M0
    M0 = cf(count)*handles.BasisFID(:,c1)*10^handles.ZyScale;
    % Frequency shift
    nu(c1) = 0.001*cf(count+1);
    % Line width
    if (c1 == coorFullLW)
        DeltaLW = 0.0;              % Fit full linewidth
    else
        DeltaLW = cf(count+2);      % Fit full + difference linewidth
    end;
    
    switch handles.LineShapeSelection
        case 'Gaussian'
            T2(c1) = 2000*sqrt(log(2))/(pi*(FullLW + DeltaLW));
        case 'Lorentzian'
            T2(c1) = 1000/(pi*(FullLW + DeltaLW));
    end;

    count = count + 3;
    
    switch handles.LineShapeSelection
        case 'Gaussian'
            FIDfit = M0.*exp(2*pi*1i*nu(c1)*time).*exp(-time.*time/(T2(c1)*T2(c1)));
        case 'Lorentzian'
            FIDfit = M0.*exp(2*pi*1i*nu(c1)*time).*exp(-time/T2(c1));
    end;
    
    % Add phase term
    GroupCSkHz = -0.001*(handles.RFCenterFrequency - handles.PKData.GroupCS(c1,1))*handles.nu0;
    nutotal = GroupCSkHz + 0.001*nu(c1);
    FIDPH = exp(1i*(pi/180)*cfPH(1) + 1i*(pi/180)*cfPH(2)*nutotal);
    FIDfit = FIDfit.*FIDPH;
    
    % Apply lineshape distortion in time domain
    FIDfit = FIDfit.*FIDLSD;
    
    % Apodization and Fourier transformation
    FIDapodized = DMIWizard_MRSI_Apodization(reshape(FIDfit,[],1),handles);
    specfit1 = fftshift(fft(FIDapodized,handles.npzf));
    
    specfit = specfit + specfit1;
end;

% Skip over phase correction entries
switch handles.PhaseSelection
    case 'Zero-order phase'
        count = count + 1;
    case 'First-order phase'
        if (handles.FirstOrderFix > 0)
            count = count + 1;
        else
            count = count + 2;
        end;
end;
specfit = DMIWizard_MRSI_PhaseCorrection(specfit,handles);

% Add low-order baseline
freq = -0.5*handles.sw:handles.sw/(handles.npzf-1):0.5*handles.sw;
freq = reshape(freq,[],1);
switch handles.BaselineOrder
    case 0
        % Constant offset baseline
        specfit = specfit + (10^handles.ZyScale)*cf(count);
    case 1
        % Linear baseline
        specfit = specfit + (10^handles.ZyScale)*(cf(count) + cf(count+1)*freq);
    case 2
        % Second-order baseline
        specfit = specfit + (10^handles.ZyScale)*(cf(count) + cf(count+1)*freq + cf(count+2)*freq.*freq);
    otherwise
        % No baseline
end;

outdata = real(specfit(coor));