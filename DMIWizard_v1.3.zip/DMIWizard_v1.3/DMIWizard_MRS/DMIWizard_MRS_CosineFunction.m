function outdata = DMIWizard_MRS_CosineFunction(coeff,ph)

outdata = coeff(1)*cos((pi/180)*(ph-coeff(2)));