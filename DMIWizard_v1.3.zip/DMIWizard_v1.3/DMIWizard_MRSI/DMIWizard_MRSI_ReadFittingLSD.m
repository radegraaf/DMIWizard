function [LSD, ErrorFlag] = DMIWizard_MRSI_ReadFittingLSD(handles)

%**************************************************************************
% DMIWizard_MRSI_ReadFittingLSD.m
%
% Read lineshape distortion-related results from disk.
%**************************************************************************

if ismac
    % Mac plaform
    coor = find(handles.MRSIPath == '/');
elseif isunix
    % Linux plaform
    coor = find(handles.MRSIPath == '/');
elseif ispc
    % Windows platform
    coor = find(handles.MRSIPath == '\');
end               
MRSIPathDir = handles.MRSIPath(1:max(coor));
    
file = [MRSIPathDir 'FittingResultsLSD.txt'];
fileID = fopen(file,'r+');
LSD = zeros(3*handles.MaxLSD,handles.np1,handles.np2,handles.np3);
ErrorFlag = 0;
if (fileID > 0)
    datain = fscanf(fileID,'%g %g %g %g %g %g %g %g %g %g %g %g',[12 Inf]);
    fclose(fileID);
    
    for c1 = 1:3*handles.MaxLSD;
        LSD(c1,:,:,:) = reshape(datain(c1+3,:),handles.np1,handles.np2,handles.np3);
    end;
    
    [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
    TextOutput0 = [OperationTime ' - Reading distortion-related spectral fitting results from ' file];
    disp(TextOutput0);
else
    ErrorFlag = 1;
    LSD = [];
end;