function DMIWizard_MRSI_WriteFittingBaseline(handles)

%**************************************************************************
% DMIWizard_MRSI_WriteFittingBaseline.m
%
% Write spectral fitting baseline results to disk.
%**************************************************************************

% Extract directory for saving purposes
if ismac
    % Mac plaform
    coor = find(handles.MRSIPath == '/');
elseif isunix
    % Linux plaform
    coor = find(handles.MRSIPath == '/');
elseif ispc
    % Windows platform
    coor = find(handles.MRSIPath == '\');
end               
MRSIPathDir = handles.MRSIPath(1:max(coor));

% Generate index matrix for position
[pos1,pos2,pos3] = ndgrid(1:handles.np1,1:handles.np2,1:handles.np3);

FittingResults = [reshape(pos1,1,[]); reshape(pos2,1,[]); reshape(pos3,1,[])]; 
FittingResults = [FittingResults; reshape(handles.LCMFit.Baseline(1,:,:,:),1,[])];  % Offset
FittingResults = [FittingResults; reshape(handles.LCMFit.Baseline(2,:,:,:),1,[])];  % Linear
FittingResults = [FittingResults; reshape(handles.LCMFit.Baseline(3,:,:,:),1,[])];  % Quadratic

file = [MRSIPathDir '\FittingResultsBaseline.txt'];
fileID = fopen(file,'w+');
fprintf(fileID,'%2.0f   %2.0f   %2.0f   %6.3f   %6.3f   %6.3f\n',FittingResults);
fclose(fileID);