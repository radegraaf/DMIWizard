% DMIWizardVersionModifications.m

% V1.0 to V1.1
%-------------
% 20190917 -    Extended tooltip strings for baseline and integration 'Define' 
%               buttons and updated the manual.
% 20190917 -    In 1D MRS menu expanded Bruker parameter files to include
%               TopSpin 'acqus' file (in addition to ParaVision 'acqp').
% 20190917 -    Added big-endian or long data format check box. This is primarily
%               for reading older Bruker and Varian data.

% 20190920 -    Fixed a spatial phase roll in fid.lpp due to incorrect
%               fftshift in DMIWizard_MRSI_FFT.m.

% 20190924 -    Removed flip() function calls to enhance compatibility with
%               older Matlab versions.
% 20190924 -    Removed rescale() function calls to enhance compatibility with
%               older Matlab versions.
% 20190924 -    Provided color and font initialization file (DMIWizardSettings.txt)
%               to enhance user customization and cross-platform compatibility.

% 20190930 -    Improved metabolic map interpolation by forcing the size of
%               the maps to become (DMI size x MRI size) in case that the
%               MRI size is not an integer multiple of the DMI size.

% 20191001 -    Forced the recalculation and replacement of the original FID
%               data following Linear Prediction and Auto Phasing in order
%               to retain the phase information.

% 20191002 -    Added default file path option to DMIWizardSettings.txt.

% 20191004 -    Added k-space value rounding (Bruker data) to four digits 
%               in order to prevent machine precision issues on different platforms.

% 20191009 -    For zero or negative linear prediction data points, linear
%               prediction is bypassed. The data is still written to .lpp
%               file.

% 20191121 -    Generate a phase correction bypass and warning message when
%               the first FID data point following LP has zero intensity (which
%               would result in NaN during phase correction).

% 20191210 -    Solved an error when linear prediction data points = 0 in
%               the presence of multiple receivers.

% 20191227 -    Changed the display of MRSI grids. Instead of displaying
%               each MRSI spectrum in its own subplot, data is now
%               displayed as 1D traces - this decreases the display time
%               by > 20-fold.

% 20200102 -    Solved an error during Bruker 3D MRI file loading when the
%               actual and indicated file dimensions are not in agreement.

% 20200102 -    Fixed a problem where the frequency aligment fitting option
%               was not assigned to the proper parameter.


% V1.1 to V1.2
%-------------
% 20200105 -    Added an Advanced Mapping option (checkbox) to provide the
%               user with control of the metabolic map vertical scale and
%               allow conversion from arbitrary intensity to concentration.

% 20200107 -    Fixed a problem where a parameter file would not be read if
%               the base filename is without an extension.

% 20200312 -    Added an option (checkbox) for baseline correction before 
%               integration during Parameter Mapping. The polynomial
%               fitting order is currently set to 1 (linear) in
%               DMIWizard_MRSI_ParameterMapping.m. Since not every spectrum
%               can be manually inspected, it is recommended to not use
%               higher-order baseline correction.

% V1.2 to V1.3
%-------------
% 20210219 �    Added a Spectral Fitting option (checkbox) to provide the user 
%               with a GUI for spectral quantification using least-squares-based 
%               spectral fitting.

% 20210311 -    Fixed the spectral zoom used for automatic phase correction.

% 20210830 -    Fixed an issue where spectral fitting parameters were read incorrectly
%               from file when the baseline order or line shape distortion were changed
%               during single voxel fit.

% 20210830 -    Changed the definition of the lineshape distortion function.
%               The first frequency component is now set by the maximum
%               global frequency offset, whereby subsequent frequencies are
%               set as delta's relative to that frequency.

% 20210915 -    Added a DICOM saving option for metabolic maps (as an intermediate step to
%               allow saving in multiple formats).

% 20210923 -    Fixed an issue when the MRI slice number was too high due to
%               a previously loaded larger MRI dataset and a previously
%               selected orientation with a larger matrix dimension.

% 20210923 -    Added the option for an extended MRI matrix size through
%               zero-filling.

% 20210924 -    Changed the way linewidths for different compounds are fitted.
%               The full linewidth is fitted for only one compound (for which
%               PKData.GroupLWLink < 0), whereby the linewidth for the
%               remaining signals is fitted as a difference. This approach
%               allows one to fit a wide range of linewidths WITHOUT a
%               large linewidth difference between signals. The option to
%               link/fix linewidths is then redundant and has been removed. 

% 20210924 -    Fixed an issue where the RF Center Frequency is not set/known 
%               before attempting to start a spectral fit.

% 20210924 -    Extended the data format list to include Bruker-PV360, which has a
%               different data format (float64) compared to Bruker-PV6 (long).

% 20210924 -    Fixed an issue where the MRSI voxel location (red square) would
%               not display on the MRI for a single-slice MRI.

% 20211001 -    Disabled FT-based convolution of metabolic maps due to
%               undesirable features in the presence of large amplitude changes.

% 20211001 -    Redesigned the Advanced Mapping GUI to allow selection for
%               metabolic maps, ROI maps and other files with arbitrary
%               names. The Advanced Mapping GUI is closed when there is a
%               potential mismatch between ROI, DMI and MRI matrix sizes.

% 20220110 -    Added the option for spatial shifting of DMI and/or MRI.
%               The presence of the files DMIshift.txt or MRIshift.txt in 
%               the DMI or MRI data directories will trigger an automatic
%               read of the three shift values (in pixels) during data
%               loading. The spatial shift is executed during FFT. Note -
%               ideally this is done BEFORE any advanced data processing
%               (e.g. fitting, phasing) is performed.

% 20220112 -    Fixed an issue where changing the number of spectral points
%               produced error messages and incorrect spatial shifts. Now,
%               upon changing the number of spectral points a full DMI FFT
%               is performed followed by spectral display.

% 20220112 -    Added the option for spatial shifting of metabolic maps in
%               the Advanced Mapping menu. The maps can be shifted in any
%               dimension by indicating the Map Shift (in pixels, integer
%               value). This option is most useful on data that has already
%               undergone advanced processing (e.g. fitting) and for which
%               an pre-processing data shift would invalidate the fitting
%               results. The philosophy here is to calculate and shift the 
%               metabolic maps, saving them at each step, before a final
%               display/overlay with a (shifted) MRI.

% 20220628 -    When working with Microsoft Excel files, Matlab can produce
%               an error related to xlsread:
%               'Excel Worksheet could not be activated.'
%               This needs to be solved in Excel, not Matlab:
%               1. Open Excel
%               2. Go to options
%               3. Under Advanced > General check the box with 'Ignore
%               other applications that use DDE'.

% 20220705 -    Fine-tuning of the spectral fitting algorithm.
%               1. Option to fix the first-order phase to a constant value
%               2. Additional parameters are now written to and read from
%               the parameter file, including threshold, first-order phase and
%               global offset.
%               3. All fitting parameters from a previous run are automatically 
%               populated when clicking 'Voxel-specific prior knowledge.'.
%               This includes loading of the PK Excel file.
%               Fitting convergence can be improved by:
%               1. Fitting data with no voxel-specific PK and zero-order phase.
%               2. Then select voxel-specific PK and first-order phase (not fixed).
%               3. Fix the first-order phase and run again.

% 20221006 -    Force the fitting results to zero for voxels that are below the
%               intensity threshold. This is done after all the fitting is
%               performed, but before the results are written to disk.
%               This option is relevant when a fitting session is performed
%               following a previous fitting session during which the
%               intensity threshold was lower than the current value.
%               If 'Single Voxel Fit' is selected, this routine is bypassed to
%               allow single spectra below the threshold to be fitted and included.
%               Note that a subsequent fit of all voxels will remove any
%               fitting results for single voxels below the threshold. In
%               other words, single voxels below the threshold should
%               always be pursued AFTER the fitting of 'All' voxels is
%               completed.