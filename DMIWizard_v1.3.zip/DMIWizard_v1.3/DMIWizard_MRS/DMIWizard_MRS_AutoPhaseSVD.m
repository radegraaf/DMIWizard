function FIDsvd = DMIWizard_MRS_AutoPhaseSVD(FID, handles, FreqBoundary01, FreqBoundary02)

%**************************************************************
% Maximum number of SVD points - chosen to minimize
% truncation while maintaining low memory and calculation
% time requirements.
%**************************************************************
npsvd = 2048;
npfid = length(FID);

if (npsvd <= npfid)
    % FID is longer than npsvd > truncate FID
    FID = FID(1:npsvd);
else
    % FID is shorter than npsvd > reduce npsvd
    npsvd = npfid;
end;

nHSVD = round(0.1*npsvd);              % Maximum number of SVD components

tacq = npsvd/(1000*handles.sw);        % Acquisition time (in s)
dt = tacq/npsvd;                       % Dwell-time (in s)
time = 0:dt:(npsvd-1)*dt;              % Time base of FID
time = reshape(time,npsvd,1);

Lmax = round(0.4*npsvd);               % Dimension 1 for LxM SVD matrix
Mmax = npsvd+1-Lmax;                   % Dimension 2 for LxM SVD matrix

%*****************
% Allocate memory
%*****************
U = zeros(Lmax,Lmax);
V = zeros(Mmax,Mmax);
S = zeros(Lmax,Mmax);

H = zeros(Lmax,Mmax);

%**********************************************
% Create Hankel matrix from original FID data
%**********************************************
for L = 1:1:Lmax;
    M = 1:1:Mmax;
    H(L,M) = FID(L+M-1);
end;

%**********************************************
% Perform SVD on Hankel matrix
%**********************************************
[U,S,V] = svd(H);

Uup = zeros(Lmax-1,nHSVD);
Udown = zeros(Lmax-1,nHSVD);

%**********************************************
% Calculate truncated SVD matrix
%**********************************************
Utr = U(:,1:1:nHSVD);
Str = S(:,1:1:nHSVD);
Vtr = V(:,1:1:nHSVD);

for kk1 = 2:Lmax;
   for kk2 = 1:nHSVD;
      Uup(kk1-1,kk2) = Utr(kk1,kk2);
      Udown(kk1-1,kk2) = Utr(kk1-1,kk2);
   end;
end;

Z = pinv(Udown)*Uup;

q = eig(Z);
q = log(q);

%*****************************************************************
% Determine frequencies and T2 constants from D to be used
% as good initial estimates for the final least-squares fitting.
%*****************************************************************

% Frequency (in Hz)
frq = imag(q)/(2*pi*dt);
% Time constant (in s)
decay = real(q)/dt;

%******************************************************************
% Determine amplitudes (and phase) estimates
%******************************************************************
basis = zeros(npsvd,nHSVD);

% Calculate basis functions
for kk1 = 1:1:nHSVD;
    basis(:,kk1) = exp((decay(kk1)+2*pi*1i*frq(kk1))*time);
end;

% Amplitude estimates
ampcomplex = pinv(basis)*FID;
 
amp = abs(ampcomplex);
phs = atan2(imag(ampcomplex),real(ampcomplex));

%*****************************************************************
% Remove extremely broad (baseline) and narrow (spikes) lines
%*****************************************************************
LWHigh = 250;               % Maximum acceptable linewidth (in Hz)
LWLow = 0.1;                % Minimum acceptable linewidth (in Hz)
T2Low = 1/(pi*LWHigh);      % Lowest acceptable T2 value (in s)
T2High = 1/(pi*LWLow);      % Highest acceptable T2 value (in s)

decaycoor = find((decay > (-1/T2Low)) & (decay < (-1/T2High)));

frqred = frq(decaycoor);
decayred = decay(decaycoor);
ampred = amp(decaycoor);
phsred = phs(decaycoor);

%*******************************************************************
% Only retain resonances in the frequency range of interest
%*******************************************************************
frqcoor = find(((frqred > 1000*FreqBoundary01) & (frqred < 1000*FreqBoundary02)));

frqROI = frqred(frqcoor);
decayROI = decayred(frqcoor);
ampROI = ampred(frqcoor);
phsROI = phsred(frqcoor);

%*****************************************************************
% Reconstruct the total fitted FID
%*****************************************************************
time = 0:dt:(npfid-1)*dt;              % Original time base of FID
time = reshape(time,npfid,1);

FIDsvd = 0;

for kk1 = 1:length(frqROI);
    FIDsvd = FIDsvd + ampROI(kk1)*exp(2*pi*1i*frqROI(kk1)*time).*exp(time*decayROI(kk1)).*exp(1i*phsROI(kk1));
end;