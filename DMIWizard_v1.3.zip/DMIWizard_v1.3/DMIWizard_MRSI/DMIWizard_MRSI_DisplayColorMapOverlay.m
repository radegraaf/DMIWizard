function DMIWizard_MRSI_DisplayColorMapOverlay(handles)

OutputFileName = handles.OutputFileName;

if (max(max(handles.ROI)) == 0)
    handles.ROI = 0*handles.ROI + 1;
end;

% Generate extended and (optionally) extrapolated metabolic maps
% to match the MRI resoltuion.
[handles.MetabolicM0mapExpanded,handles.MetabolicM0mapFFTIP,handles.MetabolicM0mapConvIP,...
    handles.MRIsliceExpanded,handles.ROIExpanded] = DMIWizard_MRSI_GenerateInterpolatedMaps(handles);

% % Write extrapolated maps to disk
% OutputFileName = handles.OutputFileName;
% handles.OutputFileName = [OutputFileName '_FFTInterpolated'];
% handles.MMStyle = 'FFT interpolated M0';
% DMIWizard_MRSI_WriteMetabolicMap(handles.MetabolicM0mapFFTIP,handles);

% Write extrapolated maps to disk
[OperationTime,~] = DMIWizard_MRSI_CalculateTime;
TextOutput1 = [OperationTime ' - Convolution kernel width = ' num2str(handles.KernelWidth)];
disp(TextOutput1);

% Write information to processing history file
DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);

handles.OutputFileName = [OutputFileName '_ConvolutionInterpolated'];
handles.MMStyle = 'convolution interpolated M0';
DMIWizard_MRSI_WriteMetabolicMap(handles.MetabolicM0mapConvIP,handles);

% Scale MRI to [0 .. 0.5] and MetabolicM0map to [0.5 .. 1]
ColorScaledM0 = abs(handles.MetabolicM0mapExpanded.*handles.ROIExpanded);
ColorScaledM0 = ColorScaledM0/max(max(ColorScaledM0));
%ColorScaledM0 = ColorScaledM0/3000000;
ColorScaledM0 = 0.5*ColorScaledM0 + 0.5;

ColorScaledMRI = handles.MRIsliceExpanded;
ColorScaledMRI = ColorScaledMRI/max(max(ColorScaledMRI));
ColorScaledMRI = 0.5*ColorScaledMRI;
ColorScaledMRIOrig = ColorScaledMRI;

% Identify coordinates of all points above the threshold
NumericalThreshold = 0.50;
coor2 = find(ColorScaledM0 > NumericalThreshold);

% Replace Above Threshold Points in MRI image
ColorScaledMRI(coor2) = ColorScaledM0(coor2);

% Create new colormap and display modified MRI image
cmap = [gray(128); jet(128)];

fh = figure;
nn = ['M0 map (slice ' num2str(handles.sp3) ' out of ' num2str(handles.np3) ')'];
set(fh,'Name',nn);
imshow(ColorScaledMRIOrig,[0 .5],'InitialMagnification','fit'); colormap(cmap);
hold on;
h = imshow(ColorScaledMRI, [0 1],'InitialMagnification','fit'); colormap(cmap);
hold off;
set(h,'AlphaData',handles.Transparency)

% Show interpolated maps
if (handles.Interpolation > 0)
    
    % Scale interpolated metabolic maps to [0.5 .. 1]
    ColorScaledM0FFTIP = abs(handles.MetabolicM0mapFFTIP.*handles.ROIExpanded);
    ColorScaledM0FFTIP = ColorScaledM0FFTIP/max(max(ColorScaledM0FFTIP));
    ColorScaledM0FFTIP = 0.5*ColorScaledM0FFTIP + 0.5;
    
    ColorScaledMRI = handles.MRIsliceExpanded;
    ColorScaledMRI = ColorScaledMRI/max(max(ColorScaledMRI));
    ColorScaledMRI = 0.5*ColorScaledMRI;
    ColorScaledMRIOrig = ColorScaledMRI;
     
    % Identify coordinates of all points above the threshold
    NumericalThreshold = 0.50;
    coor2 = find(ColorScaledM0FFTIP > NumericalThreshold);
    
    % Replace Above Threshold Points in MRI image
    ColorScaledMRI(coor2) = ColorScaledM0FFTIP(coor2);
       
    fh = figure;
    nn = ['FFT-based, interpolated M0 map (slice ' num2str(handles.sp3) ' out of ' num2str(handles.np3) ')'];
    set(fh,'Name',nn);
    imshow(ColorScaledMRIOrig,[0 .5],'InitialMagnification','fit'); colormap(cmap);
    hold on;
    h = imshow(ColorScaledMRI, [0 1],'InitialMagnification','fit'); colormap(cmap);
    hold off;
    set(h,'AlphaData',handles.Transparency)
    
    % Scale interpolated metabolic maps to [0.5 .. 1]
    ColorScaledM0ConvIP = abs(handles.MetabolicM0mapConvIP.*handles.ROIExpanded);
    ColorScaledM0ConvIP = ColorScaledM0ConvIP/max(max(ColorScaledM0ConvIP));
    %ColorScaledM0ConvIP = ColorScaledM0ConvIP/4000000000;
    ColorScaledM0ConvIP = 0.5*ColorScaledM0ConvIP + 0.5;
    
    ColorScaledMRI = handles.MRIsliceExpanded;
    ColorScaledMRI = ColorScaledMRI/max(max(ColorScaledMRI));
    ColorScaledMRI = 0.5*ColorScaledMRI;
    ColorScaledMRIOrig = ColorScaledMRI;

    % Identify coordinates of all points above the threshold
    NumericalThreshold = 0.50;
    coor2 = find(ColorScaledM0ConvIP > NumericalThreshold);

    % Replace Above Threshold Points in MRI image
    ColorScaledMRI(coor2) = ColorScaledM0ConvIP(coor2);
    
    fh = figure;
    nn = ['Convolution-based, interpolated M0 map (slice ' num2str(handles.sp3) ' out of ' num2str(handles.np3) ')'];
    set(fh,'Name',nn);
    imshow(ColorScaledMRIOrig,[0 0.5],'InitialMagnification','fit'); colormap(cmap);
    hold on;
    h = imshow(ColorScaledMRI, [0 1],'InitialMagnification','fit'); colormap(cmap);
    hold off;
    set(h,'AlphaData',handles.Transparency)

end;