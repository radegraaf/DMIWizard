function handles = DMIWizard_MRS_AutoPhase(handles)

%************************************************************
% Performs automatic phasing of a NMR spectrum.
%
% Only performs zero-order phasing if:
% 1. No AutoPhaseBoundary01.txt file is found - spectral range
% between handles.ZxLow and handles.ZxHigh is used.
% 2. An AutoPhaseBoundaries.txt file is found with 2 entries - 
% spectral range within the file is used.
%
% Performs zero- and first-order phasing if:
% 1. An AutoPhaseBoundaries.txt with 4 entries is found.
% Ideally the two spectral ranges are narrow and well 
% separated. Huge first-order phases as caused by the Bruker 
% digital group delay can NOT be auto phased.
%************************************************************

if isfield(handles,'InvalidEntry') > 0
    if (sum(handles.InvalidEntry) < 1)
        if isfield(handles,'spec') > 0
           % Force zero and first-order phase to be zero
           handles.ph0 = 0;
           %handles.ph1 = 0;
           
           % Fourier transformation
           handles = DMIWizard_MRS_FFT(handles);
            
           % Check for the existence of an AutoPhaseBoundaries.txt file
           if (ispc > 0)
               coor = find(handles.MetaboliteFile == '\');
           else
               coor = find(handles.MetaboliteFile == '/');
           end;
           MetaboliteFileDir = handles.MetaboliteFile(1:max(coor));
          
           AutoPhaseBoundariesFile = [MetaboliteFileDir 'AutoPhaseBoundaries.txt'];
           if (exist(AutoPhaseBoundariesFile,'file') > 0)
               fileID = fopen(AutoPhaseBoundariesFile,'r');
               AutoPhaseBoundaries = fscanf(fileID,'%g',[1 Inf]);
               fclose(fileID);
               
               disp(' ');
               disp('Auto phasing boundaries file AutoPhaseBoundaries.txt found.');
               
               if (mod(numel(AutoPhaseBoundaries),2) > 0)
                   disp('Error: AutoPhaseBoundaries.txt file contains an odd number of boundaries.');
                   disp('Solution: Enter two frequency boundaries for every spectral range.');
               else
                   % Starting from the spectrum (rather than the FID) removes
                   % the digital group delay.
                   FIDPC = DMIWizard_MRS_PhaseCorrection(handles.spec,handles); 
                   FIDPC = ifft(fftshift(FIDPC));
                   FIDPC = FIDPC(1:length(handles.FID));
                        
                   for kk2 = 1:round(0.5*numel(AutoPhaseBoundaries));
                       dd = ['Performing automatic zero-order phase correction on spectral range ' ...
                           num2str(AutoPhaseBoundaries(2*kk2-1)) ' to ' num2str(AutoPhaseBoundaries(2*kk2)) ' kHz.'];
                        disp(dd);
               
                        %*********************************************
                        % Decompose spectrum by SVD
                        %********************************************* 
                        FIDsvd = DMIWizard_MRS_AutoPhaseSVD(FIDPC,handles,min(AutoPhaseBoundaries(2*kk2-1:2*kk2)),max(AutoPhaseBoundaries(2*kk2-1:2*kk2)));
                        FIDsvd(1) = FIDsvd(1)/2;
                        specsvd = fftshift(fft(FIDsvd,handles.npzf));
                        specsvd = reshape(specsvd,handles.npzf,1);
                        
                        figure(3);
                        clf;
                        axes('XDir','reverse','XLim',[min(AutoPhaseBoundaries(2*kk2-1:2*kk2)) max(AutoPhaseBoundaries(2*kk2-1:2*kk2))],'YLim',...
                            [handles.ZyLow handles.ZyHigh],'NextPlot','add');
                        hold on;

                        ff = -0.5*handles.sw:handles.sw/(handles.npzf-1):0.5*handles.sw;
                        specPC = fftshift(fft(FIDPC,handles.npzf));
                        plot(ff,(real(specPC)/(10^handles.ZyScale)),'b',ff,(real(specsvd)/(10^handles.ZyScale)),'r')
                        xlabel('Frequency (kHz)');
                        
                        pause(1);
                        
                        %**********************
                        % Auto phasing loop
                        %**********************
                        count = 1;
                        intspec = zeros(1,360);
                        npb = handles.npb;
                        ph1 = handles.ph1;
                        handles.npb = 0;
                        handles.ph1 = 0;
                        if (kk2 == 1)
                            for kk0 = -179:1:180;
                                handles.ph0 = kk0;
                                specsvdph = DMIWizard_MRS_PhaseCorrection(specsvd, handles);  
                                intspec(count) = sum(real(specsvdph));
                                count = count + 1;
                                clear specsvdph;
                            end;

                            handles.npb = npb;
                            handles.ph1 = ph1;
                            %figure(4); plot(-179:1:180,intspec,'o')
                            [maxvalue,maxpos] = max(intspec);
                            dd = ['Optimal phase = ' num2str(maxpos-180) ' degrees, at frequency offset ' num2str(mean(AutoPhaseBoundaries(2*kk2-1:2*kk2))) ' kHz.'];
                            disp(dd);

                            OptimalPhase(kk2) = maxpos-180;
                            FrequencyOffset(kk2) = mean(AutoPhaseBoundaries(2*kk2-1:2*kk2));
                        else
                            % Center the phase range around the first value
                            % to minimize the effects of phase wrap
                            for kk0 = OptimalPhase(1)-179:1:OptimalPhase(1)+180;
                                handles.ph0 = kk0;
                                specsvdph = MRSPhaseCorrection(specsvd, handles);  
                                intspec(count) = sum(real(specsvdph));
                                count = count + 1;
                                clear specsvdph;
                            end;

                            handles.npb = npb;
                            handles.ph1 = ph1;
                            
                            clear npb ph1;
                            
                            [maxvalue,maxpos] = max(intspec);
                            dd = ['Optimal phase = ' num2str(maxpos-180+OptimalPhase(1)) ' degrees, at frequency offset ' num2str(mean(AutoPhaseBoundaries(2*kk2-1:2*kk2))) ' kHz.'];
                            disp(dd);

                            OptimalPhase(kk2) = maxpos-180+OptimalPhase(1);
                            FrequencyOffset(kk2) = mean(AutoPhaseBoundaries(2*kk2-1:2*kk2));
                        end;
                   end;        
                   
                   % Calculate zero and first-order phases by linear regression
                   if (round(0.5*numel(AutoPhaseBoundaries)) > 1)
                       PhaseValues = polyfit(FrequencyOffset,OptimalPhase,1);
                       
                       handles.ph0 = PhaseValues(2);
                       ph0_Object = findall(0,'Tag','ZeroOrderPhase_edit');
                       set(ph0_Object,'String',handles.ph0);
                       
                       handles.ph1 = -1.0*PhaseValues(1);
                       ph1_Object = findall(0,'Tag','FirstOrderPhase_edit');
                       set(ph1_Object,'String',handles.ph1);
                       
                       disp('Linear regression gives the following phases: ');
                       dd1 = ['Zero-order phase = ' num2str(handles.ph0) ' degrees.'];
                       dd2 = ['First-order phase = ' num2str(handles.ph1) ' degrees/kHz.'];
                       disp(dd1); disp(dd2);
                   else
                       handles.ph0 = OptimalPhase(1);
                       ph0_Object = findall(0,'Tag','ZeroOrderPhase_edit');
                       set(ph0_Object,'String',handles.ph0);
                   end;
               end;
           else
               %***************************************************************
               % No AutoPhaseBoundaries.txt file exists - zero-order
               % phasing is performed on the visual spectral range
               %***************************************************************
               dd = ['Performing automatic zero-order phase correction on spectral range ' ...
                   num2str(handles.ZxLow) ' to ' num2str(handles.ZxHigh) ' kHz.'];
               disp(dd);
               
               %*********************************************
               % Decompose spectrum by SVD
               %*********************************************
               
               % Starting from the spectrum (rather than the FID) removes
               % the digital group delay.
               FIDPC = MRSPhaseCorrection(spec,handles); 
               FIDPC = ifft(fftshift(FIDPC));
               FIDPC = FIDPC(1:length(FID));
                     
               FIDsvd = MRSAutoPhaseSVD(FIDPC,handles,handles,handles.ZxLow,handles.ZxHigh);
               FIDsvd(1) = FIDsvd(1)/2;
               specsvd = fftshift(fft(FIDsvd,handles.npzf));
               specsvd = reshape(specsvd,handles.npzf,1);

               figure(3); 
               clf;
               axes('XDir','reverse','XLim',[handles.ZxLow handles.ZxHigh],'YLim',[handles.ZyLow handles.ZyHigh],'NextPlot','add');
               hold on;

               ff = -0.5*handles.sw:handles.sw/(handles.npzf-1):0.5*handles.sw;
               specPC = fftshift(fft(FIDPC,handles.npzf));
               plot(ff,(real(specPC)/(10^handles.ZyScale)),'b',ff,(real(specsvd)/(10^handles.ZyScale)),'r')
               xlabel('Frequency (kHz)')

               %**********************
               % Auto phasing loop
               %**********************
               count = 1;
               intspec = zeros(1,360);
               npb = handles.npb;
               ph1 = handles.ph1;
               handles.npb = 0;
               handles.ph1 = 0;
               for kk0 = -179:1:180;
                   handles.ph0 = kk0;
                   specsvdph = DMIWizard_MRS_PhaseCorrection(specsvd, handles);  
                   intspec(count) = sum(real(specsvdph));
                   count = count + 1;
                   clear specsvdph;
               end;
               handles.ph0 = 0;
               handles.npb = npb;
               handles.ph1 = ph1;
               
               clear npb ph1;

               %figure(4); plot(-179:1:180,intspec,'o')
               [maxvalue,maxpos] = max(intspec);
               dd = ['Optimal phase = ' num2str(maxpos-180) ' degrees.'];
               disp(dd);

               handles.ph0 = maxpos-180;
               ph0_Object = findall(0,'Tag','ZeroOrderPhase_edit');
               set(ph0_Object,'String',handles.ph0);
           end;
        end;
    else
        disp('Error : Invalid entry for one or more variables.');
        beep;
    end;
end;