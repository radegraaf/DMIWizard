function handles = DMIWizard_MRSI_ParameterMapping(handles)
%*********************************************************
% Generates a metabolic parameter map from an indicated
% spectral region.
%
% Parameters include:
% 1. Integrated intensity (always included)
% 2. SNR based on integral (optional)
% 3. SNR based on height (optional)
% 4. Line width (optional)
% 5. Line shift (optional)
%*********************************************************

handles.BLO = 1;    % Baseline polynomial fitting order

% Attempt to read ROI map from disk
if ismac
    % Mac platform
    coor = find(handles.MRSIPath == '/');
elseif isunix
    % Linux platform
    coor = find(handles.MRSIPath == '/');
elseif ispc
    % Windows platform
    coor = find(handles.MRSIPath == '\');
end
ROIDir = handles.MRSIPath(1:max(coor));
ROIFile = [ROIDir 'ROImap'];

fileID = fopen(ROIFile,'r');
if (fileID > 0)
    handles.ROI = fscanf(fileID,'%g',[1 Inf]);
    fclose(fileID);
    
    [OperationTime,OperationDate] = DMIWizard_MRSI_CalculateTime;
    TextOutput1 = [OperationTime ' - ROI map read from file:'];
    TextOutput2 = [OperationTime ' - ' ROIFile];
    disp(TextOutput1); disp(TextOutput2);
    
    if (numel(handles.ROI) == handles.np1mri*handles.np2mri*handles.np3mri)
        handles.ROI = reshape(handles.ROI,handles.np1mri,handles.np2mri,handles.np3mri);
    else
        TextOutput1 = [OperationTime ' - Error   : ROI map read from file incompatible with MRI dimensions.'];
        TextOutput2 = [OperationTime ' - Solution: Continuing with unity ROI map.'];
        disp(TextOutput1); disp(TextOutput2);
        
        handles.ROI = ones(handles.np1mri,handles.np2mri,handles.np3mri);
    end;
end;

if (isfield(handles,'ROI') < 1)
    % Create ROI map if one does not exist
    handles.ROI = ones(handles.np1mri,handles.np2mri,handles.np3mri);
end;

% Linear relation between frequency (kHz) and number of spectral points
mmslope = (handles.npzf - 1)/handles.sw;
mmintercept = 1 + 0.5*(handles.npzf - 1);

% Set boundaries in kHz
figure(2); 

if (handles.BC < 1)
    % No baseline correction or definition
    rfreq = ginput(2);
    rfreq = rfreq(:,1);
    rfreq = sort(rfreq,'ascend');
    
    % Draw integration boundaries on spectral display
    hh1 = line([rfreq(1) rfreq(1)],[-1e9 1e9]); set(hh1,'Color','r','Linewidth',1.5);
    hh2 = line([rfreq(2) rfreq(2)],[-1e9 1e9]); set(hh2,'Color','r','Linewidth',1.5);

    [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
    TextOutput1 = [OperationTime ' - Generating parameter maps between [' num2str(rfreq(1),4) ' .. ' num2str(rfreq(2),4) '] kHz'];
    disp(TextOutput1);
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
    
    % Calculate boundaries in points
    rpoint = round(mmslope*rfreq + mmintercept);
    rpoint = sort(rpoint,'ascend');
    
    % Prepare display of fitted metabolic M0, linewidth and lineshift maps - if available
    handles.FittedMetabolicM0map = zeros(handles.np1,handles.np2,handles.np3);
    handles.FittedMetabolicLWmap = zeros(handles.np1,handles.np2,handles.np3);
    handles.FittedMetabolicLSmap = zeros(handles.np1,handles.np2,handles.np3);
    if (isfield(handles,'spec3Dfit') > 0)
        for c1 = 1:handles.nresFit;
            if ((handles.LCMFit.MetaboliteFreq(c1) > min(rfreq)) && (handles.LCMFit.MetaboliteFreq(c1) < max(rfreq)))
%                 c1=3;
                handles.FittedMetabolicM0map = squeeze(handles.LCMFit.M0(c1,:,:,:));
                handles.FittedMetabolicLWmap = squeeze(handles.LCMFit.LineWidth(c1,:,:,:));
                handles.FittedMetabolicLSmap = squeeze(handles.LCMFit.LineShift(c1,:,:,:));
            end;
        end;
    end;
else
    % [Baseline - signal - baseline] definition for baseline correction
    rfreq = ginput(4);
    rfreq = rfreq(:,1);
    rfreq = sort(rfreq,'ascend');
    
    % Draw integration and baseline boundaries on spectral display 
    hh1 = line([rfreq(1) rfreq(1)],[-1e9 1e9]); set(hh1,'Color','b','Linewidth',1.5);
    hh2 = line([rfreq(2) rfreq(2)],[-1e9 1e9]); set(hh2,'Color','r','Linewidth',1.5);
    hh3 = line([rfreq(3) rfreq(3)],[-1e9 1e9]); set(hh3,'Color','r','Linewidth',1.5);
    hh4 = line([rfreq(4) rfreq(4)],[-1e9 1e9]); set(hh4,'Color','b','Linewidth',1.5);
    
    [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
    TextOutput1 = [OperationTime ' - Generating parameter maps between [' num2str(rfreq(2),4) ' .. ' num2str(rfreq(3),4) '] kHz'];
    TextOutput2 = [OperationTime ' - Baseline defined between [' num2str(rfreq(1),4) ' .. ' num2str(rfreq(2),4) ...
        '] and [' num2str(rfreq(3),4) ' .. ' num2str(rfreq(4),4) '] kHz'];   
    disp(TextOutput1); disp(TextOutput2);
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
    DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput2);
    
    % Calculate boundaries in points
    rpoint = round(mmslope*rfreq + mmintercept);
    rpoint = sort(rpoint,'ascend');
    
    % Prepare display of fitted metabolic M0, linewidth and lineshift maps - if available
    handles.FittedMetabolicM0map = zeros(handles.np1,handles.np2,handles.np3);
    handles.FittedMetabolicLWmap = zeros(handles.np1,handles.np2,handles.np3);
    handles.FittedMetabolicLSmap = zeros(handles.np1,handles.np2,handles.np3);
    if (isfield(handles,'spec3Dfit') > 0)
        for c1 = 1:handles.nresFit;
            if ((handles.LCMFit.MetaboliteFreq(c1) > min([rfreq(2) rfreq(3)])) && (handles.LCMFit.MetaboliteFreq(c1) < max([rfreq(2) rfreq(3)])))
                handles.FittedMetabolicM0map = squeeze(handles.LCMFit.M0(c1,:,:,:));
                handles.FittedMetabolicLWmap = squeeze(handles.LCMFit.LineWidth(c1,:,:,:));
                handles.FittedMetabolicLSmap = squeeze(handles.LCMFit.LineShift(c1,:,:,:));
            end;
        end;
    end;
end;

if (handles.BC > 0)
    freq = -0.5*handles.sw:handles.sw/(handles.npzf-1):0.5*handles.sw;
    
    % Display baseline correction for selected voxel location
    BLpointY = []; 
    BLpointX1 = rpoint(1):1:rpoint(2);    % Baseline region 1
    BLpointX2 = rpoint(3):1:rpoint(4);    % Baseline region 2
    BLpointX = [BLpointX1 BLpointX2];
    specpointX = rpoint(2):1:rpoint(3);   % Spectral region
    if (handles.av > 0)
        % Baseline region 1
        BLpointY = [BLpointY abs(handles.spec3D(rpoint(1):1:rpoint(2),round(handles.sp1),round(handles.sp2),round(handles.sp3)))'];
        % Baseline region 2
        BLpointY = [BLpointY abs(handles.spec3D(rpoint(3):1:rpoint(4),round(handles.sp1),round(handles.sp2),round(handles.sp3)))'];
        % Low-order polynomial fitting of baseline
        P = polyfit(BLpointX,BLpointY,handles.BLO);
        % Reconstruction of fitted baseline across [baseline - signal - spectrum].
        BLpoint1 = polyval(P,BLpointX1);
        BLpoint2 = polyval(P,BLpointX2);
        specpoint = polyval(P,specpointX);
    else
        % Baseline region 1
        BLpointY = [BLpointY real(handles.spec3D(rpoint(1):1:rpoint(2),round(handles.sp1),round(handles.sp2),round(handles.sp3)))'];
        % Baseline region 2
        BLpointY = [BLpointY real(handles.spec3D(rpoint(3):1:rpoint(4),round(handles.sp1),round(handles.sp2),round(handles.sp3)))'];
        % Low-order polynomial fitting of baseline
        P = polyfit(BLpointX,BLpointY,handles.BLO);
        % Reconstruction of fitted baseline across spectral integration region.
        BLpoint1 = polyval(P,BLpointX1);
        BLpoint2 = polyval(P,BLpointX2);
        specpoint = polyval(P,specpointX);
    end;
       
    figure(2);
    % Draw baseline, region 1
    for c1 = 1:length(BLpoint1)-1;
        hh1 = line([freq(BLpointX1(c1)) freq(BLpointX1(c1+1))],[BLpoint1(c1) BLpoint1(c1+1)]/10^handles.ZyScale); 
        set(hh1,'Color','b','Linewidth',1.5);
    end;
    
    % Draw baseline, region 2
    for c1 = 1:length(BLpoint2)-1;
        hh1 = line([freq(BLpointX2(c1)) freq(BLpointX2(c1+1))],[BLpoint2(c1) BLpoint2(c1+1)]/10^handles.ZyScale); 
        set(hh1,'Color','b','Linewidth',1.5);
    end;
    
    % Draw signal region 
    for c1 = 1:length(specpoint)-1;
        hh1 = line([freq(specpointX(c1)) freq(specpointX(c1+1))],[specpoint(c1) specpoint(c1+1)]/10^handles.ZyScale); 
        set(hh1,'Color','r','Linewidth',1.5);
    end;
end;

% Establish spectral noise level
if (handles.SNRDisplay > 0)
    noise3D = real(handles.spec3D(1:round(handles.npzf/4),:,:,:));
    % Remove spectral baseline (offset only)
    for c1 = 1:handles.np1;
        for c2 = 1:handles.np2;
            for c3 = 1:handles.np3;
                noise3D(:,c1,c2,c3) = noise3D(:,c1,c2,c3) - mean(noise3D(:,c1,c2,c3));
            end;
        end;
    end;
    noise3D = reshape(noise3D,1,[]);
    noiseSD = std(noise3D);
    
    nbins = 200;
    noisebins = min(noise3D):(max(noise3D)-min(noise3D))/(nbins-1):max(noise3D);
    noisehist = hist(noise3D,noisebins);
    noisehist = 100*noisehist/max(noisehist);
    noisehistint = cumsum(noisehist);
    noisehistint = 100*noisehistint/max(noisehistint);
    
    [~,coor1] = find((noisehistint > 13.8650) & (noisehistint < 17.8650));
    coor1 = round(mean(coor1));
    
    [~,coor2] = find((noisehistint > 82.135) & (noisehistint < 86.135));
    coor2 = round(mean(coor2));
    
    % Display noise histogram to evaluate Gaussian nature of 
    % the selected noise region.
    if ((isnan(coor1) + isnan(coor2)) < 1)
        figure; plot(noisebins,noisehist,'b',noisebins,noisehistint,'r',...
            noisebins(1:coor1),noisebins(1:coor1)*0+15.865,'k--',[noisebins(coor1) noisebins(coor1)],[0 15.865],'k--',...
            noisebins(1:coor2),noisebins(1:coor2)*0+84.135,'k--',[noisebins(coor2) noisebins(coor2)],[0 84.135],'k--')
        axis([min(noise3D) max(noise3D) 0 100]);
        tt = ['Noise SD = ' num2str(noiseSD) '; Noise SD from histogram = ' num2str((noisebins(coor2)-noisebins(coor1))/2)];
        title(tt);
        xlabel('Noise amplitude');
        ylabel('Relative occurence');
    else
        figure; plot(noisebins,noisehist,'b',noisebins,noisehistint,'r')
        axis([min(noise3D) max(noise3D) 0 100]);
        tt = ['Noise SD = ' num2str(noiseSD)];
        title(tt);
        xlabel('Noise amplitude');
        ylabel('Relative occurence');
        
        [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
        WarningOutput1 = [OperationTime ' - Warning: At least one of the histogram boundaries in invalid.'];
        WarningOutput2 = [OperationTime ' - Warning: Noise distribution is likely non-Gaussian.'];
        disp(' '); disp(WarningOutput1); disp(WarningOutput2); beep;
    end;
    
    [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
    TextOutput1 = [OperationTime ' - Noise is estimated from first ' num2str(round(handles.npzf/4)) ' points of every spectrum.'];
    TextOutput2 = [OperationTime ' - In the absence of resonances, noise histogram should be centered around zero.'];
    disp(' '); disp(TextOutput1); disp(TextOutput2);
end;

switch handles.Orientation
    case 1
        %------------------------------------------------------------------
        %------------------------------------------------------------------
        % Axial plane
        %------------------------------------------------------------------
        %------------------------------------------------------------------
        handles.MetabolicM0map = zeros(handles.np1,handles.np2);
        handles.MetabolicPHmap = zeros(handles.np1,handles.np2);
        df = 1000*handles.sw/handles.npzf;  % Integration frequency 'bin'
        
        if (handles.BC < 1)
            % Integration without baseline correction
            for c1 = 1:1:handles.np1;
                for c2 = 1:1:handles.np2;
                    if (handles.av > 0)
                        specpoint = abs(handles.spec3D(rpoint(1):1:rpoint(2),c1,c2,round(handles.sp3)));
                    else
                        specpoint = real(handles.spec3D(rpoint(1):1:rpoint(2),c1,c2,round(handles.sp3)));
                    end;

                    handles.MetabolicM0map(c1,c2) = sum(specpoint)*df;     % Integral
                    handles.MetabolicPHmap(c1,c2) = max(specpoint);        % Peak height
                end;
            end;
        else
            % Integration with baseline correction
            BLpointX = []; 
            BLpointX = [BLpointX rpoint(1):1:rpoint(2)];    % Baseline region 1
            BLpointX = [BLpointX rpoint(3):1:rpoint(4)];    % Baseline region 2
            specpointX = rpoint(2):1:rpoint(3);             % Spectral region
            for c1 = 1:1:handles.np1;
                for c2 = 1:1:handles.np2;
                    BLpoint = []; BLpointY = [];
                    if (handles.av > 0)
                        % Baseline region 1
                        BLpointY = [BLpointY abs(handles.spec3D(rpoint(1):1:rpoint(2),c1,c2,round(handles.sp3)))'];
                        % Baseline region 2
                        BLpointY = [BLpointY abs(handles.spec3D(rpoint(3):1:rpoint(4),c1,c2,round(handles.sp3)))'];
                        % Low-order polynomial fitting of baseline
                        P = polyfit(BLpointX,BLpointY,handles.BLO);
                        % Reconstruction of fitted baseline across spectral integration region.
                        BLpoint = polyval(P,specpointX);
                        specpoint = abs(handles.spec3D(rpoint(2):1:rpoint(3),c1,c2,round(handles.sp3)))';
                    else
                        % Baseline region 1
                        BLpointY = [BLpointY real(handles.spec3D(rpoint(1):1:rpoint(2),c1,c2,round(handles.sp3)))'];
                        % Baseline region 2
                        BLpointY = [BLpointY real(handles.spec3D(rpoint(3):1:rpoint(4),c1,c2,round(handles.sp3)))'];
                        % Low-order polynomial fitting of baseline
                        P = polyfit(BLpointX,BLpointY,handles.BLO);
                        % Reconstruction of fitted baseline across spectral integration region.
                        BLpoint = polyval(P,specpointX);
                        specpoint = real(handles.spec3D(rpoint(2):1:rpoint(3),c1,c2,round(handles.sp3)))';
                    end;

                    handles.MetabolicM0map(c1,c2) = sum(specpoint - BLpoint)*df;     % Integral
                    handles.MetabolicPHmap(c1,c2) = max(specpoint);                  % Peak height
                end;
            end;
        end;
        
        % Write metabolic M0 map with map ID to file
        handles.OutputFileName = ['MetabolicMap_' num2str(handles.np1) 'x' num2str(handles.np2)...
            '_Zslice' num2str(handles.sp3) '_' handles.MapID];
        handles.MMStyle = 'M0';
        DMIWizard_MRSI_WriteMetabolicMap(handles.MetabolicM0map,handles);
        
        % Write fitted metabolic M0 map with (map ID + 100) to file - if available
        if (max(handles.FittedMetabolicM0map(:)) > 0)
            handles.OutputFileName = ['MetabolicMap_' num2str(handles.np1) 'x' num2str(handles.np2)...
            '_Zslice' num2str(handles.sp3) '_' handles.MapID 'Fitted'];
            handles.MMStyle = 'M0';
            DMIWizard_MRSI_WriteMetabolicMap(squeeze(handles.FittedMetabolicM0map(:,:,handles.sp3)),handles);           
        end;

        % Display axial metabolic M0 map at original resolution without an MRI background 
        fh = figure;
        nn = ['Axial M0 map (slice ' num2str(round(handles.sp3)) ' out of ' num2str(handles.np3) ')'];
        set(fh,'Name',nn);
        imshow(handles.MetabolicM0map,[0 max(max(handles.MetabolicM0map))],'InitialMagnification','fit')
        colormap(jet); axis('off'); colorbar('vert');
                                
        % Display fitted axial metabolic M0 map - if available
        if (max(handles.FittedMetabolicM0map(:)) > 0)
            fh = figure;
            nn = ['Fitted axial M0 map (slice ' num2str(round(handles.sp3)) ' out of ' num2str(handles.np3) ')'];
            set(fh,'Name',nn);
            imshow(squeeze(handles.FittedMetabolicM0map(:,:,handles.sp3)),[0 max(max(handles.FittedMetabolicM0map(:,:,handles.sp3)))],'InitialMagnification','fit')
            colormap(jet); axis('off'); colorbar('vert');     
        end;

        % SNR-related maps
        if (handles.SNRDisplay > 0)
            fh = figure;
            nn = ['Axial SNR integral map (slice ' num2str(round(handles.sp3)) ' out of ' num2str(handles.np3) ')'];
            set(fh,'Name',nn);
            imshow(handles.MetabolicM0map/noiseSD,[0 max(max(handles.MetabolicM0map/noiseSD))],'InitialMagnification','fit');
            colorbar('vert'); colormap(jet);
            axis('off');
            
            fh = figure;
            nn = ['Axial SNR peak height map (slice ' num2str(round(handles.sp3)) ' out of ' num2str(handles.np3) ')'];
            set(fh,'Name',nn);
            imshow(handles.MetabolicPHmap/noiseSD,[0 max(max(handles.MetabolicPHmap/noiseSD))],'InitialMagnification','fit');
            colorbar('vert'); colormap(jet);
            axis('off');
            
            % Write SNR integral map to file
            [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
            OperationTime=[OperationTime(1:2) OperationTime(4:5) OperationTime(7:8)];
            handles.OutputFileName = ['SNRIntegralmap_' num2str(handles.np1) 'x' num2str(handles.np2) ...
                '_Zslice' num2str(handles.sp3) '_' handles.MapID];
            handles.MMStyle = 'SNR integral';
            DMIWizard_MRSI_WriteMetabolicMap(handles.MetabolicM0map/noiseSD,handles);
                      
            % Write SNR height map to file
            handles.OutputFileName = ['SNRHeightHeightmap_' num2str(handles.np1) 'x' num2str(handles.np2) ...
                '_Zslice' num2str(handles.sp3) '_' handles.MapID];
            handles.MMStyle = 'SNR height';
            DMIWizard_MRSI_WriteMetabolicMap(handles.MetabolicPHmap/noiseSD,handles);
        end;
        
        % Line width and shift related maps
        if ((handles.LWDisplay > 0) || (handles.LSDisplay > 0))
            [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
            TextOutput1 = [OperationTime ' - Note: Line width and shift calculations are performed on the real part of MR spectra.'];
            TextOutput2 = [OperationTime ' - Note: Ensure that MR spectra are properly phased (Auto Phasing, Linear Prediction).'];
            disp(' '); disp(TextOutput1); disp(TextOutput2);
            
            handles.LWmapTmp = zeros(handles.np1,handles.np2);
            handles.LSmap = zeros(handles.np1,handles.np2);
            for c1 = 1:1:handles.np1;
                for c2 = 1:1:handles.np2;
                    if (handles.InclusionMap(c1,c2,round(handles.sp3)) > 0)
                        if (handles.BC < 1)
                            % No baseline correction
                            [PeakHeight,PeakFreq] = max(real(handles.spec3D(rpoint(1):1:rpoint(2),c1,c2,round(handles.sp3))));
                        else
                            % No baseline correction
                            [PeakHeight,PeakFreq] = max(real(handles.spec3D(rpoint(2):1:rpoint(3),c1,c2,round(handles.sp3))));
                        end;
                        handles.LWmapTmp(c1,c2) = PeakHeight;
                        handles.LSmap(c1,c2) = PeakFreq;
                    end;
                end;
            end;
                                    
            coor1 = find(handles.InclusionMap(:,:,round(handles.sp3)) > 0);
            coor2 = find(handles.InclusionMap(:,:,round(handles.sp3)) < 1);
            
            handles.LWmap = zeros(handles.np1,handles.np2);
            for c1 = 1:1:handles.np1;
                for c2 = 1:1:handles.np2;
                    if (handles.InclusionMap(c1,c2,round(handles.sp3)) > 0)
                        if (handles.BC < 1)
                            % No baseline correction
                            FreqPos1 = handles.LSmap(c1,c2) + rpoint(1);
                            while (real(handles.spec3D(FreqPos1,c1,c2,round(handles.sp3))) > 0.5*handles.LWmapTmp(c1,c2));
                                FreqPos1 = FreqPos1 - 1;
                            end;

                            FreqPos2 = handles.LSmap(c1,c2) + rpoint(1);
                            while (real(handles.spec3D(FreqPos2,c1,c2,round(handles.sp3))) > 0.5*handles.LWmapTmp(c1,c2));
                                FreqPos2 = FreqPos2 + 1;
                            end;
                        else
                            % Baseline correction
                            FreqPos1 = handles.LSmap(c1,c2) + rpoint(2);
                            while (real(handles.spec3D(FreqPos1,c1,c2,round(handles.sp3))) > 0.5*handles.LWmapTmp(c1,c2));
                                FreqPos1 = FreqPos1 - 1;
                            end;

                            FreqPos2 = handles.LSmap(c1,c2) + rpoint(2);
                            while (real(handles.spec3D(FreqPos2,c1,c2,round(handles.sp3))) > 0.5*handles.LWmapTmp(c1,c2));
                                FreqPos2 = FreqPos2 + 1;
                            end;                           
                        end;
                        
                        handles.LWmap(c1,c2) = abs(FreqPos2 - FreqPos1)*1000*(handles.sw/handles.npzf);
                    end;
                end;
            end;
                       
            % Convert line shift (in pixels) to line shift (in Hz)
            if (handles.BC < 1)
                % No baseline correction
                handles.LSmap = 1000*rfreq(1) + handles.LSmap*1000*(handles.sw/handles.npzf);
            else
                % Baseline correction
                handles.LSmap = 1000*rfreq(2) + handles.LSmap*1000*(handles.sw/handles.npzf);                
            end;
            handles.LSmap(coor2) = 0;
            
            if (handles.LWDisplay > 0)
                fh = figure;
                nn = ['Axial line width map (slice ' num2str(round(handles.sp3)) ' out of ' num2str(handles.np3) ...
                    '), digital resolution = ' num2str(1000*(handles.sw/handles.npzf),2) ' Hz per point'];
                set(fh,'Name',nn);
                imshow(handles.LWmap,[0.0 max(handles.LWmap(coor1))],'InitialMagnification','fit');
                colorbar('vert'); colormap(jet);
                axis('off');
                               
                % Write linewidth map to disk
                [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
                coor = find(handles.InclusionMap(:,:,round(handles.sp3)) > 0);
                TextOutput1 = [OperationTime ' - Average line width = ' num2str(mean(handles.LWmap(coor)),3) ' +/- ' num2str(std(handles.LWmap(coor)),3) ' Hz'];
                disp(' '); disp(TextOutput1);
                DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
                
                [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
                OperationTime = [OperationTime(1:2) OperationTime(4:5) OperationTime(7:8)];
                handles.OutputFileName = ['LWmap_' num2str(handles.np1) 'x' num2str(handles.np2) ...
                    '_Zslice' num2str(handles.sp3) '_' handles.MapID];
                handles.MMStyle = 'line width';
                DMIWizard_MRSI_WriteMetabolicMap(handles.LWmap,handles);
                
                % Display fitted axial metabolic linewidth map - if available
                if (max(handles.FittedMetabolicLWmap(:)) > 0)
                    fh = figure;
                    nn = ['Fitted axial line width map (slice ' num2str(round(handles.sp3)) ' out of ' num2str(handles.np3) ')'];
                    set(fh,'Name',nn);
                    imshow(squeeze(handles.FittedMetabolicLWmap(:,:,handles.sp3)),[],'InitialMagnification','fit')
                    colormap(jet); axis('off'); colorbar('vert');     
                end;
            end;
            
            if (handles.LSDisplay > 0)
                fh = figure;
                nn = ['Axial line shift map (slice ' num2str(round(handles.sp3)) ' out of ' num2str(handles.np3) ...
                    '), digital resolution = ' num2str(1000*(handles.sw/handles.npzf),2) ' Hz per point'];
                set(fh,'Name',nn);
                maxLS = max(handles.LSmap(coor1)); minLS =  min(handles.LSmap(coor1)); deltaLS = maxLS - minLS;
                imshow(handles.LSmap,[minLS-0.1*deltaLS maxLS+0.1*deltaLS],'InitialMagnification','fit');
                colorbar('vert'); colormap(jet);
                axis('off');
                
                % Write lineshift map to disk
                [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
                coor = find(handles.InclusionMap(:,:,round(handles.sp3)) > 0);
                TextOutput1 = [OperationTime ' - Average line shift = ' num2str(mean(handles.LSmap(coor)),3) ' +/- ' num2str(std(handles.LSmap(coor)),3) ' Hz'];
                disp(' '); disp(TextOutput1);
                DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
                
                [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
                OperationTime = [OperationTime(1:2) OperationTime(4:5) OperationTime(7:8)];
                handles.OutputFileName = ['LSmap_' num2str(handles.np1) 'x' num2str(handles.np2) ...
                    '_Zslice' num2str(handles.sp3) '_' handles.MapID];
                handles.MMStyle = 'line shift';
                DMIWizard_MRSI_WriteMetabolicMap(handles.LSmap,handles);
                
                % Display fitted axial metabolic lineshift map - if available
                if (max(handles.FittedMetabolicLSmap(:)) > 0)
                    fh = figure;
                    nn = ['Fitted axial line shift map relative to basisset (slice ' num2str(round(handles.sp3)) ' out of ' num2str(handles.np3) ')'];
                    set(fh,'Name',nn);
                    imshow(squeeze(handles.FittedMetabolicLSmap(:,:,handles.sp3)),[],'InitialMagnification','fit')
                    colormap(jet); axis('off'); colorbar('vert');     
                end;
            end;
        end;
  
     case 2
        %------------------------------------------------------------------
        %------------------------------------------------------------------
        % Coronal plane
        %------------------------------------------------------------------
        %------------------------------------------------------------------
        handles.MetabolicM0map = zeros(handles.np1,handles.np3);
        handles.MetabolicPHmap = zeros(handles.np1,handles.np3);
        df = 1000*handles.sw/handles.npzf;  % Integration frequency 'bin'
        
        if (handles.BC < 1)
            % Integration without baseline correction
            for c1 = 1:1:handles.np1;
                for c3 = 1:1:handles.np3;
                    if (handles.av > 0)
                        specpoint = abs(handles.spec3D(rpoint(1):1:rpoint(2),c1,round(handles.sp2),c3));
                    else
                        specpoint = real(handles.spec3D(rpoint(1):1:rpoint(2),c1,round(handles.sp2),c3));
                    end;

                    handles.MetabolicM0map(c1,c3) = sum(specpoint)*df;      % Integral
                    handles.MetabolicPHmap(c1,c3) = max(specpoint);         % Peak height
                end;
            end;
        else
            % Integration with baseline correction
            BLpointX = []; 
            BLpointX = [BLpointX rpoint(1):1:rpoint(2)];    % Baseline region 1
            BLpointX = [BLpointX rpoint(3):1:rpoint(4)];    % Baseline region 2
            specpointX = rpoint(2):1:rpoint(3);             % Spectral region
            for c1 = 1:1:handles.np1;
                for c3 = 1:1:handles.np3;
                    BLpoint = []; BLpointY = [];
                    if (handles.av > 0)
                        % Baseline region 1
                        BLpointY = [BLpointY abs(handles.spec3D(rpoint(1):1:rpoint(2),c1,round(handles.sp2),c3))'];
                        % Baseline region 2
                        BLpointY = [BLpointY abs(handles.spec3D(rpoint(3):1:rpoint(4),c1,round(handles.sp2),c3))'];
                        % Low-order polynomial fitting of baseline
                        P = polyfit(BLpointX,BLpointY,handles.BLO);
                        % Reconstruction of fitted baseline across spectral integration region.
                        BLpoint = polyval(P,specpointX);
                        specpoint = abs(handles.spec3D(rpoint(2):1:rpoint(3),c1,round(handles.sp2),c3))';
                    else
                        % Baseline region 1
                        BLpointY = [BLpointY real(handles.spec3D(rpoint(1):1:rpoint(2),c1,round(handles.sp2),c3))'];
                        % Baseline region 2
                        BLpointY = [BLpointY real(handles.spec3D(rpoint(3):1:rpoint(4),c1,round(handles.sp2),c3))'];
                        % Low-order polynomial fitting of baseline
                        P = polyfit(BLpointX,BLpointY,handles.BLO);
                        % Reconstruction of fitted baseline across spectral integration region.
                        BLpoint = polyval(P,specpointX);
                        specpoint = real(handles.spec3D(rpoint(2):1:rpoint(3),c1,round(handles.sp2),c3))';
                    end;

                    handles.MetabolicM0map(c1,c3) = sum(specpoint - BLpoint)*df;     % Integral
                    handles.MetabolicPHmap(c1,c3) = max(specpoint);                  % Peak height
                end;
            end;
        end;
            
        % Write metabolic M0 map with map ID to file
        handles.OutputFileName = ['MetabolicMap_' num2str(handles.np1) 'x' num2str(handles.np3) ...
            '_Yslice' num2str(handles.sp2) '_' handles.MapID];
        handles.MMStyle = 'M0';
        DMIWizard_MRSI_WriteMetabolicMap(handles.MetabolicM0map,handles);
        
        % Write fitted metabolic M0 map with (map ID + 100) to file - if available
        if (max(handles.FittedMetabolicM0map(:)) > 0)
            handles.OutputFileName = ['MetabolicMap_' num2str(handles.np1) 'x' num2str(handles.np3) ...
                    '_Yslice' num2str(handles.sp2) '_' handles.MapID 'Fitted'];
            handles.MMStyle = 'M0';
            DMIWizard_MRSI_WriteMetabolicMap(squeeze(handles.FittedMetabolicM0map(:,handles.sp2,:)),handles);           
        end;
                 
        % Display coronal metabolic M0 map at original resolution without an MRI background 
        fh = figure;
        nn = ['Coronal M0 map (slice ' num2str(round(handles.sp2)) ' out of ' num2str(handles.np2) ')'];
        set(fh,'Name',nn);
        imshow(handles.MetabolicM0map,[0 max(max(handles.MetabolicM0map))],'InitialMagnification','fit')
        colormap(jet); axis('off');

        % Display fitted coronal metabolic M0 map - if available
        if (max(handles.FittedMetabolicM0map(:)) > 0)
            fh = figure;
            nn = ['Fitted coronal M0 map (slice ' num2str(round(handles.sp2)) ' out of ' num2str(handles.np2) ')'];
            set(fh,'Name',nn);
            imshow(squeeze(handles.FittedMetabolicM0map(:,handles.sp2,:)),[0 max(max(handles.FittedMetabolicM0map(:,handles.sp2,:)))],'InitialMagnification','fit')
            colormap(jet); axis('off'); colorbar('vert');
        end;
       
        % SNR-related maps
        if (handles.SNRDisplay > 0)
            fh = figure;
            nn = ['Coronal SNR integral map (slice ' num2str(round(handles.sp2)) ' out of ' num2str(handles.np2) ')'];
            set(fh,'Name',nn);
            imshow(handles.MetabolicM0map/noiseSD,[0 max(max(handles.MetabolicM0map/noiseSD))],'InitialMagnification','fit');
            colorbar('vert'); colormap(jet);
            axis('off');
            
            fh = figure;
            nn = ['Coronal SNR peak height map (slice ' num2str(round(handles.sp2)) ' out of ' num2str(handles.np2) ')'];
            set(fh,'Name',nn);
            imshow(handles.MetabolicPHmap/noiseSD,[0 max(max(handles.MetabolicPHmap/noiseSD))],'InitialMagnification','fit');
            colorbar('vert'); colormap(jet);
            axis('off');
            
            [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
            OperationTime=[OperationTime(1:2) OperationTime(4:5) OperationTime(7:8)];
            handles.OutputFileName = ['SNRIntegralmap_' num2str(handles.np1) 'x' num2str(handles.np3) ...
                '_Yslice' num2str(handles.sp2) '_' handles.MapID];
            handles.MMStyle = 'SNR integral';
            DMIWizard_MRSI_WriteMetabolicMap(handles.MetabolicM0map/noiseSD,handles);
            
            handles.OutputFileName = ['SNRHeightmap_' num2str(handles.np1) 'x' num2str(handles.np3) ...
                '_Yslice' num2str(handles.sp2) '_' handles.MapID];
            handles.MMStyle = 'SNR height';
            DMIWizard_MRSI_WriteMetabolicMap(handles.MetabolicPHmap/noiseSD,handles);
        end;
        
        % Line width and shift related maps
        if ((handles.LWDisplay > 0) || (handles.LSDisplay > 0))
            [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
            TextOutput1 = [OperationTime ' - Note: Line width and shift calculations are performed on the real part of MR spectra.'];
            TextOutput2 = [OperationTime ' - Note: Ensure that MR spectra are properly phased (Auto Phasing, Linear Prediction).'];
            disp(' '); disp(TextOutput1); disp(TextOutput2);
            
            handles.LWmapTmp = zeros(handles.np1,handles.np3);
            handles.LSmap = zeros(handles.np1,handles.np3);
            for c1 = 1:1:handles.np1;
                for c2 = 1:1:handles.np3;
                    if (handles.InclusionMap(c1,round(handles.sp2),c2) > 0)
                        if (handles.BC < 1)
                            % No baseline correction
                            [PeakHeight,PeakFreq] = max(real(handles.spec3D(rpoint(1):1:rpoint(2),c1,round(handles.sp2),c2)));
                            handles.LWmapTmp(c1,c2) = PeakHeight;
                            handles.LSmap(c1,c2) = PeakFreq;
                        else
                            % Baseline correction
                            [PeakHeight,PeakFreq] = max(real(handles.spec3D(rpoint(2):1:rpoint(3),c1,round(handles.sp2),c2)));
                            handles.LWmapTmp(c1,c2) = PeakHeight;
                            handles.LSmap(c1,c2) = PeakFreq;                           
                        end;
                    end;
                end;
            end;
            
            coor1 = find(squeeze(handles.InclusionMap(:,round(handles.sp2),:)) > 0);
            coor2 = find(squeeze(handles.InclusionMap(:,round(handles.sp2),:)) < 1);
            
            handles.LWmap = zeros(handles.np1,handles.np3);
            for c1 = 1:1:handles.np1;
                for c2 = 1:1:handles.np3;
                    if (handles.InclusionMap(c1,round(handles.sp2),c2) > 0)
                        if (handles.BC < 1)
                            % No baseline correction
                            FreqPos1 = handles.LSmap(c1,c2) + rpoint(1);
                            while (real(handles.spec3D(FreqPos1,c1,round(handles.sp2),c2)) > 0.5*handles.LWmapTmp(c1,c2));
                                FreqPos1 = FreqPos1 - 1;
                            end;

                            FreqPos2 = handles.LSmap(c1,c2) + rpoint(1);
                            while (real(handles.spec3D(FreqPos2,c1,round(handles.sp2),c2)) > 0.5*handles.LWmapTmp(c1,c2));
                                FreqPos2 = FreqPos2 + 1;
                            end;
                        else
                            % Baseline correction
                            FreqPos1 = handles.LSmap(c1,c2) + rpoint(2);
                            while (real(handles.spec3D(FreqPos1,c1,round(handles.sp2),c2)) > 0.5*handles.LWmapTmp(c1,c2));
                                FreqPos1 = FreqPos1 - 1;
                            end;

                            FreqPos2 = handles.LSmap(c1,c2) + rpoint(2);
                            while (real(handles.spec3D(FreqPos2,c1,round(handles.sp2),c2)) > 0.5*handles.LWmapTmp(c1,c2));
                                FreqPos2 = FreqPos2 + 1;
                            end;                            
                        end;
                        
                        handles.LWmap(c1,c2) = abs(FreqPos2 - FreqPos1)*1000*(handles.sw/handles.npzf);
                    end;
                end;
            end;
            clear handles.LWmapTmp;
            
            % Convert line shift (in pixels) to line shift (in Hz)
            if (handles.BC < 1)
                % No baseline correction
                handles.LSmap = 1000*rfreq(1) + handles.LSmap*1000*(handles.sw/handles.npzf);
            else
                % Baseline correction
                handles.LSmap = 1000*rfreq(2) + handles.LSmap*1000*(handles.sw/handles.npzf);                
            end;
            handles.LSmap(coor2) = 0;
            
            if (handles.LWDisplay > 0)
                fh = figure;
                nn = ['Coronal line width map (slice ' num2str(round(handles.sp2)) ' out of ' num2str(handles.np2) ...
                    '), digital resolution = ' num2str(1000*(handles.sw/handles.npzf),2) ' Hz per point'];
                set(fh,'Name',nn);
                imshow(handles.LWmap,[0.0 max(handles.LWmap(coor1))],'InitialMagnification','fit');
                colorbar('vert'); colormap(jet);
                axis('off');
                               
                % Write linewidth map to disk
                [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
                coor = find(handles.InclusionMap(:,round(handles.sp2),:) > 0);
                TextOutput1 = [OperationTime ' - Average line width = ' num2str(mean(handles.LWmap(coor)),3) ' +/- ' num2str(std(handles.LWmap(coor)),3) ' Hz'];
                disp(' '); disp(TextOutput1);
                DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
                
                [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
                OperationTime = [OperationTime(1:2) OperationTime(4:5) OperationTime(7:8)];
                handles.OutputFileName = ['LWmap_' num2str(handles.np1) 'x' num2str(handles.np3) ...
                    '_Yslice' num2str(handles.sp2) '_' handles.MapID];
                handles.MMStyle = 'line width';
                DMIWizard_MRSI_WriteMetabolicMap(handles.LWmap,handles);
                
                % Display fitted coronal metabolic linewidth map - if available
                if (max(handles.FittedMetabolicLWmap(:)) > 0)
                    fh = figure;
                    nn = ['Fitted coronal line width map (slice ' num2str(round(handles.sp2)) ' out of ' num2str(handles.np2) ')'];
                    set(fh,'Name',nn);
                    imshow(squeeze(handles.FittedMetabolicLWmap(:,handles.sp2,:)),[],'InitialMagnification','fit')
                    colormap(jet); axis('off'); colorbar('vert');     
                end;
            end;
            
            if (handles.LSDisplay > 0)
                fh = figure;
                nn = ['Coronal line shift map (slice ' num2str(round(handles.sp2)) ' out of ' num2str(handles.np2) ...
                    '), digital resolution = ' num2str(1000*(handles.sw/handles.npzf),2) ' Hz per point'];
                set(fh,'Name',nn);
                maxLS = max(handles.LSmap(coor1)); minLS =  min(handles.LSmap(coor1)); deltaLS = maxLS - minLS;
                imshow(handles.LSmap,[minLS-0.1*deltaLS maxLS+0.1*deltaLS],'InitialMagnification','fit');
                colorbar('vert'); colormap(jet);
                axis('off');
                
                % Write lineshift map to disk
                [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
                coor = find(handles.InclusionMap(:,round(handles.sp2),:) > 0);
                TextOutput1 = [OperationTime ' - Average line shift = ' num2str(mean(handles.LSmap(coor)),3) ' +/- ' num2str(std(handles.LSmap(coor)),3) ' Hz'];
                disp(' '); disp(TextOutput1);
                DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
                
                [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
                OperationTime = [OperationTime(1:2) OperationTime(4:5) OperationTime(7:8)];
                handles.OutputFileName = ['LSmap_' num2str(handles.np1) 'x' num2str(handles.np3) ...
                    '_Yslice' num2str(handles.sp2) '_' handles.MapID];
                handles.MMStyle = 'line shift';
                DMIWizard_MRSI_WriteMetabolicMap(handles.LSmap,handles);
                
                % Display fitted coronal metabolic lineshift map - if available
                if (max(handles.FittedMetabolicLSmap(:)) > 0)
                    fh = figure;
                    nn = ['Fitted coronal line shift map relative to basisset (slice ' num2str(round(handles.sp2)) ' out of ' num2str(handles.np2) ')'];
                    set(fh,'Name',nn);
                    imshow(squeeze(handles.FittedMetabolicLSmap(:,handles.sp2,:)),[],'InitialMagnification','fit')
                    colormap(jet); axis('off'); colorbar('vert');     
                end;
            end;
        end;
        
    case 3
        %------------------------------------------------------------------
        %------------------------------------------------------------------
        % Sagittal plane
        %------------------------------------------------------------------
        %------------------------------------------------------------------
        handles.MetabolicM0map = zeros(handles.np2,handles.np3);
        handles.MetabolicPHmap = zeros(handles.np2,handles.np3);
        df = 1000*handles.sw/handles.npzf;  % Integration frequency 'bin'
        
        if (handles.BC < 1)
            % Integration without baseline correction
            for c2 = 1:1:handles.np2;
                for c3 = 1:1:handles.np3;
                    if (handles.av > 0)
                        specpoint = abs(handles.spec3D(rpoint(1):1:rpoint(2),round(handles.sp1),c2,c3));
                    else
                        specpoint = real(handles.spec3D(rpoint(1):1:rpoint(2),round(handles.sp1),c2,c3));
                    end;

                    handles.MetabolicM0map(c2,c3) = sum(specpoint)*df;      % Integral
                    handles.MetabolicPHmap(c2,c3) = max(specpoint);         % Peak height
                end;
            end;
        else
            % Integration with baseline correction
            BLpointX = []; 
            BLpointX = [BLpointX rpoint(1):1:rpoint(2)];    % Baseline region 1
            BLpointX = [BLpointX rpoint(3):1:rpoint(4)];    % Baseline region 2
            specpointX = rpoint(2):1:rpoint(3);             % Spectral region
            for c2 = 1:1:handles.np2;
                for c3 = 1:1:handles.np3;
                    BLpoint = []; BLpointY = [];
                    if (handles.av > 0)
                        % Baseline region 1
                        BLpointY = [BLpointY abs(handles.spec3D(rpoint(1):1:rpoint(2),round(handles.sp1),c2,c3))'];
                        % Baseline region 2
                        BLpointY = [BLpointY abs(handles.spec3D(rpoint(3):1:rpoint(4),round(handles.sp1),c2,c3))'];
                        % Low-order polynomial fitting of baseline
                        P = polyfit(BLpointX,BLpointY,handles.BLO);
                        % Reconstruction of fitted baseline across spectral integration region.
                        BLpoint = polyval(P,specpointX);
                        specpoint = abs(handles.spec3D(rpoint(2):1:rpoint(3),round(handles.sp1),c2,c3))';
                    else
                        % Baseline region 1
                        BLpointY = [BLpointY real(handles.spec3D(rpoint(1):1:rpoint(2),round(handles.sp1),c2,c3))'];
                        % Baseline region 2
                        BLpointY = [BLpointY real(handles.spec3D(rpoint(3):1:rpoint(4),round(handles.sp1),c2,c3))'];
                        % Low-order polynomial fitting of baseline
                        P = polyfit(BLpointX,BLpointY,handles.BLO);
                        % Reconstruction of fitted baseline across spectral integration region.
                        BLpoint = polyval(P,specpointX);
                        specpoint = real(handles.spec3D(rpoint(2):1:rpoint(3),round(handles.sp1),c2,c3))';
                    end;

                    handles.MetabolicM0map(c2,c3) = sum(specpoint - BLpoint)*df;     % Integral
                    handles.MetabolicPHmap(c2,c3) = max(specpoint);                  % Peak height
                end;
            end;
        end;
            
        % Write metabolic M0 map with map ID to file
        handles.OutputFileName = ['MetabolicMap_' num2str(handles.np2) 'x' num2str(handles.np3) ...
            '_Xslice' num2str(handles.sp1) '_' handles.MapID];
        handles.MMStyle = 'M0';
        DMIWizard_MRSI_WriteMetabolicMap(handles.MetabolicM0map,handles);
        
        % Write fitted metabolic M0 map with (map ID + 100) to file - if available
        if (max(handles.FittedMetabolicM0map(:)) > 0)
            handles.OutputFileName = ['MetabolicMap_' num2str(handles.np2) 'x' num2str(handles.np3) ...
                '_Xslice' num2str(handles.sp1) '_' handles.MapID 'Fitted'];
            handles.MMStyle = 'M0';
            DMIWizard_MRSI_WriteMetabolicMap(squeeze(handles.FittedMetabolicM0map(handles.sp1,:,:)),handles);           
        end;
    
        % Display sagital metabolic M0 map at original resolution without an MRI background 
        fh = figure;
        nn = ['Sagital M0 map (slice ' num2str(round(handles.sp1)) ' out of ' num2str(handles.np1) ')'];
        set(fh,'Name',nn);
        imshow(handles.MetabolicM0map,[0 max(max(handles.MetabolicM0map))],'InitialMagnification','fit')
        colormap(jet); axis('off');

        % Display fitted sagital metabolic M0 map - if available
        if (max(handles.FittedMetabolicM0map(:)) > 0)
            fh = figure;
            nn = ['Fitted sagital M0 map (slice ' num2str(round(handles.sp1)) ' out of ' num2str(handles.np1) ')'];
            set(fh,'Name',nn);
            imshow(squeeze(handles.FittedMetabolicM0map(handles.sp1,:,:)),[0 max(max(handles.FittedMetabolicM0map(handles.sp1,:,:)))],'InitialMagnification','fit')
            colormap(jet); axis('off'); colorbar('vert');      
        end;

        % SNR-related maps
        if (handles.SNRDisplay > 0)
            fh = figure;
            nn = ['Sagital SNR integral map (slice ' num2str(round(handles.sp1)) ' out of ' num2str(handles.np1) ')'];
            set(fh,'Name',nn);
            imshow(handles.MetabolicM0map/noiseSD,[0 max(max(handles.MetabolicM0map/noiseSD))],'InitialMagnification','fit');
            colorbar('vert'); colormap(jet);
            axis('off');
            
            fh = figure;
            nn = ['Sagital SNR peak height map (slice ' num2str(round(handles.sp1)) ' out of ' num2str(handles.np1) ')'];
            set(fh,'Name',nn);
            imshow(handles.MetabolicPHmap/noiseSD,[0 max(max(handles.MetabolicPHmap/noiseSD))],'InitialMagnification','fit');
            colorbar('vert'); colormap(jet);
            axis('off');
            
            [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
            OperationTime=[OperationTime(1:2) OperationTime(4:5) OperationTime(7:8)];
            handles.OutputFileName = ['SNRIntegralmap_' num2str(handles.np2) 'x' num2str(handles.np3) ...
                '_Xslice' num2str(handles.sp1) '_' handles.MapID];
            handles.MMStyle = 'SNR integral';
            DMIWizard_MRSI_WriteMetabolicMap(handles.MetabolicM0map/noiseSD,handles);
            
            handles.OutputFileName = ['SNRHeightmap_' num2str(handles.np2) 'x' num2str(handles.np3) ...
                '_Xslice' num2str(handles.sp1) '_' handles.MapID];
            handles.MMStyle = 'SNR height';
            DMIWizard_MRSI_WriteMetabolicMap(handles.MetabolicPHmap/noiseSD,handles);
        end;
        
        % Line width and shift related maps
        if ((handles.LWDisplay > 0) || (handles.LSDisplay > 0))
            [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
            TextOutput1 = [OperationTime ' - Note: Line width and shift calculations are performed on the real part of MR spectra.'];
            TextOutput2 = [OperationTime ' - Note: Ensure that MR spectra are properly phased (Auto Phasing, Linear Prediction).'];
            disp(' '); disp(TextOutput1); disp(TextOutput2);
            
            handles.LWmapTmp = zeros(handles.np2,handles.np3);
            handles.LSmap = zeros(handles.np2,handles.np3);
            for c1 = 1:1:handles.np2;
                for c2 = 1:1:handles.np3;
                    if (handles.InclusionMap(round(handles.sp1),c1,c2) > 0)
                        if (handles.BC < 1)
                            % No baseline correction
                            [PeakHeight,PeakFreq] = max(real(handles.spec3D(rpoint(1):1:rpoint(2),round(handles.sp1),c1,c2)));
                        else
                            % Baseline correction
                            [PeakHeight,PeakFreq] = max(real(handles.spec3D(rpoint(2):1:rpoint(3),round(handles.sp1),c1,c2)));
                        end;
                        handles.LWmapTmp(c1,c2) = PeakHeight;
                        handles.LSmap(c1,c2) = PeakFreq;
                    end;
                end;
            end;
            
            coor1 = find(squeeze(handles.InclusionMap(round(handles.sp1),:,:)) > 0);
            coor2 = find(squeeze(handles.InclusionMap(round(handles.sp1),:,:)) < 1);
            
            handles.LWmap = zeros(handles.np2,handles.np3);
            for c1 = 1:1:handles.np2;
                for c2 = 1:1:handles.np3;
                    if (handles.InclusionMap(round(handles.sp1),c1,c2) > 0)
                        if (handles.BC < 1)
                            % No baseline correction
                            FreqPos1 = handles.LSmap(c1,c2) + rpoint(1);
                            while (real(handles.spec3D(FreqPos1,round(handles.sp1),c1,c2)) > 0.5*handles.LWmapTmp(c1,c2));
                                FreqPos1 = FreqPos1 - 1;
                            end;

                            FreqPos2 = handles.LSmap(c1,c2) + rpoint(1);
                            while (real(handles.spec3D(FreqPos2,round(handles.sp1),c1,c2)) > 0.5*handles.LWmapTmp(c1,c2));
                                FreqPos2 = FreqPos2 + 1;
                            end;
                        else
                            % Baseline correction
                            FreqPos1 = handles.LSmap(c1,c2) + rpoint(2);
                            while (real(handles.spec3D(FreqPos1,round(handles.sp1),c1,c2)) > 0.5*handles.LWmapTmp(c1,c2));
                                FreqPos1 = FreqPos1 - 1;
                            end;

                            FreqPos2 = handles.LSmap(c1,c2) + rpoint(2);
                            while (real(handles.spec3D(FreqPos2,round(handles.sp1),c1,c2)) > 0.5*handles.LWmapTmp(c1,c2));
                                FreqPos2 = FreqPos2 + 1;
                            end;
                        end;
                        
                        handles.LWmap(c1,c2) = abs(FreqPos2 - FreqPos1)*1000*(handles.sw/handles.npzf);
                    end;
                end;
            end;
            clear handles.LWmapTmp;
            
            % Convert line shift (in pixels) to line shift (in Hz)
            if (handles.BC < 1)
                % No baseline correction
                handles.LSmap = 1000*rfreq(1) + handles.LSmap*1000*(handles.sw/handles.npzf);
            else
                % Baseline correction
                handles.LSmap = 1000*rfreq(2) + handles.LSmap*1000*(handles.sw/handles.npzf);                
            end;
            handles.LSmap(coor2) = 0;
            
            if (handles.LWDisplay > 0)
                fh = figure;
                nn = ['Sagital line width map (slice ' num2str(round(handles.sp1)) ' out of ' num2str(handles.np1) ...
                    '), digital resolution = ' num2str(1000*(handles.sw/handles.npzf),2) ' Hz per point'];
                set(fh,'Name',nn);
                imshow(handles.LWmap,[0.0 max(handles.LWmap(coor1))],'InitialMagnification','fit');
                colorbar('vert'); colormap(jet);
                axis('off');
                
                % Write linewidth map to disk
                [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
                coor = find(handles.InclusionMap(round(handles.sp1),:,:) > 0);
                TextOutput1 = [OperationTime ' - Average line width = ' num2str(mean(handles.LWmap(coor)),3) ' +/- ' num2str(std(handles.LWmap(coor)),3) ' Hz'];
                disp(' '); disp(TextOutput1);
                DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
                
                [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
                OperationTime = [OperationTime(1:2) OperationTime(4:5) OperationTime(7:8)];
                handles.OutputFileName = ['LWmap_' num2str(handles.np2) 'x' num2str(handles.np3) ...
                    '_Xslice' num2str(handles.sp1) '_' handles.MapID];
                handles.MMStyle = 'line width';
                DMIWizard_MRSI_WriteMetabolicMap(handles.LWmap,handles);
                
                % Display fitted sagital metabolic linewidth map - if available
                if (max(handles.FittedMetabolicLWmap(:)) > 0)
                    fh = figure;
                    nn = ['Fitted sagital line width map (slice ' num2str(round(handles.sp1)) ' out of ' num2str(handles.np1) ')'];
                    set(fh,'Name',nn);
                    imshow(squeeze(handles.FittedMetabolicLWmap(handles.sp1,:,:)),[],'InitialMagnification','fit')
                    colormap(jet); axis('off'); colorbar('vert');     
                end;
            end;
            
            if (handles.LSDisplay > 0)
                fh = figure;
                nn = ['Sagital line shift map (slice ' num2str(round(handles.sp1)) ' out of ' num2str(handles.np1) ...
                    '), digital resolution = ' num2str(1000*(handles.sw/handles.npzf),2) ' Hz per point'];
                set(fh,'Name',nn);
                maxLS = max(handles.LSmap(coor1)); minLS =  min(handles.LSmap(coor1)); deltaLS = maxLS - minLS;
                imshow(handles.LSmap,[minLS-0.1*deltaLS maxLS+0.1*deltaLS],'InitialMagnification','fit');
                colorbar('vert'); colormap(jet);
                axis('off');
                
                % Write lineshift map to disk
                [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
                coor = find(handles.InclusionMap(round(handles.sp1),:,:) > 0);
                TextOutput1 = [OperationTime ' - Average line shift = ' num2str(mean(handles.LSmap(coor)),3) ' +/- ' num2str(std(handles.LSmap(coor)),3) ' Hz'];
                disp(' '); disp(TextOutput1);
                DMIWizard_WriteProcessHistory(handles.ProcessingHistoryFile,'a',TextOutput1);
                
                [OperationTime,~] = DMIWizard_MRSI_CalculateTime;
                OperationTime = [OperationTime(1:2) OperationTime(4:5) OperationTime(7:8)];
                handles.OutputFileName = ['LSmap_' num2str(handles.np2) 'x' num2str(handles.np3) ...
                    '_Xslice' num2str(handles.sp1) '_' handles.MapID];
                handles.MMStyle = 'line shift';
                DMIWizard_MRSI_WriteMetabolicMap(handles.LSmap,handles);
                
                % Display fitted sagital metabolic lineshift map - if available
                if (max(handles.FittedMetabolicLSmap(:)) > 0)
                    fh = figure;
                    nn = ['Fitted sagital line shift map relative to basisset (slice ' num2str(round(handles.sp1)) ' out of ' num2str(handles.np1) ')'];
                    set(fh,'Name',nn);
                    imshow(squeeze(handles.FittedMetabolicLSmap(handles.sp1,:,:)),[],'InitialMagnification','fit')
                    colormap(jet); axis('off'); colorbar('vert');     
                end;
            end;
        end;
end;