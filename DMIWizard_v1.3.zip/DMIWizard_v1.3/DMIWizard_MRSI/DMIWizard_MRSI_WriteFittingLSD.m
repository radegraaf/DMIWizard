function DMIWizard_MRSI_WriteFittingLSD(handles)

%**************************************************************************
% DMIWizard_MRSI_WriteFittingLSD.m
%
% Write spectral fitting lineshape distortion results to disk.
%**************************************************************************

% Extract directory for saving purposes
if ismac
    % Mac plaform
    coor = find(handles.MRSIPath == '/');
elseif isunix
    % Linux plaform
    coor = find(handles.MRSIPath == '/');
elseif ispc
    % Windows platform
    coor = find(handles.MRSIPath == '\');
end               
MRSIPathDir = handles.MRSIPath(1:max(coor));

% Generate index matrix for position
[pos1,pos2,pos3] = ndgrid(1:handles.np1,1:handles.np2,1:handles.np3);

FittingResults = [reshape(pos1,1,[]); reshape(pos2,1,[]); reshape(pos3,1,[])]; 
for c1 = 1:3*handles.MaxLSD;
    FittingResults = [FittingResults; reshape(handles.LCMFit.LSD(c1,:,:,:),1,[])];
end;

file = [MRSIPathDir '\FittingResultsLSD.txt'];
fileID = fopen(file,'w+');
fprintf(fileID,'%2.0f   %2.0f   %2.0f   %9.8f   %9.8f   %9.8f   %9.8f   %9.8f   %9.8f   %9.8f   %9.8f   %9.8f\n',FittingResults);
fclose(fileID);