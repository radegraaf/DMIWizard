function DMIWizard_MRSI_WriteFittingResults(handles)

%**************************************************************************
% DMIWizard_MRSI_WriteFittingResults.m
%
% Write spectral fitting results to disk (fitting parameters are saved
% in a separate file).
%**************************************************************************

% Extract directory for saving purposes
if ismac
    % Mac plaform
    coor = find(handles.MRSIPath == '/');
elseif isunix
    % Linux plaform
    coor = find(handles.MRSIPath == '/');
elseif ispc
    % Windows platform
    coor = find(handles.MRSIPath == '\');
end               
MRSIPathDir = handles.MRSIPath(1:max(coor));

% Generate index matrix for compound number and position
[res,pos1,pos2,pos3] = ndgrid(1:handles.nres,1:handles.np1,1:handles.np2,1:handles.np3);
            
% Main fitting results (amplitude, line width, line shift)
FittingResults = [reshape(res,1,[]); reshape(pos1,1,[]); reshape(pos2,1,[]); reshape(pos3,1,[])];
FittingResults = [FittingResults; reshape(handles.LCMFit.M0,1,[])];
FittingResults = [FittingResults; reshape(handles.LCMFit.LineShift,1,[])];
FittingResults = [FittingResults; reshape(handles.LCMFit.LineWidth,1,[])];

file = [MRSIPathDir '\FittingResultsMain.txt'];
fileID = fopen(file,'w+');
fprintf(fileID,'%2.0f   %2.0f   %2.0f   %2.0f   %10.7f  %10.7f  %10.7f\n',FittingResults);
fclose(fileID);

[OperationTime,~] = DMIWizard_MRSI_CalculateTime;
TextOutput1 = [OperationTime ' - Main fitting results written to: ' file];
disp(' '); disp(TextOutput1);

% Phase fitting
% Generate index matrix for position
[pos1,pos2,pos3] = ndgrid(1:handles.np1,1:handles.np2,1:handles.np3);

FittingResults = [reshape(pos1,1,[]); reshape(pos2,1,[]); reshape(pos3,1,[])];
FittingResults = [FittingResults; reshape(handles.LCMFit.Phase(1,:,:,:),1,[])];  % Zero-order phase
FittingResults = [FittingResults; reshape(handles.LCMFit.Phase(2,:,:,:),1,[])];  % First-order phase

file = [MRSIPathDir '\FittingResultsPhase.txt'];
fileID = fopen(file,'w+');
fprintf(fileID,'%2.0f   %2.0f   %2.0f   %6.3f   %6.3f\n',FittingResults);
fclose(fileID);

[OperationTime,~] = DMIWizard_MRSI_CalculateTime;
TextOutput1 = [OperationTime ' - Phase-related fitting results written to: ' file];
disp(TextOutput1);